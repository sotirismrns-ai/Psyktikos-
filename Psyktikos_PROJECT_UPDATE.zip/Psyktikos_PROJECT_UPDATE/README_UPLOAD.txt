Psyktikos update project

Upload/replace the files in this ZIP in the repository root.
IMPORTANT: keep the existing KEYSTORE_BASE64-1.txt in the repository.
IMPORTANT: keep the GitHub Secret KEYSTORE_PASSWORD unchanged.
Workflow path: .github/workflows/build-apk.yml
