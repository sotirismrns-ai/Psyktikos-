# Psyktikos v1.0 FINAL

This project contains the complete Android project with the requested final changes:

1. Functional left back arrow in the Faultology navigation.
2. Faultology navigation: Brands -> Machine Type -> Model/Series -> Faults -> Diagnostic Specs.

The GitHub Actions workflow is ready at `.github/workflows/build-apk.yml` and builds the release APK directly from the Android project.
