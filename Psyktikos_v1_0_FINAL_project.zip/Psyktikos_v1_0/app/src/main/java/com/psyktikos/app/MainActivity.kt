package com.psyktikos.app

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private var pendingPhotoKey = ""
    private var pendingPhotoCategory = ""
    private val PHOTO_PICKER = 8108
    private val BACKUP_EXPORT = 9101
    private val BACKUP_IMPORT = 9102

    private val blue = Color.rgb(18, 92, 160)
    private val bg = Color.rgb(242, 246, 250)
    private val prefs by lazy { getSharedPreferences("psyktikos_data", Context.MODE_PRIVATE) }

    data class Customer(val id: Long, val name: String, val phone: String, val address: String, val notes: String)
    data class Machine(val id: Long, val customerId: Long, val brand: String, val model: String, val serial: String, val refrigerant: String, val capacity: String, val type: String, val year: String, val address: String, val notes: String)
    data class Job(val id: Long, val customerId: Long, val machineId: Long, val date: String, val type: String, val symptom: String, val faultCode: String, val diagnosis: String, val action: String, val suction: String, val discharge: String, val suctionTemp: String, val liquidTemp: String, val roomTemp: String, val outletTemp: String, val superheat: String, val subcooling: String, val materials: String, val materialCost: String, val laborHours: String, val laborRate: String, val total: String, val checklist: String, val photos: String, val notes: String, val status: String)
    data class Note(val id: Long, val title: String, val text: String)

    data class Fault(val brand: String, val code: String, val meaning: String, val causes: String, val checks: String)
    private val faults = listOf(
        Fault("Daikin", "U4", "Σφάλμα επικοινωνίας εσωτερικής–εξωτερικής μονάδας", "Καλωδίωση, τροφοδοσία, πλακέτα, επικοινωνία", "Έλεγξε καλωδίωση, ακροδέκτες, τάσεις, πλακέτες και συνδέσεις."),
        Fault("Daikin", "A5", "Προστασία κατά της ψύξης/πάγου στον εναλλάκτη", "Μειωμένη ροή αέρα, φίλτρα, αισθητήρας, συνθήκες λειτουργίας", "Έλεγξε φίλτρα, εναλλάκτη, ανεμιστήρα, αισθητήρες και ψυκτικό κύκλωμα."),
        Fault("Mitsubishi Electric", "P8", "Ανωμαλία θερμοκρασίας σωλήνα", "Αισθητήρας, φόρτιση, ροή ψυκτικού, συνθήκες λειτουργίας", "Έλεγξε αισθητήρα, σωληνώσεις, πιέσεις και θερμοκρασίες."),
        Fault("Gree", "E6", "Σφάλμα επικοινωνίας", "Καλωδίωση ή πλακέτες", "Έλεγξε καλωδίωση επικοινωνίας, τροφοδοσία και πλακέτες."),
        Fault("Γενικό", "NO COOL", "Το κλιματιστικό λειτουργεί αλλά δεν αποδίδει στην ψύξη", "Έλλειψη ψυκτικού, βρώμικοι εναλλάκτες/φίλτρα, ανεμιστήρας, εκτονωτικό, αισθητήρες, συμπιεστής", "Μέτρησε θερμοκρασίες, πιέσεις, superheat/subcooling και έλεγξε ροή αέρα πριν συμπεράνεις έλλειψη ψυκτικού.")
    )

    override fun onCreate(state: Bundle?) { super.onCreate(state); home() }

    private fun base(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 28, 22, 18); setBackgroundColor(bg) }
    private fun title(text: String, size: Float = 25f) = TextView(this).apply { this.text = text; textSize = size; setTextColor(blue); setPadding(0,0,0,10) }
    private fun button(text: String, action: () -> Unit) = Button(this).apply { this.text=text; isAllCaps=false; textSize=16f; setOnClickListener{action()} }
    private fun input(hint: String) = EditText(this).apply { this.hint=hint; textSize=16f; setPadding(14,10,14,10) }
    private fun card(text: String, action: (() -> Unit)? = null) = TextView(this).apply { this.text=text; textSize=16f; setPadding(16,16,16,16); background=GradientDrawable().apply{setColor(Color.WHITE);cornerRadius=20f}; if(action!=null)setOnClickListener{action()} }
    private fun scroll(list: View): ScrollView = ScrollView(this).apply { addView(list) }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
    private fun jsonArray(key:String)=JSONArray(prefs.getString(key,"[]"))

    private fun home() {
        val r=base(); r.addView(title("🔧  ΨΥΚΤΙΚΟΣ",29f)); r.addView(TextView(this).apply{text="Επαγγελματικό εργαλείο ψυκτικού • v1.0 FINAL";textSize=15f;setPadding(0,0,0,10)})
        val c=customers().size; val m=machines().size; val j=jobs().count{it.status!="Ολοκληρώθηκε"}
        r.addView(card("👥 Πελάτες: $c     ❄️ Μηχανήματα: $m     🛠️ Εκκρεμείς: $j"))
        r.addView(button("🔎  ΑΝΑΖΗΤΗΣΗ ΟΛΗΣ ΤΗΣ ΕΦΑΡΜΟΓΗΣ"){searchScreen()}); r.addView(button("⚠️  ΒΛΑΒΟΛΟΓΙΟ 2.0"){faultsScreen()}); r.addView(button("👥  ΠΕΛΑΤΟΛΟΓΙΟ"){customersScreen()}); r.addView(button("❄️  ΜΗΧΑΝΗΜΑΤΑ"){machinesScreen(null)}); r.addView(button("📅  ΕΡΓΑΣΙΕΣ / ΙΣΤΟΡΙΚΟ"){jobsScreen()}); r.addView(button("🧮  ΕΡΓΑΛΕΙΑ ΨΥΚΤΙΚΟΥ"){toolsScreen()}); r.addView(button("📋  CHECKLISTS"){checklistScreen()}); r.addView(button("🤖  AI ΨΥΚΤΙΚΟΥ"){aiScreen()}); r.addView(button("📚  ΤΕΧΝΙΚΗ ΒΙΒΛΙΟΘΗΚΗ"){techScreen()}); r.addView(button("📝  ΣΗΜΕΙΩΣΕΙΣ"){notesScreen()}); r.addView(button("📦  ΥΛΙΚΑ / ΑΠΟΘΗΚΗ"){materialsScreen()}); r.addView(button("💾  BACKUP / ΕΠΑΝΑΦΟΡΑ"){backupScreen()}); setContentView(r)
    }

    private fun customers():MutableList<Customer>{ val a=jsonArray("customers"); return MutableList(a.length()){i->val o=a.getJSONObject(i);Customer(o.getLong("id"),o.optString("name"),o.optString("phone"),o.optString("address"),o.optString("notes"))} }
    private fun saveCustomers(x:List<Customer>){val a=JSONArray();x.forEach{a.put(JSONObject().apply{put("id",it.id);put("name",it.name);put("phone",it.phone);put("address",it.address);put("notes",it.notes)})};prefs.edit().putString("customers",a.toString()).apply()}
    private fun machines():MutableList<Machine>{val a=jsonArray("machines");return MutableList(a.length()){i->val o=a.getJSONObject(i);Machine(o.getLong("id"),o.getLong("customerId"),o.optString("brand"),o.optString("model"),o.optString("serial"),o.optString("refrigerant"),o.optString("capacity"),o.optString("type"),o.optString("year"),o.optString("address"),o.optString("notes"))}}
    private fun saveMachines(x:List<Machine>){val a=JSONArray();x.forEach{a.put(JSONObject().apply{put("id",it.id);put("customerId",it.customerId);put("brand",it.brand);put("model",it.model);put("serial",it.serial);put("refrigerant",it.refrigerant);put("capacity",it.capacity);put("type",it.type);put("year",it.year);put("address",it.address);put("notes",it.notes)})};prefs.edit().putString("machines",a.toString()).apply()}
    private fun jobs():MutableList<Job>{val a=jsonArray("jobs");return MutableList(a.length()){i->val o=a.getJSONObject(i);Job(o.getLong("id"),o.optLong("customerId"),o.optLong("machineId"),o.optString("date"),o.optString("type"),o.optString("symptom"),o.optString("faultCode"),o.optString("diagnosis"),o.optString("action"),o.optString("suction"),o.optString("discharge"),o.optString("suctionTemp"),o.optString("liquidTemp"),o.optString("roomTemp"),o.optString("outletTemp"),o.optString("superheat"),o.optString("subcooling"),o.optString("materials"),o.optString("materialCost"),o.optString("laborHours"),o.optString("laborRate"),o.optString("total"),o.optString("checklist"),o.optString("photos"),o.optString("notes"),o.optString("status"))}}
    private fun saveJobs(x:List<Job>){val a=JSONArray();x.forEach{j->a.put(JSONObject().apply{put("id",j.id);put("customerId",j.customerId);put("machineId",j.machineId);put("date",j.date);put("type",j.type);put("symptom",j.symptom);put("faultCode",j.faultCode);put("diagnosis",j.diagnosis);put("action",j.action);put("suction",j.suction);put("discharge",j.discharge);put("suctionTemp",j.suctionTemp);put("liquidTemp",j.liquidTemp);put("roomTemp",j.roomTemp);put("outletTemp",j.outletTemp);put("superheat",j.superheat);put("subcooling",j.subcooling);put("materials",j.materials);put("materialCost",j.materialCost);put("laborHours",j.laborHours);put("laborRate",j.laborRate);put("total",j.total);put("checklist",j.checklist);put("photos",j.photos);put("notes",j.notes);put("status",j.status)})};prefs.edit().putString("jobs",a.toString()).apply()}

    private fun photoArray(key:String): JSONArray = JSONArray(prefs.getString(key,"[]"))
    private fun addPhotoRecord(key:String, category:String, uri:String){
        val a=photoArray(key)
        a.put(JSONObject().apply{put("category",category);put("uri",uri);put("time",System.currentTimeMillis())})
        prefs.edit().putString(key,a.toString()).apply()
    }
    private fun photoKey(owner:String,id:Long)="photos_${owner}_${id}"
    private fun choosePhoto(owner:String,id:Long,category:String){
        pendingPhotoKey=photoKey(owner,id); pendingPhotoCategory=category
        val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="image/*";putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);addCategory(Intent.CATEGORY_OPENABLE)}
        startActivityForResult(i,PHOTO_PICKER)
    }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==BACKUP_EXPORT && resultCode==RESULT_OK && data?.data!=null){
            try {
                contentResolver.openOutputStream(data.data!!)?.use { it.write(backupJson().toString(2).toByteArray(Charsets.UTF_8)) }
                toast("Το backup αποθηκεύτηκε επιτυχώς.")
            } catch(e:Exception) { toast("Αποτυχία αποθήκευσης backup: ${e.message}") }
            return
        }
        if(requestCode==BACKUP_IMPORT && resultCode==RESULT_OK && data?.data!=null){
            try {
                val text=contentResolver.openInputStream(data.data!!)?.bufferedReader()?.use{it.readText()} ?: ""
                val root=JSONObject(text)
                val keys=listOf("customers","machines","jobs","notes","materials")
                val edit=prefs.edit()
                keys.forEach { k -> if(root.has(k)) edit.putString(k, root.getJSONArray(k).toString()) }
                edit.apply(); toast("Η επαναφορά ολοκληρώθηκε."); home()
            } catch(e:Exception) { toast("Μη έγκυρο backup JSON: ${e.message}") }
            return
        }
        if(requestCode==PHOTO_PICKER && resultCode==RESULT_OK && data!=null){
            val clip=data.clipData
            if(clip!=null){for(i in 0 until clip.itemCount)addPhotoRecord(pendingPhotoKey,pendingPhotoCategory,clip.getItemAt(i).uri.toString())}
            else data.data?.let{addPhotoRecord(pendingPhotoKey,pendingPhotoCategory,it.toString())}
            try{data.data?.let{contentResolver.takePersistableUriPermission(it,Intent.FLAG_GRANT_READ_URI_PERMISSION)}}catch(_:Exception){}
            toast("Η φωτογραφία προστέθηκε.")
            if(pendingPhotoKey.startsWith("photos_job_")) jobEditor(jobs().firstOrNull{it.id==pendingPhotoKey.substringAfterLast('_').toLongOrNull()})
            else if(pendingPhotoKey.startsWith("photos_machine_")) machineEditor(machines().firstOrNull{it.id==pendingPhotoKey.substringAfterLast('_').toLongOrNull()})
        }
    }
    private fun photoGallery(parent:LinearLayout,key:String){
        val a=photoArray(key)
        if(a.length()==0){parent.addView(card("📷 Δεν υπάρχουν φωτογραφίες ακόμη."));return}
        for(i in 0 until a.length()){
            val o=a.getJSONObject(i); val uri=Uri.parse(o.optString("uri")); val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
            row.addView(TextView(this).apply{text="📷 ${o.optString("category","Φωτογραφία")}";textSize=14f;setTextColor(blue);setPadding(0,8,0,4)})
            val image=ImageView(this).apply{layoutParams=LinearLayout.LayoutParams(-1,220);scaleType=ImageView.ScaleType.CENTER_CROP;try{setImageURI(uri)}catch(_:Exception){}}
            row.addView(image);parent.addView(row)
        }
    }
    private fun searchScreen(){
        val r=base();r.addView(title("🔎 Αναζήτηση"));val q=input("Όνομα, τηλέφωνο, μοντέλο, Serial, κωδικός, εργασία, υλικό...");val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        fun render(){
            list.removeAllViews(); val term=q.text.toString().trim(); if(term.isBlank()){list.addView(card("Πληκτρολόγησε κάτι για αναζήτηση σε όλη την εφαρμογή."));return}
            customers().filter{"${it.name} ${it.phone} ${it.address} ${it.notes}".contains(term,true)}.forEach{list.addView(card("👤 ${it.name}\n📞 ${it.phone}\n📍 ${it.address}"){customerEditor(it)})}
            machines().filter{"${it.brand} ${it.model} ${it.serial} ${it.refrigerant} ${it.type} ${it.address} ${it.notes}".contains(term,true)}.forEach{list.addView(card("❄️ ${it.brand} ${it.model}\nSerial: ${it.serial}\nΨυκτικό: ${it.refrigerant}"){machineEditor(it)})}
            jobs().filter{"${it.date} ${it.type} ${it.symptom} ${it.faultCode} ${it.diagnosis} ${it.action} ${it.notes}".contains(term,true)}.forEach{list.addView(card("🛠️ ${it.date} • ${it.type}\n${it.symptom}\n${it.diagnosis}"){jobEditor(it)})}
            materialList().filter{"${it.name} ${it.code} ${it.notes}".contains(term,true)}.forEach{list.addView(card("📦 ${it.name}\nΚωδικός: ${it.code}\nΠοσότητα: ${it.qty}"){materialEditor(it)})}
            faults.filter{"${it.brand} ${it.code} ${it.meaning} ${it.causes} ${it.checks}".contains(term,true)}.forEach{list.addView(card("⚠️ ${it.brand} ${it.code}\n${it.meaning}"))}
            if(list.childCount==0)list.addView(card("Δεν βρέθηκαν αποτελέσματα."))
        }
        q.setOnKeyListener{_,_,_->render();false}; q.addTextChangedListener(object:android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){render()};override fun afterTextChanged(e:android.text.Editable?){}})
        r.addView(q);r.addView(scroll(list),LinearLayout.LayoutParams(-1,0,1f));r.addView(button("← Πίσω"){home()});setContentView(r)
    }

    private fun customersScreen(){val r=base();r.addView(title("👥 Πελατολόγιο"));val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};val data=customers();if(data.isEmpty())list.addView(card("Δεν υπάρχουν πελάτες ακόμα."));data.forEach{c->list.addView(card("👤 ${c.name}\n📞 ${c.phone}\n📍 ${c.address}\n${c.notes}"){customerEditor(c)})};r.addView(scroll(list),LinearLayout.LayoutParams(-1,0,1f));r.addView(button("＋ Νέος πελάτης"){customerEditor(null)});r.addView(button("← Πίσω"){home()});setContentView(r)}
    private fun customerEditor(e:Customer?){val r=base();r.addView(title(if(e==null)"＋ Νέος πελάτης" else "✏️ Πελάτης"));val n=input("Όνομα / Επωνυμία");val p=input("Τηλέφωνο");val a=input("Διεύθυνση");val no=input("Σημειώσεις");if(e!=null){n.setText(e.name);p.setText(e.phone);a.setText(e.address);no.setText(e.notes)};listOf(n,p,a,no).forEach{r.addView(it)};r.addView(button("💾 Αποθήκευση"){if(n.text.isBlank()){toast("Συμπλήρωσε όνομα.");return@button};val d=customers();val id=e?.id?:System.currentTimeMillis();val x=Customer(id,n.text.toString().trim(),p.text.toString().trim(),a.text.toString().trim(),no.text.toString().trim());val i=d.indexOfFirst{it.id==id};if(i>=0)d[i]=x else d.add(x);saveCustomers(d);customersScreen()});if(e!=null)r.addView(button("🗑 Διαγραφή"){saveCustomers(customers().filter{it.id!=e.id});saveMachines(machines().filter{it.customerId!=e.id});customersScreen()});r.addView(button("❄️ Μηχανήματα πελάτη"){machinesScreen(e.id)});r.addView(button("← Πίσω"){customersScreen()});setContentView(r)}

    private fun machinesScreen(customerId:Long?){val r=base();r.addView(title("❄️ Μηχανήματα"));val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};val all=machines().filter{customerId==null||it.customerId==customerId};if(all.isEmpty())list.addView(card("Δεν υπάρχουν μηχανήματα."));all.forEach{m->val c=customers().firstOrNull{it.id==m.customerId};list.addView(card("❄️ ${m.brand} ${m.model}\nSerial: ${m.serial}\nΨυκτικό: ${m.refrigerant} • ${m.capacity}\n👤 ${c?.name?:"Χωρίς πελάτη"}\n📍 ${m.address}"){machineEditor(m)})};r.addView(scroll(list),LinearLayout.LayoutParams(-1,0,1f));r.addView(button("＋ Νέο μηχάνημα"){machineEditor(null,customerId)});r.addView(button("← Πίσω"){if(customerId!=null)customersScreen() else home()});setContentView(r)}
    private fun machineEditor(e:Machine?, preCustomer:Long?=null){
        val r=base();r.addView(title(if(e==null)"＋ Νέο μηχάνημα" else "✏️ Μηχάνημα"));val c=input("Customer ID (προσωρινά)"),brand=input("Μάρκα"),model=input("Μοντέλο"),serial=input("Serial Number"),ref=input("Ψυκτικό μέσο"),cap=input("BTU / kW"),type=input("Τύπος μηχανήματος"),year=input("Έτος εγκατάστασης"),addr=input("Διεύθυνση εγκατάστασης"),no=input("Παρατηρήσεις");
        if(e!=null){c.setText(e.customerId.toString());brand.setText(e.brand);model.setText(e.model);serial.setText(e.serial);ref.setText(e.refrigerant);cap.setText(e.capacity);type.setText(e.type);year.setText(e.year);addr.setText(e.address);no.setText(e.notes)}else if(preCustomer!=null)c.setText(preCustomer.toString())
        listOf(c,brand,model,serial,ref,cap,type,year,addr,no).forEach{r.addView(it)}
        val id=e?.id?:System.currentTimeMillis()
        r.addView(button("📷 Προσθήκη φωτογραφίας μηχανήματος"){choosePhoto("machine",id,"Μηχάνημα")})
        val gallery=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};photoGallery(gallery,photoKey("machine",id));r.addView(gallery)
        r.addView(button("💾 Αποθήκευση"){val cid=c.text.toString().toLongOrNull();if(cid==null){toast("Βάλε Customer ID. Από την καρτέλα πελάτη συμπληρώνεται αυτόματα.");return@button};val d=machines();val x=Machine(id,cid,brand.text.toString(),model.text.toString(),serial.text.toString(),ref.text.toString(),cap.text.toString(),type.text.toString(),year.text.toString(),addr.text.toString(),no.text.toString());val i=d.indexOfFirst{it.id==id};if(i>=0)d[i]=x else d.add(x);saveMachines(d);machineEditor(x)})
        if(e!=null){r.addView(button("🛠️ Νέα εργασία"){jobEditor(null,e.customerId,e.id)});r.addView(button("📜 Ιστορικό μηχανήματος"){machineHistory(e.id)});r.addView(button("🗑 Διαγραφή"){saveMachines(machines().filter{it.id!=e.id});machinesScreen(preCustomer)})};r.addView(button("← Πίσω"){machinesScreen(preCustomer)});setContentView(r)
    }
    private fun machineHistory(mid:Long){val r=base();val m=machines().firstOrNull{it.id==mid};r.addView(title("📜 Ιστορικό μηχανήματος"));r.addView(card("${m?.brand} ${m?.model}\nSerial: ${m?.serial}\nΨυκτικό: ${m?.refrigerant}"));val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};jobs().filter{it.machineId==mid}.forEach{j->list.addView(card("${j.date} • ${j.type}\n${j.symptom}\n🔎 ${j.diagnosis}\n💶 ${j.total}"){jobEditor(j)})};r.addView(scroll(list),LinearLayout.LayoutParams(-1,0,1f));r.addView(button("＋ Νέα εργασία"){jobEditor(null,m?.customerId?:0L,mid)});r.addView(button("← Πίσω"){machineEditor(m)});setContentView(r)}

    private fun jobEditor(e:Job?, preCustomer:Long?=null, preMachine:Long?=null){
        val r=base();r.addView(title(if(e==null)"＋ Νέα εργασία" else "✏️ Εργασία"));fun f(h:String)=input(h);val cid=f("Customer ID"),mid=f("Machine ID"),date=f("Ημερομηνία / ώρα"),type=f("Είδος: Service / Επισκευή / Εγκατάσταση / Διάγνωση"),sym=f("Σύμπτωμα"),code=f("Κωδικός βλάβης"),diag=f("Διάγνωση"),action=f("Εργασία που έγινε"),suc=f("Πίεση αναρρόφησης"),dis=f("Πίεση κατάθλιψης"),st=f("Θερμοκρασία αναρρόφησης"),lt=f("Θερμοκρασία υγρού"),room=f("Θερμοκρασία χώρου"),out=f("Θερμοκρασία εξόδου"),sh=f("Superheat"),sc=f("Subcooling"),mat=f("Υλικά / ανταλλακτικά"),mc=f("Κόστος υλικών €"),lh=f("Ώρες εργατικών"),lr=f("Τιμή/ώρα €"),total=f("Σύνολο €"),notes=f("Σημειώσεις");
        if(e!=null){cid.setText(e.customerId.toString());mid.setText(e.machineId.toString());date.setText(e.date);type.setText(e.type);sym.setText(e.symptom);code.setText(e.faultCode);diag.setText(e.diagnosis);action.setText(e.action);suc.setText(e.suction);dis.setText(e.discharge);st.setText(e.suctionTemp);lt.setText(e.liquidTemp);room.setText(e.roomTemp);out.setText(e.outletTemp);sh.setText(e.superheat);sc.setText(e.subcooling);mat.setText(e.materials);mc.setText(e.materialCost);lh.setText(e.laborHours);lr.setText(e.laborRate);total.setText(e.total);notes.setText(e.notes)}else{preCustomer?.let{cid.setText(it.toString())};preMachine?.let{mid.setText(it.toString())}}
        listOf(cid,mid,date,type,sym,code,diag,action,suc,dis,st,lt,room,out,sh,sc,mat,mc,lh,lr,total,notes).forEach{r.addView(it)}
        val id=e?.id?:System.currentTimeMillis(); val key=photoKey("job",id)
        r.addView(button("📷 Φωτογραφία ΠΡΙΝ"){choosePhoto("job",id,"Πριν")});r.addView(button("📷 Φωτογραφία ΚΑΤΑ"){choosePhoto("job",id,"Κατά")});r.addView(button("📷 Φωτογραφία ΜΕΤΑ"){choosePhoto("job",id,"Μετά")})
        val gallery=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};photoGallery(gallery,key);r.addView(gallery)
        r.addView(button("📋 Checklist"){if(e==null){toast("Αποθήκευσε πρώτα την εργασία για να κρατηθεί το checklist.")}else checklistForJob(e.id)})
        r.addView(button("💾 Αποθήκευση"){val d=jobs();val x=Job(id,cid.text.toString().toLongOrNull()?:0L,mid.text.toString().toLongOrNull()?:0L,date.text.toString(),type.text.toString(),sym.text.toString(),code.text.toString(),diag.text.toString(),action.text.toString(),suc.text.toString(),dis.text.toString(),st.text.toString(),lt.text.toString(),room.text.toString(),out.text.toString(),sh.text.toString(),sc.text.toString(),mat.text.toString(),mc.text.toString(),lh.text.toString(),lr.text.toString(),total.text.toString(),"",photoArray(key).toString(),notes.text.toString(),e?.status?:"Εκκρεμεί");val i=d.indexOfFirst{it.id==id};if(i>=0)d[i]=x else d.add(x);saveJobs(d);toast("Η εργασία αποθηκεύτηκε.");if(x.machineId!=0L)machineHistory(x.machineId)else jobsScreen()});
        if(e!=null){r.addView(button(if(e.status=="Ολοκληρώθηκε")"↩ Εκκρεμής" else "✅ Ολοκληρώθηκε"){val d=jobs();val i=d.indexOfFirst{it.id==e.id};if(i>=0)d[i]=d[i].copy(status=if(e.status=="Ολοκληρώθηκε")"Εκκρεμεί" else "Ολοκληρώθηκε");saveJobs(d);jobEditor(d[i])});r.addView(button("🗑 Διαγραφή"){saveJobs(jobs().filter{it.id!=e.id});jobsScreen()})};r.addView(button("← Πίσω"){if(preMachine!=null)machineHistory(preMachine)else jobsScreen()});setContentView(r)
    }
    private fun jobsScreen(){val r=base();r.addView(title("📅 Εργασίες / Ιστορικό"));val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};jobs().sortedBy{it.status=="Ολοκληρώθηκε"}.forEach{j->val c=customers().firstOrNull{it.id==j.customerId};val m=machines().firstOrNull{it.id==j.machineId};list.addView(card("${if(j.status=="Ολοκληρώθηκε")"✅" else "🔧"} ${j.date} • ${j.type}\n👤 ${c?.name?:"Πελάτης #${j.customerId}"}\n❄️ ${m?.brand?:"Μηχάνημα"} ${m?.model?:""}\n${j.symptom}\n💶 ${j.total}"){jobEditor(j)})};r.addView(scroll(list),LinearLayout.LayoutParams(-1,0,1f));r.addView(button("＋ Νέα εργασία"){jobEditor(null)});r.addView(button("← Πίσω"){home()});setContentView(r)}

    private fun faultsScreen(){val r=base();r.addView(title("⚠️ Βλαβολόγιο 2.0"));val q=input("Κωδικός, μάρκα ή σύμπτωμα");val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};fun render(){list.removeAllViews();faults.filter{"${it.brand} ${it.code} ${it.meaning} ${it.causes} ${it.checks}".contains(q.text.toString(),true)}.forEach{f->list.addView(card("❗ ${f.brand} ${f.code}\n${f.meaning}\n\nΠιθανές αιτίες:\n${f.causes}\n\nΈλεγχοι:\n${f.checks}"))}};q.setOnKeyListener{_,_,_->render();false};render();r.addView(q);r.addView(scroll(list),LinearLayout.LayoutParams(-1,0,1f));r.addView(button("← Πίσω"){home()});setContentView(r)}

    private fun toolsScreen(){
        val r=base(); r.addView(title("🧮 Εργαλεία ψυκτικού"))
        r.addView(button("🌡️ Superheat"){calculator("Superheat = Θερμοκρασία αναρρόφησης − Θερμοκρασία κορεσμού\\n\\nΒάλε τις δύο θερμοκρασίες σε °C.","SH")})
        r.addView(button("❄️ Subcooling"){calculator("Subcooling = Θερμοκρασία κορεσμού υγρού − Θερμοκρασία υγρού\\n\\nΒάλε τις δύο θερμοκρασίες σε °C.","SC")})
        r.addView(button("📏 Πίεση bar ↔ psi"){pressureConverter()})
        r.addView(button("⚡ kW ↔ BTU/h"){powerConverter()})
        r.addView(button("🌡️ °C ↔ °F"){temperatureConverter()})
        r.addView(button("🔎 Βοήθεια διάγνωσης"){diagnosisAssistant()})
        r.addView(button("← Πίσω"){home()}); setContentView(r)
    }
    private fun resultText()=TextView(this).apply{textSize=20f;setPadding(0,18,0,18);setTextColor(blue)}
    private fun pressureConverter(){
        val r=base();r.addView(title("📏 Bar ↔ PSI"));val a=input("Τιμή");val result=resultText();r.addView(a)
        r.addView(button("bar → psi"){val x=a.text.toString().replace(',','.').toDoubleOrNull();result.text=if(x==null)"Βάλε σωστή τιμή." else "%.2f bar = %.2f psi".format(x,x*14.5037738)})
        r.addView(button("psi → bar"){val x=a.text.toString().replace(',','.').toDoubleOrNull();result.text=if(x==null)"Βάλε σωστή τιμή." else "%.2f psi = %.2f bar".format(x,x/14.5037738)})
        r.addView(result);r.addView(button("← Πίσω"){toolsScreen()});setContentView(r)
    }
    private fun powerConverter(){
        val r=base();r.addView(title("⚡ kW ↔ BTU/h"));val a=input("Τιμή");val result=resultText();r.addView(a)
        r.addView(button("kW → BTU/h"){val x=a.text.toString().replace(',','.').toDoubleOrNull();result.text=if(x==null)"Βάλε σωστή τιμή." else "%.2f kW = %.0f BTU/h".format(x,x*3412.142)})
        r.addView(button("BTU/h → kW"){val x=a.text.toString().replace(',','.').toDoubleOrNull();result.text=if(x==null)"Βάλε σωστή τιμή." else "%.0f BTU/h = %.3f kW".format(x,x/3412.142)})
        r.addView(result);r.addView(button("← Πίσω"){toolsScreen()});setContentView(r)
    }
    private fun temperatureConverter(){
        val r=base();r.addView(title("🌡️ °C ↔ °F"));val a=input("Θερμοκρασία");val result=resultText();r.addView(a)
        r.addView(button("°C → °F"){val x=a.text.toString().replace(',','.').toDoubleOrNull();result.text=if(x==null)"Βάλε σωστή τιμή." else "%.2f °C = %.2f °F".format(x,x*9/5+32)})
        r.addView(button("°F → °C"){val x=a.text.toString().replace(',','.').toDoubleOrNull();result.text=if(x==null)"Βάλε σωστή τιμή." else "%.2f °F = %.2f °C".format(x,(x-32)*5/9)})
        r.addView(result);r.addView(button("← Πίσω"){toolsScreen()});setContentView(r)
    }
    private fun diagnosisAssistant(){
        val r=base();r.addView(title("🔎 Βοήθεια διάγνωσης"));r.addView(TextView(this).apply{text="Πέρασε τα βασικά στοιχεία. Η εφαρμογή θα προτείνει κατευθύνσεις ελέγχου — όχι αυθαίρετη διάγνωση.";textSize=15f})
        val symptom=input("Σύμπτωμα");val refrigerant=input("Ψυκτικό (π.χ. R32)");val suction=input("Πίεση αναρρόφησης bar");val discharge=input("Πίεση κατάθλιψης bar");val sh=input("Superheat °C");val sc=input("Subcooling °C");val out=input("Θερμοκρασία εξόδου °C");val result=TextView(this).apply{textSize=16f;setPadding(0,12,0,12)}
        listOf(symptom,refrigerant,suction,discharge,sh,sc,out).forEach{r.addView(it)}
        r.addView(button("🧠 Ανάλυση"){val s=symptom.text.toString().lowercase();val notes=mutableListOf<String>();if(s.contains("δεν κρυ")||s.contains("δεν αποδ")||s.contains("δεν παγ"))notes.add("• Έλεγξε πρώτα ροή αέρα, καθαρότητα εναλλακτών και σωστή λειτουργία ανεμιστήρων.")
            val shv=sh.text.toString().replace(',','.').toDoubleOrNull();val scv=sc.text.toString().replace(',','.').toDoubleOrNull();if(shv!=null)notes.add("• Superheat: %.1f °C — αξιολόγησέ το σε σχέση με το συγκεκριμένο σύστημα και τις συνθήκες λειτουργίας.".format(shv));if(scv!=null)notes.add("• Subcooling: %.1f °C — αξιολόγησέ το σε σχέση με το συγκεκριμένο σύστημα και τις συνθήκες λειτουργίας.".format(scv));if(suction.text.isNotBlank()||discharge.text.isNotBlank())notes.add("• Μην κρίνεις τη φόρτιση μόνο από μία πίεση. Συνδύασε πιέσεις, θερμοκρασίες, superheat/subcooling και κατάσταση εναλλακτών.");if(notes.isEmpty())notes.add("• Συμπλήρωσε σύμπτωμα και μετρήσεις για πιο χρήσιμη κατεύθυνση ελέγχου.");result.text="Προτεινόμενη πορεία:\\n"+notes.joinToString("\\n")})
        r.addView(result);r.addView(button("← Πίσω"){toolsScreen()});setContentView(r)
    }
    private fun calculator(info:String,type:String){val r=base();r.addView(title(if(type=="SH")"🌡️ Superheat" else "❄️ Subcooling"));r.addView(TextView(this).apply{text=info;textSize=16f});val a=input(if(type=="SH")"Θερμοκρασία αναρρόφησης °C" else "Θερμοκρασία κορεσμού υγρού °C");val b=input(if(type=="SH")"Θερμοκρασία κορεσμού °C" else "Θερμοκρασία υγρού °C");val result=TextView(this).apply{textSize=20f;setPadding(0,18,0,18);setTextColor(blue)};r.addView(a);r.addView(b);r.addView(button("ΥΠΟΛΟΓΙΣΜΟΣ"){val x=a.text.toString().replace(',','.').toDoubleOrNull();val y=b.text.toString().replace(',','.').toDoubleOrNull();if(x==null||y==null){toast("Βάλε σωστές θερμοκρασίες.");return@button};val v=if(type=="SH")x-y else x-y;result.text="Αποτέλεσμα: %.1f °C".format(v)});r.addView(result);r.addView(button("← Πίσω"){toolsScreen()});setContentView(r)}

    private fun checklistScreen(){val r=base();r.addView(title("📋 Checklists"));r.addView(button("🔧 Checklist Service"){checklist("Service")});r.addView(button("❄️ Checklist Εγκατάστασης"){checklist("Εγκατάσταση")});r.addView(button("← Πίσω"){home()});setContentView(r)}
    private fun checklistForJob(jobId:Long){
        val r=base(); r.addView(title("📋 Checklist εργασίας"));
        val items=listOf("Οπτικός έλεγχος","Φίλτρα / εναλλάκτες","Αποχέτευση","Ηλεκτρικές συνδέσεις","Σωληνώσεις / μόνωση","Έλεγχος διαρροών","Πίεση αναρρόφησης","Πίεση κατάθλιψης","Superheat","Subcooling","Ρεύμα λειτουργίας","Δοκιμή ψύξης","Δοκιμή θέρμανσης","Καθαρισμός / παράδοση");
        val saved=jsonArray("checklist_$jobId"); val done=HashSet<String>(); for(i in 0 until saved.length()) done.add(saved.optString(i));
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}; val checks=mutableListOf<CheckBox>();
        items.forEach{label-> val cb=CheckBox(this).apply{text=label;textSize=16f;isChecked=done.contains(label);setPadding(4,8,4,8)}; checks.add(cb); box.addView(cb)}
        r.addView(scroll(box),LinearLayout.LayoutParams(-1,0,1f));
        r.addView(button("💾 Αποθήκευση checklist"){ val a=JSONArray(); checks.filter{it.isChecked}.forEach{a.put(it.text.toString())}; prefs.edit().putString("checklist_$jobId",a.toString()).apply(); toast("Το checklist αποθηκεύτηκε."); jobEditor(jobs().firstOrNull{it.id==jobId}) });
        r.addView(button("← Πίσω"){jobEditor(jobs().firstOrNull{it.id==jobId})}); setContentView(r)
    }
    private fun checklist(kind:String){
        val r=base(); r.addView(title("📋 $kind"))
        val key="checklist_template_${kind}"
        val items=if(kind.startsWith("Εγκατάσταση"))
            listOf("Έλεγχος θέσης εσωτερικής μονάδας","Έλεγχος θέσης εξωτερικής μονάδας","Στήριξη εσωτερικής","Στήριξη εξωτερικής","Σωληνώσεις","Μόνωση","Αποχέτευση","Καλωδίωση","Έλεγχος διαρροών","Vacuum","Έλεγχος πιέσεων","Δοκιμή ψύξης","Δοκιμή θέρμανσης","Έλεγχος αποχέτευσης","Παράδοση στον πελάτη")
        else
            listOf("Οπτικός έλεγχος εσωτερικής","Οπτικός έλεγχος εξωτερικής","Φίλτρα","Ανεμιστήρας","Αποχέτευση","Ηλεκτρικές συνδέσεις","Σωληνώσεις/μονώσεις","Θερμοκρασίες","Ψύξη","Θέρμανση","Θόρυβοι/κραδασμοί","Διαρροή","Πίεση αναρρόφησης","Πίεση κατάθλιψης","Superheat","Subcooling","Ρεύμα λειτουργίας","Καθαρισμός χώρου","Ενημέρωση πελάτη","Φωτογραφίες μετά")
        val saved=jsonArray(key)
        val done=HashSet<String>()
        for(i in 0 until saved.length()) done.add(saved.optString(i))
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val checks=mutableListOf<CheckBox>()
        items.forEach { label ->
            val cb=CheckBox(this).apply{
                text=label; textSize=16f; isChecked=done.contains(label); setPadding(4,8,4,8)
            }
            checks.add(cb); box.addView(cb)
        }
        r.addView(scroll(box),LinearLayout.LayoutParams(-1,0,1f))
        r.addView(button("💾 Αποθήκευση checklist"){
            val a=JSONArray()
            checks.filter{it.isChecked}.forEach{a.put(it.text.toString())}
            prefs.edit().putString(key,a.toString()).apply()
            toast("Το checklist αποθηκεύτηκε.")
        })
        r.addView(button("↻ Καθαρισμός checklist"){
            prefs.edit().remove(key).apply()
            checks.forEach{it.isChecked=false}
            toast("Το checklist καθαρίστηκε.")
        })
        r.addView(button("← Πίσω"){home()})
        setContentView(r)
    }

    private fun aiScreen(){
        val r=base(); r.addView(title("🤖 AI Ψυκτικού"))
        r.addView(TextView(this).apply{text="Ο βοηθός χρησιμοποιεί τα αποθηκευμένα στοιχεία πελάτη, μηχανήματος και εργασίας για να οργανώσει τη διάγνωση. Οι προτάσεις είναι τεχνικές κατευθύνσεις και όχι βεβαιότητα.";textSize=15f;setPadding(0,0,0,14)})
        val jobId=input("ID εργασίας (προαιρετικό)"); val symptom=input("Σύμπτωμα / επιπλέον παρατήρηση")
        val result=TextView(this).apply{textSize=16f;setPadding(0,16,0,16)}
        r.addView(jobId); r.addView(symptom)
        r.addView(button("🧠 Ανάλυση αποθηκευμένης εργασίας"){
            val id=jobId.text.toString().toLongOrNull(); val j=id?.let{jobs().firstOrNull{x->x.id==it}}
            if(j==null){result.text="Δεν βρέθηκε εργασία με αυτό το ID. Άφησε το πεδίο κενό για γενική ανάλυση."; if(symptom.text.isNotBlank()) result.append("\n\nΣύμπτωμα: ${symptom.text}"); return@button}
            val c=customers().firstOrNull{it.id==j.customerId}; val m=machines().firstOrNull{it.id==j.machineId}
            val out=StringBuilder(); out.append("📋 Εργασία #${j.id}\n👤 ${c?.name?:"Άγνωστος πελάτης"}\n❄️ ${m?.brand?:""} ${m?.model?:""}\nΨυκτικό: ${m?.refrigerant?:"-"}\n")
            out.append("\n🔍 Σύμπτωμα: ${j.symptom.ifBlank{symptom.text.toString().ifBlank{"-"}}}\nΚωδικός: ${j.faultCode.ifBlank{"-"}}\nΔιάγνωση που καταχωρήθηκε: ${j.diagnosis.ifBlank{"-"}}\n")
            out.append("\n🌡️ Μετρήσεις\nΑναρρόφηση: ${j.suction.ifBlank{"-"}} bar\nΚατάθλιψη: ${j.discharge.ifBlank{"-"}} bar\nΘερμ. αναρρόφησης: ${j.suctionTemp.ifBlank{"-"}} °C\nΘερμ. υγρού: ${j.liquidTemp.ifBlank{"-"}} °C\nΈξοδος: ${j.outletTemp.ifBlank{"-"}} °C\nSuperheat: ${j.superheat.ifBlank{"-"}} °C\nSubcooling: ${j.subcooling.ifBlank{"-"}} °C\n")
            val sh=j.superheat.replace(',','.').toDoubleOrNull(); val sc=j.subcooling.replace(',','.').toDoubleOrNull()
            out.append("\n🧪 Προτεινόμενη πορεία ελέγχου\n")
            if(j.symptom.contains("δεν κρυ",true)||j.symptom.contains("δεν αποδ",true)) out.append("• Έλεγξε πρώτα ροή αέρα, φίλτρα, εναλλάκτες και ανεμιστήρες.\n")
            if(sh!=null) out.append("• Αξιολόγησε το Superheat ($sh °C) σε σχέση με τον κατασκευαστή και τις συνθήκες.\n")
            if(sc!=null) out.append("• Αξιολόγησε το Subcooling ($sc °C) σε σχέση με τον κατασκευαστή και τις συνθήκες.\n")
            out.append("• Μην συμπεραίνεις έλλειψη ψυκτικού από μία μόνο πίεση. Συνδύασε πιέσεις, θερμοκρασίες, SH/SC, ροή αέρα και ιστορικό.\n")
            val history=jobs().filter{it.machineId==j.machineId && it.id!=j.id}.sortedByDescending{it.date}.take(3)
            if(history.isNotEmpty()){out.append("\n📜 Πρόσφατο ιστορικό μηχανήματος\n");history.forEach{out.append("• ${it.date}: ${it.type} — ${it.symptom.ifBlank{"χωρίς σύμπτωμα"}}\n")}}
            result.text=out.toString()
        })
        r.addView(button("🔎 Γενική βοήθεια διάγνωσης"){diagnosisAssistant()})
        r.addView(result); r.addView(button("← Πίσω"){home()}); setContentView(r)
    }
    private fun techScreen(){val r=base();r.addView(title("📚 Τεχνική βιβλιοθήκη"));listOf("Ψυκτικά: R32 / R410A / R134a / R407C / R290","Superheat & Subcooling","Vacuum και αφύγρανση κυκλώματος","Έλεγχος διαρροών","Ηλεκτρολογικοί έλεγχοι","Inverter και αισθητήρες","Σωληνώσεις και εγκατάσταση").forEach{r.addView(card("• $it"))};r.addView(button("← Πίσω"){home()});setContentView(r)}
    private fun notes():MutableList<Note>{val a=jsonArray("notes");return MutableList(a.length()){i->val o=a.getJSONObject(i);Note(o.getLong("id"),o.optString("title"),o.optString("text"))}}
    private fun saveNotes(x:List<Note>){val a=JSONArray();x.forEach{a.put(JSONObject().apply{put("id",it.id);put("title",it.title);put("text",it.text)})};prefs.edit().putString("notes",a.toString()).apply()}
    private fun notesScreen(){val r=base();r.addView(title("📝 Σημειώσεις"));val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};notes().forEach{n->list.addView(card("📌 ${n.title}\n${n.text}"){noteEditor(n)})};r.addView(scroll(list),LinearLayout.LayoutParams(-1,0,1f));r.addView(button("＋ Νέα σημείωση"){noteEditor(null)});r.addView(button("← Πίσω"){home()});setContentView(r)}
    private fun noteEditor(e:Note?){val r=base();r.addView(title("📝 Σημείωση"));val t=input("Τίτλος"),x=input("Κείμενο");e?.let{t.setText(it.title);x.setText(it.text)};r.addView(t);r.addView(x);r.addView(button("💾 Αποθήκευση"){val d=notes();val id=e?.id?:System.currentTimeMillis();val n=Note(id,t.text.toString(),x.text.toString());val i=d.indexOfFirst{it.id==id};if(i>=0)d[i]=n else d.add(n);saveNotes(d);notesScreen()});if(e!=null)r.addView(button("🗑 Διαγραφή"){saveNotes(notes().filter{it.id!=e.id});notesScreen()});r.addView(button("← Πίσω"){notesScreen()});setContentView(r)}
    private data class Material(val id:Long,val name:String,val code:String,val qty:String,val price:String,val notes:String)
    private fun materialList():MutableList<Material>{val a=jsonArray("materials");return MutableList(a.length()){i->val o=a.getJSONObject(i);Material(o.getLong("id"),o.optString("name"),o.optString("code"),o.optString("qty"),o.optString("price"),o.optString("notes"))}}
    private fun saveMaterialList(x:List<Material>){val a=JSONArray();x.forEach{m->a.put(JSONObject().apply{put("id",m.id);put("name",m.name);put("code",m.code);put("qty",m.qty);put("price",m.price);put("notes",m.notes)})};prefs.edit().putString("materials",a.toString()).apply()}
    private fun materialsScreen(){val r=base();r.addView(title("📦 Υλικά / Αποθήκη"));val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};val data=materialList();if(data.isEmpty())list.addView(card("Δεν υπάρχουν υλικά. Πρόσθεσε τα βασικά ανταλλακτικά και αναλώσιμα που χρησιμοποιείς."));data.forEach{m->list.addView(card("🔩 ${m.name}\nΚωδικός: ${m.code}\nΠοσότητα: ${m.qty} • Τιμή: €${m.price}\n${m.notes}"){materialEditor(m)})};r.addView(scroll(list),LinearLayout.LayoutParams(-1,0,1f));r.addView(button("＋ Νέο υλικό"){materialEditor(null)});r.addView(button("← Πίσω"){home()});setContentView(r)}
    private fun materialEditor(e:Material?){val r=base();r.addView(title(if(e==null)"＋ Νέο υλικό" else "✏️ Υλικό"));val n=input("Όνομα υλικού");val c=input("Κωδικός / Part Number");val q=input("Ποσότητα");val pr=input("Τιμή (€)");val no=input("Σημειώσεις");e?.let{n.setText(it.name);c.setText(it.code);q.setText(it.qty);pr.setText(it.price);no.setText(it.notes)};listOf(n,c,q,pr,no).forEach{r.addView(it)};r.addView(button("💾 Αποθήκευση"){if(n.text.isBlank()){toast("Συμπλήρωσε όνομα.");return@button};val d=materialList();val id=e?.id?:System.currentTimeMillis();val m=Material(id,n.text.toString(),c.text.toString(),q.text.toString(),pr.text.toString(),no.text.toString());val i=d.indexOfFirst{it.id==id};if(i>=0)d[i]=m else d.add(m);saveMaterialList(d);materialsScreen()});if(e!=null)r.addView(button("🗑 Διαγραφή"){saveMaterialList(materialList().filter{it.id!=e.id});materialsScreen()});r.addView(button("← Πίσω"){materialsScreen()});setContentView(r)}
    private fun backupJson(): JSONObject {
        val keys=listOf("customers","machines","jobs","notes","materials")
        return JSONObject().apply {
            put("app", "Psyktikos")
            put("version", "1.0")
            put("createdAt", System.currentTimeMillis())
            keys.forEach { k -> put(k, JSONArray(prefs.getString(k,"[]"))) }
        }
    }

    private fun backupScreen(){
        val r=base(); r.addView(title("💾 Backup / Επαναφορά"))
        r.addView(TextView(this).apply{
            text="Στο v1.0 μπορείς να εξάγεις όλα τα βασικά δεδομένα της εφαρμογής σε αρχείο JSON και να τα επαναφέρεις αργότερα. Τα δεδομένα παραμένουν τοπικά στη συσκευή."
            textSize=16f; setPadding(0,0,0,16)
        })
        r.addView(button("📤 Εξαγωγή backup JSON"){
            val i=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{
                addCategory(Intent.CATEGORY_OPENABLE); type="application/json"; putExtra(Intent.EXTRA_TITLE,"Psyktikos_backup_v1.0.json")
            }; startActivityForResult(i,BACKUP_EXPORT)
        })
        r.addView(button("📥 Επαναφορά από backup JSON"){
            val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{
                addCategory(Intent.CATEGORY_OPENABLE); type="application/json"
            }; startActivityForResult(i,BACKUP_IMPORT)
        })
        r.addView(button("👁 Προβολή backup"){
            val v=EditText(this).apply{setText(backupJson().toString(2));textSize=12f;minLines=12;isVerticalScrollBarEnabled=true}
            r.addView(v,2); toast("Το backup είναι έτοιμο.")
        })
        r.addView(button("🧹 Καθαρισμός όλων των δεδομένων"){
            AlertDialog.Builder(this).setTitle("Προσοχή").setMessage("Θα διαγραφούν πελάτες, μηχανήματα, εργασίες, σημειώσεις και υλικά.")
                .setNegativeButton("Ακύρωση",null).setPositiveButton("Διαγραφή"){_,_->prefs.edit().clear().apply();home()}.show()
        })
        r.addView(button("← Πίσω"){home()}); setContentView(r)
    }

}
