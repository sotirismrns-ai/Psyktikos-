Psyktikos v1.2 - Βλαβολόγιο 3.0

Ροή Βλαβολογίου:
1. Μόνο μάρκες με logo.
2. Επιλογή τύπου μηχανήματος.
3. Βλάβες μόνο της επιλεγμένης κατηγορίας.

Το project χρησιμοποιεί package com.psyktikos.app.
Το signing key ΔΕΝ περιλαμβάνεται στο ZIP. Το workflow αντιγράφει το μόνιμο keystore από KEYSTORE_BASE64-1.txt του repository.
