package com.psyktikos.app
import java.io.BufferedReader
import java.io.InputStreamReader
import android.text.Editable
import android.text.TextWatcher

import android.content.Context
import android.provider.Settings
import android.location.LocationManager
import android.content.pm.PackageManager
import android.Manifest
import android.graphics.Color
import android.graphics.Bitmap
import android.graphics.drawable.GradientDrawable
import android.graphics.BitmapFactory
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.MotionEvent
import android.widget.*
import android.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private val aiChatHistory = mutableListOf<Pair<String,String>>()
    private var aiAttachedPhoto: Uri? = null
    private var aiChatRefresh: (() -> Unit)? = null
    private var homeTemperatureView: TextView? = null
    private var homeClockView: TextView? = null
    private val HOME_LOCATION_PERMISSION = 9321

    // Browser-like navigation history for every screen in the app.
    private val pageHistory = mutableListOf<View>()
    private var pageHistoryIndex = -1
    private var restoringHistory = false
    private var swipeDownX = 0f
    private var swipeDownY = 0f

    override fun setContentView(view: View) {
        if (!restoringHistory) {
            if (pageHistoryIndex < pageHistory.lastIndex) {
                pageHistory.subList(pageHistoryIndex + 1, pageHistory.size).clear()
            }
            pageHistory.add(view)
            pageHistoryIndex = pageHistory.lastIndex
        }
        super.setContentView(view)
    }


    private fun faultMatchesModel(f: Fault, brand: String, type: String, model: String): Boolean {
        // FIX: Οι κωδικοί που έχουμε συλλέξει είναι brand/platform scoped.
        // Εμφανίζονται σε όλα τα μοντέλα της ίδιας μάρκας ώστε καμία καρτέλα
        // μοντέλου να μη δείχνει λανθασμένα "0 κωδικοί βλαβών".
        // Το πεδίο series/type μέσα στην κάθε βλάβη δείχνει σε ποια πλατφόρμα
        // ή κατηγορία ισχύει ο συγκεκριμένος κωδικός.
        return f.brand.equals(brand, ignoreCase = true)
    }

    private fun showHistoryPage(index:Int):Boolean{
        if(index !in pageHistory.indices || index==pageHistoryIndex) return false
        pageHistoryIndex=index
        val view=pageHistory[index]
        (view.parent as? android.view.ViewGroup)?.removeView(view)
        restoringHistory=true
        super.setContentView(view)
        restoringHistory=false
        return true
    }

    private fun goBackHistory():Boolean = showHistoryPage(pageHistoryIndex-1)
    private fun goForwardHistory():Boolean = showHistoryPage(pageHistoryIndex+1)

    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
        when(event.actionMasked){
            MotionEvent.ACTION_DOWN -> {
                swipeDownX=event.rawX
                swipeDownY=event.rawY
            }
            MotionEvent.ACTION_UP -> {
                val dx=event.rawX-swipeDownX
                val dy=event.rawY-swipeDownY
                if(kotlin.math.abs(dx)>150f &&
                   kotlin.math.abs(dx)>kotlin.math.abs(dy)*1.25f){
                    if(dx>0 && goBackHistory()) return true
                    if(dx<0 && goForwardHistory()) return true
                }
            }
        }
        return super.dispatchTouchEvent(event)
    }

    private var pendingPhotoKey = ""
    private var pendingPhotoCategory = ""
    private val PHOTO_PICKER = 8108
    private val BACKUP_EXPORT = 9101
    private val BACKUP_IMPORT = 9102

    private val blue = Color.rgb(18, 92, 160)
    private val bg = Color.rgb(2, 25, 49)
    private val prefs by lazy { getSharedPreferences("psyktikos_data", Context.MODE_PRIVATE) }

    data class Customer(val id: Long, val name: String, val phone: String, val address: String, val notes: String)
    data class Machine(val id: Long, val customerId: Long, val brand: String, val model: String, val serial: String, val refrigerant: String, val capacity: String, val type: String, val year: String, val address: String, val notes: String)
    data class Job(val id: Long, val customerId: Long, val machineId: Long, val date: String, val type: String, val symptom: String, val faultCode: String, val diagnosis: String, val action: String, val suction: String, val discharge: String, val suctionTemp: String, val liquidTemp: String, val roomTemp: String, val outletTemp: String, val superheat: String, val subcooling: String, val materials: String, val materialCost: String, val laborHours: String, val laborRate: String, val total: String, val checklist: String, val photos: String, val notes: String, val status: String)
    data class Note(val id: Long, val title: String, val text: String)

    data class Fault(val brand: String, val code: String, val symptom: String, val meaning: String, val causes: String, val checks: String, val action: String, val type: String = "Split / Inverter", val series: String = "Γενικοί κωδικοί", val source: String = "")

    /*
     * ΠΛΗΡΕΣ ΒΛΑΒΟΛΟΓΙΟ v1.0
     * Τοπικό, χωρίς internet. Οι κωδικοί/ερμηνείες πρέπει πάντα να διασταυρώνονται
     * με το service manual του ακριβούς μοντέλου, επειδή ίδιος κωδικός μπορεί να
     * σημαίνει διαφορετικό πράγμα σε διαφορετικές σειρές.
     */
    private val faults = listOf(
        // ===== FINAL REMAINING DEEP PASS: TOSHIBA / TOYOTOMI / TRANE / VAILLANT / VIESSMANN / YORK / PITSOS / SENDO / MORRIS / JURO-PRO / F&U / UNITED / ARGO / CIAT =====
        Fault("Toshiba","E01","Σφάλμα λήψης χειριστηρίου","Remote controller reception error","Remote controller, wiring ή indoor PCB","Έλεγξε remote bus, wiring και indoor PCB","Αποκατάσταση λήψης/επικοινωνίας","Light Commercial / VRF","RAV / TCC-LINK","Toshiba official service manual"),
        Fault("Toshiba","E02","Σφάλμα μετάδοσης χειριστηρίου","Remote controller transmission error","Remote controller ή wiring","Έλεγξε remote wiring και controller","Αποκατάσταση μετάδοσης","Light Commercial / VRF","RAV / TCC-LINK","Toshiba official service manual"),
        Fault("Toshiba","E09","Διπλό master χειριστήριο","Duplicated master remote controllers","Λάθος remote configuration","Έλεγξε master/follower remote settings","Διόρθωσε configuration","Light Commercial / VRF","RAV / TCC-LINK","Toshiba official service manual"),
        Fault("Toshiba","E12","Σφάλμα εκκίνησης αυτόματης διευθυνσιοδότησης","Automatic address starting error","Addressing/configuration","Έλεγξε addressing και communication bus","Επανέλαβε σωστά auto-address","VRF","SMMS / TCC-LINK","Toshiba official service manual"),
        Fault("Toshiba","E15","Δεν βρέθηκε εσωτερική κατά auto-address","Indoor unit not found during automatic address setting","Power, bus ή addressing","Έλεγξε τροφοδοσίες IDU και bus","Αποκατάσταση και επανάληψη addressing","VRF","SMMS / TCC-LINK","Toshiba official service manual"),
        Fault("Toshiba","E16","Υπερβολικός αριθμός εσωτερικών","Too many indoor units connected / overloading","Υπέρβαση επιτρεπόμενου combination","Έλεγξε αριθμό και capacity combination","Διόρθωσε combination","VRF","SMMS / TCC-LINK","Toshiba official service manual"),
        Fault("Toshiba","F01","Βλάβη αισθητήρα εναλλάκτη TCJ","Heat exchanger TCJ sensor open/short","Thermistor/wiring","Έλεγξε TCJ και connector","Αντικατάσταση αισθητήρα","Light Commercial / VRF","RAV / TCC-LINK","Toshiba official service manual"),
        Fault("Toshiba","F02","Βλάβη αισθητήρα εναλλάκτη TC2","Heat exchanger TC2 sensor open/short","Thermistor/wiring","Έλεγξε TC2","Αντικατάσταση αισθητήρα","Light Commercial / VRF","RAV / TCC-LINK","Toshiba official service manual"),
        Fault("Toshiba","F03","Βλάβη αισθητήρα εναλλάκτη TC1","Heat exchanger TC1 sensor open/short","Thermistor/wiring","Έλεγξε TC1","Αντικατάσταση αισθητήρα","Light Commercial / VRF","RAV / TCC-LINK","Toshiba official service manual"),
        Fault("Toshiba","F10","Βλάβη αισθητήρα χώρου TA","Room temperature sensor TA open/short","Thermistor/wiring","Έλεγξε TA","Αντικατάσταση αισθητήρα","Light Commercial / VRF","RAV / TCC-LINK","Toshiba official service manual"),
        Fault("Toshiba","F11","Βλάβη αισθητήρα αέρα κατάθλιψης","Discharge air temperature sensor open/short","Thermistor/wiring","Έλεγξε sensor/connector","Αντικατάσταση αισθητήρα","Light Commercial / VRF","RAV / TCC-LINK","Toshiba official service manual"),
        Fault("Toshiba","F29","Βλάβη EEPROM εσωτερικής","Indoor EEPROM abnormal","Indoor PCB/EEPROM","Power reset και έλεγχος PCB","Επισκευή/αντικατάσταση PCB","Light Commercial / VRF","RAV / TCC-LINK","Toshiba official service manual"),
        Fault("Toshiba","P10","Overflow / υψηλή στάθμη συμπυκνωμάτων","Overflow detected","Drain, pump ή float","Έλεγξε drain, pump και float","Αποκατάσταση αποχέτευσης","Light Commercial / VRF","RAV / TCC-LINK","Toshiba official service manual"),
        Fault("Toshiba","P12","Βλάβη DC ανεμιστήρα εσωτερικής","Indoor DC fan error","Fan overcurrent/lock ή PCB","Έλεγξε fan, motor και PCB","Αποκατάσταση fan/PCB","Light Commercial / VRF","RAV / TCC-LINK","Toshiba official service manual"),

        Fault("Toyotomi","E5","Προστασία υπερφόρτωσης συμπιεστή","Compressor overload protection","Υψηλό load/current ή compressor","Έλεγξε ρεύμα, πιέσεις και compressor","Αποκατάσταση αιτίας overload","VRF / Ducted","Toyotomi multi-variable platform","Toyotomi official manual"),
        Fault("Toyotomi","E7","Σύγκρουση τρόπων λειτουργίας","Modes conflict","Αντίθετα modes μεταξύ εσωτερικών","Έλεγξε modes όλων των IDU","Ρύθμισε συμβατό mode","VRF / Multi","Toyotomi multi-variable platform","Toyotomi official manual"),
        Fault("Toyotomi","F5","Βλάβη αισθητήρα εισόδου εξωτερικού στοιχείου","Outdoor coil inlet sensor malfunction","Thermistor/wiring","Έλεγξε sensor","Αντικατάσταση αισθητήρα","VRF","Toyotomi multi-variable platform","Toyotomi official manual"),
        Fault("Toyotomi","F6","Βλάβη αισθητήρα μέσης εξωτερικού στοιχείου","Outdoor coil middle sensor malfunction","Thermistor/wiring","Έλεγξε sensor","Αντικατάσταση αισθητήρα","VRF","Toyotomi multi-variable platform","Toyotomi official manual"),
        Fault("Toyotomi","F7","Βλάβη αισθητήρα εξόδου εξωτερικού στοιχείου","Outdoor coil outlet sensor malfunction","Thermistor/wiring","Έλεγξε sensor","Αντικατάσταση αισθητήρα","VRF","Toyotomi multi-variable platform","Toyotomi official manual"),
        Fault("Toyotomi","F8","Βλάβη αισθητήρα κατάθλιψης 1","Discharge temperature sensor 1 malfunction","Thermistor/wiring","Έλεγξε sensor","Αντικατάσταση αισθητήρα","VRF","Toyotomi multi-variable platform","Toyotomi official manual"),
        Fault("Toyotomi","F9","Βλάβη αισθητήρα κατάθλιψης 2","Discharge temperature sensor 2 malfunction","Thermistor/wiring","Έλεγξε sensor","Αντικατάσταση αισθητήρα","VRF","Toyotomi multi-variable platform","Toyotomi official manual"),
        Fault("Toyotomi","FC","Βλάβη αισθητήρα υψηλής πίεσης","High pressure sensor malfunction","Pressure sensor/wiring","Έλεγξε πραγματική πίεση και sensor","Αποκατάσταση sensor/wiring","VRF","Toyotomi multi-variable platform","Toyotomi official manual"),
        Fault("Toyotomi","Fd","Βλάβη αισθητήρα χαμηλής πίεσης","Low pressure sensor malfunction","Pressure sensor/wiring","Έλεγξε πραγματική πίεση και sensor","Αποκατάσταση sensor/wiring","VRF","Toyotomi multi-variable platform","Toyotomi official manual"),

        Fault("Trane","EA","Βλάβη κυκλώματος ανίχνευσης ρεύματος εξωτερικής","Outdoor current test circuit failure","Outdoor PCB/current sensing","Έλεγξε current sensing circuit","Επισκευή/αντικατάσταση PCB","Split / Inverter","4MYW inverter platform","Trane official service manual"),
        Fault("Trane","Eb","Σφάλμα επικοινωνίας main PCB-display","Main PCB/display board communication abnormal","Display board, wiring ή main PCB","Έλεγξε display wiring και main PCB","Αποκατάσταση επικοινωνίας","Split / Inverter","4MYW inverter platform","Trane official service manual"),
        Fault("Trane","EE","Βλάβη EEPROM εξωτερικής","Outdoor EEPROM failure","Outdoor PCB","Power reset και έλεγχος PCB","Επισκευή/αντικατάσταση PCB","Split / Inverter","4MYW inverter platform","Trane official service manual"),
        Fault("Trane","EF","Βλάβη DC ανεμιστήρα εξωτερικής","Outdoor DC fan motor failure","Fan motor/PCB","Έλεγξε fan και outdoor PCB","Αποκατάσταση fan/PCB","Split / Inverter","4MYW inverter platform","Trane official service manual"),
        Fault("Trane","EU","Βλάβη κυκλώματος μέτρησης τάσης εξωτερικής","Outdoor voltage test circuit abnormal","Outdoor PCB","Έλεγξε voltage sensing circuit","Επισκευή/αντικατάσταση PCB","Split / Inverter","4MYW inverter platform","Trane official service manual"),
        Fault("Trane","P0","Προστασία IPM","IPM module protection","IPM/PCB/compressor","Έλεγξε IPM, DC bus και compressor","Αποκατάσταση module/αιτίας","Split / Inverter","4MYW inverter platform","Trane official service manual"),
        Fault("Trane","P1","Προστασία υπέρτασης/υπότασης","Over/under voltage protection","Supply ή outdoor PCB","Μέτρησε supply/DC bus","Αποκατάσταση τροφοδοσίας","Split / Inverter","4MYW inverter platform","Trane official service manual"),
        Fault("Trane","P2","Προστασία υπερέντασης","Over current protection","Supply, PCB ή compressor load","Έλεγξε ρεύμα, τάση και compressor","Αποκατάσταση αιτίας","Split / Inverter","4MYW inverter platform","Trane official service manual"),
        Fault("Trane","P4","Υπερθέρμανση σωλήνα κατάθλιψης","Discharge pipe over-temperature protection","Υψηλή discharge temp/refrigerant issue","Έλεγξε discharge temp, πιέσεις και φόρτιση","Αποκατάσταση αιτίας","Split / Inverter","4MYW inverter platform","Trane official service manual"),
        // ===== DEEP PASS 6: SAMSUNG / SHARP / SINCLAIR / TCL / TESLA =====
        Fault("Samsung","E201","Σφάλμα επικοινωνίας εσωτερικής-εξωτερικής κατά το tracking","Communication error between indoor and outdoor units during tracking","Communication wiring, addressing ή PCB","Έλεγξε communication line, addressing, τροφοδοσίες και PCB","Αποκατάσταση επικοινωνίας","DVM / System AC","Samsung DVM platform","Samsung service manual"),
        Fault("Samsung","E202","Σφάλμα επικοινωνίας εσωτερικής-εξωτερικής","Indoor/outdoor communication error","Bus, wiring ή PCB","Έλεγξε communication bus, connectors και PCB","Αποκατάσταση επικοινωνίας","DVM / System AC","Samsung DVM platform","Samsung service manual"),
        Fault("Samsung","E203","Σφάλμα επικοινωνίας main-sub MICOM εξωτερικής","Communication error between outdoor main/sub MICOMs or outdoor units","Outdoor communication/control board","Έλεγξε outdoor boards, communication wiring και connectors","Αποκατάσταση επικοινωνίας/PCB","DVM / System AC","Samsung DVM platform","Samsung service manual"),

        Fault("Sharp","THERMISTOR","Βλάβη thermistor","Thermistor error","Thermistor open/short ή wiring","Χρησιμοποίησε self-diagnosis display του συγκεκριμένου μοντέλου και μέτρησε thermistor","Αντικατάσταση επιβεβαιωμένου thermistor/σύνδεσης","Split / Inverter","AY-XP / AE-XP families","Sharp official service manual"),
        Fault("Sharp","COMP START","Αποτυχία εκκίνησης συμπιεστή","Compressor startup error","Compressor, inverter ή supply","Έλεγξε compressor windings/insulation, inverter και τροφοδοσία","Αποκατάσταση compressor/drive","Split / Inverter","AY-XP / AE-XP families","Sharp official service manual"),
        Fault("Sharp","AC OVERCURRENT","Προστασία υπερέντασης AC","AC overcurrent protection","Υψηλό compressor current ή load","Έλεγξε ρεύμα, τάση, πιέσεις και compressor","Αποκατάσταση αιτίας overcurrent","Split / Inverter","AY-XP / AE-XP families","Sharp official service manual"),

        Fault("Sinclair","E2","Σφάλμα επικοινωνίας εσωτερικής-εξωτερικής","Indoor/outdoor communication error","Communication wiring, addressing ή PCB","Έλεγξε P/Q/E ή αντίστοιχο bus, connectors και PCB","Αποκατάσταση επικοινωνίας","VRF / SDV","SDV5 / ASDH platform","Sinclair service manual"),
        Fault("Sinclair","E4","Βλάβη αισθητήρα T3/T4","T3/T4 temperature sensor fault","Thermistor ή wiring","Έλεγξε sensor resistance και connector","Αντικατάσταση αισθητήρα","VRF / SDV","SDV5 / ASDH platform","Sinclair service manual"),
        Fault("Sinclair","E5","Ανώμαλη τάση τροφοδοσίας","Abnormal power supply voltage","Supply out of range","Μέτρησε supply voltage και συνδέσεις","Αποκατάσταση τροφοδοσίας","VRF / SDV","SDV5 platform","Sinclair service manual"),
        Fault("Sinclair","E6","Βλάβη DC ανεμιστήρα","DC fan motor error","Fan motor, feedback ή PCB","Έλεγξε fan, motor, feedback και PCB","Αποκατάσταση fan/PCB","VRF / SDV","SDV5 platform","Sinclair service manual"),
        Fault("Sinclair","E7","Βλάβη αισθητήρα κατάθλιψης T5/T7","Discharge temperature sensor error","Discharge thermistor ή wiring","Έλεγξε sensor/connector","Αντικατάσταση αισθητήρα","VRF / SDV","SDV5 / ASDH platform","Sinclair service manual"),
        Fault("Sinclair","E9","Βλάβη EEPROM","EEPROM error","EEPROM/main PCB","Power reset και έλεγχος main PCB","Επισκευή/αντικατάσταση PCB","VRF / SDV","SDV5 platform","Sinclair service manual"),
        Fault("Sinclair","P1","Προστασία υψηλής πίεσης","High pressure protection","Υψηλή πίεση ή ανεπαρκής απόρριψη θερμότητας","Έλεγξε πιέσεις, condenser, airflow και φόρτιση","Αποκατάσταση αιτίας HP","VRF / SDV","SDV5 platform","Sinclair service manual"),
        Fault("Sinclair","P2","Προστασία χαμηλής πίεσης αναρρόφησης","Suction low pressure protection","Διαρροή, χαμηλή φόρτιση ή restriction","Έλεγξε πιέσεις, διαρροές και ψυκτικό κύκλωμα","Επισκευή και σωστή φόρτιση","VRF / SDV","SDV5 platform","Sinclair service manual"),
        Fault("Sinclair","P3","Προστασία ρεύματος συμπιεστή","Compressor current protection","Υπερένταση compressor","Έλεγξε current, compressor, load και inverter","Αποκατάσταση αιτίας overcurrent","VRF / SDV","ASDH platform","Sinclair service manual"),
        Fault("Sinclair","P5","Προστασία θερμοκρασίας σωλήνα","Pipe temperature protection","Υψηλή/μη φυσιολογική pipe temp","Έλεγξε T3 sensor, load και ψυκτικό κύκλωμα","Αποκατάσταση αιτίας","VRF / SDV","ASDH platform","Sinclair service manual"),
        Fault("Sinclair","P6","Προστασία inverter module","Inverter module protection","IPM/inverter/compressor","Έλεγξε inverter module, DC bus και compressor","Αποκατάσταση module/αιτίας","VRF / SDV","ASDH platform","Sinclair service manual"),
        Fault("Sinclair","H5","Προστασία IPM","IPM protection","IPM, compressor ή drive","Έλεγξε IPM, compressor και τροφοδοσία","Αποκατάσταση IPM/drive","Heat Pump / Split","S-Therm / Gree-derived platform","Sinclair service manual"),
        Fault("Sinclair","H7","Αποσυγχρονισμός μοτέρ συμπιεστή","Compressor motor desynchronizing","Compressor/inverter","Έλεγξε compressor και inverter output","Αποκατάσταση drive/compressor","Heat Pump / Split","S-Therm platform","Sinclair service manual"),
        Fault("Sinclair","LD","Απώλεια φάσης","Phase loss","Supply/inverter output","Έλεγξε φάσεις, τάσεις και connections","Αποκατάσταση phase loss","Heat Pump / Split","S-Therm platform","Sinclair service manual"),

        Fault("TCL","E1","Βλάβη αισθητήρα θερμοκρασίας χώρου εσωτερικής","IDU room temperature sensor failure","IDU sensor ή PCB","Έλεγξε room thermistor και PCB connection","Αντικατάσταση sensor/PCB μετά διάγνωση","Split / ON-OFF","TAC-CSD/XAB1","TCL service manual"),
        Fault("TCL","E2","Βλάβη αισθητήρα στοιχείου εσωτερικής","IDU coil temperature sensor failure","Coil sensor ή PCB","Έλεγξε coil thermistor και connector","Αντικατάσταση sensor/PCB","Split / ON-OFF","TAC-CSD/XAB1","TCL service manual"),
        Fault("TCL","E4","Ανεπαρκές ψυκτικό","Insufficient refrigerant","Χαμηλή φόρτιση/διαρροή","Έλεγξε πίεση σε ψύξη και στεγανότητα","Επισκευή διαρροής και σωστή φόρτιση","Split / ON-OFF","TAC-CSD/XAB1","TCL service manual"),
        Fault("TCL","E5","Προστασία συστήματος","System protection","High/low pressure protection depending on model","Έλεγξε πιέσεις, airflow και pressure protection","Αποκατάσταση αιτίας προστασίας","Split / ON-OFF","TAC-CSD/XAB1","TCL service manual"),
        Fault("TCL","E6","Ανωμαλία μοτέρ εσωτερικού ανεμιστήρα","IDU PG/DC fan motor abnormal","Fan motor, blade ή PCB","Έλεγξε fan blade, motor και PCB","Αποκατάσταση fan/PCB","Split / ON-OFF","TAC-CSD/XAB1","TCL service manual"),
        Fault("TCL","P7","Προστασία υπερθέρμανσης στη θέρμανση","Overheating protection in heating mode","Υψηλή θερμοκρασία coil/airflow issue","Έλεγξε airflow, coil sensor και ψυκτικό κύκλωμα","Αποκατάσταση αιτίας overheating","Split / ON-OFF","TAC-CSD/XAB1","TCL service manual"),

        Fault("Tesla","E1","Βλάβη αισθητήρα θερμοκρασίας χώρου","Indoor room temperature sensor fault","Thermistor ή wiring","Έλεγξε sensor resistance και connector","Αντικατάσταση αισθητήρα","Split / Inverter","Tesla residential OEM platform","Model-specific service/error documentation"),
        Fault("Tesla","E2","Βλάβη αισθητήρα εσωτερικού στοιχείου","Indoor coil sensor fault","Thermistor ή wiring","Έλεγξε coil sensor και connector","Αντικατάσταση αισθητήρα","Split / Inverter","Tesla residential OEM platform","Model-specific service/error documentation"),
        Fault("Tesla","E4","Πρόβλημα ψυκτικού κυκλώματος / χαμηλή φόρτιση","Refrigerant system fault / low charge","Διαρροή ή ανεπαρκής φόρτιση","Έλεγξε στεγανότητα, πιέσεις και φόρτιση","Επισκευή και σωστή φόρτιση","Split / Inverter","Tesla residential OEM platform","Model-specific service/error documentation"),
        Fault("Tesla","E6","Βλάβη εσωτερικού ανεμιστήρα","Indoor fan motor fault","Fan motor, feedback ή PCB","Έλεγξε fan, motor και PCB","Αποκατάσταση fan/PCB","Split / Inverter","Tesla residential OEM platform","Model-specific service/error documentation"),
        // ===== DEEP PASS 5: KLIMAIRE / LENNOX / MITSUBISHI HEAVY / NORDSTAR / ROTENSO =====
        Fault("Klimaire","E0","Σφάλμα παραμέτρων EEPROM","EEPROM parameter error","EEPROM/PCB","Power reset και έλεγχος main PCB","Επισκευή/αντικατάσταση PCB","Split / Inverter","KSIV series","Klimaire KSIV Troubleshooting Manual"),
        Fault("Klimaire","F4","Σφάλμα παραμέτρων EEPROM εξωτερικής","Outdoor EEPROM parameter error","Outdoor PCB/EEPROM","Power reset και έλεγχος outdoor PCB","Επισκευή/αντικατάσταση PCB","Split / Inverter","KSIV series","Klimaire KSIV Troubleshooting Manual"),
        Fault("Klimaire","E1","Σφάλμα επικοινωνίας εσωτερικής-εξωτερικής","Indoor/outdoor communication error","Interconnect, τροφοδοσία ή PCB","Έλεγξε wiring, τροφοδοσίες και PCB","Αποκατάσταση επικοινωνίας","Split / Inverter","KSIV series","Klimaire KSIV Troubleshooting Manual"),
        Fault("Klimaire","E2","Σφάλμα ανίχνευσης zero-crossing","Zero-crossing detection error","AC supply/zero-cross circuit","Έλεγξε τροφοδοσία και indoor PCB","Αποκατάσταση supply/PCB","Split / Inverter","KSIV series","Klimaire KSIV Troubleshooting Manual"),
        Fault("Klimaire","F0","Προστασία υπερέντασης","Overload current protection","Υψηλό φορτίο, compressor ή inverter","Έλεγξε ρεύμα, τάση, πιέσεις και compressor","Αποκατάσταση αιτίας overload","Split / Inverter","KSIV series","Klimaire KSIV Troubleshooting Manual"),
        Fault("Klimaire","P0","Βλάβη IPM / υπερένταση IGBT","IPM malfunction / IGBT over-strong current protection","IPM, compressor ή DC bus","Έλεγξε IPM, DC bus και compressor","Αποκατάσταση module/αιτίας","Split / Inverter","KSIV series","Klimaire KSIV Troubleshooting Manual"),
        Fault("Klimaire","P1","Προστασία υπέρτασης/υπότασης","Over/under voltage protection","Supply/DC bus","Μέτρησε input voltage και DC bus","Αποκατάσταση τροφοδοσίας","Split / Inverter","KSIV series","Klimaire KSIV Troubleshooting Manual"),
        Fault("Klimaire","P2","Υψηλή θερμοκρασία IPM","High temperature protection of IPM module","Module cooling ή load","Έλεγξε module heatsink, airflow και load","Αποκατάσταση αιτίας υπερθέρμανσης","Split / Inverter","KSIV series","Klimaire KSIV Troubleshooting Manual"),
        Fault("Klimaire","P4","Σφάλμα οδήγησης inverter συμπιεστή","Inverter compressor drive error","Compressor/inverter drive","Έλεγξε compressor, wiring και inverter","Αποκατάσταση drive/compressor","Split / Inverter","KSIV series","Klimaire KSIV Troubleshooting Manual"),

        Fault("Lennox","E2","Σφάλμα επικοινωνίας outdoor main control-IPM","Communication error between outdoor main control and IPM","Signal wiring, IPM ή outdoor main board","Έλεγξε signal wire, LEDs IPM και main PCB","Αποκατάσταση wiring/IPM/main PCB","Multi Split","MPA009S4S platform","Lennox MPA Service Manual"),

        Fault("Mitsubishi Heavy","E10","Υπερβολικός αριθμός συνδεδεμένων εσωτερικών","Excessive number of connected indoor units","Πάνω από επιτρεπόμενο αριθμό IDU σε ένα remote","Έλεγξε αριθμό/ομαδοποίηση εσωτερικών","Διόρθωσε grouping/configuration","PAC / VRF","FDT/FDU/FDC families","MHI official service manual"),
        Fault("Mitsubishi Heavy","E11","Σφάλμα διεύθυνσης εσωτερικών","Indoor unit address setting error","Addressing","Έλεγξε indoor addresses","Διόρθωσε addressing","PAC / VRF","FDT/FDU/FDC families","MHI official service manual"),
        Fault("Mitsubishi Heavy","E14","Σφάλμα επικοινωνίας master-slave εσωτερικών","Master/slave indoor communication error","Bus/addressing/wiring","Έλεγξε master/slave settings και wiring","Αποκατάσταση επικοινωνίας","PAC / VRF","FDT/FDU/FDC families","MHI official service manual"),
        Fault("Mitsubishi Heavy","E18","Σφάλμα διεύθυνσης master/slave","Master/slave address setting error","Address configuration","Έλεγξε master/slave addresses","Διόρθωσε addressing","PAC / VRF","FDT/FDU/FDC families","MHI official service manual"),
        Fault("Mitsubishi Heavy","E19","Σφάλμα operation/drain-pump check setting","Operation check / drain pump motor check setting error","Service/test setting","Έλεγξε service/test configuration","Διόρθωσε setting","PAC / VRF","FDT/FDU/FDC families","MHI official service manual"),
        Fault("Mitsubishi Heavy","E20","Ανωμαλία ταχύτητας εσωτερικού ανεμιστήρα","Indoor fan motor rotation speed anomaly","Fan motor/feedback/PCB","Έλεγξε fan, feedback και PCB","Αποκατάσταση fan/PCB","PAC / VRF","FDT/FDU/FDC families","MHI official service manual"),
        Fault("Mitsubishi Heavy","E21","Βλάβη panel switch","Defective panel switch operation","Panel switch/PCB","Έλεγξε panel switch και wiring","Αποκατάσταση panel/control","Κασέτα","FDT series","MHI official service manual"),
        Fault("Mitsubishi Heavy","E40","Κλειστή service valve αερίου","Service valve gas-side closing operation","Κλειστή βαλβίδα ή σχετική ανωμαλία","Έλεγξε service valves και ψυκτικό κύκλωμα","Άνοιγμα valve/αποκατάσταση αιτίας","PAC / VRF","FDC families","MHI official service manual"),
        Fault("Mitsubishi Heavy","E51","Βλάβη power transistor","Power transistor anomaly","Power transistor/inverter","Έλεγξε inverter module και compressor","Αποκατάσταση power module/αιτίας","PAC / VRF","FDC families","MHI official service manual"),
        Fault("Mitsubishi Heavy","E58","Current safe stop","Current safe stop","Overload/current protection condition","Έλεγξε ρεύματα, πιέσεις, compressor και inverter","Αποκατάσταση αιτίας current protection","PAC / VRF","FDC families","MHI official service manual"),
        Fault("Mitsubishi Heavy","E60","Μπλοκάρισμα rotor συμπιεστή","Compressor rotor lock anomaly","Compressor/inverter","Έλεγξε compressor, phase output και inverter","Αποκατάσταση compressor/drive","PAC / VRF","FDC families","MHI official service manual"),

        Fault("Rotenso","EH 00","Σφάλμα παραμέτρων EEPROM εσωτερικής","Indoor EEPROM parameter error","EEPROM/PCB","Power reset και έλεγχος indoor PCB","Επισκευή/αντικατάσταση PCB","LCAC / Multi","LCAC / Hiro series","Rotenso LCAC/Hiro Service Manual"),
        Fault("Rotenso","EL 01","Σφάλμα επικοινωνίας εσωτερικής-εξωτερικής","Indoor/outdoor communication error","Interconnect, supply ή PCB","Έλεγξε wiring, τροφοδοσίες και PCB","Αποκατάσταση επικοινωνίας","LCAC / Multi","LCAC / Hiro series","Rotenso LCAC/Hiro Service Manual"),
        Fault("Rotenso","EH 03","Ταχύτητα εσωτερικού ανεμιστήρα εκτός ορίων","Indoor fan speed outside normal range","Fan motor, feedback ή PCB","Έλεγξε fan, motor και PCB","Αποκατάσταση fan/PCB","LCAC / Multi","LCAC / Hiro series","Rotenso LCAC/Hiro Service Manual"),
        Fault("Rotenso","EL 0C","Ανίχνευση διαρροής ψυκτικού","Refrigerant leakage detection","Διαρροή/χαμηλή φόρτιση","Έλεγξε διαρροές, πιέσεις και φόρτιση","Επισκευή, κενό και σωστή φόρτιση","LCAC / Multi","LCAC / Hiro series","Rotenso LCAC/Hiro Service Manual"),
        Fault("Rotenso","EH 0E","Συναγερμός στάθμης νερού","Water-level alarm malfunction","Drain pump, float ή αποχέτευση","Έλεγξε pump, float και drain","Αποκατάσταση αποχέτευσης","Κασέτα / Duct","LCAC / Hiro series","Rotenso LCAC/Hiro Service Manual"),
        Fault("Rotenso","PC 00","Βλάβη IPM / υπερένταση IGBT","IPM malfunction / IGBT over-current protection","IPM, compressor ή DC bus","Έλεγξε IPM, DC bus και compressor","Αποκατάσταση module/αιτίας","LCAC / Multi","LCAC / Hiro series","Rotenso LCAC/Hiro Service Manual"),
        Fault("Rotenso","P4","Υπερθέρμανση κατάθλιψης εξωτερικής","ODU discharge temperature overheating protection","Υψηλή discharge temp, airflow ή ψυκτικό κύκλωμα","Έλεγξε condenser, airflow, πιέσεις και φόρτιση","Αποκατάσταση αιτίας υπερθέρμανσης","Split / Inverter","Roni series","Rotenso Roni Service Manual"),
        Fault("Rotenso","P5","Προστασία υποψύξης σε ψύξη/αφύγρανση","Sub-cooling protection in Cooling/Dry mode","Πολύ χαμηλή θερμοκρασία εξατμιστή","Έλεγξε airflow, evaporator sensor και ψυκτικό","Αποκατάσταση αιτίας χαμηλής coil temp","Split / Inverter","Roni series","Rotenso Roni Service Manual"),
        Fault("Rotenso","P6","Προστασία υπερθέρμανσης σε ψύξη","Overheating protection in Cooling mode","Υψηλή θερμοκρασία condenser","Έλεγξε outdoor airflow, condenser και sensor","Αποκατάσταση heat rejection","Split / Inverter","Roni series","Rotenso Roni Service Manual"),

        // Nordstar already has a strong TN+ code set; keep an explicit platform marker rather than mixing another OEM table.
        Fault("Nordstar","TN+ COMM","Διάγνωση επικοινωνίας πλατφόρμας TN+","TN+ platform communication diagnostic","Communication wiring/PCB","Χρησιμοποίησε E0 και το TN+ service flow για wiring/PCB checks","Αποκατάσταση σύμφωνα με TN+ service manual","Split / Inverter","TN+ / NORP CHSD TP41I","Nordstar TN+ service manual"),
        // ===== DEEP PASS 4: CARRIER / CLIMAVENETA / COOPER&HUNTER / HISENSE / INVENTOR =====
        Fault("Cooper&Hunter","E1","Προστασία υψηλής πίεσης","System high pressure protection","Υψηλή πίεση, airflow ή φόρτιση","Έλεγξε πιέσεις, condenser, fan και φόρτιση","Αποκατάσταση αιτίας υψηλής πίεσης","Split / Inverter","ICY II / Supreme / NG families","Cooper&Hunter service manual"),
        Fault("Cooper&Hunter","E2","Αντιπαγωτική προστασία","Antifreezing protection","Χαμηλή coil temp ή airflow","Έλεγξε φίλτρα, fan, coil και ψυκτικό","Αποκατάσταση αιτίας παγώματος","Split / Inverter","ICY II / Supreme / NG families","Cooper&Hunter service manual"),
        Fault("Cooper&Hunter","F0","Προστασία έλλειψης ψυκτικού","Refrigerant leakage/lack protection","Διαρροή ή χαμηλή φόρτιση","Έλεγξε διαρροές, πιέσεις και φόρτιση","Επισκευή, κενό και σωστή φόρτιση","Split / Inverter","ICY II / Supreme / NG families","Cooper&Hunter service manual"),
        Fault("Cooper&Hunter","E4","Υψηλή θερμοκρασία κατάθλιψης","High compressor discharge temperature protection","Χαμηλή φόρτιση/restriction/overheat","Έλεγξε discharge temp, πιέσεις και φόρτιση","Αποκατάσταση αιτίας","Split / Inverter","ICY II / Supreme / NG families","Cooper&Hunter service manual"),
        Fault("Cooper&Hunter","E5","Προστασία υπερέντασης","Overcurrent protection","Compressor/inverter/load","Έλεγξε ρεύμα, τάση, πιέσεις και compressor","Αποκατάσταση αιτίας overcurrent","Split / Inverter","ICY II / Supreme / NG families","Cooper&Hunter service manual"),
        Fault("Cooper&Hunter","E6","Σφάλμα επικοινωνίας","Communication malfunction","Wiring ή PCB","Έλεγξε communication wiring και PCB","Αποκατάσταση επικοινωνίας","Split / Inverter","ICY II / Supreme / NG families","Cooper&Hunter service manual"),
        Fault("Cooper&Hunter","E8","Προστασία υψηλής θερμοκρασίας","High temperature resistant protection","Υψηλή θερμοκρασία module/coil","Έλεγξε airflow, module και θερμοκρασίες","Αποκατάσταση αιτίας","Split / Inverter","ICY II / Supreme / NG families","Cooper&Hunter service manual"),
        Fault("Cooper&Hunter","EE","Βλάβη EEPROM","EEPROM malfunction","PCB/EEPROM","Power reset και έλεγχος PCB","Επισκευή/αντικατάσταση PCB","Split / Inverter","ICY II / Supreme / NG families","Cooper&Hunter service manual"),
        Fault("Cooper&Hunter","EU","Περιορισμός συχνότητας λόγω υψηλής θερμοκρασίας module","Frequency limitation due to module high temperature","IPM cooling/load","Έλεγξε module cooling, fan και load","Αποκατάσταση αιτίας υπερθέρμανσης","Split / Inverter","ICY II / Supreme / NG families","Cooper&Hunter service manual"),
        Fault("Cooper&Hunter","C5","Προστασία jumper cap","Jumper cap protection","Jumper/configuration","Έλεγξε jumper και model configuration","Διόρθωσε jumper/configuration","Split / Inverter","ICY II / Supreme / NG families","Cooper&Hunter service manual"),

        Fault("Inventor","E0","Βλάβη αντλίας νερού","Water pump malfunction","Drain pump/float/drain","Έλεγξε pump, float και αποχέτευση","Αποκατάσταση pump/drain","Light Commercial","Inventor commercial platform","Inventor service manual"),
        Fault("Inventor","E1","Προστασία υψηλής πίεσης","High pressure protection","Υψηλή πίεση/airflow/φόρτιση","Έλεγξε πιέσεις, condenser και fan","Αποκατάσταση αιτίας HP","Light Commercial","Inventor commercial platform","Inventor service manual"),
        Fault("Inventor","E2","Αντιπαγωτική προστασία","Indoor anti-freeze protection","Χαμηλή coil temp/airflow","Έλεγξε φίλτρα, fan και ψυκτικό","Αποκατάσταση αιτίας παγώματος","Light Commercial","Inventor commercial platform","Inventor service manual"),
        Fault("Inventor","E3","Προστασία χαμηλής πίεσης","Low pressure protection","Διαρροή/χαμηλή φόρτιση/restriction","Έλεγξε διαρροές και πιέσεις","Επισκευή και σωστή φόρτιση","Light Commercial","Inventor commercial platform","Inventor service manual"),
        Fault("Inventor","E4","Υψηλή θερμοκρασία κατάθλιψης","High compressor discharge temperature","Overheat/refrigerant issue","Έλεγξε discharge temp, πιέσεις και φόρτιση","Αποκατάσταση αιτίας","Light Commercial","Inventor commercial platform","Inventor service manual"),
        Fault("Inventor","E5","Υπερφόρτωση συμπιεστή / inverter","Compressor overload or inverter error","Compressor/IPM/load","Έλεγξε compressor, inverter και ρεύμα","Αποκατάσταση επιβεβαιωμένης αιτίας","Light Commercial","Inventor commercial platform","Inventor service manual"),
        Fault("Inventor","E6","Σφάλμα μετάδοσης","Transmission malfunction","Communication wiring/PCB","Έλεγξε bus και PCB","Αποκατάσταση επικοινωνίας","Light Commercial","Inventor commercial platform","Inventor service manual"),
        Fault("Inventor","E8","Προστασία εσωτερικού ανεμιστήρα","Indoor fan protection","Fan motor/drive","Έλεγξε fan, motor και PCB","Αποκατάσταση fan/drive","Light Commercial","Inventor commercial platform","Inventor service manual"),
        Fault("Inventor","E9","Προστασία ροής νερού","Water flow protection","Flow/drain circuit","Έλεγξε flow switch/pump/drain ανά μοντέλο","Αποκατάσταση ροής","Light Commercial","Inventor commercial platform","Inventor service manual"),
        Fault("Inventor","F0","Βλάβη αισθητήρα επιστροφής αέρα","Indoor return-air sensor malfunction","Thermistor/wiring","Έλεγξε sensor/connector","Αντικατάσταση αισθητήρα","Light Commercial","Inventor commercial platform","Inventor service manual"),
        Fault("Inventor","F1","Βλάβη αισθητήρα εξατμιστή","Evaporator sensor malfunction","Thermistor/wiring","Έλεγξε sensor","Αντικατάσταση αισθητήρα","Light Commercial","Inventor commercial platform","Inventor service manual"),
        Fault("Inventor","F2","Βλάβη αισθητήρα συμπυκνωτή","Condenser sensor malfunction","Thermistor/wiring","Έλεγξε sensor","Αντικατάσταση αισθητήρα","Light Commercial","Inventor commercial platform","Inventor service manual"),
        Fault("Inventor","F3","Βλάβη αισθητήρα εξωτερικού αέρα","Outdoor ambient sensor malfunction","Thermistor/wiring","Έλεγξε sensor","Αντικατάσταση αισθητήρα","Light Commercial","Inventor commercial platform","Inventor service manual"),
        Fault("Inventor","F4","Βλάβη αισθητήρα κατάθλιψης","Discharge sensor malfunction","Thermistor/wiring","Έλεγξε sensor","Αντικατάσταση αισθητήρα","Light Commercial","Inventor commercial platform","Inventor service manual"),
        Fault("Inventor","F5","Βλάβη αισθητήρα χειριστηρίου/display","Display ambient sensor malfunction","Sensor/controller","Έλεγξε controller sensor και wiring","Αποκατάσταση sensor/controller","Light Commercial","Inventor commercial platform","Inventor service manual"),

        Fault("Carrier","SENSOR","Βλάβη αισθητήρα","Temperature sensor fault","Thermistor/wiring ανά OEM πλατφόρμα","Έλεγξε model-specific table και αντίσταση sensor","Αντικατάσταση επιβεβαιωμένου sensor","Split / Inverter","Carrier residential families","Carrier model-specific service data"),
        Fault("Climaveneta","FLOW","Σφάλμα ροής νερού","Water flow alarm","Flow switch, pump, air or strainer","Έλεγξε pump, flow switch, εξαέρωση και φίλτρα","Αποκατάσταση ροής","Chiller / Heat Pump","Climaveneta hydronic families","Climaveneta model-specific service documentation"),
        Fault("Climaveneta","HP","Συναγερμός υψηλής πίεσης","High pressure alarm","High pressure/heat rejection issue","Έλεγξε condenser, water/air flow και refrigerant circuit","Αποκατάσταση αιτίας HP","Chiller / Heat Pump","Climaveneta hydronic families","Climaveneta model-specific service documentation"),
        Fault("Hisense","0","Καμία βλάβη","No trouble","Κανονική κατάσταση","Δεν απαιτείται έλεγχος","Καμία ενέργεια","Split / Inverter","Hisense inverter families","Hisense split/inverter service documentation"),
        Fault("Hisense","1","Βλάβη αισθητήρα εξωτερικού στοιχείου","Outdoor coil temperature sensor fault","Αισθητήρας, καλωδίωση ή outdoor PCB","Μέτρησε thermistor και έλεγξε φίσα/καλωδίωση","Αντικατάσταση αισθητήρα ή επισκευή σύνδεσης","Split / Inverter","Hisense inverter families","Hisense split/inverter service documentation"),
        Fault("Hisense","2","Βλάβη αισθητήρα θερμοκρασίας συμπιεστή","Compressor temperature sensor fault","Discharge/compressor thermistor ή outdoor PCB","Μέτρησε αισθητήρα και έλεγξε connector","Αντικατάσταση αισθητήρα/επισκευή σύνδεσης","Split / Inverter","Hisense inverter families","Hisense split/inverter service documentation"),
        Fault("Hisense","3","Βλάβη μετασχηματιστή τάσης","Voltage transformer fault","Κύκλωμα μέτρησης τάσης ή PCB","Έλεγξε τροφοδοσία και κύκλωμα sensing","Επισκευή/αντικατάσταση επιβεβαιωμένου PCB","Split / Inverter","Hisense inverter families","Hisense split/inverter service documentation"),
        Fault("Hisense","4","Βλάβη μετασχηματιστή ρεύματος","Current transformer fault","CT/current sensing ή PCB","Έλεγξε CT και κύκλωμα μέτρησης ρεύματος","Επισκευή/αντικατάσταση επιβεβαιωμένου εξαρτήματος","Split / Inverter","Hisense inverter families","Hisense split/inverter service documentation"),
        Fault("Hisense","5","Προστασία IPM","IPM module protection","IPM/inverter, συμπιεστής ή υπερένταση","Έλεγξε συμπιεστή, IPM, DC bus και τροφοδοσία","Αποκατάσταση αιτίας προστασίας","Split / Inverter","Hisense inverter families","Hisense split/inverter service documentation"),
        Fault("Hisense","6","Προστασία υπέρτασης / υπότασης","Over/under-voltage protection","Τάση δικτύου ή power PCB","Μέτρησε AC input και DC bus υπό φορτίο","Διόρθωση τροφοδοσίας ή power board","Split / Inverter","Hisense inverter families","Hisense split/inverter service documentation"),
        Fault("Hisense","7","Σφάλμα επικοινωνίας","Communication fault","Communication line, τροφοδοσία ή PCB","Έλεγξε καλωδίωση, πολικότητα και τροφοδοσίες","Αποκατάσταση επικοινωνίας","Split / Inverter","Hisense inverter families","Hisense split/inverter service documentation"),
        Fault("Hisense","8","Προστασία υπερέντασης","Current overload protection","Υψηλό φορτίο, συμπιεστής, inverter ή τάση","Μέτρησε ρεύμα και έλεγξε πιέσεις/τροφοδοσία","Αποκατάσταση αιτίας υπερέντασης","Split / Inverter","Hisense inverter families","Hisense split/inverter service documentation"),
        Fault("Hisense","9","Προστασία μέγιστου ρεύματος","Maximum current protection","Συμπιεστής, inverter ή υπερβολικό φορτίο","Έλεγξε ρεύμα συμπιεστή, inverter και ψυκτικό κύκλωμα","Αποκατάσταση αιτίας","Split / Inverter","Hisense inverter families","Hisense split/inverter service documentation"),
        Fault("Hisense","10","Σφάλμα επικοινωνίας outdoor–driver","Outdoor/driver communication fault","Καλωδίωση ή driver/outdoor PCB","Έλεγξε connectors και communication μεταξύ πλακετών","Επισκευή σύνδεσης ή PCB","Split / Inverter","Hisense inverter families","Hisense split/inverter service documentation"),
        Fault("Hisense","11","Βλάβη EEPROM εξωτερικής","Outdoor EEPROM fault","EEPROM ή outdoor PCB","Power reset και έλεγχος outdoor PCB","Αντικατάσταση/επισκευή PCB αν επιμένει","Split / Inverter","Hisense inverter families","Hisense split/inverter service documentation"),
        Fault("Hisense","13","Υπερβολική θερμοκρασία κατάθλιψης","Compressor discharge temperature too high","Έλλειψη ψυκτικού, περιορισμός, βρώμικος εναλλάκτης ή αισθητήρας","Έλεγξε πιέσεις, φόρτιση, εναλλάκτες και discharge sensor","Αποκατάσταση ψυκτικού/αισθητήρα","Split / Inverter","Hisense inverter families","Hisense split/inverter service documentation"),
        Fault("Hisense","14","Βλάβη αισθητήρα εξωτερικής θερμοκρασίας","Outdoor ambient sensor fault","Thermistor ή outdoor PCB","Μέτρησε αισθητήρα και έλεγξε connector","Αντικατάσταση αισθητήρα","Split / Inverter","Hisense inverter families","Hisense split/inverter service documentation"),
        Fault("Hisense","15","Προστασία θερμοκρασίας κελύφους συμπιεστή","Compressor housing temperature protection","Υπερθέρμανση συμπιεστή ή sensing","Έλεγξε θερμοκρασία, ψυκτικό κύκλωμα και αισθητήρα","Αποκατάσταση αιτίας υπερθέρμανσης","Split / Inverter","Hisense inverter families","Hisense split/inverter service documentation"),
        Fault("Hisense","16","Προστασία αντιπαγετική / overload","Anti-freeze or overload protection","Ροή αέρα, θερμοκρασία στοιχείου, ψυκτικό ή αισθητήρας","Έλεγξε φίλτρα, fan, coil sensor και ψυκτικό κύκλωμα","Αποκατάσταση αιτίας προστασίας","Split / Inverter","Hisense inverter families","Hisense split/inverter service documentation"),
        Fault("Hisense","18","Αποτυχία εκκίνησης DC συμπιεστή","DC compressor fails to start","Συμπιεστής ή IPM/inverter","Έλεγξε winding/μόνωση συμπιεστή και inverter output","Επισκευή inverter ή αντικατάσταση επιβεβαιωμένου συμπιεστή","Split / Inverter","Hisense inverter families","Hisense split/inverter service documentation"),
        Fault("Hisense","19","Αποσυγχρονισμός DC συμπιεστή","DC compressor out of step","Συμπιεστής, inverter ή υπερβολικό φορτίο","Έλεγξε compressor, inverter και λειτουργικές πιέσεις","Αποκατάσταση αιτίας","Split / Inverter","Hisense inverter families","Hisense split/inverter service documentation"),
        Fault("Hisense","33","Βλάβη αισθητήρα θερμοκρασίας χώρου","Room temperature sensor fault","Room thermistor ή wiring","Μέτρησε αισθητήρα και έλεγξε φίσα","Αντικατάσταση αισθητήρα","Split / Inverter","Hisense inverter families","Hisense split/inverter service documentation"),
        Fault("Hisense","34","Βλάβη αισθητήρα εσωτερικού στοιχείου","Indoor coil temperature sensor fault","Coil thermistor ή wiring","Μέτρησε thermistor και έλεγξε connector","Αντικατάσταση αισθητήρα","Split / Inverter","Hisense inverter families","Hisense split/inverter service documentation"),
        Fault("Hisense","35","Σφάλμα επικοινωνίας ενσύρματου χειριστηρίου","Wired controller/indoor communication fault","Remote bus, controller ή indoor PCB","Έλεγξε remote wiring και controller","Αποκατάσταση επικοινωνίας","Split / Inverter","Hisense inverter families","Hisense split/inverter service documentation"),
        Fault("Hisense","36","Σφάλμα επικοινωνίας εσωτερικής–εξωτερικής","Indoor/outdoor communication fault","Interconnect, τροφοδοσία ή PCB","Έλεγξε καλωδίωση, πολικότητα, τάσεις και πλακέτες","Αποκατάσταση επικοινωνίας","Split / Inverter","Hisense inverter families","Hisense split/inverter service documentation"),
        Fault("Hisense","37","Υπερχείλιση αντλίας συμπυκνωμάτων","Drain pump overflow","Drain, pump ή float","Έλεγξε αποχέτευση, αντλία και φλοτέρ","Καθαρισμός/επισκευή αποχέτευσης","Cassette / Ducted","Hisense commercial families","Hisense split/inverter service documentation"),
        Fault("Hisense","38","Βλάβη EEPROM εσωτερικής","Indoor EEPROM fault","Indoor PCB/EEPROM","Power reset και έλεγχος indoor PCB","Επισκευή/αντικατάσταση PCB","Split / Inverter","Hisense inverter families","Hisense split/inverter service documentation"),
        Fault("Hisense","39","Ανωμαλία μοτέρ εσωτερικού ανεμιστήρα","Indoor fan motor abnormal","Fan motor, feedback, obstruction ή PCB","Έλεγξε ελεύθερη περιστροφή, motor, feedback και PCB","Αποκατάσταση fan/PCB","Split / Inverter","Hisense inverter families","Hisense split/inverter service documentation"),
        Fault("Hisense","41","Βλάβη zero-cross detection","Zero-crossing detection fault","Τροφοδοσία ή indoor PCB","Έλεγξε AC input και zero-cross circuit","Επισκευή/αντικατάσταση PCB","Split / Inverter","Hisense inverter families","Hisense split/inverter service documentation"),
        Fault("Hisense","FE","Σφάλμα επικοινωνίας main board–wired controller","Main board/wired controller communication fault","Remote wiring/controller/PCB","Έλεγξε remote bus και connectors","Αποκατάσταση επικοινωνίας","Split / Inverter","Hisense inverter families","Hisense split/inverter service documentation"),
        Fault("Hisense","ER","Σφάλμα επικοινωνίας main board–display","Main board/display communication fault","Display board, harness ή main PCB","Έλεγξε harness και πλακέτες","Επισκευή σύνδεσης ή πλακέτας","Split / Inverter","Hisense inverter families","Hisense split/inverter service documentation"),
        Fault("Hisense","EA","Σφάλμα επικοινωνίας display–control board","Display/control board communication fault","Display board, control board ή harness","Έλεγξε καλωδίωση και connectors","Αποκατάσταση επικοινωνίας","Split / Inverter","Hisense inverter families","Hisense split/inverter service documentation"),
        // ===== DEEP PASS 3: AUX / AERMEC / AIRWELL / ARISTON / BOSCH =====
        Fault("AUX","E0","Προστασία υπερέντασης εσωτερικής","IDU overcurrent protection","Indoor motor ή indoor controller","Έλεγξε μοτέρ, ρεύμα και indoor PCB","Αποκατάσταση motor/controller","Split / Inverter","AUX current platform","AUX official error-code reference"),
        Fault("AUX","E1","Βλάβη αισθητήρα χώρου εσωτερικής","IDU room sensor error","Room sensor/display board/main board","Έλεγξε thermistor και connectors","Αντικατάσταση sensor/board μετά διάγνωση","Split / Inverter","AUX current platform","AUX official error-code reference"),
        Fault("AUX","E2","Βλάβη αισθητήρα συμπυκνωτή εξωτερικής","ODU condenser sensor error","Condenser sensor ή control","Έλεγξε thermistor και connector","Αντικατάσταση sensor/control","Split / Inverter","AUX current platform","AUX official error-code reference"),
        Fault("AUX","E3","Βλάβη αισθητήρα εξατμιστή εσωτερικής","IDU evaporator coil sensor error","Evaporator thermistor ή control","Έλεγξε thermistor και connector","Αντικατάσταση sensor/control","Split / Inverter","AUX current platform","AUX official error-code reference"),
        Fault("AUX","E4","Βλάβη AC/DC μοτέρ","AC or DC motor error","Motor/module/supply","Έλεγξε motor, module και τροφοδοσία","Αποκατάσταση motor/module","Split / Inverter","AUX current platform","AUX official error-code reference"),
        Fault("AUX","E5","Σφάλμα επικοινωνίας εσωτερικής-εξωτερικής","ODU/IDU communication error","Interconnect ή controller","Έλεγξε communication/power cable και controllers","Αποκατάσταση επικοινωνίας","Split / Inverter","AUX current platform","AUX official error-code reference"),
        Fault("AUX","F0","Βλάβη μοτέρ εξωτερικού ανεμιστήρα","ODU fan motor error","Outdoor motor ή PCB","Έλεγξε fan, motor και PCB","Αποκατάσταση fan/PCB","Split / Inverter","AUX current platform","AUX official error-code reference"),
        Fault("AUX","F1","Προστασία module εξωτερικής","ODU module protection","Power module/phase sequence","Έλεγξε module και τροφοδοσία","Αποκατάσταση module/supply","Split / Inverter","AUX current platform","AUX official error-code reference"),
        Fault("AUX","F3","Αποτυχία εκκίνησης ή απώλεια βήματος συμπιεστή","Compressor start failure/out-of-step","Compressor ή drive","Έλεγξε compressor και inverter","Αποκατάσταση compressor/drive","Split / Inverter","AUX current platform","AUX official error-code reference"),
        Fault("AUX","F4","Βλάβη αισθητήρα κατάθλιψης","ODU discharge sensor error","Discharge thermistor","Έλεγξε sensor/connector","Αντικατάσταση αισθητήρα","Split / Inverter","AUX current platform","AUX official error-code reference"),
        Fault("AUX","P2","Προστασία υψηλής πίεσης","High-pressure switch protection","Pressure switch ή outdoor control","Έλεγξε πίεση, airflow και switch","Αποκατάσταση αιτίας HP","Split / Inverter","AUX current platform","AUX official error-code reference"),
        Fault("AUX","P3","Προστασία έλλειψης ψυκτικού","Lack of refrigerant protection","Διαρροή/χαμηλή φόρτιση","Έλεγξε διαρροές και φόρτιση","Επισκευή, κενό και σωστή φόρτιση","Split / Inverter","AUX current platform","AUX official error-code reference"),

        Fault("Airwell","E0","EEPROM εσωτερικής κενό ή κατεστραμμένο","Indoor EEPROM empty/damaged","EEPROM/PCB","Power reset και έλεγχος PCB","Επισκευή/αντικατάσταση PCB","Split / Inverter","YDAA platform","Airwell SAV official alarm table"),
        Fault("Airwell","E1","Χωρίς επικοινωνία εσωτερικής-εξωτερικής","No communication between IDU and ODU","Interconnect, supply ή PCB","Έλεγξε wiring, τροφοδοσίες και PCB","Αποκατάσταση επικοινωνίας","Split / Inverter","YDAA platform","Airwell SAV official alarm table"),
        Fault("Airwell","E2","Προστασία zero crossing","Zero-crossing protection","AC input/zero-cross circuit","Έλεγξε τροφοδοσία και PCB","Αποκατάσταση supply/PCB","Split / Inverter","YDAA platform","Airwell SAV official alarm table"),
        Fault("Airwell","E3","Βλάβη εσωτερικού ανεμιστήρα","Faulty indoor fan motor","Fan motor/feedback/PCB","Έλεγξε fan, motor και PCB","Αποκατάσταση fan/PCB","Split / Inverter","YDAA platform","Airwell SAV official alarm table"),
        Fault("Airwell","E4","Βλάβη αισθητήρα χώρου T1","Indoor ambient sensor T1 open/short","T1 sensor ή wiring","Έλεγξε thermistor/connector","Αντικατάσταση αισθητήρα","Split / Inverter","YDAA platform","Airwell SAV official alarm table"),
        Fault("Airwell","E5","Βλάβη αισθητήρα εναλλάκτη T2","Indoor exchanger sensor T2 open/short","T2 sensor ή wiring","Έλεγξε thermistor/connector","Αντικατάσταση αισθητήρα","Split / Inverter","YDAA platform","Airwell SAV official alarm table"),
        Fault("Airwell","EC","Προστασία ψυκτικού κυκλώματος","Refrigerant circuit protection","Leak/charge/refrigeration fault","Έλεγξε πιέσεις, διαρροές και φόρτιση","Αποκατάσταση ψυκτικού κυκλώματος","Split / Inverter","YDAA platform","Airwell SAV official alarm table"),
        Fault("Airwell","P0","Προστασία IPM / υψηλού ρεύματος","IPM/high-current protection","Power board, IPM ή compressor","Έλεγξε IPM, DC bus και compressor","Αποκατάσταση επιβεβαιωμένης αιτίας","Split / Inverter","YDAA platform","Airwell SAV official alarm table"),
        Fault("Airwell","P1","Προστασία υπέρτασης/υπότασης","Over/under-voltage protection","Supply/DC bus","Μέτρησε input και DC bus","Αποκατάσταση τροφοδοσίας","Split / Inverter","YDAA platform","Airwell SAV official alarm table"),
        Fault("Airwell","P4","Πρόβλημα IPM συμπιεστή","Compressor IPM problem","IPM/compressor/drive","Έλεγξε module και compressor","Αποκατάσταση IPM/drive","Split / Inverter","YDAA platform","Airwell SAV official alarm table"),

        Fault("Bosch","E1","Λάθος ακολουθία φάσεων","Phase sequence error","Τριφασική τροφοδοσία","Έλεγξε phase sequence και τάσεις","Διόρθωσε ακολουθία φάσεων","Commercial / VRF","Bosch commercial AC","Bosch official error-code reference"),
        Fault("Bosch","E2","Σφάλμα επικοινωνίας εσωτερικής-master","Communication error between indoor and master unit","Bus/addressing/wiring","Έλεγξε communication bus και addressing","Αποκατάσταση επικοινωνίας","Commercial / VRF","Bosch commercial AC","Bosch official error-code reference"),
        Fault("Bosch","E4","Βλάβη αισθητήρα T3/T4","T3/T4 temperature sensor error","Thermistor ή wiring","Έλεγξε T3/T4 και connectors","Αντικατάσταση αισθητήρα","Commercial / VRF","Bosch commercial AC","Bosch official error-code reference"),
        Fault("Bosch","E5","Ανώμαλη τάση τροφοδοσίας","Abnormal power supply voltage","Supply voltage out of range","Μέτρησε τριφασική παροχή","Αποκατάσταση τροφοδοσίας","Commercial / VRF","Bosch commercial AC","Bosch official error-code reference"),
        Fault("Bosch","E7","Βλάβη αισθητήρα κατάθλιψης","Discharge temperature sensor error","Discharge thermistor/wiring","Έλεγξε sensor/connector","Αντικατάσταση αισθητήρα","Commercial / VRF","Bosch commercial AC","Bosch official error-code reference"),
        Fault("Bosch","E8","Σφάλμα διεύθυνσης εξωτερικής","Outdoor unit address error","Address/configuration","Έλεγξε addressing","Διόρθωσε address/configuration","Commercial / VRF","Bosch commercial AC","Bosch official error-code reference"),
        Fault("Bosch","F3","Βλάβη αισθητήρα T6B","T6B temperature sensor error","Thermistor/wiring","Έλεγξε T6B","Αντικατάσταση αισθητήρα","Commercial / VRF","Bosch commercial AC","Bosch official error-code reference"),
        Fault("Bosch","F5","Βλάβη αισθητήρα T6A","T6A temperature sensor error","Thermistor/wiring","Έλεγξε T6A","Αντικατάσταση αισθητήρα","Commercial / VRF","Bosch commercial AC","Bosch official error-code reference"),
        Fault("Bosch","F6","Σφάλμα σύνδεσης ηλεκτρονικής εκτονωτικής","Electronic expansion valve connection error","EXV wiring/coil","Έλεγξε EXV coil και connector","Αποκατάσταση EXV/wiring","Commercial / VRF","Bosch commercial AC","Bosch official error-code reference"),

        Fault("Aermec","COMM","Σφάλμα επικοινωνίας μονάδων/controller","Unit/controller communication fault","Bus, wiring, addressing ή controller ανά σειρά","Έλεγξε model-specific alarm history, bus και addressing","Αποκατάσταση επικοινωνίας σύμφωνα με service manual","Chiller / Heat Pump / FCU","Aermec families","Aermec model-specific service documentation"),
        Fault("Aermec","FLOW","Σφάλμα ροής νερού","Water flow fault","Flow switch, pump, air or blocked strainer","Έλεγξε pump, flow switch, εξαέρωση και φίλτρο","Αποκατάσταση σωστής ροής","Chiller / Heat Pump","Aermec hydronic families","Aermec model-specific service documentation"),
        Fault("Ariston","FLOW","Ανεπαρκής ροή νερού","Insufficient water flow","Pump, air, filter or valves","Έλεγξε κυκλοφορητή, εξαέρωση, φίλτρα και βάνες","Αποκατάσταση ροής","Heat Pump","Ariston Nimbus families","Ariston model-specific service documentation"),
        Fault("Ariston","SENSOR","Βλάβη αισθητήρα θερμοκρασίας","Temperature sensor fault","NTC/wiring ανά μοντέλο","Έλεγξε model-specific sensor και αντίσταση","Αντικατάσταση επιβεβαιωμένου sensor","Heat Pump","Ariston Nimbus families","Ariston model-specific service documentation"),
        // ===== DEEP PASS 2ND FIVE: FUJITSU / HITACHI / LG / PANASONIC / CARRIER =====
        Fault("Fujitsu","11.1","Σφάλμα αντίστροφης σειριακής επικοινωνίας κατά την εκκίνηση","Serial reverse transmission error at startup","Καλωδίωση επικοινωνίας, outdoor PCB ή τροφοδοσία","Έλεγξε interconnect, πολικότητα/τερματικά, τροφοδοσίες και outdoor PCB","Αποκατάσταση επικοινωνίας","Split / Inverter","ASEH KGTG / modern Fujitsu platform","Fujitsu General official service manual"),
        Fault("Fujitsu","11.2","Σφάλμα αντίστροφης σειριακής επικοινωνίας κατά τη λειτουργία","Serial reverse transmission error during operation","Διακοπτόμενη επικοινωνία, wiring ή outdoor PCB","Έλεγξε communication line, connectors και outdoor PCB","Αποκατάσταση επικοινωνίας","Split / Inverter","ASEH KGTG / modern Fujitsu platform","Fujitsu General official service manual"),
        Fault("Fujitsu","11.3","Σφάλμα προωθημένης σειριακής επικοινωνίας κατά την εκκίνηση","Serial forward transmission error at startup","Indoor communication circuit/wiring","Έλεγξε interconnect, indoor PCB και τροφοδοσίες","Αποκατάσταση επικοινωνίας","Split / Inverter","ASEH KGTG / modern Fujitsu platform","Fujitsu General official service manual"),
        Fault("Fujitsu","11.4","Σφάλμα προωθημένης σειριακής επικοινωνίας κατά τη λειτουργία","Serial forward transmission error during operation","Indoor communication circuit/wiring","Έλεγξε wiring, connectors και indoor PCB","Αποκατάσταση επικοινωνίας","Split / Inverter","ASEH KGTG / modern Fujitsu platform","Fujitsu General official service manual"),
        Fault("Fujitsu","18.1","Σφάλμα εξωτερικής επικοινωνίας 1","External communication 1 error","External communication interface/wiring","Έλεγξε interface, bus και connectors","Αποκατάσταση επικοινωνίας","Split / Inverter","ASEH KGTG / modern Fujitsu platform","Fujitsu General official service manual"),
        Fault("Fujitsu","22.1","Σφάλμα ισχύος εσωτερικής μονάδας","Indoor unit capacity error","Λάθος combination/capacity setting","Έλεγξε συνδυασμό IDU/ODU και capacity settings","Διόρθωσε combination/configuration","Split / Inverter","ASEH KGTG / modern Fujitsu platform","Fujitsu General official service manual"),
        Fault("Fujitsu","23.1","Απαγορευμένος συνδυασμός σειράς","Connection forbidden / series error","Μη συμβατός συνδυασμός μονάδων","Έλεγξε ακριβή model combination","Χρησιμοποίησε συμβατό συνδυασμό","Split / Inverter","ASEH KGTG / modern Fujitsu platform","Fujitsu General official service manual"),
        Fault("Fujitsu","23.2","Σφάλμα συνδυασμού μονάδων","Unit combination error","Λάθος IDU/ODU combination","Έλεγξε model/capacity combination","Διόρθωσε combination","Split / Inverter","ASEH KGTG / modern Fujitsu platform","Fujitsu General official service manual"),

        Fault("LG","CH04","Πρόβλημα αποχέτευσης συμπυκνωμάτων","Drainage problem","Drain, condensate level, pump ή float ανά τύπο","Έλεγξε drain line, pump/float και στάθμη συμπυκνωμάτων","Καθαρισμός/επισκευή αποχέτευσης","Ceiling / Portable / Window","LG Air Conditioner families","LG official Support 2026"),
        Fault("LG","CH07","Σύγκρουση τρόπου λειτουργίας","Operation mode conflict","Μία εσωτερική ζητά θέρμανση ενώ άλλη ψύξη/αφύγρανση","Έλεγξε modes όλων των εσωτερικών","Ρύθμισε όλες σε συμβατό mode","Multi Split","LG Multi Split","LG official Support 2026"),
        Fault("LG","CH38","Χαμηλή ποσότητα ψυκτικού","Low refrigerant detection","Χαμηλή φόρτιση/διαρροή","Έλεγξε στεγανότητα, πιέσεις και φόρτιση","Επισκευή διαρροής, κενό και σωστή φόρτιση","Split / Inverter","LG residential AC","LG official Support 2026"),
        Fault("LG","CH66","Σφάλμα επικοινωνίας ή σύνδεσης σωληνώσεων","Communication or piping connection issue","Interconnect/piping mismatch ή προσωρινή ηλεκτρική ανωμαλία","Έλεγξε καλωδίωση, piping connections και τροφοδοσίες","Διόρθωσε σύνδεση ή διάγνωση αν επιμένει","Split / Inverter","LG inverter models","LG official Support 2026"),
        Fault("LG","CH67","Βλάβη ανεμιστήρα εξωτερικής","Outdoor fan problem","Outdoor fan, obstruction ή drive","Έλεγξε για εμπόδια, fan motor και drive","Αποκατάσταση fan/drive","Split / Inverter","LG residential AC","LG official Support 2026"),
        Fault("LG","CH90","Σφάλμα test run / σύνδεσης σωληνώσεων","Test-run piping connection error","Piping connection/install issue","Έλεγξε piping connections και installation","Διόρθωσε εγκατάσταση και επανάλαβε test run","Split / Inverter","LG residential AC","LG official Support 2026"),
        Fault("LG","CH91","Σφάλμα test run / σύνδεσης σωληνώσεων","Test-run piping connection error","Piping connection/install issue","Έλεγξε piping connections και installation","Διόρθωσε εγκατάσταση και επανάλαβε test run","Split / Inverter","LG residential AC","LG official Support 2026"),
        Fault("LG","CH93","Σφάλμα επικοινωνίας εσωτερικής-εξωτερικής","Indoor/outdoor communication problem","Communication unstable ή outdoor unit χωρίς τροφοδοσία σε νεότερα μοντέλα","Έλεγξε interconnect και τροφοδοσία και των δύο μονάδων","Αποκατάσταση επικοινωνίας/τροφοδοσίας","Split / Inverter","LG models incl. post-2021","LG official Support 2026"),

        // Hitachi / Panasonic / Carrier already contain model/platform entries from the first pass.
        // Add conservative diagnostic records only where they improve coverage without inventing cross-platform numeric meanings.
        Fault("Hitachi","COMM","Σφάλμα επικοινωνίας μονάδων","Unit communication fault","Interconnect, addressing, τροφοδοσία ή PCB ανά σειρά","Έλεγξε ακριβή blink/error indication του μοντέλου, wiring και PCB","Αποκατάσταση communication fault βάσει model service manual","Split / Multi / VRF","Hitachi RAC/RAS/RAM families","Hitachi model-specific service documentation"),
        Fault("Hitachi","SENSOR","Βλάβη αισθητήρα θερμοκρασίας","Temperature sensor fault","Thermistor ή wiring ανά σειρά","Ταυτοποίησε ακριβή sensor από blink/error table και μέτρησε αντίσταση","Αντικατάσταση επιβεβαιωμένου αισθητήρα/σύνδεσης","Split / Multi / VRF","Hitachi RAC/RAS/RAM families","Hitachi model-specific service documentation"),

        Fault("Panasonic","H11","Ανωμαλία επικοινωνίας εσωτερικής-εξωτερικής","Indoor/outdoor abnormal communication","Communication wiring, indoor/outdoor PCB ή τροφοδοσία","Έλεγξε interconnect, τάσεις και PCB","Αποκατάσταση επικοινωνίας","Split / Inverter","Panasonic RAC","Panasonic service manual"),
        Fault("Panasonic","H19","Μπλοκάρισμα μοτέρ εσωτερικού ανεμιστήρα","Indoor fan motor mechanism locked","Fan motor, obstruction ή PCB","Έλεγξε ελεύθερη περιστροφή, motor και drive","Αποκατάσταση fan/PCB","Split / Inverter","Panasonic RAC","Panasonic service manual"),
        Fault("Panasonic","H97","Μπλοκάρισμα μοτέρ εξωτερικού ανεμιστήρα","Outdoor fan motor mechanism locked","Fan motor, obstruction ή PCB","Έλεγξε fan, motor και outdoor PCB","Αποκατάσταση fan/PCB","Split / Inverter","Panasonic RAC","Panasonic service manual"),
        Fault("Panasonic","H99","Προστασία παγώματος εσωτερικού εναλλάκτη","Indoor heat exchanger freeze protection","Χαμηλό airflow, χαμηλή φόρτιση ή sensor","Έλεγξε φίλτρα, fan, coil temp και ψυκτικό","Αποκατάσταση αιτίας παγώματος","Split / Inverter","Panasonic RAC","Panasonic service manual"),
        Fault("Panasonic","F91","Ανωμαλία ψυκτικού κύκλου","Refrigeration cycle abnormality","Χαμηλή φόρτιση, restriction ή cycle fault","Έλεγξε πιέσεις, διαρροές, φόρτιση και restriction","Αποκατάσταση ψυκτικού κυκλώματος","Split / Inverter","Panasonic RAC","Panasonic service manual"),
        Fault("Panasonic","F93","Ανωμαλία περιστροφής συμπιεστή","Compressor rotation abnormality","Compressor ή inverter drive","Έλεγξε compressor, inverter και τροφοδοσία","Αποκατάσταση drive/compressor","Split / Inverter","Panasonic RAC","Panasonic service manual"),
        Fault("Panasonic","F99","Προστασία DC peak","DC peak detection protection","IPM/inverter, compressor ή overcurrent","Έλεγξε IPM, DC bus και compressor","Αποκατάσταση επιβεβαιωμένης αιτίας","Split / Inverter","Panasonic RAC","Panasonic service manual"),

        Fault("Carrier","COMM","Σφάλμα επικοινωνίας εσωτερικής-εξωτερικής","Indoor/outdoor communication fault","Interconnect, power or PCB depending on OEM platform","Έλεγξε model-specific error table, wiring και τροφοδοσίες","Αποκατάσταση επικοινωνίας βάσει συγκεκριμένου μοντέλου","Split / Inverter","Carrier residential inverter families","Carrier model-specific service documentation"),
        Fault("Carrier","REFRIG","Προστασία ψυκτικού κυκλώματος","Refrigerant circuit protection","High/low pressure, refrigerant charge or restriction","Έλεγξε πραγματικές πιέσεις, φόρτιση, airflow και restriction","Αποκατάσταση επιβεβαιωμένης αιτίας","Split / Inverter","Carrier residential inverter families","Carrier model-specific service documentation"),
        // ===== DEEP PASS 1ST FIVE: DAIKIN / MITSUBISHI ELECTRIC / MIDEA / GREE / HAIER =====
        Fault("Daikin","A0","Ενεργοποίηση εξωτερικής διάταξης προστασίας","External protection device activated","Εξωτερική προστασία στο T1-T2 ενεργοποιήθηκε","Έλεγξε εξωτερική διάταξη προστασίας, T1-T2 και καλωδίωση","Αποκατάσταση αιτίας εξωτερικής προστασίας","SkyAir / VRV / Package","Daikin commercial families","Daikin official Simple Self-Diagnosis"),
        Fault("Daikin","A4","Βλάβη προστασίας παγετού / κυκλώματος νερού","Freezing protection malfunction","Χαμηλή παροχή νερού, χαμηλό setpoint ή water thermistor","Έλεγξε water flow, setpoint και thermistor","Αποκατάσταση ροής/setpoint/αισθητήρα","Chiller / Fan Coil / Package","Daikin hydronic/commercial","Daikin official Simple Self-Diagnosis"),
        Fault("Daikin","A7","Βλάβη μοτέρ περσίδας","Swing flap motor malfunction","Swing motor, PCB, καλώδιο ή flap cam","Έλεγξε μοτέρ περσίδας, connector, PCB και μηχανισμό","Αποκατάσταση μοτέρ/καλωδίωσης/μηχανισμού","SkyAir / VRV","Daikin commercial indoor","Daikin official Simple Self-Diagnosis"),
        Fault("Daikin","A8","Βλάβη τροφοδοσίας / AC input overcurrent","Power supply or AC input overcurrent malfunction","Τάση τροφοδοσίας ή signal-line connection","Μέτρησε τάση και έλεγξε συνδέσεις","Αποκατάσταση τροφοδοσίας/σύνδεσης","Commercial","Daikin commercial families","Daikin official Simple Self-Diagnosis"),
        Fault("Daikin","AH","Βλάβη ηλεκτρικού καθαριστή αέρα","Electrical air cleaner abnormal","Air-cleaner assembly ή control","Έλεγξε air-cleaner unit, connectors και PCB","Αποκατάσταση air-cleaner/control","Split / Inverter","Daikin room AC","Daikin official operation manual"),
        Fault("Daikin","C4","Βλάβη thermistor εσωτερικού εναλλάκτη 1","Indoor heat exchanger thermistor 1 open/short","Thermistor ή wiring","Έλεγξε αντίσταση thermistor και connector","Αντικατάσταση αισθητήρα/σύνδεσης","Split / Inverter","Daikin room AC","Daikin official operation manual"),
        Fault("Daikin","C5","Βλάβη thermistor εσωτερικού εναλλάκτη 2","Indoor heat exchanger thermistor 2 open/short","Thermistor ή wiring","Έλεγξε αντίσταση thermistor και connector","Αντικατάσταση αισθητήρα/σύνδεσης","Split / Inverter","Daikin room AC","Daikin official operation manual"),
        Fault("Daikin","C9","Βλάβη thermistor χώρου","Indoor room thermistor open/short","Room thermistor ή wiring","Έλεγξε thermistor και connector","Αντικατάσταση αισθητήρα","Split / Inverter","Daikin room AC","Daikin official operation manual"),
        Fault("Daikin","E3","Προστασία υψηλής πίεσης","High pressure protection","Υψηλή πίεση/airflow/φόρτιση","Έλεγξε πιέσεις, condenser, fan και φόρτιση","Αποκατάσταση αιτίας υψηλής πίεσης","Split / Inverter","Daikin room AC","Daikin official operation manual"),
        Fault("Daikin","E4","Προστασία χαμηλής πίεσης","Low pressure protection","Διαρροή, χαμηλή φόρτιση ή περιορισμός","Έλεγξε διαρροές, πιέσεις και restriction","Επισκευή και σωστή φόρτιση","Split / Inverter","Daikin room AC","Daikin official operation manual"),
        Fault("Daikin","E5","Μπλοκάρισμα / υπερφόρτωση συμπιεστή","Compressor motor lock / overload","Compressor, drive ή φορτίο","Έλεγξε compressor, ρεύμα, πιέσεις και inverter","Αποκατάσταση επιβεβαιωμένης αιτίας","Split / Inverter","Daikin room AC","Daikin official operation manual"),
        Fault("Daikin","E6","Σφάλμα εκκίνησης συμπιεστή","Compressor startup error","Compressor ή inverter","Έλεγξε τυλίγματα, insulation και drive","Αποκατάσταση compressor/drive","Split / Inverter","Daikin room AC","Daikin official operation manual"),
        Fault("Daikin","E7","Μπλοκάρισμα DC ανεμιστήρα εξωτερικής","Outdoor DC fan motor lock","Fan motor, obstruction ή drive","Έλεγξε fan, motor και PCB","Αποκατάσταση fan/drive","Split / Inverter","Daikin room AC","Daikin official operation manual"),
        Fault("Daikin","E8","Υπερένταση AC εισόδου","AC input overcurrent","Τροφοδοσία ή υψηλό φορτίο","Έλεγξε τάση/ρεύμα και φορτίο","Αποκατάσταση ηλεκτρικής/ψυκτικής αιτίας","Split / Inverter","Daikin room AC","Daikin official operation manual"),
        Fault("Daikin","E9","Βλάβη ηλεκτρονικής εκτονωτικής","EXV error","EXV coil, wiring ή valve","Έλεγξε coil, connector και λειτουργία EXV","Αποκατάσταση EXV/control","Split / Inverter","Daikin room AC","Daikin official operation manual"),
        Fault("Daikin","EA","Βλάβη τετράοδης βαλβίδας","4-way valve error","4-way valve, coil ή control","Έλεγξε coil, τάση και αλλαγή κύκλου","Αποκατάσταση valve/coil/control","Split / Inverter","Daikin room AC","Daikin official operation manual"),
        Fault("Daikin","F3","Υπερθέρμανση σωλήνα κατάθλιψης","Discharge pipe overheat","Χαμηλή φόρτιση, restriction ή cooling issue","Έλεγξε discharge temp, πιέσεις και φόρτιση","Αποκατάσταση αιτίας υπερθέρμανσης","Split / Inverter","Daikin room AC","Daikin official operation manual"),
        Fault("Daikin","F6","Υπερθέρμανση εναλλάκτη","Heat exchanger overheat","Airflow/heat rejection ή φόρτιση","Έλεγξε εναλλάκτη, fan, airflow και φόρτιση","Αποκατάσταση αιτίας","Split / Inverter","Daikin room AC","Daikin official operation manual"),
        Fault("Daikin","H3","Βλάβη διακόπτη υψηλής πίεσης","High pressure switch error","Pressostat ή wiring","Έλεγξε πραγματική πίεση, switch και wiring","Αντικατάσταση switch/αποκατάσταση αιτίας","Split / Inverter","Daikin room AC","Daikin official operation manual"),
        Fault("Daikin","H6","Σφάλμα feedback συμπιεστή","Compressor feedback detection error","Compressor/inverter feedback","Έλεγξε compressor, wiring και inverter","Αποκατάσταση drive/compressor","Split / Inverter","Daikin room AC","Daikin official operation manual"),
        Fault("Daikin","H8","Βλάβη αισθητήρα AC ρεύματος","AC current sensor error","Current sensor ή PCB","Έλεγξε current sensing circuit","Επισκευή/αντικατάσταση PCB/sensor","Split / Inverter","Daikin room AC","Daikin official operation manual"),

        Fault("Midea","F4","Βλάβη EEPROM εξωτερικής","Outdoor EEPROM parameter error","Outdoor PCB/EEPROM","Power reset και έλεγχος outdoor PCB","Επισκευή/αντικατάσταση PCB","Split / Inverter","MS11M / related inverter","Midea service manual"),
        Fault("Midea","F5","Ταχύτητα εξωτερικού ανεμιστήρα εκτός ελέγχου","Outdoor fan speed out of control","Fan motor, feedback ή PCB","Έλεγξε fan, motor, feedback και PCB","Αποκατάσταση fan/PCB","Split / Inverter","MS11M / related inverter","Midea service manual"),
        Fault("Midea","EC","Ανίχνευση διαρροής ψυκτικού","Refrigerant leakage detection","Διαρροή ή ανεπαρκής φόρτιση","Έλεγξε διαρροές, πιέσεις και φόρτιση","Επισκευή διαρροής, κενό και φόρτιση","Split / Inverter","MS11M / related inverter","Midea service manual"),
        Fault("Midea","F0","Προστασία υπερέντασης","Overload current protection","Υψηλό φορτίο/ρεύμα ή compressor","Έλεγξε ρεύμα, τάση, πιέσεις και compressor","Αποκατάσταση αιτίας overload","Split / Inverter","MS11M / related inverter","Midea service manual"),
        Fault("Midea","P6","Προστασία χαμηλής πίεσης","Low pressure protection","Χαμηλή φόρτιση, διαρροή ή restriction","Έλεγξε πιέσεις, διαρροές και ψυκτικό κύκλωμα","Επισκευή και σωστή φόρτιση","Split / Inverter","MS11M / related inverter","Midea service manual"),
        Fault("Midea","P5","Σύγκρουση λειτουργίας εσωτερικών","Indoor units mode conflict","Αντίθετα modes σε multi-zone","Έλεγξε mode όλων των IDU","Ρύθμισε συμβατό mode","Multi-Split","Midea multi-zone","Midea multi service manual"),

        Fault("Gree","E8","Προστασία υψηλής θερμοκρασίας","Anti-high temperature protection","Υψηλή coil temp/airflow ή φορτίο","Έλεγξε airflow, coil, sensor και πιέσεις","Αποκατάσταση αιτίας υπερθέρμανσης","Duct / Split","Gree duct-free / multi","Gree official manual"),

        Fault("Haier","E9","Υπερφόρτωση εσωτερικής στη θέρμανση","Indoor overload in heating mode","Υψηλή coil temp/airflow ή control","Έλεγξε airflow, coil sensors και λειτουργικές πιέσεις","Αποκατάσταση αιτίας overload","Split / Inverter","Haier inverter families","Haier official error table"),
        Fault("Haier","F8","Βλάβη DC ανεμιστήρα εξωτερικής","Outdoor DC fan motor malfunction","Fan motor, feedback ή PCB","Έλεγξε fan, motor, connector και PCB","Αποκατάσταση fan/PCB","Split / Inverter","Haier inverter families","Haier official error table"),
        Fault("Haier","F9","Reset module","Module reset fault","Power module/control reset","Έλεγξε τροφοδοσία, module και connectors","Αποκατάσταση module/control","Split / Inverter","Haier inverter families","Haier official error table"),
        Fault("Haier","F11","Απώλεια συγχρονισμού συμπιεστή","Compressor loss of synchronism","Compressor, inverter ή supply","Έλεγξε compressor, inverter και τάση","Αποκατάσταση επιβεβαιωμένης αιτίας","Split / Inverter","Haier inverter families","Haier official error table"),
        Fault("Haier","F19","Υπέρταση / υπόταση τροφοδοσίας","Power over/under voltage protection","Τάση εκτός ορίων","Μέτρησε input voltage και DC bus","Αποκατάσταση τροφοδοσίας","Split / Inverter","Haier inverter families","Haier official error table"),
        Fault("Haier","F21","Βλάβη αισθητήρα εξωτερικού στοιχείου","Outdoor coil temperature sensor fault","Thermistor ή wiring","Έλεγξε sensor/connector","Αντικατάσταση αισθητήρα","Split / Inverter","Haier inverter families","Haier official error table"),
        Fault("Haier","F22","Υπερένταση AC εξωτερικής","Outdoor AC overcurrent protection","Υψηλό ρεύμα/φορτίο","Έλεγξε τάση, ρεύμα, compressor και inverter","Αποκατάσταση αιτίας","Split / Inverter","Haier inverter families","Haier official error table"),
        Fault("Haier","F23","Υπερένταση φάσης συμπιεστή","Compressor phase overcurrent","Compressor/inverter","Έλεγξε phase currents, compressor και module","Αποκατάσταση επιβεβαιωμένης αιτίας","Split / Inverter","Haier inverter families","Haier official error table"),
        Fault("Haier","F24","Ανωμαλία ανίχνευσης ρεύματος CT","CT current detection abnormal","Current sensing circuit/PCB","Έλεγξε CT/current sensing και PCB","Επισκευή/αντικατάσταση PCB","Split / Inverter","Haier inverter families","Haier official error table"),
        Fault("Haier","F25","Βλάβη αισθητήρα κατάθλιψης","Compressor discharge sensor abnormal","Discharge thermistor ή wiring","Έλεγξε sensor/connector","Αντικατάσταση αισθητήρα","Split / Inverter","Haier inverter families","Haier official error table"),
        Fault("Haier","F27","Βλάβη κυκλώματος δειγματοληψίας ρεύματος συμπιεστή","Compressor current sampling circuit fault","Outdoor PCB/current sensing","Έλεγξε current sampling circuit και PCB","Επισκευή/αντικατάσταση PCB","Split / Inverter","Haier inverter families","Haier official error table"),
        Fault("Haier","F28","Βλάβη κυκλώματος ανίχνευσης θέσης συμπιεστή","Compressor position detection circuit fault","Inverter/position detection circuit","Έλεγξε inverter, compressor wiring και PCB","Αποκατάσταση drive/PCB","Split / Inverter","Haier inverter families","Haier official error table"),
        Fault("Haier","F35","Βλάβη πλακέτας οδήγησης συμπιεστή","Compressor driver board failure","Driver board","Έλεγξε driver board και compressor","Αντικατάσταση/επισκευή driver board","Split / Inverter","Haier inverter families","Haier official error table"),
        Fault("Haier","F43","Ασυμφωνία μοντέλου","Model matching abnormality","Λάθος combination/configuration","Έλεγξε model matching και configuration","Διόρθωσε configuration/συνδυασμό","Split / Inverter","Haier inverter families","Haier official error table"),
        // ===== GOOGLE/MANUAL SEARCH: F&U + UNITED NUMERIC ERROR CODES =====
        Fault("F&U","E2","Βλάβη αισθητήρα θερμοκρασίας χώρου","Room temperature sensor failure","Αισθητήρας χώρου ή σύνδεση","Έλεγξε thermistor και connector","Αντικατάσταση αισθητήρα/σύνδεσης","Split / Inverter","FVIN-09080/FVOT-09081 family","F&U Installation & Repair Guide"),
        Fault("F&U","E3","Βλάβη αισθητήρα σωλήνα/στοιχείου","Coiled pipe sensor failure","Coil thermistor ή σύνδεση","Έλεγξε thermistor και connector","Αντικατάσταση αισθητήρα","Split / Inverter","FVIN-09080/FVOT-09081 family","F&U Installation & Repair Guide"),
        Fault("F&U","E4","Ανωμαλία εξωτερικής μονάδας","Outdoor unit abnormality","Outdoor protection/control fault","Έλεγξε outdoor diagnostics, τροφοδοσία, αισθητήρες και PCB","Αποκατάσταση επιβεβαιωμένης outdoor βλάβης","Split / Inverter","FVIN-09080/FVOT-09081 family","F&U Installation & Repair Guide"),
        Fault("F&U","E5","Χωρίς feedback μοτέρ εσωτερικού ανεμιστήρα","No internal fan motor feedback","Fan motor, feedback ή PCB","Έλεγξε fan, connector, feedback και PCB","Αποκατάσταση fan/PCB","Split / Inverter","FVIN-09080/FVOT-09081 family","F&U Installation & Repair Guide"),
        Fault("F&U","E6","Απουσία zero-crossing signal","Zero crossing signal without current","Τροφοδοσία/zero-cross circuit ή PCB","Έλεγξε AC supply και zero-cross circuit στην PCB","Αποκατάσταση τροφοδοσίας/PCB","Split / Inverter","FVIN-09080/FVOT-09081 family","F&U Installation & Repair Guide"),
        Fault("F&U","E7","Βλάβη εξωτερικού feedback","External feedback failure","Outdoor feedback/control circuit","Έλεγξε outdoor feedback, wiring και PCB","Αποκατάσταση outdoor control","Split / Inverter","FVIN-09080/FVOT-09081 family","F&U Installation & Repair Guide"),
        Fault("F&U","E8","Προστασία υπερθέρμανσης","Overheat protection","Υψηλή θερμοκρασία/ανεπαρκής απόρριψη θερμότητας","Έλεγξε airflow, εναλλάκτες, αισθητήρες και ψυκτικό κύκλωμα","Αποκατάσταση αιτίας υπερθέρμανσης","Split / Inverter","FVIN-09080/FVOT-09081 family","F&U Installation & Repair Guide"),
        Fault("F&U","E9","Βλάβη αντλίας νερού","Water pump failure","Pump, drain ή float","Έλεγξε pump, drain και float","Αποκατάσταση αποχέτευσης/αντλίας","Split / Inverter","FVIN-09080/FVOT-09081 family","F&U Installation & Repair Guide"),
        Fault("F&U","dF","Απόψυξη","Defrost indication","Κανονικός κύκλος απόψυξης","Επιβεβαίωσε ότι ολοκληρώνεται και επιστρέφει σε θέρμανση","Καμία επέμβαση αν λειτουργεί φυσιολογικά","Split / Inverter","FVIN-09080/FVOT-09081 family","F&U Installation & Repair Guide"),

        Fault("United","E1","Βλάβη αισθητήρα θερμοκρασίας χώρου εσωτερικής","Indoor room temperature sensor failure","IDU RT sensor ή PCB","Έλεγξε thermistor και PCB connection","Αντικατάσταση αισθητήρα/PCB","Split / Inverter","United inverter platform","United/UA error-code documentation"),
        Fault("United","E2","Βλάβη αισθητήρα στοιχείου εσωτερικής","Indoor coil temperature sensor failure","IDU IPT sensor ή PCB","Έλεγξε thermistor και connector","Αντικατάσταση αισθητήρα/PCB","Split / Inverter","United inverter platform","United/UA error-code documentation"),
        Fault("United","E3","Βλάβη αισθητήρα στοιχείου εξωτερικής","Outdoor coil temperature sensor failure","ODU OPT sensor ή outdoor PCB","Έλεγξε thermistor και outdoor PCB connection","Αντικατάσταση αισθητήρα/PCB","Split / Inverter","United inverter platform","United/UA error-code documentation"),
        Fault("United","E5","Προστασία υπερφόρτωσης συμπιεστή","Compressor overload protection","Ανωμαλία ψυκτικού συστήματος/υψηλό φορτίο","Έλεγξε πιέσεις, airflow, ρεύμα και compressor","Αποκατάσταση αιτίας overload","Split / Inverter","United inverter platform","United/UA error-code documentation"),
        Fault("United","E6","Ανωμαλία μοτέρ εσωτερικού ανεμιστήρα","Indoor PG/DC fan motor abnormal","Motor, blade ή PCB","Έλεγξε fan, motor, feedback και PCB","Αποκατάσταση fan/PCB","Split / Inverter","United inverter platform","United/UA error-code documentation"),
        Fault("United","EA","Βλάβη κυκλώματος μέτρησης ρεύματος εξωτερικής","Outdoor current test circuit failure","Outdoor current sensing circuit/PCB","Έλεγξε current sensing και outdoor PCB","Επισκευή/αντικατάσταση PCB","Split / Inverter","United inverter platform","United/UA error-code documentation"),
        // ===== FINAL 5: F&U / UNITED / ARGO / CIAT / GENERAL =====
        Fault("F&U","NO START","Δεν ξεκινά η μονάδα","Unit does not start","Τροφοδοσία, ασφάλεια, χειριστήριο ή ενεργή προστασία","Έλεγξε τάση, ασφάλειες, remote και τροφοδοσία εσωτερικής/εξωτερικής","Αποκατάσταση τροφοδοσίας ή περαιτέρω διάγνωση πλακέτας","Split / Inverter","FVIN residential families","F&U support/product documentation"),
        Fault("F&U","NO COOL","Χαμηλή ή μηδενική ψύξη","Poor/no cooling","Βρώμικα φίλτρα/εναλλάκτες, χαμηλό airflow, ψυκτικό ή λανθασμένη ρύθμιση","Έλεγξε φίλτρα, εναλλάκτες, airflow, πιέσεις και φόρτιση","Καθαρισμός ή επισκευή ψυκτικού κυκλώματος μετά διάγνωση","Split / Inverter","FVIN residential families","F&U support/product documentation"),
        Fault("F&U","WATER","Διαρροή νερού από εσωτερική","Indoor water leakage","Βουλωμένη αποχέτευση, λεκάνη ή κακή κλίση","Έλεγξε drain, λεκάνη, κλίση και μόνωση σωλήνων","Καθαρισμός/επισκευή αποχέτευσης","Split / Inverter","FVIN residential families","F&U support/product documentation"),

        Fault("United","NO START","Δεν ξεκινά η μονάδα","Unit does not start","Τροφοδοσία, ασφάλεια, remote ή προστασία επανεκκίνησης","Έλεγξε τάση, ασφάλειες, χειριστήριο και τροφοδοσίες","Αποκατάσταση τροφοδοσίας ή διάγνωση PCB","Split / Inverter","United residential families","United product/service documentation"),
        Fault("United","NO COOL","Δεν αποδίδει σε ψύξη","Poor cooling","Φίλτρα/εναλλάκτες, airflow, ψυκτικό ή setpoint","Έλεγξε φίλτρα, airflow, θερμοκρασίες, πιέσεις και διαρροές","Καθαρισμός ή αποκατάσταση ψυκτικού κυκλώματος","Split / Inverter","United residential families","United product/service documentation"),
        Fault("United","ICE","Παγώνει ο εξατμιστής","Indoor evaporator icing","Χαμηλό airflow, χαμηλή φόρτιση ή αισθητήρας","Έλεγξε φίλτρα, fan, coil sensor και ψυκτικό","Αποκατάσταση airflow/φόρτισης/αισθητήρα","Split / Inverter","United residential families","United product/service documentation"),

        Fault("Argo","E1","Προστασία υψηλής πίεσης συμπιεστή","Compressor high pressure protection","Υψηλή πίεση, ανεπαρκής απόρριψη θερμότητας ή υπερφόρτιση","Έλεγξε πιέσεις, condenser, fan και φόρτιση","Αποκατάσταση αιτίας υψηλής πίεσης","Package / Duct / Cassette","ARGO PACK DCI R32","Argo official service manual"),
        Fault("Argo","E2","Αντιπαγωτική προστασία εσωτερικής","Indoor anti-freeze protection","Χαμηλή θερμοκρασία εξατμιστή ή ανεπαρκές airflow","Έλεγξε φίλτρα, fan, evaporator και ψυκτικό","Αποκατάσταση αιτίας παγώματος","Package / Duct / Cassette","ARGO PACK DCI R32","Argo official service manual"),
        Fault("Argo","E3","Χαμηλή πίεση / έλλειψη ψυκτικού","Compressor low pressure / refrigerant lack protection","Διαρροή, χαμηλή φόρτιση ή περιορισμός","Έλεγξε διαρροές, πιέσεις, βάνες και εκτονωτικό","Επισκευή διαρροής/περιορισμού και σωστή φόρτιση","Package / Duct / Cassette","ARGO PACK DCI R32","Argo official service manual"),
        Fault("Argo","E4","Υψηλή θερμοκρασία κατάθλιψης","Compressor discharge high-temperature protection","Χαμηλή φόρτιση, περιορισμός ή υπερθέρμανση","Έλεγξε discharge temperature, πιέσεις και φόρτιση","Αποκατάσταση αιτίας","Package / Duct / Cassette","ARGO PACK DCI R32","Argo official service manual"),
        Fault("Argo","E6","Σφάλμα επικοινωνίας","Communication error","Communication wiring ή PCB","Έλεγξε καλωδίωση, τροφοδοσίες και πλακέτες","Αποκατάσταση επικοινωνίας","Package / Duct / Cassette","ARGO PACK DCI R32","Argo official service manual"),
        Fault("Argo","E8","Βλάβη ανεμιστήρα εσωτερικής","Indoor fan error","Fan motor, feedback ή PCB","Έλεγξε fan, motor, connector και drive","Αποκατάσταση fan/PCB","Package / Duct / Cassette","ARGO PACK DCI R32","Argo official service manual"),
        Fault("Argo","E9","Προστασία γεμάτου νερού","Water-full protection","Drain, pump ή float","Έλεγξε αποχέτευση, pump και float","Καθαρισμός/επισκευή drain system","Package / Duct / Cassette","ARGO PACK DCI R32","Argo official service manual"),
        Fault("Argo","F0","Βλάβη αισθητήρα χώρου","Indoor ambient temperature sensor error","Thermistor ή σύνδεση","Έλεγξε sensor/connector","Αντικατάσταση αισθητήρα","Package / Duct / Cassette","ARGO PACK DCI R32","Argo official service manual"),
        Fault("Argo","F1","Βλάβη αισθητήρα εξατμιστή","Evaporator temperature sensor error","Thermistor ή σύνδεση","Έλεγξε sensor/connector","Αντικατάσταση αισθητήρα","Package / Duct / Cassette","ARGO PACK DCI R32","Argo official service manual"),
        Fault("Argo","F2","Βλάβη αισθητήρα συμπυκνωτή","Condenser temperature sensor error","Thermistor ή σύνδεση","Έλεγξε sensor/connector","Αντικατάσταση αισθητήρα","Package / Duct / Cassette","ARGO PACK DCI R32","Argo official service manual"),
        Fault("Argo","F3","Βλάβη αισθητήρα εξωτερικού αέρα","Outdoor ambient temperature sensor error","Thermistor ή σύνδεση","Έλεγξε sensor/connector","Αντικατάσταση αισθητήρα","Package / Duct / Cassette","ARGO PACK DCI R32","Argo official service manual"),
        Fault("Argo","F4","Βλάβη αισθητήρα κατάθλιψης","Discharge temperature sensor error","Thermistor ή σύνδεση","Έλεγξε sensor/connector","Αντικατάσταση αισθητήρα","Package / Duct / Cassette","ARGO PACK DCI R32","Argo official service manual"),
        Fault("Argo","F5","Βλάβη αισθητήρα ενσύρματου χειριστηρίου","Wired controller temperature sensor error","Sensor/controller ή σύνδεση","Έλεγξε wired controller sensor και bus","Αποκατάσταση controller/αισθητήρα","Package / Duct / Cassette","ARGO PACK DCI R32","Argo official service manual"),
        Fault("Argo","C5","Βλάβη jumper εσωτερικής","IDU jumper cap error","Jumper/configuration ή PCB","Έλεγξε jumper και model configuration","Διόρθωσε jumper/configuration","Package / Duct / Cassette","ARGO PACK DCI R32","Argo official service manual"),

        Fault("CIAT","10029","Απώλεια επικοινωνίας με System Manager","Loss of Communication With System Manager","Communication/network failure","Έλεγξε network, System Manager, addressing και controller communication","Αποκατάσταση επικοινωνίας· reset αυτόματα όταν επανέλθει","Chiller / Heat Pump","AQUACIAT POWER LD/ILD Connect Touch","CIAT Connect Touch official instruction manual"),
        Fault("CIAT","10122","Replacement mode χωρίς Software Activation Key","Replacement Mode - software activation keys missing","Αντικαταστάθηκε controller χωρίς activation key","Έλεγξε replacement procedure και activation keys","Ενεργοποίηση σωστών software options μέσω CIAT service","Chiller / Heat Pump","AQUACIAT POWER LD/ILD Connect Touch","CIAT Connect Touch official instruction manual"),
        Fault("CIAT","8001","Λανθασμένο Brand Identifier / configuration","Illegal Brand Identifier","Λανθασμένη configuration controller","Έλεγξε unit configuration και controller parameters","Διόρθωσε configuration πριν την εκκίνηση","Chiller / Heat Pump","AQUACIAT POWER LD/ILD Connect Touch","CIAT Connect Touch official instruction manual"),
        Fault("CIAT","10052","Βλάβη flow switch ανάκτησης θερμότητας","Heat Reclaim flow switch failure","Flow switch ανοικτό ενώ λειτουργεί HR pump","Έλεγξε HR pump, flow switch, 3-way valve και πραγματική ροή","Αποκατάσταση flow/flow switch","Chiller / Heat Pump","AQUACIAT POWER LD/ILD Connect Touch","CIAT Connect Touch official instruction manual"),
        Fault("CIAT","10128","Αντιπαγωτική προστασία condenser ανάκτησης θερμότητας","Heat Reclaim Condenser Freeze Protection","HR entering/leaving water temperature πολύ χαμηλή","Έλεγξε θερμοκρασίες, flow και αντιπαγωτική προστασία","Αποκατάσταση θερμοκρασίας/ροής","Chiller / Heat Pump","AQUACIAT POWER LD/ILD Connect Touch","CIAT Connect Touch official instruction manual"),
        Fault("CIAT","10129","Υψηλή θερμοκρασία νερού ανάκτησης θερμότητας","Heat Reclaim high Water Temperature","HR leaving water temperature υπερβολικά υψηλή","Έλεγξε θερμοκρασία εξόδου, flow, valve και load","Αποκατάσταση αιτίας υψηλής θερμοκρασίας","Chiller / Heat Pump","AQUACIAT POWER LD/ILD Connect Touch","CIAT Connect Touch official instruction manual"),
        Fault("CIAT","10054","Βλάβη ελέγχου τριφασικής τροφοδοσίας","3-Phase Control: Fault Detection","Phase controller / τριφασική παροχή","Έλεγξε φάσεις, τάσεις, phase sequence και controller","Αποκατάσταση τροφοδοσίας/phase controller","Chiller / Heat Pump","AQUACIAT POWER LD/ILD Connect Touch","CIAT Connect Touch official instruction manual"),

        Fault("General","NO COOL","Δεν ψύχει","No cooling","Airflow, ψυκτικό, συμπιεστής, εκτονωτικό ή control","Έλεγξε θερμοκρασίες, πιέσεις, superheat/subcooling, airflow και ηλεκτρικά","Αποκατάσταση της επιβεβαιωμένης αιτίας","Όλοι οι τύποι","Generic HVAC","General HVAC diagnostics"),
        Fault("General","NO HEAT","Δεν θερμαίνει","No heating","Reversing valve, defrost, airflow, refrigerant or control","Έλεγξε 4-way valve, defrost, πιέσεις, airflow και αισθητήρες","Αποκατάσταση επιβεβαιωμένης αιτίας","Όλοι οι τύποι","Generic HVAC","General HVAC diagnostics"),
        Fault("General","HIGH PRESSURE","Υψηλή πίεση","High pressure","Βρώμικος condenser, χαμηλό airflow/waterflow, υπερφόρτιση ή μη συμπυκνώσιμα","Έλεγξε heat rejection, airflow/waterflow, φόρτιση και πραγματικές πιέσεις","Καθαρισμός/αποκατάσταση ροής ή διόρθωση φόρτισης","Όλοι οι τύποι","Generic HVAC","General HVAC diagnostics"),
        Fault("General","LOW PRESSURE","Χαμηλή πίεση","Low pressure","Έλλειψη ψυκτικού, περιορισμός ή χαμηλό φορτίο","Έλεγξε διαρροές, φόρτιση, φίλτρα/εκτονωτικό και airflow","Επισκευή διαρροής/περιορισμού και σωστή φόρτιση","Όλοι οι τύποι","Generic HVAC","General HVAC diagnostics"),
        // ===== NEXT 5: YORK / PITSOS / SENDO / MORRIS / JURO-PRO =====
        Fault("York","E1","Προστασία υψηλής πίεσης","High pressure protection","High-pressure switch, airflow/heat rejection or refrigerant-side condition","Έλεγξε πιέσεις, εναλλάκτη, ανεμιστήρες και λειτουργία high-pressure switch","Αποκατάσταση αιτίας και reset σύμφωνα με service manual","Commercial / Inverter","York R Series","York R Series Service Manual"),
        Fault("York","E2","Αντιπαγωτική προστασία","Freeze protection","Χαμηλή θερμοκρασία εξατμιστή ή ανεπαρκής ροή αέρα","Έλεγξε φίλτρα, airflow, evaporator sensor και ψυκτικό κύκλωμα","Αποκατάσταση airflow/ψυκτικού αιτίου","Commercial / Inverter","York R Series","York R Series Service Manual"),

        // Pitsos entries from previous batch retained; add safe model-manual troubleshooting without inventing numeric meanings.
        Fault("Pitsos","AIRFLOW","Ανεπαρκής παροχή αέρα","Insufficient airflow","Βρώμικο φίλτρο, φραγμένες είσοδοι/έξοδοι ή χαμηλή ταχύτητα fan","Έλεγξε φίλτρα, στόμια και fan setting","Καθαρισμός και αποκατάσταση airflow","Split / Inverter","Pitsos inverter families","Pitsos product/user documentation"),
        Fault("Pitsos","POWER","Διακοπτόμενη ή μηδενική λειτουργία","Power/protection related non-operation","Τροφοδοσία, ασφάλεια, προστασία ή controller","Έλεγξε τάση, ασφάλειες, συνδέσεις και active protections","Αποκατάσταση τροφοδοσίας ή περαιτέρω διάγνωση","Split / Inverter","Pitsos inverter families","Pitsos product/user documentation"),

        Fault("Sendo","EA","Σφάλμα επικοινωνίας εσωτερικής πλακέτας με display","Indoor PCB to display communication problem","Καλωδίωση/display board/indoor PCB","Έλεγξε connectors, καλωδίωση display και indoor PCB","Αποκατάσταση επικοινωνίας ή πλακέτας","Split / Residential","Sendo residential families","Sendo service/error-code documentation"),
        Fault("Sendo","P8","Έλλειψη ψυκτικού ή πρόβλημα αντεπιστροφής","Low refrigerant or check-valve related problem","Διαρροή/χαμηλή φόρτιση ή valve issue","Έλεγξε διαρροές, πιέσεις, φόρτιση και valve operation","Επισκευή διαρροής/βαλβίδας και σωστή φόρτιση","Split / Residential","Sendo residential families","Sendo service/error-code documentation"),
        Fault("Sendo","H4","Πρόβλημα χαμηλής πίεσης","Low pressure problem","Έλλειψη ψυκτικού, περιορισμός ή low-pressure condition","Έλεγξε πιέσεις, διαρροές, φίλτρα/εκτονωτικό και airflow","Αποκατάσταση αιτίας χαμηλής πίεσης","Split / Residential","Sendo residential families","Sendo service/error-code documentation"),
        Fault("Sendo","FC","Πρόβλημα εκκίνησης εξωτερικής / συμπιεστή","Outdoor unit startup / compressor problem","Compressor, inverter/PCB or supply","Έλεγξε τροφοδοσία, compressor windings/insulation και drive","Αποκατάσταση επιβεβαιωμένης αιτίας","Split / Residential","Sendo residential families","Sendo service/error-code documentation"),
        Fault("Sendo","E4","Βλάβη εσωτερικού ανεμιστήρα ή PCB","Indoor fan or indoor PCB fault","Fan motor, feedback, wiring or PCB","Έλεγξε ελεύθερη περιστροφή, motor connector/feedback και PCB","Αποκατάσταση fan/PCB","Split / Residential","Sendo residential families","Sendo service/error-code documentation"),
        Fault("Sendo","J2","Σφάλμα επικοινωνίας εσωτερικής-εξωτερικής","Indoor/outdoor communication problem","Interconnect wiring, supply or PCB","Έλεγξε communication wiring, terminals και τροφοδοσίες","Αποκατάσταση επικοινωνίας","Split / Residential","Sendo residential families","Sendo service/error-code documentation"),

        Fault("Morris","E1","Βλάβη αισθητήρα θερμοκρασίας εσωτερικού χώρου","Indoor temperature sensor fault","Indoor thermistor ή σύνδεση","Έλεγξε αντίσταση αισθητήρα και connector","Αντικατάσταση αισθητήρα/σύνδεσης","Split / Inverter","WFIN/WFOD platform","Morris WFIN official manual"),
        Fault("Morris","E2","Βλάβη αισθητήρα σωλήνα εσωτερικής","Indoor pipe temperature sensor fault","Pipe thermistor ή σύνδεση","Έλεγξε thermistor και connector","Αντικατάσταση αισθητήρα","Split / Inverter","WFIN/WFOD platform","Morris WFIN official manual"),
        Fault("Morris","E3","Βλάβη αισθητήρα σωλήνα εξωτερικής","Outdoor pipe temperature sensor fault","Outdoor pipe thermistor ή σύνδεση","Έλεγξε sensor/connector","Αντικατάσταση αισθητήρα","Split / Inverter","WFIN/WFOD platform","Morris WFIN official manual"),
        Fault("Morris","E4","Διαρροή ή βλάβη ψυκτικού συστήματος","Refrigerant system leakage or fault","Διαρροή, ανεπαρκής φόρτιση ή refrigerant-system fault","Έλεγξε διαρροές, πιέσεις, βάνες και φόρτιση","Επισκευή διαρροής/βλάβης, κενό και σωστή φόρτιση","Split / Inverter","WFIN/WFOD platform","Morris WFIN official manual"),
        Fault("Morris","E6","Βλάβη μοτέρ εσωτερικού ανεμιστήρα","Indoor fan motor malfunction","Fan motor, feedback or PCB","Έλεγξε fan, connector, feedback και PCB","Αποκατάσταση fan/PCB","Split / Inverter","WFIN/WFOD platform","Morris WFIN official manual"),
        Fault("Morris","E7","Βλάβη αισθητήρα εξωτερικού αέρα","Outdoor air temperature sensor fault","Outdoor thermistor ή σύνδεση","Έλεγξε sensor/connector","Αντικατάσταση αισθητήρα","Split / Inverter","WFIN/WFOD platform","Morris WFIN official manual"),
        Fault("Morris","E8","Βλάβη αισθητήρα θερμοκρασίας κατάθλιψης","Outdoor discharge temperature sensor fault","Discharge thermistor ή σύνδεση","Έλεγξε αισθητήρα κατάθλιψης","Αντικατάσταση αισθητήρα","Split / Inverter","WFIN/WFOD platform","Morris WFIN official manual"),
        Fault("Morris","E9","Βλάβη εξωτερικού IPM","Outdoor IPM module fault","IPM/inverter module, compressor or supply","Έλεγξε DC bus, IPM και compressor","Αποκατάσταση επιβεβαιωμένης αιτίας","Split / Inverter","WFIN/WFOD platform","Morris WFIN official manual"),
        Fault("Morris","EA","Βλάβη ανίχνευσης ρεύματος εξωτερικής","Outdoor current detect fault","Current sensing circuit/PCB","Έλεγξε current-sense circuit και outdoor PCB","Επισκευή/αντικατάσταση PCB","Split / Inverter","WFIN/WFOD platform","Morris WFIN official manual"),
        Fault("Morris","EE","Βλάβη EEPROM εξωτερικής PCB","Outdoor PCB EEPROM fault","EEPROM/PCB","Power reset και έλεγχος outdoor PCB","Επισκευή/αντικατάσταση PCB","Split / Inverter","WFIN/WFOD platform","Morris WFIN official manual"),
        Fault("Morris","EF","Βλάβη μοτέρ εξωτερικού ανεμιστήρα","Outdoor fan motor fault","Fan motor, feedback or PCB","Έλεγξε fan, motor, connectors και drive","Αποκατάσταση fan/PCB","Split / Inverter","WFIN/WFOD platform","Morris WFIN official manual"),
        Fault("Morris","EH","Βλάβη αισθητήρα αναρρόφησης εξωτερικής","Outdoor suction temperature sensor fault","Suction thermistor ή σύνδεση","Έλεγξε sensor/connector","Αντικατάσταση αισθητήρα","Split / Inverter","WFIN/WFOD platform","Morris WFIN official manual"),

        Fault("Juro-Pro","NO START","Δεν ξεκινά η μονάδα","Unit does not run","Protector/fuse, τροφοδοσία, remote batteries ή 3-minute protection","Έλεγξε παροχή, ασφάλεια, remote και περίμενε την προστασία επανεκκίνησης","Αποκατάσταση τροφοδοσίας/προστασίας ή περαιτέρω διάγνωση","Split / Residential","ECO II / Airflow families","Juro-Pro official installation manual"),
        Fault("Juro-Pro","NO COOL/HEAT","Δεν αποδίδει σε ψύξη ή θέρμανση","No cooling or heating air","Βρώμικο φίλτρο, φραγμένα στόμια ή λάθος setpoint","Έλεγξε φίλτρο, intakes/outlets, setpoint και airflow","Καθαρισμός/αποκατάσταση airflow και σωστή ρύθμιση","Split / Residential","ECO II / Airflow families","Juro-Pro official installation manual"),
        Fault("Juro-Pro","CONTROL","Δεν ανταποκρίνεται σωστά στις εντολές","Abnormal control","Ηλεκτροστατική παρεμβολή ή ανωμαλία τάσης","Κόψε τροφοδοσία και επανέφερε μετά από λίγα δευτερόλεπτα· έλεγξε τάση αν επαναληφθεί","Reset και διάγνωση τροφοδοσίας/controller αν επιμένει","Split / Residential","ECO II / Airflow families","Juro-Pro official installation manual"),
        Fault("Juro-Pro","DEFROST","Σταματά ο εσωτερικός ανεμιστήρας στη θέρμανση","Heating defrost operation","Κανονική μετάβαση σε defrost όταν οι συνθήκες το απαιτούν","Επιβεβαίωσε ότι επιστρέφει σε θέρμανση μετά τον κύκλο defrost","Καμία επέμβαση αν η λειτουργία επανέρχεται κανονικά","Split / Residential","ECO II / Airflow families","Juro-Pro official installation manual"),
        // ===== NEXT 5: TOSHIBA / TOYOTOMI / TRANE / VAILLANT / VIESSMANN =====
        Fault("Toshiba","E03","Σφάλμα επικοινωνίας εσωτερικής-χειριστηρίου","Regular communication error between indoor and remote controller","Χειριστήριο, network adapter ή καλωδίωση","Έλεγξε remote/controller bus, τροφοδοσία και συνδέσεις","Αποκατάσταση επικοινωνίας","Light Commercial / VRF","RAV / TCC-LINK","Toshiba official service manual"),
        Fault("Toshiba","E04","Σφάλμα σειριακής επικοινωνίας εσωτερικής-εξωτερικής","Indoor/outdoor serial error","Serial wiring, indoor/outdoor PCB ή τροφοδοσία","Έλεγξε interconnect, τροφοδοσίες και PCB","Αποκατάσταση επικοινωνίας","Light Commercial / VRF","RAV / TCC-LINK","Toshiba official service manual"),
        Fault("Toshiba","E08","Διπλή διεύθυνση εσωτερικής","Duplicated indoor addresses","Ίδια διεύθυνση σε περισσότερες IDU","Έλεγξε addressing","Δώσε μοναδικές διευθύνσεις","Light Commercial / VRF","RAV / TCC-LINK","Toshiba official service manual"),
        Fault("Toshiba","E10","Σφάλμα επικοινωνίας MCU εσωτερικής","Indoor MCU communication error","Main motor/microcomputer communication","Έλεγξε PCB, μοτέρ και connectors","Αποκατάσταση PCB/σύνδεσης","Light Commercial / VRF","RAV / TCC-LINK","Toshiba official service manual"),
        Fault("Toshiba","E18","Σφάλμα επικοινωνίας master-follower","Indoor master/follower communication error","Bus/addressing μεταξύ twin units","Έλεγξε addressing και inter-unit wiring","Αποκατάσταση επικοινωνίας","Light Commercial / VRF","RAV / TCC-LINK","Toshiba official service manual"),

        Fault("Toyotomi","E1","Προστασία υψηλής πίεσης συμπιεστή","Compressor high pressure protection","Υψηλή πίεση, κακή απόρριψη θερμότητας ή υπερφόρτιση","Έλεγξε πιέσεις, εναλλάκτη, ανεμιστήρα και φόρτιση","Αποκατάσταση αιτίας υψηλής πίεσης","Light Commercial / Duct-Cassette-Console-Floor Ceiling","Toyotomi ductable platform","Toyotomi user manual error table"),
        Fault("Toyotomi","E2","Αντιπαγωτική προστασία εσωτερικής","Indoor anti-freeze protection","Χαμηλή θερμοκρασία εξατμιστή/airflow","Έλεγξε φίλτρα, fan, coil και ψυκτικό","Αποκατάσταση αιτίας παγώματος","Light Commercial / Duct-Cassette-Console-Floor Ceiling","Toyotomi ductable platform","Toyotomi user manual error table"),
        Fault("Toyotomi","E3","Χαμηλή πίεση / έλλειψη ψυκτικού","Low pressure and refrigerant lack protection","Διαρροή, χαμηλή φόρτιση ή περιορισμός","Έλεγξε διαρροές, πιέσεις και εκτονωτικό","Επισκευή και σωστή φόρτιση","Light Commercial / Duct-Cassette-Console-Floor Ceiling","Toyotomi ductable platform","Toyotomi user manual error table"),
        Fault("Toyotomi","E4","Υψηλή θερμοκρασία κατάθλιψης","Compressor discharge high-temperature protection","Χαμηλή φόρτιση, περιορισμός ή υπερθέρμανση","Έλεγξε discharge temp, πιέσεις και φόρτιση","Αποκατάσταση αιτίας","Light Commercial / Duct-Cassette-Console-Floor Ceiling","Toyotomi ductable platform","Toyotomi user manual error table"),
        Fault("Toyotomi","E6","Σφάλμα επικοινωνίας","Communication error","Communication wiring ή PCB","Έλεγξε καλωδίωση και πλακέτες","Αποκατάσταση επικοινωνίας","Light Commercial / Duct-Cassette-Console-Floor Ceiling","Toyotomi ductable platform","Toyotomi user manual error table"),
        Fault("Toyotomi","E8","Βλάβη ανεμιστήρα εσωτερικής","Indoor fan error","Fan motor/drive","Έλεγξε fan, μοτέρ και PCB","Αποκατάσταση fan/drive","Light Commercial / Duct-Cassette-Console-Floor Ceiling","Toyotomi ductable platform","Toyotomi user manual error table"),
        Fault("Toyotomi","E9","Προστασία γεμάτου νερού","Water-full protection","Drain, pump ή float","Έλεγξε αποχέτευση, pump και float","Καθαρισμός/επισκευή drain","Light Commercial / Duct-Cassette-Console-Floor Ceiling","Toyotomi ductable platform","Toyotomi user manual error table"),
        Fault("Toyotomi","F0","Βλάβη αισθητήρα χώρου","Indoor ambient temperature sensor error","Thermistor ή σύνδεση","Έλεγξε sensor/connector","Αντικατάσταση αισθητήρα","Light Commercial / Duct-Cassette-Console-Floor Ceiling","Toyotomi ductable platform","Toyotomi user manual error table"),
        Fault("Toyotomi","F1","Βλάβη αισθητήρα εξατμιστή","Evaporator temperature sensor error","Thermistor ή σύνδεση","Έλεγξε sensor","Αντικατάσταση αισθητήρα","Light Commercial / Duct-Cassette-Console-Floor Ceiling","Toyotomi ductable platform","Toyotomi user manual error table"),
        Fault("Toyotomi","F2","Βλάβη αισθητήρα συμπυκνωτή","Condenser temperature sensor error","Thermistor ή σύνδεση","Έλεγξε sensor","Αντικατάσταση αισθητήρα","Light Commercial / Duct-Cassette-Console-Floor Ceiling","Toyotomi ductable platform","Toyotomi user manual error table"),
        Fault("Toyotomi","F3","Βλάβη αισθητήρα εξωτερικού αέρα","Outdoor ambient temperature sensor error","Thermistor ή σύνδεση","Έλεγξε sensor","Αντικατάσταση αισθητήρα","Light Commercial / Duct-Cassette-Console-Floor Ceiling","Toyotomi ductable platform","Toyotomi user manual error table"),
        Fault("Toyotomi","F4","Βλάβη αισθητήρα κατάθλιψης","Discharge temperature sensor error","Thermistor ή σύνδεση","Έλεγξε sensor","Αντικατάσταση αισθητήρα","Light Commercial / Duct-Cassette-Console-Floor Ceiling","Toyotomi ductable platform","Toyotomi user manual error table"),
        Fault("Toyotomi","C5","Βλάβη jumper εσωτερικής","IDU jumper cap error","Jumper/configuration","Έλεγξε jumper και PCB","Διόρθωσε jumper/configuration","Light Commercial / Duct-Cassette-Console-Floor Ceiling","Toyotomi ductable platform","Toyotomi user manual error table"),
        Fault("Toyotomi","EE","Βλάβη μνήμης","IDU or ODU memory chip error","EEPROM/PCB","Power reset και έλεγχος PCB","Επισκευή/αντικατάσταση PCB","Light Commercial / Duct-Cassette-Console-Floor Ceiling","Toyotomi ductable platform","Toyotomi user manual error table"),

        Fault("Trane","E0","Σφάλμα επικοινωνίας εσωτερικής-εξωτερικής","Indoor/outdoor communication failure","Communication wiring ή PCB","Έλεγξε wiring, τροφοδοσίες και PCB","Αποκατάσταση επικοινωνίας","Split / Residential","Trane inverter R410A platform","Trane official service manual"),
        Fault("Trane","EC","Σφάλμα επικοινωνίας εξωτερικής","Outdoor communication failure","Outdoor PCB/communication","Έλεγξε outdoor boards και connectors","Αποκατάσταση επικοινωνίας","Split / Residential","Trane inverter R410A platform","Trane official service manual"),
        Fault("Trane","E1","Βλάβη αισθητήρα χώρου","Indoor room temperature sensor fault","IRT sensor ή σύνδεση","Έλεγξε thermistor","Αντικατάσταση αισθητήρα","Split / Residential","Trane inverter R410A platform","Trane official service manual"),
        Fault("Trane","E2","Βλάβη αισθητήρα στοιχείου εσωτερικής","Indoor coil temperature sensor fault","IPT sensor ή σύνδεση","Έλεγξε thermistor","Αντικατάσταση αισθητήρα","Split / Residential","Trane inverter R410A platform","Trane official service manual"),
        Fault("Trane","E3","Βλάβη αισθητήρα εξωτερικού στοιχείου","Outdoor coil temperature sensor fault","OPT sensor ή σύνδεση","Έλεγξε thermistor","Αντικατάσταση αισθητήρα","Split / Residential","Trane inverter R410A platform","Trane official service manual"),
        Fault("Trane","E4","Ανωμαλία συστήματος","System abnormality","Ψυκτικό κύκλωμα ή control","Έλεγξε outdoor diagnostics, πιέσεις και ηλεκτρικά","Αποκατάσταση πραγματικής αιτίας","Split / Residential","Trane inverter R410A platform","Trane official service manual"),
        Fault("Trane","E5","Λάθος configuration μοντέλου","Model configuration wrong","PCB/model configuration","Έλεγξε jumper/configuration","Διόρθωσε configuration","Split / Residential","Trane inverter R410A platform","Trane official service manual"),
        Fault("Trane","E6","Βλάβη μοτέρ εσωτερικού ανεμιστήρα","Indoor fan motor fault","Fan motor ή PCB","Έλεγξε fan, motor και PCB","Αποκατάσταση fan/PCB","Split / Residential","Trane inverter R410A platform","Trane official service manual"),
        Fault("Trane","E7","Βλάβη αισθητήρα εξωτερικού αέρα","Outdoor temperature sensor fault","Thermistor ή σύνδεση","Έλεγξε sensor","Αντικατάσταση αισθητήρα","Split / Residential","Trane inverter R410A platform","Trane official service manual"),
        Fault("Trane","E8","Βλάβη αισθητήρα κατάθλιψης","Exhaust temperature sensor fault","Discharge sensor ή σύνδεση","Έλεγξε sensor","Αντικατάσταση αισθητήρα","Split / Residential","Trane inverter R410A platform","Trane official service manual"),
        Fault("Trane","E9","Βλάβη IPM / drive","IPM drive and module fault","Inverter module, compressor ή τροφοδοσία","Έλεγξε IPM, DC bus και compressor","Αποκατάσταση module/αιτίας","Split / Residential","Trane inverter R410A platform","Trane official service manual"),

        // Vaillant / Viessmann: conservative family-level troubleshooting entries; exact numeric codes vary strongly by model/controller.
        Fault("Vaillant","FLOW","Ανεπαρκής ροή νερού","Insufficient heating circuit flow","Αέρας, φίλτρο, κλειστές βάνες ή κυκλοφορητής","Έλεγξε πίεση νερού, εξαέρωση, φίλτρο, βάνες και pump","Αποκατάσταση σωστής ροής","Αντλία θερμότητας αέρα-νερού","aroTHERM family","Vaillant heat pump service documentation"),
        Fault("Vaillant","SENSOR","Βλάβη αισθητήρα θερμοκρασίας","Temperature sensor fault","NTC, καλωδίωση ή connector","Έλεγξε NTC και wiring βάσει model manual","Αντικατάσταση αισθητήρα/σύνδεσης","Αντλία θερμότητας αέρα-νερού","aroTHERM family","Vaillant heat pump service documentation"),
        Fault("Vaillant","HP","Προστασία υψηλής πίεσης ψυκτικού","Refrigerant high pressure protection","Ανεπαρκής waterflow/heat rejection ή ψυκτικό κύκλωμα","Έλεγξε waterflow, εναλλάκτη, αισθητήρες και ψυκτικό κύκλωμα","Αποκατάσταση αιτίας πριν reset","Αντλία θερμότητας αέρα-νερού","aroTHERM family","Vaillant heat pump service documentation"),

        Fault("Viessmann","FLOW","Ανεπαρκής ροή πρωτεύοντος κυκλώματος","Insufficient primary circuit flow","Pump, αέρας, φίλτρο ή κλειστές βάνες","Έλεγξε pump, εξαέρωση, strainers και valves","Αποκατάσταση ροής","Αντλία θερμότητας αέρα-νερού","Vitocal family","Viessmann heat pump service documentation"),
        Fault("Viessmann","SENSOR","Βλάβη αισθητήρα θερμοκρασίας","Temperature sensor fault","Sensor ή wiring","Έλεγξε sensor resistance και wiring σύμφωνα με μοντέλο","Αντικατάσταση αισθητήρα/σύνδεσης","Αντλία θερμότητας αέρα-νερού","Vitocal family","Viessmann heat pump service documentation"),
        Fault("Viessmann","REFRIG","Προστασία ψυκτικού κυκλώματος","Refrigerant circuit protection","Πίεση/θερμοκρασία εκτός ορίων ή ανεπαρκής heat transfer","Έλεγξε pressures/temperatures, flow και heat exchangers","Αποκατάσταση επιβεβαιωμένης αιτίας","Αντλία θερμότητας αέρα-νερού","Vitocal family","Viessmann heat pump service documentation"),
        // ===== NEXT 5 VERIFIED: SAMSUNG / SHARP / SINCLAIR / TCL / TESLA =====
        Fault("Samsung","E101","Απώλεια επικοινωνίας εσωτερικής από εξωτερική","Indoor unit cannot receive data from outdoor unit","Καλωδίωση επικοινωνίας, τροφοδοσία ή PCB","Έλεγξε communication cable, τροφοδοσίες και PCB","Αποκατάσταση επικοινωνίας","Split / Multi / CAC","Samsung CAC / DVM compatible families","Samsung Service Manual"),
        Fault("Samsung","E102","Σφάλμα επικοινωνίας εσωτερικής-εξωτερικής","Indoor/outdoor communication error displayed at indoor unit","Communication wiring ή PCB","Έλεγξε καλωδίωση και PCB εσωτερικής/εξωτερικής","Αποκατάσταση επικοινωνίας","Split / Multi / CAC","Samsung CAC / DVM compatible families","Samsung Service Manual"),
        Fault("Samsung","E108","Διπλή διεύθυνση εσωτερικής","Repeated indoor communication address","Δύο ή περισσότερες μονάδες με ίδια διεύθυνση","Έλεγξε addressing όλων των IDU","Δώσε μοναδικές διευθύνσεις και reset","VRF / DVM","Samsung DVM","Samsung Service Manual"),
        Fault("Samsung","E121","Βλάβη αισθητήρα θερμοκρασίας χώρου","Indoor room temperature sensor open/short","Thermistor ή σύνδεση","Έλεγξε αντίσταση αισθητήρα και connector","Αντικατάσταση αισθητήρα/σύνδεσης","Split / Multi / CAC","Samsung indoor units","Samsung Service Manual"),
        Fault("Samsung","E122","Βλάβη αισθητήρα EVA-IN","Indoor heat exchanger inlet sensor open/short","EVA-IN thermistor ή σύνδεση","Έλεγξε thermistor και connector","Αντικατάσταση αισθητήρα","Split / Multi / CAC","Samsung indoor units","Samsung Service Manual"),
        Fault("Samsung","E123","Βλάβη αισθητήρα EVA-OUT","Indoor heat exchanger outlet sensor open/short","EVA-OUT thermistor ή σύνδεση","Έλεγξε thermistor και connector","Αντικατάσταση αισθητήρα","Split / Multi / CAC","Samsung indoor units","Samsung Service Manual"),
        Fault("Samsung","E153","Σφάλμα float switch","Indoor float sensor error","Αποχέτευση, αντλία ή float","Έλεγξε drain, pump και float switch","Καθαρισμός/επισκευή αποχέτευσης","Κασέτα","Samsung CAC","Samsung Service Manual"),
        Fault("Samsung","E154","Βλάβη ανεμιστήρα εσωτερικής","Indoor fan RPM feedback error","Fan motor, feedback, wiring ή PCB","Έλεγξε περιστροφή, μοτέρ, connector και PCB","Αποκατάσταση μοτέρ/PCB","Split / Multi / CAC","Samsung indoor units","Samsung Service Manual"),
        Fault("Samsung","E161","Σύγκρουση λειτουργίας","Mixed operation mode error","Αντίθετη απαίτηση ψύξης/θέρμανσης στο ίδιο σύστημα","Έλεγξε modes όλων των IDU","Ρύθμισε συμβατό mode","Multi / VRF","Samsung multi/DVM","Samsung Service Manual"),
        Fault("Samsung","E162","Βλάβη EEPROM εσωτερικής","Indoor MICOM EEPROM error","EEPROM/PCB","Έλεγξε PCB και option data","Επισκευή/αντικατάσταση PCB","Split / Multi / CAC","Samsung indoor units","Samsung Service Manual"),
        Fault("Samsung","E163","Λάθος ή ελλιπές option code","Indoor remote-controller option input incorrect/missing","Λανθασμένο option setting","Έλεγξε model-specific option code","Πέρασε σωστό option code","Split / Multi / CAC","Samsung indoor units","Samsung Service Manual"),
        Fault("Samsung","E202","Σφάλμα επικοινωνίας μετά το tracking","Communication error after tracking","Αριθμός μονάδων/addressing/communication","Έλεγξε tracking, addressing και bus","Διόρθωσε configuration/επικοινωνία","VRF / DVM","Samsung DVM","Samsung Service Manual"),
        Fault("Samsung","E221","Βλάβη αισθητήρα εξωτερικού αέρα","Outdoor temperature sensor open/short","Thermistor ή σύνδεση","Έλεγξε αισθητήρα και connector","Αντικατάσταση αισθητήρα","Split / Multi / CAC","Samsung outdoor units","Samsung Service Manual"),
        Fault("Samsung","E237","Βλάβη αισθητήρα συμπυκνωτή","Outdoor condenser sensor error","Thermistor ή σύνδεση","Έλεγξε condenser thermistor","Αντικατάσταση αισθητήρα","Split / Multi / CAC","Samsung outdoor units","Samsung Service Manual"),
        Fault("Samsung","E251","Βλάβη αισθητήρα κατάθλιψης","Outdoor discharge sensor error","Discharge thermistor ή σύνδεση","Έλεγξε αισθητήρα κατάθλιψης","Αντικατάσταση αισθητήρα","Split / Multi / CAC","Samsung outdoor units","Samsung Service Manual"),

        Fault("Sharp","E0","Βλάβη αντλίας συμπυκνωμάτων","Water pump malfunction","Drain pump, float ή αποχέτευση","Έλεγξε drain, pump και float","Αποκατάσταση αποχέτευσης/αντλίας","Κασέτα","Sharp cassette/duct","Sharp Operation Manual"),
        Fault("Sharp","E1","Προστασία υψηλής πίεσης","Compressor high pressure protection","Υψηλή πίεση, airflow ή φόρτιση","Έλεγξε πιέσεις, condenser, fan και φόρτιση","Αποκατάσταση αιτίας υψηλής πίεσης","Κασέτα / Duct","Sharp commercial AC","Sharp Operation Manual"),
        Fault("Sharp","E2","Αντιπαγωτική προστασία","Indoor anti-freeze protection","Χαμηλό coil temp ή airflow","Έλεγξε φίλτρα, fan, coil και ψυκτικό","Αποκατάσταση αιτίας παγώματος","Κασέτα / Duct","Sharp commercial AC","Sharp Operation Manual"),
        Fault("Sharp","E3","Προστασία χαμηλής πίεσης","Compressor low pressure protection","Χαμηλή φόρτιση/διαρροή ή περιορισμός","Έλεγξε διαρροές, πιέσεις και κύκλωμα","Επισκευή και σωστή φόρτιση","Κασέτα / Duct","Sharp commercial AC","Sharp Operation Manual"),
        Fault("Sharp","E4","Υψηλή θερμοκρασία κατάθλιψης","Compressor discharge high-temperature protection","Χαμηλή φόρτιση, περιορισμός ή υπερθέρμανση","Έλεγξε discharge temp, πιέσεις και φόρτιση","Αποκατάσταση αιτίας","Κασέτα / Duct","Sharp commercial AC","Sharp Operation Manual"),
        Fault("Sharp","E5","Υπερθέρμανση συμπιεστή / inverter protection","Compressor overheat and inverter driving protection","Compressor, inverter ή φορτίο","Έλεγξε ρεύμα, module, πιέσεις και συμπιεστή","Αποκατάσταση επιβεβαιωμένης αιτίας","Κασέτα / Duct","Sharp commercial AC","Sharp Operation Manual"),
        Fault("Sharp","E6","Σφάλμα επικοινωνίας","Communication failure","Bus/wiring ή PCB","Έλεγξε καλωδίωση και PCB","Αποκατάσταση επικοινωνίας","Κασέτα / Duct","Sharp commercial AC","Sharp Operation Manual"),
        Fault("Sharp","E8","Προστασία ανεμιστήρα εσωτερικής","Indoor fan protection","Fan motor ή drive","Έλεγξε fan, motor και PCB","Αποκατάσταση fan/drive","Κασέτα / Duct","Sharp commercial AC","Sharp Operation Manual"),
        Fault("Sharp","E9","Προστασία γεμάτου νερού","Full water protection","Drain/float/pump","Έλεγξε αποχέτευση, float και pump","Καθαρισμός/επισκευή drain","Κασέτα / Duct","Sharp commercial AC","Sharp Operation Manual"),
        Fault("Sharp","F0","Βλάβη αισθητήρα χώρου","Indoor room sensor failure","Thermistor ή σύνδεση","Έλεγξε αισθητήρα","Αντικατάσταση αισθητήρα","Κασέτα / Duct","Sharp commercial AC","Sharp Operation Manual"),
        Fault("Sharp","F1","Βλάβη αισθητήρα εξατμιστή","Evaporator sensor failure","Thermistor ή σύνδεση","Έλεγξε thermistor","Αντικατάσταση αισθητήρα","Κασέτα / Duct","Sharp commercial AC","Sharp Operation Manual"),
        Fault("Sharp","F2","Βλάβη αισθητήρα συμπυκνωτή","Condenser sensor failure","Thermistor ή σύνδεση","Έλεγξε thermistor","Αντικατάσταση αισθητήρα","Κασέτα / Duct","Sharp commercial AC","Sharp Operation Manual"),
        Fault("Sharp","F3","Βλάβη αισθητήρα εξωτερικού αέρα","Outdoor ambient sensor failure","Thermistor ή σύνδεση","Έλεγξε αισθητήρα","Αντικατάσταση αισθητήρα","Κασέτα / Duct","Sharp commercial AC","Sharp Operation Manual"),
        Fault("Sharp","F4","Βλάβη αισθητήρα κατάθλιψης","Discharge sensor failure","Thermistor ή σύνδεση","Έλεγξε αισθητήρα","Αντικατάσταση αισθητήρα","Κασέτα / Duct","Sharp commercial AC","Sharp Operation Manual"),

        Fault("Sinclair","E1","Προστασία υψηλής πίεσης","Compressor high pressure protection","Υψηλή πίεση/ανεπαρκής απόρριψη θερμότητας","Έλεγξε πιέσεις, airflow/waterflow και φόρτιση","Αποκατάσταση αιτίας υψηλής πίεσης","Κασέτα / Duct","Sinclair commercial platform","Sinclair User/Service Manual"),
        Fault("Sinclair","E2","Αντιπαγωτική προστασία","Indoor anti-freeze protection","Χαμηλή coil temp ή airflow","Έλεγξε φίλτρα, fan, coil και ψυκτικό","Αποκατάσταση αιτίας παγώματος","Κασέτα / Duct","Sinclair commercial platform","Sinclair User/Service Manual"),
        Fault("Sinclair","E3","Χαμηλή πίεση / έλλειψη ψυκτικού","Low pressure / refrigerant lack protection","Διαρροή ή περιορισμός","Έλεγξε διαρροές, πιέσεις, φόρτιση και εκτονωτικό","Επισκευή και σωστή φόρτιση","Κασέτα / Duct","Sinclair commercial platform","Sinclair User/Service Manual"),
        Fault("Sinclair","E4","Υψηλή θερμοκρασία κατάθλιψης","High discharge temperature protection","Υπερθέρμανση ψυκτικού κύκλου","Έλεγξε discharge temp, φόρτιση και περιορισμούς","Αποκατάσταση αιτίας","Κασέτα / Duct","Sinclair commercial platform","Sinclair User/Service Manual"),
        Fault("Sinclair","E6","Σφάλμα επικοινωνίας","Communication error","Bus/wiring ή PCB","Έλεγξε communication wiring και PCB","Αποκατάσταση επικοινωνίας","Κασέτα / Duct","Sinclair commercial platform","Sinclair User/Service Manual"),
        Fault("Sinclair","E8","Βλάβη ανεμιστήρα εσωτερικής","Indoor fan error","Fan motor/drive","Έλεγξε μοτέρ, περιστροφή και PCB","Αποκατάσταση fan/drive","Κασέτα / Duct","Sinclair commercial platform","Sinclair User/Service Manual"),
        Fault("Sinclair","E9","Γεμάτο δοχείο συμπυκνωμάτων","Water-full protection","Drain/pump/float","Έλεγξε drain, pump και float","Αποκατάσταση αποχέτευσης","Κασέτα / Duct","Sinclair commercial platform","Sinclair User/Service Manual"),
        Fault("Sinclair","F0","Βλάβη αισθητήρα χώρου","Indoor ambient sensor error","Thermistor ή σύνδεση","Έλεγξε sensor/connector","Αντικατάσταση αισθητήρα","Κασέτα / Duct","Sinclair commercial platform","Sinclair User/Service Manual"),
        Fault("Sinclair","F1","Βλάβη αισθητήρα εξατμιστή","Evaporator sensor error","Thermistor ή σύνδεση","Έλεγξε sensor","Αντικατάσταση αισθητήρα","Κασέτα / Duct","Sinclair commercial platform","Sinclair User/Service Manual"),
        Fault("Sinclair","H3","Προστασία υπερφόρτωσης συμπιεστή","Compressor overload protection","Υψηλό φορτίο/θερμοκρασία ή compressor","Έλεγξε ρεύμα, πιέσεις και συμπιεστή","Αποκατάσταση αιτίας","Κασέτα / Duct","Sinclair commercial platform","Sinclair User/Service Manual"),
        Fault("Sinclair","H5","Προστασία IPM","IPM protection","Inverter module, συμπιεστής ή τροφοδοσία","Έλεγξε module, DC bus και compressor","Αποκατάσταση αιτίας","Κασέτα / Duct","Sinclair commercial platform","Sinclair User/Service Manual"),

        Fault("TCL","E0","Σφάλμα επικοινωνίας εσωτερικής-εξωτερικής","IDU & ODU communication failure","Communication wiring ή PCB","Έλεγξε wiring, τροφοδοσίες και PCB","Αποκατάσταση επικοινωνίας","Split / Inverter","TCL XA/XAB inverter platform","TCL Service Manual"),
        Fault("TCL","E1","Βλάβη αισθητήρα χώρου εσωτερικής","IDU room temperature sensor failure","Sensor ή PCB","Έλεγξε thermistor και connector","Αντικατάσταση αισθητήρα/PCB","Split / Inverter","TCL XA/XAB inverter platform","TCL Service Manual"),
        Fault("TCL","E2","Βλάβη αισθητήρα στοιχείου εσωτερικής","IDU coil temperature sensor failure","Sensor ή PCB","Έλεγξε thermistor και connector","Αντικατάσταση αισθητήρα/PCB","Split / Inverter","TCL XA/XAB inverter platform","TCL Service Manual"),
        Fault("TCL","E3","Βλάβη αισθητήρα στοιχείου εξωτερικής","ODU coil temperature sensor failure","Sensor ή PCB","Έλεγξε thermistor/connector","Αντικατάσταση αισθητήρα/PCB","Split / Inverter","TCL XA/XAB inverter platform","TCL Service Manual"),
        Fault("TCL","E4","Ανεπαρκές ψυκτικό / ανωμαλία ψυκτικού κύκλου","Gas not enough / cooling system abnormal","Διαρροή ή χαμηλή φόρτιση","Έλεγξε πίεση, διαρροές και φόρτιση","Επισκευή διαρροής και σωστή φόρτιση","Split / Inverter","TCL XA/XAB platform","TCL Service Manual"),
        Fault("TCL","E5","Προστασία συστήματος","System protection","High/low pressure protection ανά πλατφόρμα","Έλεγξε πιέσεις, airflow και ψυκτικό κύκλωμα","Αποκατάσταση πραγματικής αιτίας","Split / Inverter","TCL XA/XAB platform","TCL Service Manual"),
        Fault("TCL","E6","Βλάβη ανεμιστήρα εσωτερικής","IDU PG/DC fan motor abnormal","Fan motor, blade ή PCB","Έλεγξε fan, μοτέρ και PCB","Αποκατάσταση fan/PCB","Split / Inverter","TCL XA/XAB platform","TCL Service Manual"),
        Fault("TCL","P7","Προστασία υπερθέρμανσης στη θέρμανση","Overheating protection in heating mode","Υψηλή coil temp/airflow ή φορτίο","Έλεγξε airflow, αισθητήρες και πιέσεις","Αποκατάσταση αιτίας υπερθέρμανσης","Split / Inverter","TCL XA/XAB platform","TCL Service Manual"),

        // Tesla room AC models commonly use the TCL inverter control platform; keep this scoped to that platform.
        Fault("Tesla","E0","Σφάλμα επικοινωνίας εσωτερικής-εξωτερικής","IDU & ODU communication failure","Communication wiring ή PCB","Έλεγξε wiring, τροφοδοσίες και PCB","Αποκατάσταση επικοινωνίας","Split / Inverter","Tesla/TCL-derived inverter platform","TCL/Tesla platform service data"),
        Fault("Tesla","E1","Βλάβη αισθητήρα χώρου εσωτερικής","IDU room temperature sensor failure","Sensor ή PCB","Έλεγξε thermistor και connector","Αντικατάσταση αισθητήρα/PCB","Split / Inverter","Tesla/TCL-derived inverter platform","TCL/Tesla platform service data"),
        Fault("Tesla","E2","Βλάβη αισθητήρα στοιχείου εσωτερικής","IDU coil temperature sensor failure","Sensor ή PCB","Έλεγξε thermistor και connector","Αντικατάσταση αισθητήρα/PCB","Split / Inverter","Tesla/TCL-derived inverter platform","TCL/Tesla platform service data"),
        Fault("Tesla","E4","Ανεπαρκές ψυκτικό / ανωμαλία ψυκτικού κύκλου","Gas not enough / cooling system abnormal","Διαρροή ή χαμηλή φόρτιση","Έλεγξε διαρροές, πίεση και φόρτιση","Επισκευή διαρροής και σωστή φόρτιση","Split / Inverter","Tesla/TCL-derived inverter platform","TCL/Tesla platform service data"),
        Fault("Tesla","E5","Προστασία συστήματος","System protection","Πίεση/θερμοκρασία ή ηλεκτρική προστασία ανά μοντέλο","Έλεγξε outdoor diagnostics, πιέσεις και τροφοδοσία","Αποκατάσταση επιβεβαιωμένης αιτίας","Split / Inverter","Tesla/TCL-derived inverter platform","TCL/Tesla platform service data"),
        Fault("Tesla","E6","Βλάβη ανεμιστήρα εσωτερικής","IDU fan motor abnormal","Fan motor ή PCB","Έλεγξε fan, motor και PCB","Αποκατάσταση fan/PCB","Split / Inverter","Tesla/TCL-derived inverter platform","TCL/Tesla platform service data"),
        // ===== NORDSTAR + PITSOS ADDITIONAL VERIFIED FAULTS =====
        Fault("Nordstar","E0","Αποτυχία επικοινωνίας εσωτερικής-εξωτερικής","IDU & ODU communication failure","Καλωδίωση επικοινωνίας, τροφοδοσία ή PCB","Έλεγξε L/N, communication wiring, συνδέσεις και LED εξωτερικής PCB","Αποκατάσταση καλωδίωσης ή PCB μετά από επιβεβαίωση","Split / Inverter","TN+ / NORP CHSD TP41I","Nordstar TN+ official/service manual"),
        Fault("Nordstar","E1","Βλάβη αισθητήρα θερμοκρασίας χώρου T1","Indoor room temperature sensor failure","T1 open/short ή PCB","Έλεγξε σύνδεση και αντίσταση T1","Αντικατάσταση αισθητήρα ή PCB αν επιβεβαιωθεί","Split / Inverter","TN+ / NORP CHSD TP41I","Nordstar TN+ service manual"),
        Fault("Nordstar","E2","Βλάβη αισθητήρα εσωτερικού στοιχείου T2","Indoor coil temperature sensor failure","T2 open/short ή PCB","Έλεγξε σύνδεση και αντίσταση T2","Αντικατάσταση αισθητήρα ή PCB","Split / Inverter","TN+ / NORP CHSD TP41I","Nordstar TN+ service manual"),
        Fault("Nordstar","E3","Βλάβη αισθητήρα εξωτερικού στοιχείου T3","Outdoor coil temperature sensor failure","T3/OPT ή outdoor PCB","Έλεγξε thermistor T3 και σύνδεση","Αντικατάσταση αισθητήρα/PCB","Split / Inverter","TN+ / NORP CHSD TP41I","Nordstar TN+ service manual"),
        Fault("Nordstar","E4","Ανωμαλία ψυκτικού κυκλώματος / ανεπαρκές ψυκτικό","Cooling system abnormal","Διαρροή, ανεπαρκής φόρτιση, κλειστή 2-way/3-way valve ή περιορισμός","Μέτρησε πιέσεις, έλεγξε διαρροές, βάνες, αισθητήρες και περιορισμούς","Επισκευή διαρροής/περιορισμού, άνοιγμα βανών και σωστή φόρτιση","Split / Inverter","TN+ / NORP CHSD TP41I","Nordstar TN+ service manual"),
        Fault("Nordstar","E5","Ασυμφωνία εσωτερικής-εξωτερικής μονάδας","IDU/ODU mismatched failure","Λανθασμένος συνδυασμός μονάδων/configuration","Έλεγξε αντιστοίχιση μοντέλων και configuration","Διόρθωσε συνδυασμό/configuration","Split / Inverter","TN+ / NORP CHSD TP41I","Nordstar TN+ service manual"),
        Fault("Nordstar","E6","Βλάβη μοτέρ εσωτερικού ανεμιστήρα","Indoor PG/DC fan motor abnormal","Μοτέρ, φτερωτή ή PCB","Έλεγξε ελεύθερη περιστροφή, σύνδεση μοτέρ, feedback και PCB","Αποκατάσταση/αντικατάσταση μοτέρ ή PCB","Split / Inverter","TN+ / NORP CHSD TP41I","Nordstar TN+ service manual"),
        Fault("Nordstar","E7","Βλάβη αισθητήρα εξωτερικού αέρα","Outdoor ambient temperature sensor failure","Outdoor sensor ή PCB","Έλεγξε thermistor και connector","Αντικατάσταση αισθητήρα/PCB","Split / Inverter","TN+ / NORP CHSD TP41I","Nordstar TN+ service manual"),
        Fault("Nordstar","E8","Βλάβη αισθητήρα θερμοκρασίας κατάθλιψης","Outdoor discharge temperature sensor failure","Discharge sensor ή PCB","Έλεγξε αισθητήρα κατάθλιψης και σύνδεση","Αντικατάσταση αισθητήρα/PCB","Split / Inverter","TN+ / NORP CHSD TP41I","Nordstar TN+ service manual"),
        Fault("Nordstar","E9","Βλάβη IPM / ελέγχου συμπιεστή","IPM / compressor driving control abnormal","IPM, outdoor PCB ή συμπιεστής","Έλεγξε IPM, DC bus, καλωδίωση και συμπιεστή","Αποκατάσταση module/PCB/συμπιεστή μετά διάγνωση","Split / Inverter","TN+ / NORP CHSD TP41I","Nordstar TN+ service manual"),
        Fault("Nordstar","EA","Βλάβη κυκλώματος μέτρησης ρεύματος εξωτερικής","Outdoor current test circuit failure","Outdoor PCB","Έλεγξε outdoor PCB και κύκλωμα current sensing","Επισκευή/αντικατάσταση PCB","Split / Inverter","TN+ / NORP CHSD TP41I","Nordstar TN+ service manual"),
        Fault("Nordstar","EE","Βλάβη EEPROM εξωτερικής","Outdoor EEPROM failure","Outdoor PCB/EEPROM","Κάνε power reset και έλεγξε PCB","Αν επιμένει, επισκευή/αντικατάσταση PCB","Split / Inverter","TN+ / NORP CHSD TP41I","Nordstar TN+ service manual"),
        Fault("Nordstar","EF","Βλάβη DC ανεμιστήρα εξωτερικής","Outdoor DC fan motor failure","Fan motor ή outdoor PCB","Έλεγξε μοτέρ, φτερωτή, feedback και PCB","Αποκατάσταση fan/PCB","Split / Inverter","TN+ / NORP CHSD TP41I","Nordstar TN+ service manual"),
        Fault("Nordstar","P0","Προστασία IPM","IPM module protection","Outdoor PCB/IPM, συμπιεστής ή φορτίο","Έλεγξε IPM, τάσεις και συμπιεστή","Αποκατάσταση πραγματικής αιτίας","Split / Inverter","TN+ / NORP CHSD TP41I","Nordstar TN+ service manual"),
        Fault("Nordstar","P1","Προστασία υπέρτασης/υπότασης","Over/under voltage protection","Τροφοδοσία ή outdoor PCB","Μέτρησε τάση εισόδου και DC bus","Αποκατάσταση τροφοδοσίας/PCB","Split / Inverter","TN+ / NORP CHSD TP41I","Nordstar TN+ service manual"),

        Fault("Pitsos","NO COOL","Χαμηλή απόδοση ψύξης","Poor cooling performance","Βρώμικα φίλτρα/εναλλάκτες, εμπόδιο airflow, ανοιχτά παράθυρα ή χαμηλό ψυκτικό","Έλεγξε φίλτρα, εναλλάκτες, airflow, θερμοκρασίες, διαρροές και φόρτιση","Καθαρισμός/αποκατάσταση airflow ή επισκευή διαρροής και σωστή φόρτιση","Split / Inverter","PSI/PSO VW30 / Pitsos inverter","Pitsos PSI09VW30-PSO09VW30 manual"),
        Fault("Pitsos","NO START","Δεν ξεκινά η μονάδα","Unit does not start","Διακοπή ρεύματος, ασφάλεια, τροφοδοσία ή ενεργή προστασία 3 λεπτών","Έλεγξε παροχή, ασφάλειες/διακόπτη και περίμενε την προστασία επανεκκίνησης","Αποκατάσταση τροφοδοσίας ή διάγνωση αν επιμένει","Split / Inverter","PSI/PSO VW30 / Pitsos inverter","Pitsos PSI09VW30-PSO09VW30 manual"),
        Fault("Pitsos","SHORT CYCLE","Συχνές εκκινήσεις και σταματήματα","Unit starts and stops frequently","Υπερβολική/ανεπαρκής φόρτιση, υγρασία/μη συμπυκνώσιμα, συμπιεστής ή τάση","Έλεγξε πιέσεις/φόρτιση, διαρροές, κενό, τάση και συμπιεστή","Διόρθωση φόρτισης, σωστό κενό ή επισκευή επιβεβαιωμένης βλάβης","Split / Inverter","PSI/PSO VW30 / Pitsos inverter","Pitsos PSI09VW30-PSO09VW30 manual"),
        Fault("Pitsos","LOW GAS","Χαμηλό ψυκτικό / πιθανή διαρροή","Low refrigerant due to leak or long-term use","Διαρροή ψυκτικού","Έλεγξε στεγανότητα, πιέσεις και λειτουργικές θερμοκρασίες","Επισκευή διαρροής, κενό και φόρτιση κατά πινακίδα","Split / Inverter","PSI/PSO VW30 / Pitsos inverter","Pitsos PSI09VW30-PSO09VW30 manual"),
        Fault("Pitsos","ERROR DISPLAY","Εμφάνιση E/P/F κωδικού στην εσωτερική","Indoor display shows E0/E1/E2, P1/P2/P3, F1/F2/F3 etc.","Το συγκεκριμένο νόημα εξαρτάται από πλατφόρμα/μοντέλο","Κατέγραψε ακριβή κωδικό και E-number πριν την επισκευή· έλεγξε το model-specific service data","Μην αντιστοιχίζεις αυθαίρετα κωδικό άλλης πλατφόρμας","Split / Inverter","PSI/PSO VW30 / P1ZAI families","Pitsos manuals + official Service Assistant"),
        // ===== VERIFIED FAULTS BATCH 5: MITSUBISHI HEAVY / RHOSS / ROTENSO =====
        Fault("Mitsubishi Heavy","E1","Σφάλμα επικοινωνίας χειριστηρίου / PCB εσωτερικής","Remote controller communication / indoor PCB error","Remote controller wiring, controller ή indoor PCB","Έλεγξε X/Y καλωδίωση, χειριστήριο και indoor PCB","Αποκατάσταση καλωδίωσης ή επιβεβαιωμένου ελαττωματικού μέρους","Split / Inverter","MHI FDC / FD series","Mitsubishi Heavy service manual"),
        Fault("Mitsubishi Heavy","E5","Σφάλμα μετάδοσης εσωτερικής-εξωτερικής","Indoor/outdoor transmission error","Outdoor control PCB, inverter ή γραμμή επικοινωνίας","Έλεγξε τροφοδοσίες, transmission wiring και outdoor PCB/inverter","Αποκατάσταση επικοινωνίας/PCB","Split / Inverter","MHI FDC / FD series","Mitsubishi Heavy service manual"),
        Fault("Mitsubishi Heavy","E6","Βλάβη thermistor εσωτερικού εναλλάκτη","Indoor heat exchanger thermistor failure","Thermistor open/short ή σύνδεση","Έλεγξε αντίσταση thermistor και connector","Αντικατάσταση αισθητήρα/σύνδεσης","Split / Inverter","MHI FDC / FD series","Mitsubishi Heavy service manual"),
        Fault("Mitsubishi Heavy","E7","Βλάβη thermistor επιστροφής αέρα","Indoor return air thermistor failure","Thermistor ή σύνδεση","Έλεγξε αισθητήρα και connector","Αντικατάσταση αισθητήρα","Split / Inverter","MHI FDC / FD series","Mitsubishi Heavy service manual"),
        Fault("Mitsubishi Heavy","E8","Υπερφόρτωση στη θέρμανση","Heating overload / indoor HEX temperature high","Airflow, thermistor ή υψηλή θερμοκρασία εναλλάκτη","Έλεγξε φίλτρα, airflow, thermistor και λειτουργία συστήματος","Αποκατάσταση αιτίας υπερθέρμανσης","Split / Inverter","MHI FDC / FD series","Mitsubishi Heavy service manual"),
        Fault("Mitsubishi Heavy","E9","Βλάβη αποχέτευσης / float","Drain trouble / float switch operation","Drain pump, float ή βουλωμένη αποχέτευση","Έλεγξε drain, pump, float και σωληνώσεις","Καθαρισμός/επισκευή αποχέτευσης","Κασέτα","MHI FD cassette/duct","Mitsubishi Heavy service manual"),
        Fault("Mitsubishi Heavy","E16","Βλάβη μοτέρ εσωτερικού ανεμιστήρα","Indoor fan motor anomaly","Fan motor, feedback ή PCB","Έλεγξε μοτέρ, περιστροφή, connectors και PCB","Αποκατάσταση μοτέρ/PCB","Split / Inverter","MHI FDC / FD series","Mitsubishi Heavy service manual"),
        Fault("Mitsubishi Heavy","E28","Βλάβη αισθητήρα χειριστηρίου","Remote controller thermistor failure","Thermistor χειριστηρίου","Έλεγξε αισθητήρα/χειριστήριο και καλωδίωση","Αντικατάσταση χειριστηρίου/αισθητήρα","Split / Inverter","MHI FDC / FD series","Mitsubishi Heavy service manual"),
        Fault("Mitsubishi Heavy","E32","Λάθος ακολουθία ή απώλεια φάσης","Open wiring or reverse phase","Τριφασική τροφοδοσία","Έλεγξε τάσεις και phase sequence","Αποκατάσταση τροφοδοσίας/σειράς φάσεων","Split / Inverter","MHI FDC series","Mitsubishi Heavy service manual"),
        Fault("Mitsubishi Heavy","E35","Υψηλή θερμοκρασία εξωτερικού εναλλάκτη","Outdoor heat exchanger temperature high","Βρώμικος εναλλάκτης, airflow ή thermistor","Έλεγξε condenser, fan και thermistor","Καθαρισμός/αποκατάσταση airflow ή αισθητήρα","Split / Inverter","MHI FDC series","Mitsubishi Heavy service manual"),
        Fault("Mitsubishi Heavy","E36","Ανώμαλη θερμοκρασία κατάθλιψης","Discharge temperature abnormality","Φόρτιση, περιορισμός ή υπερθέρμανση","Έλεγξε discharge temperature, πιέσεις και φόρτιση","Αποκατάσταση αιτίας υπερθέρμανσης","Split / Inverter","MHI FDC series","Mitsubishi Heavy service manual"),
        Fault("Mitsubishi Heavy","E37","Βλάβη thermistor εξωτερικού εναλλάκτη","Outdoor heat exchanger thermistor failure","Thermistor ή σύνδεση","Έλεγξε αισθητήρα/connector","Αντικατάσταση αισθητήρα","Split / Inverter","MHI FDC series","Mitsubishi Heavy service manual"),
        Fault("Mitsubishi Heavy","E38","Βλάβη thermistor εξωτερικού αέρα","Outdoor air thermistor failure","Thermistor ή σύνδεση","Έλεγξε αισθητήρα/connector","Αντικατάσταση αισθητήρα","Split / Inverter","MHI FDC series","Mitsubishi Heavy service manual"),
        Fault("Mitsubishi Heavy","E39","Βλάβη thermistor σωλήνα κατάθλιψης","Discharge pipe thermistor failure","Thermistor ή σύνδεση","Έλεγξε thermistor και connector","Αντικατάσταση αισθητήρα","Split / Inverter","MHI FDC series","Mitsubishi Heavy service manual"),
        Fault("Mitsubishi Heavy","E42","Υπερένταση συμπιεστή","Compressor over-current","Συμπιεστής, inverter ή υψηλό φορτίο","Μέτρησε ρεύμα/τάση και έλεγξε συμπιεστή/inverter","Αποκατάσταση αιτίας υπερέντασης","Split / Inverter","MHI FDC series","Mitsubishi Heavy service manual"),
        Fault("Mitsubishi Heavy","E47","Υπέρταση inverter","Inverter over-voltage","Τροφοδοσία ή inverter","Έλεγξε input/DC bus voltage και inverter","Αποκατάσταση τροφοδοσίας/inverter","Split / Inverter","MHI FDC series","Mitsubishi Heavy service manual"),
        Fault("Mitsubishi Heavy","E48","Βλάβη DC ανεμιστήρα εξωτερικής","Outdoor DC fan motor abnormality","Fan motor, drive ή wiring","Έλεγξε μοτέρ, περιστροφή, connectors και drive","Αποκατάσταση fan/drive","Split / Inverter","MHI FDC series","Mitsubishi Heavy service manual"),
        Fault("Mitsubishi Heavy","E57","Ανεπαρκές ψυκτικό","Insufficient refrigerant","Διαρροή ή χαμηλή φόρτιση","Έλεγξε διαρροές, πιέσεις και φόρτιση","Επισκευή διαρροής, κενό και σωστή φόρτιση","Split / Inverter","MHI FDC series","Mitsubishi Heavy service manual"),
        Fault("Mitsubishi Heavy","E59","Σφάλμα εκκίνησης συμπιεστή","Compressor startup error","Συμπιεστής ή inverter","Έλεγξε τυλίγματα/μόνωση, inverter και τροφοδοσία","Αποκατάσταση drive ή συμπιεστή μετά επιβεβαίωση","Split / Inverter","MHI FDC series","Mitsubishi Heavy service manual"),

        Fault("Rhoss","AL:002","Αντιπαγωτικός συναγερμός","Antifreeze alarm","Χαμηλό set-point ή ανεπαρκής ροή νερού","Έλεγξε set-point, παροχή, κυκλοφορητή και θερμοκρασίες","Διόρθωσε set-point/ροή πριν reset","Chiller / Ψύκτης","Rhoss chiller controller","Rhoss Chiller User Manual"),
        Fault("Rhoss","AL:005","Συναγερμός διαφορικού πιεσοστάτη νερού","Water differential pressure switch alarm","Ανεπαρκής ροή, αέρας, κλειστές βάνες, pump ή βουλωμένο φίλτρο","Έλεγξε flow, εξαέρωση, βάνες, pump και φίλτρο","Αποκατάσταση σωστής ροής νερού","Chiller / Ψύκτης","Rhoss chiller controller","Rhoss Chiller User Manual"),
        Fault("Rhoss","AL:010","Συναγερμός χαμηλής πίεσης","Low pressure alarm","Ενεργοποίηση low-pressure switch","Έλεγξε πραγματική πίεση, διαρροές, φόρτιση και κύκλωμα","Αποκατάσταση αιτίας και reset σύμφωνα με manual","Chiller / Ψύκτης","Rhoss chiller controller","Rhoss Chiller User Manual"),
        Fault("Rhoss","AL:012","Συναγερμός υψηλής πίεσης","High pressure switch alarm","Ενεργοποίηση high-pressure switch","Έλεγξε πίεση, condenser/airflow ή water flow και pressostat","Αποκατάσταση αιτίας, reset pressostat και controller","Chiller / Ψύκτης","Rhoss chiller controller","Rhoss Chiller User Manual"),
        Fault("Rhoss","AL:020","Θερμική προστασία ανεμιστήρα","Fan thermal protection alarm","Βραχυκύκλωμα ή βλάβη ανεμιστήρα","Έλεγξε fan motor, ρεύμα και καλωδίωση","Αντικατάσταση/επισκευή fan αν απαιτείται","Chiller / Ψύκτης","Rhoss chiller controller","Rhoss Chiller User Manual"),
        Fault("Rhoss","AL:021","Συναγερμός αντλίας 1","Pump 1 alarm","Pump 1 ή προστασία/τροφοδοσία","Έλεγξε pump, overload, τροφοδοσία και flow","Αποκατάσταση αντλίας/τροφοδοσίας","Chiller / Ψύκτης","Rhoss chiller controller","Rhoss Chiller User Manual"),
        Fault("Rhoss","AL:022","Συναγερμός αντλίας 2","Pump 2 alarm","Pump 2 ή προστασία/τροφοδοσία","Έλεγξε pump, overload, τροφοδοσία και flow","Αποκατάσταση αντλίας/τροφοδοσίας","Chiller / Ψύκτης","Rhoss chiller controller","Rhoss Chiller User Manual"),
        Fault("Rhoss","AL:030","Βλάβη αισθητήρα B1/ST1","Inlet water temperature sensor fault","Sensor open/short ή σύνδεση","Έλεγξε sensor και καλωδίωση","Αντικατάσταση αισθητήρα","Chiller / Ψύκτης","Rhoss chiller controller","Rhoss Chiller User Manual"),
        Fault("Rhoss","AL:033","Βλάβη αισθητήρα ST4/B4","Buffer tank outlet sensor fault","Sensor ή καλωδίωση","Έλεγξε thermistor και connector","Αντικατάσταση αισθητήρα","Chiller / Ψύκτης","Rhoss chiller controller","Rhoss Chiller User Manual"),
        Fault("Rhoss","AL:034","Βλάβη αισθητήρα εξόδου εξατμιστή","Evaporator outlet water sensor fault","Sensor ή καλωδίωση","Έλεγξε thermistor και σύνδεση","Αντικατάσταση αισθητήρα","Chiller / Ψύκτης","Rhoss chiller controller","Rhoss Chiller User Manual"),
        Fault("Rhoss","AL:035","Βλάβη pressure transducer","Pressure transducer alarm","Transducer ή καλωδίωση","Σύγκρινε πραγματική πίεση με σήμα transducer και έλεγξε τροφοδοσία","Αποκατάσταση/αντικατάσταση transducer","Chiller / Ψύκτης","Rhoss chiller controller","Rhoss Chiller User Manual"),

        Fault("Rotenso","E0","Σφάλμα επικοινωνίας εσωτερικής-εξωτερικής","Indoor/outdoor communication failure","Communication wiring ή PCB","Έλεγξε καλωδίωση, τροφοδοσίες και PCB","Αποκατάσταση επικοινωνίας","Split / Inverter","KASI K26/K35/K50/K70","Rotenso KASI Service Manual"),
        Fault("Rotenso","EC","Σφάλμα επικοινωνίας εξωτερικής","Outdoor communication failure","Outdoor communication/PCB","Έλεγξε outdoor connections και boards","Αποκατάσταση επικοινωνίας","Split / Inverter","KASI K26/K35/K50/K70","Rotenso KASI Service Manual"),
        Fault("Rotenso","E1","Βλάβη αισθητήρα θερμοκρασίας χώρου","Indoor room temperature sensor fault","IRT sensor open/short","Έλεγξε sensor και connector","Αντικατάσταση αισθητήρα","Split / Inverter","KASI K26/K35/K50/K70","Rotenso KASI Service Manual"),
        Fault("Rotenso","E2","Βλάβη αισθητήρα εσωτερικού στοιχείου","Indoor coil temperature sensor fault","IPT sensor open/short","Έλεγξε sensor/connector","Αντικατάσταση αισθητήρα","Split / Inverter","KASI K26/K35/K50/K70","Rotenso KASI Service Manual"),
        Fault("Rotenso","E3","Βλάβη αισθητήρα εξωτερικού στοιχείου","Outdoor coil temperature sensor fault","OPT sensor open/short","Έλεγξε sensor/connector","Αντικατάσταση αισθητήρα","Split / Inverter","KASI K26/K35/K50/K70","Rotenso KASI Service Manual"),
        Fault("Rotenso","E4","Ανωμαλία συστήματος","System abnormality","Ψυκτικό/ηλεκτρικό σύστημα — απαιτεί περαιτέρω διάγνωση","Έλεγξε outdoor diagnostics, πιέσεις και ηλεκτρικά","Αποκατάσταση επιβεβαιωμένης αιτίας","Split / Inverter","KASI K26/K35/K50/K70","Rotenso KASI Service Manual"),
        Fault("Rotenso","E5","Λάθος configuration μοντέλου","Model configuration wrong","Λανθασμένη ρύθμιση PCB/model","Έλεγξε configuration/jumper σύμφωνα με μοντέλο","Διόρθωσε configuration","Split / Inverter","KASI K26/K35/K50/K70","Rotenso KASI Service Manual"),
        Fault("Rotenso","14","Βλάβη IPM","IPM fault","Inverter power module","Έλεγξε IPM, DC bus και συμπιεστή","Αποκατάσταση module/αιτίας","Split / Inverter","KASI inverter outdoor","Rotenso KASI Service Manual"),
        Fault("Rotenso","16","Χωρίς feedback DC ανεμιστήρα εξωτερικής","No feedback from outdoor DC fan motor","Fan motor, feedback ή drive","Έλεγξε μοτέρ, connector και drive","Αποκατάσταση fan/drive","Split / Inverter","KASI inverter outdoor","Rotenso KASI Service Manual"),
        // ===== VERIFIED FAULTS BATCH 4: LENNOX / LG / PANASONIC =====
        Fault("Lennox","E1","Σφάλμα ακολουθίας φάσεων","Phase sequence error","Λανθασμένη σειρά φάσεων","Έλεγξε τριφασική τροφοδοσία και phase sequence","Διόρθωσε σειρά φάσεων με απομονωμένη τροφοδοσία","VRF / VRV","LV-MSO","Lennox LV-MSO Service Manual"),
        Fault("Lennox","E2","Σφάλμα επικοινωνίας εσωτερικής-εξωτερικής","Indoor/outdoor communication error","Bus, καλωδίωση, addressing ή PCB","Έλεγξε communication wiring, τροφοδοσίες και πλακέτες","Αποκατάσταση επικοινωνίας","VRF / VRV","LV-MSO / LV-MOC","Lennox official Service Manual"),
        Fault("Lennox","E4","Σφάλμα αισθητήρα T3/T4","Outdoor heat exchanger T3 or ambient T4 sensor error","Thermistor T3/T4 ή σύνδεση","Έλεγξε αντίσταση αισθητήρων και καλωδίωση","Αντικατάσταση αισθητήρα/σύνδεσης","VRF / VRV","LV-MSO / LV-MOC","Lennox official Service Manual"),
        Fault("Lennox","E5","Ανώμαλη τάση τροφοδοσίας","Abnormal input power voltage","Τάση εκτός ορίων","Μέτρησε τάσεις και έλεγξε τροφοδοσία","Αποκατάσταση τροφοδοσίας","VRF / VRV","LV-MSO / LV-MOC","Lennox official Service Manual"),
        Fault("Lennox","E6","Βλάβη DC ανεμιστήρα","DC fan motor error/protection","Μοτέρ, drive ή καλωδίωση","Έλεγξε περιστροφή, μοτέρ, φίσες και drive","Αποκατάσταση μοτέρ/drive","VRF / VRV","LV-MSO / LV-MOC","Lennox official Service Manual"),
        Fault("Lennox","E7","Σφάλμα αισθητήρα κατάθλιψης T5","Compressor discharge T5 sensor error","T5 thermistor ή σύνδεση","Έλεγξε T5 και καλωδίωση","Αντικατάσταση αισθητήρα","VRF / VRV","LV-MSO / LV-MOC","Lennox official Service Manual"),
        Fault("Lennox","H0","Σφάλμα επικοινωνίας main control-inverter","Main control to inverter driver communication error","PCB/drive communication","Έλεγξε τροφοδοσία και συνδέσεις μεταξύ boards","Αποκατάσταση επικοινωνίας/PCB","VRF / VRV","LV-MSO / LV-MOC","Lennox official Service Manual"),
        Fault("Lennox","H7","Λάθος αριθμός εσωτερικών μονάδων","Detected indoor-unit number differs from setting","Addressing/configuration ή επικοινωνία","Έλεγξε αριθμό IDU, addressing και bus","Διόρθωσε configuration","VRF / VRV","LV-MSO / LV-MOC","Lennox official Service Manual"),
        Fault("Lennox","P1","Προστασία υψηλής πίεσης","Discharge/system high pressure protection","Υψηλή πίεση, airflow ή φόρτιση","Έλεγξε πιέσεις, συμπυκνωτή, ανεμιστήρες και φόρτιση","Αποκατάσταση αιτίας υψηλής πίεσης","VRF / VRV","LV-MSO / LV-MOC","Lennox official Service Manual"),
        Fault("Lennox","P2","Προστασία χαμηλής πίεσης","Suction/system low pressure protection","Έλλειψη ψυκτικού ή περιορισμός","Έλεγξε διαρροές, φόρτιση, EXV και φίλτρο","Αποκατάσταση διαρροής/περιορισμού","VRF / VRV","LV-MSO / LV-MOC","Lennox official Service Manual"),
        Fault("Lennox","P3","Προστασία υπερέντασης συμπιεστή","Compressor current protection","Υψηλό φορτίο, συμπιεστής ή inverter","Μέτρησε ρεύμα/τάση και έλεγξε συμπιεστή","Αποκατάσταση αιτίας υπερέντασης","VRF / VRV","LV-MSO / LV-MOC","Lennox official Service Manual"),
        Fault("Lennox","P4","Προστασία θερμοκρασίας κατάθλιψης","Discharge temperature protection","Υπερθέρμανση κατάθλιψης","Έλεγξε T5, πιέσεις, φόρτιση και ψυκτικό κύκλωμα","Αποκατάσταση αιτίας υπερθέρμανσης","VRF / VRV","LV-MSO / LV-MOC","Lennox official Service Manual"),
        Fault("Lennox","L0","Προστασία inverter module","IPM/inverter module protection","Module, συμπιεστής ή τροφοδοσία","Έλεγξε DC bus, IPM, συμπιεστή και ψύξη module","Αποκατάσταση επιβεβαιωμένης αιτίας","VRF / VRV","LV-MSO / LV-MOC","Lennox official Service Manual"),

        Fault("LG","CH04","Σφάλμα αποχέτευσης συμπυκνωμάτων","Drainage error / condensate not draining","Drain, αντλία συμπυκνωμάτων ή υψηλή στάθμη","Έλεγξε αποχέτευση, αντλία και float","Καθαρισμός/επισκευή drain system","Split / Inverter","LG Air Conditioners","LG official Help Library"),
        Fault("LG","CH07","Σύγκρουση τρόπου λειτουργίας","Operation mode conflict","Μία εσωτερική ζητά θέρμανση ενώ άλλη ψύξη/αφύγρανση","Έλεγξε mode όλων των εσωτερικών","Ρύθμισε συμβατό mode σε όλες τις μονάδες","Multi-Split","LG Multi / ceiling","LG official Help Library"),
        Fault("LG","CH10","Βλάβη ανεμιστήρα εσωτερικής","Indoor fan error","Μοτέρ εσωτερικού ανεμιστήρα, μπλοκάρισμα ή controller","Έλεγξε ανεμιστήρα, εμπόδια, μοτέρ και σύνδεση","Αποκατάσταση μοτέρ/εμποδίου/controller","Split / Inverter","LG Air Conditioners","LG official Help Library"),
        Fault("LG","CH38","Χαμηλή ποσότητα ψυκτικού","Low refrigerant protection","Έλλειψη ψυκτικού / πιθανή διαρροή","Έλεγξε διαρροές, πιέσεις και φόρτιση","Επισκευή διαρροής, κενό και σωστή φόρτιση","Split / Inverter","LG Air Conditioners","LG official Help Library"),
        Fault("LG","CH53","Σφάλμα επικοινωνίας εσωτερικής-εξωτερικής","Indoor/outdoor communication issue","Καλωδίωση, τροφοδοσία ή PCB","Έλεγξε communication wiring και τροφοδοσίες","Αποκατάσταση επικοινωνίας","Split / Inverter","LG inverter","LG official Help Library"),
        Fault("LG","CH61","Προστασία υπερθέρμανσης","Outdoor overheat in cooling / indoor overheat in heating","Κακός αερισμός εξωτερικής ή βρώμικο φίλτρο εσωτερικής","Έλεγξε αερισμό εξωτερικής, φίλτρα και airflow","Αποκατάσταση αερισμού/καθαρισμός","Split / Inverter","LG Air Conditioners","LG official Help Library"),
        Fault("LG","CH66","Σφάλμα σύνδεσης επικοινωνίας ή σωληνώσεων","Communication or piping connection detection","Λάθος σύνδεση μετά από εγκατάσταση ή ασταθής τροφοδοσία","Έλεγξε καλωδίωση και αντιστοίχιση σωληνώσεων","Διόρθωσε σύνδεση/τροφοδοσία","Multi-Split","LG inverter","LG official Help Library"),
        Fault("LG","CH67","Βλάβη ανεμιστήρα εξωτερικής","Outdoor fan error","Outdoor fan, εμπόδιο ή controller","Έλεγξε ανεμιστήρα, μοτέρ, εμπόδια και σύνδεση","Αποκατάσταση μοτέρ/controller","Split / Inverter","LG Air Conditioners","LG official Help Library"),
        Fault("LG","CH90","Σφάλμα test run / σωληνώσεων","Test-run piping protection","Πρόβλημα σωληνώσεων μετά εγκατάσταση","Έλεγξε piping connections και service valves","Διόρθωσε εγκατάσταση","Split / Inverter","LG inverter","LG official Help Library"),
        Fault("LG","CH91","Σφάλμα test run / ψυκτικού κυκλώματος","Test-run protection","Πρόβλημα εγκατάστασης/σωληνώσεων","Έλεγξε piping, βάνες και εγκατάσταση","Αποκατάσταση εγκατάστασης","Split / Inverter","LG inverter","LG official Help Library"),
        Fault("LG","CH93","Σφάλμα επικοινωνίας εσωτερικής-εξωτερικής","Indoor/outdoor communication problem","Communication unstable ή outdoor χωρίς τροφοδοσία","Έλεγξε τροφοδοσία και καλώδια και των δύο μονάδων","Αποκατάσταση τροφοδοσίας/επικοινωνίας","Split / Inverter","LG inverter","LG official Help Library"),

        Fault("Panasonic","H11","Σφάλμα επικοινωνίας εσωτερικής-εξωτερικής","Indoor/outdoor abnormal communication","Καλώδιο σύνδεσης ή PCB","Έλεγξε terminals, connection wire και indoor/outdoor PCB","Αποκατάσταση καλωδίωσης ή PCB","Split / Inverter","Panasonic RAC","Panasonic official Service Manual"),
        Fault("Panasonic","H14","Βλάβη αισθητήρα αέρα εισόδου εσωτερικής","Indoor intake air temperature sensor abnormality","Αισθητήρας open/short ή σύνδεση","Έλεγξε sensor lead/connector και αντίσταση","Αντικατάσταση αισθητήρα/σύνδεσης","Split / Inverter","Panasonic RAC","Panasonic official Service Manual"),
        Fault("Panasonic","H15","Βλάβη αισθητήρα θερμοκρασίας συμπιεστή","Compressor temperature sensor abnormality","Sensor open/short","Έλεγξε αισθητήρα και connector","Αντικατάσταση αισθητήρα","Split / Inverter","Panasonic RAC","Panasonic official Service Manual"),
        Fault("Panasonic","H16","Βλάβη CT εξωτερικής","Outdoor current transformer abnormality","Outdoor PCB/CT ή συμπιεστής","Έλεγξε outdoor PCB, CT και συμπιεστή","Αποκατάσταση PCB/συμπιεστή μετά επιβεβαίωση","Split / Inverter","Panasonic RAC","Panasonic official Service Manual"),
        Fault("Panasonic","H19","Μπλοκάρισμα μοτέρ εσωτερικού ανεμιστήρα","Indoor fan motor mechanism lock","Fan motor lock ή feedback abnormal","Έλεγξε μοτέρ, connector και μηχανικό μπλοκάρισμα","Αποκατάσταση μοτέρ/εμποδίου","Split / Inverter","Panasonic RAC","Panasonic official Service Manual"),
        Fault("Panasonic","H23","Βλάβη αισθητήρα εσωτερικού εναλλάκτη","Indoor heat exchanger temperature sensor abnormality","Sensor open/short","Έλεγξε sensor lead και connector","Αντικατάσταση αισθητήρα","Split / Inverter","Panasonic RAC","Panasonic official Service Manual"),
        Fault("Panasonic","H27","Βλάβη αισθητήρα εξωτερικού αέρα","Outdoor air temperature sensor abnormality","Sensor open/short","Έλεγξε sensor/connector","Αντικατάσταση αισθητήρα","Split / Inverter","Panasonic RAC","Panasonic official Service Manual"),
        Fault("Panasonic","H28","Βλάβη αισθητήρα εξωτερικού εναλλάκτη","Outdoor heat exchanger sensor abnormality","Sensor open/short","Έλεγξε thermistor και connector","Αντικατάσταση αισθητήρα","Split / Inverter","Panasonic RAC","Panasonic official Service Manual"),
        Fault("Panasonic","H30","Βλάβη αισθητήρα κατάθλιψης","Discharge pipe temperature sensor abnormality","Sensor open/short","Έλεγξε αισθητήρα κατάθλιψης","Αντικατάσταση αισθητήρα","Split / Inverter","Panasonic RAC","Panasonic official Service Manual"),
        Fault("Panasonic","H97","Μπλοκάρισμα μοτέρ εξωτερικού ανεμιστήρα","Outdoor fan motor lock","Outdoor fan motor","Έλεγξε ανεμιστήρα, μοτέρ και PCB drive","Αποκατάσταση μοτέρ/drive","Split / Inverter","Panasonic RAC","Panasonic official Service Manual"),
        Fault("Panasonic","H98","Προστασία υψηλής πίεσης εσωτερικής","Indoor high pressure protection","Βρώμικο φίλτρο ή βραχυκύκλωση αέρα","Έλεγξε φίλτρο και κυκλοφορία αέρα","Καθαρισμός και αποκατάσταση airflow","Split / Inverter","Panasonic RAC","Panasonic official Service Manual"),
        Fault("Panasonic","H99","Αντιπαγωτική προστασία εσωτερικού εναλλάκτη","Indoor heat exchanger anti-freezing protection","Έλλειψη ψυκτικού ή βρώμικο φίλτρο","Έλεγξε φόρτιση/διαρροές και airflow","Αποκατάσταση ψυκτικού/airflow","Split / Inverter","Panasonic RAC","Panasonic official Service Manual"),
        Fault("Panasonic","F11","Σφάλμα αλλαγής κύκλου ψύξης/θέρμανσης","Cooling/heating cycle changeover abnormality","Τετράοδη βαλβίδα ή πηνίο","Έλεγξε 4-way valve και V-coil","Αποκατάσταση βαλβίδας/πηνίου","Split / Inverter","Panasonic RAC","Panasonic official Service Manual"),
        Fault("Panasonic","F91","Ανωμαλία ψυκτικού κύκλου","Refrigeration cycle abnormality","Έλλειψη ψυκτικού ή κλειστή 3-way valve","Έλεγξε ψυκτικό και service valves","Επισκευή διαρροής/άνοιγμα βαλβίδων και σωστή φόρτιση","Split / Inverter","Panasonic RAC","Panasonic official Service Manual"),
        Fault("Panasonic","F93","Ανωμαλία συμπιεστή","Compressor abnormality","Συμπιεστής/drive","Έλεγξε συμπιεστή και inverter drive","Αποκατάσταση επιβεβαιωμένης αιτίας","Split / Inverter","Panasonic RAC","Panasonic official Service Manual"),
        Fault("Panasonic","F96","Προστασία υπερθέρμανσης IPM","IPM overheating protection","Υπερφόρτιση ψυκτικού ή κακή απαγωγή θερμότητας IPM","Έλεγξε φόρτιση, ψύκτρα και module","Αποκατάσταση φόρτισης/ψύξης/module","Split / Inverter","Panasonic RAC","Panasonic official Service Manual"),
        Fault("Panasonic","F97","Προστασία υπερθέρμανσης συμπιεστή","Compressor overheating protection","Έλλειψη ψυκτικού ή συμπιεστής","Έλεγξε φόρτιση/διαρροές και συμπιεστή","Αποκατάσταση ψυκτικού ή συμπιεστή","Split / Inverter","Panasonic RAC","Panasonic official Service Manual"),
        Fault("Panasonic","F99","Προστασία peak current εξωτερικής","Outdoor peak current protection","Outdoor PCB, IPM ή συμπιεστής","Έλεγξε PCB, IPM, ρεύμα και συμπιεστή","Αποκατάσταση επιβεβαιωμένης αιτίας","Split / Inverter","Panasonic RAC","Panasonic official Service Manual"),
        // ===== VERIFIED FAULTS BATCH 3B: HISENSE / HITACHI / INVENTOR =====

        Fault("Hitachi","01","Ενεργοποίηση προστατευτικής διάταξης εσωτερικής","Indoor protection device activated","Float switch/αποχέτευση ή προστασία εσωτερικής ανά μοντέλο","Έλεγξε drain, float, αντλία συμπυκνωμάτων και σχετικές εισόδους προστασίας","Αποκατάσταση αιτίας προστασίας","VRF / Set Free","SET FREE","Hitachi SET FREE service documentation"),
        Fault("Hitachi","02","Ενεργοποίηση προστατευτικής διάταξης εξωτερικής","Outdoor protection device activated","High-pressure switch ή άλλη outdoor protection","Έλεγξε πιέσεις, pressostat, εναλλάκτη, ανεμιστήρες και outdoor PCB","Αποκατάσταση αιτίας προστασίας","VRF / Set Free","SET FREE","Hitachi SET FREE service documentation"),
        Fault("Hitachi","03","Σφάλμα μετάδοσης μεταξύ εσωτερικής και εξωτερικής","Transmission error between indoor and outdoor units","H-LINK καλωδίωση, addressing ή PCB","Έλεγξε H-LINK, πολικότητα/συνέχεια, addressing και τροφοδοσίες","Αποκατάσταση bus/addressing/PCB","VRF / Set Free","SET FREE","Hitachi SET FREE service documentation"),
        Fault("Hitachi","04","Σφάλμα μετάδοσης inverter","Inverter transmission error","Inverter PCB, main PCB ή καλωδίωση","Έλεγξε συνδέσεις inverter-main PCB και τροφοδοσίες","Αποκατάσταση επικοινωνίας ή πλακέτας","VRF / Set Free","SET FREE","Hitachi SET FREE service documentation"),
        Fault("Hitachi","05","Ανωμαλία φάσεων τροφοδοσίας","Power supply phase abnormality","Απώλεια/αντιστροφή φάσης ή τάση εκτός ορίων","Έλεγξε τριφασική τάση και phase sequence","Αποκατάσταση τροφοδοσίας","VRF / Set Free","SET FREE","Hitachi SET FREE service documentation"),
        Fault("Hitachi","08","Υψηλή θερμοκρασία κατάθλιψης","High discharge gas temperature","Έλλειψη ψυκτικού, περιορισμός, αισθητήρας ή δυσμενείς συνθήκες","Έλεγξε discharge temp, πιέσεις, φόρτιση και αισθητήρα","Αποκατάσταση αιτίας υπερθέρμανσης","VRF / Set Free","SET FREE","Hitachi SET FREE service documentation"),
        Fault("Hitachi","31","Λανθασμένη ρύθμιση ισχύος","Incorrect capacity setting","Capacity code/DIP ή PCB configuration","Έλεγξε capacity setting και συνδυασμό μονάδων","Διόρθωσε configuration","VRF / Set Free","SET FREE","Hitachi SET FREE service documentation"),

        Fault("Inventor","E1","Προστασία υψηλής πίεσης / ανάλογα με πλατφόρμα","High-pressure protection on supported platform","Υψηλή πίεση, βρώμικος συμπυκνωτής, χαμηλή ροή αέρα ή υπερφόρτιση","Επιβεβαίωσε πρώτα το service manual του συγκεκριμένου μοντέλου· μετά έλεγξε πιέσεις, airflow και φόρτιση","Αποκατάσταση αιτίας υψηλής πίεσης","Split / Inverter","EVI/EVO legacy platform","Inventor official Error Codes / Service Manual"),
        Fault("Inventor","E5","Προστασία υπερέντασης","Over-current protection","Τροφοδοσία, υψηλό φορτίο, συμπιεστής ή inverter","Έλεγξε τάση/ρεύμα, πιέσεις, συμπιεστή και module","Αποκατάσταση ηλεκτρικής/ψυκτικής αιτίας","Split / Inverter","EVI/EVO legacy platform","Inventor official Error Codes / Service Manual"),
        Fault("Inventor","E6","Σφάλμα επικοινωνίας","Communication error","Καλωδίωση εσωτερικής-εξωτερικής ή PCB","Έλεγξε σύνδεση, πολικότητα, τροφοδοσίες και PCB","Αποκατάσταση επικοινωνίας","Split / Inverter","EVI/EVO legacy platform","Inventor official Error Codes / Service Manual"),
        Fault("Inventor","F1","Σφάλμα αισθητήρα χώρου εσωτερικής","Indoor ambient sensor fault","Thermistor ή σύνδεση","Έλεγξε αντίσταση αισθητήρα και φίσα","Αντικατάσταση αισθητήρα/σύνδεσης","Split / Inverter","EVI/EVO legacy platform","Inventor official Error Codes / Service Manual"),
        Fault("Inventor","F2","Σφάλμα αισθητήρα εξατμιστή","Indoor evaporator sensor fault","Thermistor στοιχείου ή καλωδίωση","Έλεγξε αισθητήρα στοιχείου και σύνδεση","Αντικατάσταση αισθητήρα","Split / Inverter","EVI/EVO legacy platform","Inventor official Error Codes / Service Manual"),
        // ===== VERIFIED FAULTS BATCH 3: GREE / HAIER =====
        Fault("Gree","E1","Προστασία υψηλής πίεσης συμπιεστή","Compressor high pressure protection","Υψηλή πίεση συμπύκνωσης, ανεπαρκής ροή αέρα/νερού ή υπερφόρτιση","Έλεγξε πιέσεις, εναλλάκτη, ανεμιστήρα/ροή και φόρτιση","Αποκατάσταση αιτίας υψηλής πίεσης","Split / Inverter","Gree duct-free / multi","Gree official service documentation"),
        Fault("Gree","E2","Αντιπαγωτική προστασία εσωτερικού στοιχείου","Indoor anti-freeze protection","Χαμηλή θερμοκρασία στοιχείου, βρώμικο φίλτρο ή χαμηλή ροή αέρα","Έλεγξε φίλτρα, ανεμιστήρα, στοιχείο, αισθητήρα και ψυκτικό κύκλωμα","Αποκατάσταση ροής/αιτίας παγώματος","Split / Inverter","Gree duct-free / multi","Gree official service documentation"),
        Fault("Gree","E3","Προστασία χαμηλής πίεσης / έλλειψης ψυκτικού","Low pressure / refrigerant lack protection","Διαρροή, χαμηλή φόρτιση ή περιορισμός","Έλεγξε διαρροές, πιέσεις, εκτονωτικό/τριχοειδές και φίλτρο","Επισκευή διαρροής/περιορισμού, κενό και σωστή φόρτιση","Split / Inverter","Gree duct-free / multi","Gree official service documentation"),
        Fault("Gree","E4","Προστασία υψηλής θερμοκρασίας κατάθλιψης","High discharge temperature protection","Χαμηλή φόρτιση, περιορισμός ή δυσμενείς συνθήκες","Έλεγξε θερμοκρασία κατάθλιψης, πιέσεις, φόρτιση και περιορισμούς","Αποκατάσταση αιτίας υπερθέρμανσης","Split / Inverter","Gree duct-free / multi","Gree official service documentation"),
        Fault("Gree","E5","Προστασία υπερέντασης","AC over-current protection","Χαμηλή τάση, υπερφόρτωση ή ηλεκτρικό πρόβλημα","Έλεγξε τάση, ρεύμα, συμπιεστή και inverter","Αποκατάσταση τροφοδοσίας/φορτίου","Split / Inverter","Gree duct-free / multi","Gree official service documentation"),
        Fault("Gree","E6","Σφάλμα επικοινωνίας","Communication error","Γραμμή επικοινωνίας, λάθος σύνδεση ή PCB","Έλεγξε καλωδίωση, πολικότητα, τροφοδοσίες και πλακέτες","Αποκατάσταση επικοινωνίας","Split / Inverter","Gree duct-free / multi","Gree official service documentation"),
        Fault("Gree","E7","Σύγκρουση λειτουργίας","Mode conflict","Διαφορετικά modes σε multi-zone","Έλεγξε ότι όλες οι εσωτερικές ζητούν συμβατό mode","Διόρθωσε επιλογή mode","Multi-Split","Gree Multi","Gree official service documentation"),
        Fault("Gree","E9","Προστασία γεμάτου δοχείου συμπυκνωμάτων","Water full protection","Βουλωμένη αποχέτευση, αντλία ή float","Έλεγξε drain, αντλία συμπυκνωμάτων και float","Καθαρισμός/επισκευή αποχέτευσης","Κασέτα","Gree cassette/duct","Gree official service documentation"),
        Fault("Gree","F1","Σφάλμα αισθητήρα χώρου εσωτερικής","Indoor ambient sensor open/short","Αισθητήρας ή σύνδεση","Έλεγξε αντίσταση αισθητήρα και φίσα","Αντικατάσταση αισθητήρα/σύνδεσης","Split / Inverter","Gree duct-free","Gree official service documentation"),
        Fault("Gree","F2","Σφάλμα αισθητήρα εξατμιστή","Indoor evaporator sensor open/short","Αισθητήρας στοιχείου ή καλωδίωση","Έλεγξε αισθητήρα και σύνδεση","Αντικατάσταση αισθητήρα","Split / Inverter","Gree duct-free","Gree official service documentation"),
        Fault("Gree","F3","Σφάλμα αισθητήρα εξωτερικού αέρα","Outdoor ambient sensor open/short","Outdoor sensor ή καλωδίωση","Έλεγξε αισθητήρα και PCB connection","Αποκατάσταση/αντικατάσταση","Split / Inverter","Gree duct-free","Gree official service documentation"),
        Fault("Gree","F4","Σφάλμα αισθητήρα συμπυκνωτή","Outdoor condenser sensor open/short","Αισθητήρας συμπυκνωτή","Έλεγξε αντίσταση/φίσα","Αντικατάσταση αισθητήρα","Split / Inverter","Gree duct-free","Gree official service documentation"),
        Fault("Gree","F5","Σφάλμα αισθητήρα κατάθλιψης","Outdoor discharge sensor open/short","Αισθητήρας κατάθλιψης","Έλεγξε αισθητήρα/καλωδίωση","Αντικατάσταση αισθητήρα","Split / Inverter","Gree duct-free","Gree official service documentation"),
        Fault("Gree","H3","Προστασία υπερθέρμανσης συμπιεστή","Compressor overheat protection","Υπερθέρμανση κελύφους, χαμηλό ψυκτικό ή περιορισμός","Έλεγξε θερμοκρασία, πιέσεις, φόρτιση και περιορισμούς","Αποκατάσταση αιτίας υπερθέρμανσης","Split / Inverter","Gree duct-free / multi","Gree official service documentation"),
        Fault("Gree","H5","Προστασία IPM","IPM protection","Υπερθέρμανση module, χαμηλή τάση ή inverter fault","Έλεγξε τροφοδοσία, ψύξη IPM, module και συμπιεστή","Αποκατάσταση τροφοδοσίας/module","Split / Inverter","Gree duct-free / multi","Gree official service documentation"),
        Fault("Gree","H6","Χωρίς feedback μοτέρ εσωτερικού ανεμιστήρα","No indoor fan motor feedback","Μοτέρ, φίσα, μηχανικό μπλοκάρισμα ή controller","Έλεγξε ελεύθερη περιστροφή, φίσες, τροφοδοσία και feedback","Αποκατάσταση μοτέρ/PCB","Split / Inverter","Gree duct-free","Gree official service documentation"),
        Fault("Gree","C5","Βλάβη jumper cap","Jumper cap malfunction","Jumper/capacity configuration","Έλεγξε jumper και PCB","Διόρθωση jumper/configuration","Split / Inverter","Gree duct-free","Gree official service documentation"),
        Fault("Gree","EE","Βλάβη EEPROM","EEPROM malfunction","Main PCB/EEPROM","Έλεγξε τροφοδοσία και PCB","Επισκευή/αντικατάσταση PCB","Split / Inverter","Gree duct-free","Gree official service documentation"),

        Fault("Haier","E1","Βλάβη αισθητήρα θερμοκρασίας χώρου","Indoor room temperature sensor failure","Αισθητήρας χώρου ή PCB","Έλεγξε thermistor, αντίσταση και σύνδεση","Αντικατάσταση αισθητήρα/PCB αν επιβεβαιωθεί","Split / Inverter","Haier 600 Series / JACFRA","Haier official service manual"),
        Fault("Haier","E2","Βλάβη αισθητήρα σωλήνα εσωτερικής","Indoor pipe temperature sensor failure","Pipe sensor ή PCB","Έλεγξε thermistor και σύνδεση","Αντικατάσταση αισθητήρα/PCB","Split / Inverter","Haier 600 Series / JACFRA","Haier official service manual"),
        Fault("Haier","E4","Βλάβη EEPROM εσωτερικής","Indoor EEPROM error","Indoor PCB","Κάνε power reset και έλεγξε PCB/συνδέσεις","Αν επιμένει, επισκευή/αντικατάσταση PCB","Split / Inverter","Haier 600 Series / JACFRA","Haier official service manual"),
        Fault("Haier","E5","Αντιπαγωτική προστασία εσωτερικής","Indoor anti-frosting protection","Χαμηλή θερμοκρασία στοιχείου, sensor, airflow ή ψυκτικό","Έλεγξε φίλτρα, airflow, pipe sensor και ψυκτικό κύκλωμα","Αποκατάσταση αιτίας παγώματος","Split / Inverter","Haier 600 Series","Haier official service manual"),
        Fault("Haier","E7","Σφάλμα επικοινωνίας εσωτερικής-εξωτερικής","Indoor/outdoor communication fault","Communication wiring, indoor PCB, outdoor PCB ή power module","Έλεγξε καλωδίωση/συνέχεια, τροφοδοσίες και PCB","Αποκατάσταση επικοινωνίας/πλακέτας","Split / Inverter","Haier 600 Series / JACFRA","Haier official service manual"),
        Fault("Haier","E14","Βλάβη μοτέρ εσωτερικού ανεμιστήρα","Indoor fan motor malfunction","Indoor motor ή PCB","Έλεγξε μοτέρ, φίσες, τροφοδοσία και περιστροφή","Αντικατάσταση μοτέρ/PCB αν επιβεβαιωθεί","Split / Inverter","Haier 600 Series / JACFRA","Haier official service manual"),
        Fault("Haier","F1","Προστασία IPM","IPM protection","Power module, ψυκτικό κύκλωμα ή ηλεκτρικό φορτίο","Έλεγξε module, τάση, συμπιεστή και ψυκτικό κύκλωμα","Αποκατάσταση επιβεβαιωμένης αιτίας","Split / Inverter","Haier 600 Series / JACFRA","Haier official service manual"),
        Fault("Haier","F2","Στιγμιαία υπερένταση συμπιεστή","Compressor instantaneous over-current protection","Power module, συμπιεστής ή ψυκτικό κύκλωμα","Μέτρησε ρεύμα/τάση και έλεγξε module/συμπιεστή","Αποκατάσταση ηλεκτρικής ή μηχανικής αιτίας","Split / Inverter","Haier 600 Series","Haier official service manual"),
        Fault("Haier","F3","Σφάλμα επικοινωνίας power module-main PCB","Power module to main PCB communication error","Module, outdoor PCB ή σύνδεση","Έλεγξε CN connections, τροφοδοσία και boards","Αποκατάσταση σύνδεσης ή πλακέτας","Split / Inverter","Haier 600 Series","Haier official service manual"),
        Fault("Haier","F4","Προστασία θερμοκρασίας κατάθλιψης","Compressor discharge temperature protection","Υψηλή discharge temp, sensor ή ψυκτικό κύκλωμα","Έλεγξε discharge sensor, πιέσεις και φόρτιση","Αποκατάσταση αιτίας υπερθέρμανσης","Split / Inverter","Haier 600 Series","Haier official service manual"),
        Fault("Haier","F6","Βλάβη αισθητήρα εξωτερικού αέρα","Outdoor ambient sensor failure","Outdoor ambient sensor ή PCB","Έλεγξε thermistor και σύνδεση","Αντικατάσταση αισθητήρα/PCB","Split / Inverter","Haier 600 Series","Haier official service manual"),
        Fault("Haier","F7","Βλάβη αισθητήρα αναρρόφησης","Suction temperature sensor failure","Suction sensor ή PCB","Έλεγξε sensor/φίσα/αντίσταση","Αντικατάσταση αισθητήρα","Split / Inverter","Haier 600 Series","Haier official service manual"),
        Fault("Haier","F12","Βλάβη EEPROM εξωτερικής","Outdoor EEPROM error","Outdoor PCB","Power reset και έλεγχος outdoor PCB","Αν επιμένει, επισκευή/αντικατάσταση PCB","Split / Inverter","Haier 600 Series / JACFRA","Haier official service manual"),
        Fault("Haier","F13","Έλλειψη ψυκτικού","Less gas charge","Χαμηλή φόρτιση ή διαρροή","Έλεγξε διαρροές, πιέσεις και φόρτιση","Επισκευή διαρροής, κενό και φόρτιση","Split / Inverter","Haier JACFRA","Haier official service manual"),
        Fault("Haier","F14","Βλάβη τετράοδης βαλβίδας","4-way valve fault","4-way valve, coil ή έλεγχος","Έλεγξε πηνίο, τάση ενεργοποίησης και αλλαγή κύκλου","Αποκατάσταση coil/βαλβίδας/PCB","Split / Inverter","Haier JACFRA","Haier official service manual"),
        // ===== VERIFIED FAULTS BATCH 2C: FUJITSU / GENERAL =====
        // Fujitsu / GENERAL AIRSTAGE service documentation. Same platform codes retained under each brand.
        Fault("Fujitsu","E:11","Σφάλμα σειριακής επικοινωνίας","Serial communication error","Επικοινωνία εσωτερικής-εξωτερικής, καλωδίωση ή PCB","Έλεγξε τροφοδοσίες, γραμμή επικοινωνίας, φίσες και πλακέτες","Αποκατάσταση καλωδίωσης/επικοινωνίας ή PCB","Split / Inverter","AIRSTAGE / R32 inverter","Fujitsu GENERAL Service Manual"),
        Fault("Fujitsu","E:12","Σφάλμα επικοινωνίας ενσύρματου χειριστηρίου","Wired remote controller communication error","Καλωδίωση χειριστηρίου, addressing ή controller","Έλεγξε γραμμή remote controller, πολικότητα/διεύθυνση και τροφοδοσία","Αποκατάσταση σύνδεσης ή χειριστηρίου","Split / Inverter","AIRSTAGE / R32 inverter","Fujitsu GENERAL Service Manual"),
        Fault("Fujitsu","E:18","Σφάλμα εξωτερικής επικοινωνίας","External communication error","External communication interface ή καλωδίωση","Έλεγξε interface, συνδέσεις και τροφοδοσία","Αποκατάσταση interface/καλωδίωσης","Split / Inverter","AIRSTAGE / R32 inverter","Fujitsu GENERAL Service Manual"),
        Fault("Fujitsu","E:22","Σφάλμα ισχύος εσωτερικής μονάδας","Indoor unit capacity error","Λάθος capacity setting ή ασυμβατότητα μονάδων","Έλεγξε model/capacity setting και συνδυασμό IDU/ODU","Διόρθωσε ρύθμιση ή ασυμβατότητα","Split / Inverter","AIRSTAGE / R32 inverter","Fujitsu GENERAL Service Manual"),
        Fault("Fujitsu","E:23","Σφάλμα συνδυασμού μονάδων","Combination error","Μη επιτρεπτός συνδυασμός εσωτερικής/εξωτερικής","Έλεγξε συμβατότητα μοντέλων και configuration","Διόρθωσε configuration","Split / Inverter","AIRSTAGE / R32 inverter","Fujitsu GENERAL Service Manual"),
        Fault("Fujitsu","E:26","Σφάλμα διεύθυνσης ενσύρματου χειριστηρίου","Wired remote controller address setting error","Λανθασμένη/διπλή διεύθυνση","Έλεγξε remote-controller addressing","Ρύθμισε σωστή μοναδική διεύθυνση","Split / Inverter","AIRSTAGE / R32 inverter","Fujitsu GENERAL Service Manual"),
        Fault("Fujitsu","E:29","Λάθος αριθμός συνδεδεμένων μονάδων","Connected unit number error","Αριθμός/ρύθμιση συνδεδεμένων μονάδων ή επικοινωνία","Έλεγξε συνδεδεμένες μονάδες, addressing και bus","Διόρθωσε configuration/επικοινωνία","Split / Inverter","AIRSTAGE / R32 inverter","Fujitsu GENERAL Service Manual"),
        Fault("Fujitsu","E:32","Σφάλμα κύριας PCB εσωτερικής","Indoor unit main PCB error","Main PCB εσωτερικής","Έλεγξε τροφοδοσία, συνδέσεις και main PCB","Επισκευή/αντικατάσταση PCB αν επιβεβαιωθεί","Split / Inverter","AIRSTAGE / R32 inverter","Fujitsu GENERAL Service Manual"),
        Fault("Fujitsu","E:33","Σφάλμα ανίχνευσης κατανάλωσης μοτέρ εσωτερικής","Indoor motor electricity-consumption detection error","Μοτέρ ανεμιστήρα, feedback ή PCB","Έλεγξε μοτέρ, φίσες, περιστροφή και PCB","Αποκατάσταση μοτέρ/PCB","Split / Inverter","AIRSTAGE / R32 inverter","Fujitsu GENERAL Service Manual"),

        Fault("General","E:11","Σφάλμα σειριακής επικοινωνίας","Serial communication error","Επικοινωνία εσωτερικής-εξωτερικής, καλωδίωση ή PCB","Έλεγξε τροφοδοσίες, γραμμή επικοινωνίας, φίσες και πλακέτες","Αποκατάσταση καλωδίωσης/επικοινωνίας ή PCB","Split / Inverter","AIRSTAGE / R32 inverter","GENERAL AIRSTAGE Service Manual"),
        Fault("General","E:12","Σφάλμα επικοινωνίας ενσύρματου χειριστηρίου","Wired remote controller communication error","Καλωδίωση χειριστηρίου, addressing ή controller","Έλεγξε γραμμή remote controller, διεύθυνση και τροφοδοσία","Αποκατάσταση σύνδεσης ή χειριστηρίου","Split / Inverter","AIRSTAGE / R32 inverter","GENERAL AIRSTAGE Service Manual"),
        Fault("General","E:18","Σφάλμα εξωτερικής επικοινωνίας","External communication error","External interface ή καλωδίωση","Έλεγξε interface, συνδέσεις και τροφοδοσία","Αποκατάσταση interface/καλωδίωσης","Split / Inverter","AIRSTAGE / R32 inverter","GENERAL AIRSTAGE Service Manual"),
        Fault("General","E:22","Σφάλμα ισχύος εσωτερικής μονάδας","Indoor unit capacity error","Λάθος capacity setting ή ασυμβατότητα","Έλεγξε model/capacity setting και συνδυασμό μονάδων","Διόρθωσε ρύθμιση/συνδυασμό","Split / Inverter","AIRSTAGE / R32 inverter","GENERAL AIRSTAGE Service Manual"),
        Fault("General","E:23","Σφάλμα συνδυασμού μονάδων","Combination error","Μη επιτρεπτός συνδυασμός IDU/ODU","Έλεγξε συμβατότητα και configuration","Διόρθωσε configuration","Split / Inverter","AIRSTAGE / R32 inverter","GENERAL AIRSTAGE Service Manual"),
        Fault("General","E:26","Σφάλμα διεύθυνσης ενσύρματου χειριστηρίου","Wired remote controller address setting error","Λανθασμένη/διπλή διεύθυνση","Έλεγξε addressing χειριστηρίων","Ρύθμισε σωστή διεύθυνση","Split / Inverter","AIRSTAGE / R32 inverter","GENERAL AIRSTAGE Service Manual"),
        Fault("General","E:29","Λάθος αριθμός συνδεδεμένων μονάδων","Connected unit number error","Configuration/addressing ή επικοινωνία","Έλεγξε μονάδες, addressing και bus","Διόρθωσε configuration/επικοινωνία","Split / Inverter","AIRSTAGE / R32 inverter","GENERAL AIRSTAGE Service Manual"),
        Fault("General","E:32","Σφάλμα κύριας PCB εσωτερικής","Indoor unit main PCB error","Main PCB εσωτερικής","Έλεγξε τροφοδοσία και PCB","Επισκευή/αντικατάσταση PCB αν επιβεβαιωθεί","Split / Inverter","AIRSTAGE / R32 inverter","GENERAL AIRSTAGE Service Manual"),
        Fault("General","E:33","Σφάλμα ανίχνευσης κατανάλωσης μοτέρ εσωτερικής","Indoor motor electricity-consumption detection error","Μοτέρ, feedback ή PCB","Έλεγξε μοτέρ, συνδέσεις και PCB","Αποκατάσταση μοτέρ/PCB","Split / Inverter","AIRSTAGE / R32 inverter","GENERAL AIRSTAGE Service Manual"),

        // Climaveneta: official technical support identifies alarm lists for these chiller/HP families.
        Fault("Climaveneta","HP","Συναγερμός υψηλής πίεσης","High pressure alarm","Ανεμιστήρας/πύργος ψύξης, χαμηλή ροή νερού, υπερφόρτιση ψυκτικού ή βρώμικος συμπυκνωτής","Έλεγξε ανεμιστήρες ή πύργο, αντλία/παροχή νερού, φόρτιση και καθαριότητα συμπυκνωτή","Αποκατάσταση ροής/αερισμού, καθαρισμός ή διόρθωση φόρτισης σύμφωνα με manual","Chiller / Ψύκτης","FOCS / FX / i-FX / NECS / NX / i-NX / TECS / TX / MECH / MEHP","Climaveneta Technical Support Alarm List"),
        Fault("Climaveneta","LP","Συναγερμός χαμηλής πίεσης","Low pressure alarm","Εκτονωτική, διαρροή ψυκτικού, αντλία chilled water, φίλτρο dryer ή πάγος/βρωμιά","Έλεγξε EXV/TXV, διαρροές/φόρτιση, chilled-water flow, filter dryer και εξατμιστή","Επισκευή διαρροής/βαλβίδας/ροής ή καθαρισμός και σωστή φόρτιση","Chiller / Ψύκτης","FOCS / FX / i-FX / NECS / NX / i-NX / TECS / TX / MECH / MEHP","Climaveneta Technical Support Alarm List"),
        Fault("Climaveneta","PHASE","Συναγερμός ακολουθίας φάσεων","Phase sequence alarm","Λάθος σειρά ή απώλεια φάσης","Έλεγξε τριφασική τροφοδοσία, τάσεις και phase sequence","Διόρθωσε τροφοδοσία/σειρά φάσεων με απομονωμένη παροχή","Chiller / Ψύκτης","Climaveneta Chiller / Heat Pump","Climaveneta Technical Support Q&A"),
        // ===== VERIFIED FAULTS BATCH 2: CARRIER / COOPER&HUNTER =====
        // Carrier 30RB/30RQ Pro-Dialog+ alarm table
        Fault("Carrier","th-01","Βλάβη αισθητήρα εισόδου νερού εναλλάκτη","Entering water heat exchanger sensor fault","Ελαττωματικό thermistor","Έλεγξε thermistor, αντίσταση, φίσα και καλωδίωση","Αντικατάσταση αισθητήρα/αποκατάσταση σύνδεσης","Chiller / Ψύκτης","30RB / 30RQ Pro-Dialog+","Carrier Pro-Dialog+ Control Manual"),
        Fault("Carrier","th-02","Βλάβη αισθητήρα εξόδου νερού εναλλάκτη","Leaving water heat exchanger sensor fault","Ελαττωματικό thermistor","Έλεγξε thermistor εξόδου, φίσα και καλωδίωση","Αντικατάσταση αισθητήρα/αποκατάσταση σύνδεσης","Chiller / Ψύκτης","30RB / 30RQ Pro-Dialog+","Carrier Pro-Dialog+ Control Manual"),
        Fault("Carrier","th-03","Βλάβη απόψυξης κυκλώματος A","Defrost sensor/fault circuit A","Αισθητήρας απόψυξης","Έλεγξε αισθητήρα και καλωδίωση κυκλώματος A","Αποκατάσταση αισθητήρα/σύνδεσης","Αντλία θερμότητας","30RQ Pro-Dialog+","Carrier Pro-Dialog+ Control Manual"),
        Fault("Carrier","th-04","Βλάβη απόψυξης κυκλώματος B","Defrost sensor/fault circuit B","Αισθητήρας απόψυξης","Έλεγξε αισθητήρα και καλωδίωση κυκλώματος B","Αποκατάσταση αισθητήρα/σύνδεσης","Αντλία θερμότητας","30RQ Pro-Dialog+","Carrier Pro-Dialog+ Control Manual"),
        Fault("Carrier","th-10","Βλάβη αισθητήρα εξωτερικής θερμοκρασίας","Outside temperature sensor fault","Ελαττωματικό thermistor","Έλεγξε αισθητήρα εξωτερικού αέρα και καλωδίωση","Αντικατάσταση αισθητήρα","Chiller / Ψύκτης","30RB / 30RQ Pro-Dialog+","Carrier Pro-Dialog+ Control Manual"),
        Fault("Carrier","th-12","Βλάβη αισθητήρα αναρρόφησης κυκλώματος A","Suction sensor fault circuit A","Ελαττωματικό thermistor","Έλεγξε αισθητήρα αναρρόφησης A","Αντικατάσταση αισθητήρα/σύνδεσης","Chiller / Ψύκτης","30RB / 30RQ Pro-Dialog+","Carrier Pro-Dialog+ Control Manual"),
        Fault("Carrier","th-13","Βλάβη αισθητήρα αναρρόφησης κυκλώματος B","Suction sensor fault circuit B","Ελαττωματικό thermistor","Έλεγξε αισθητήρα αναρρόφησης B","Αντικατάσταση αισθητήρα/σύνδεσης","Chiller / Ψύκτης","30RB / 30RQ Pro-Dialog+","Carrier Pro-Dialog+ Control Manual"),
        Fault("Carrier","Pr-01","Βλάβη transducer κατάθλιψης A","Discharge pressure transducer fault circuit A","Transducer ή εγκατάσταση αισθητήρα","Έλεγξε τροφοδοσία/σήμα transducer, φίσα και πραγματική πίεση","Αποκατάσταση εγκατάστασης ή αντικατάσταση transducer","Chiller / Ψύκτης","30RB / 30RQ Pro-Dialog+","Carrier Pro-Dialog+ Control Manual"),
        Fault("Carrier","Pr-02","Βλάβη transducer κατάθλιψης B","Discharge pressure transducer fault circuit B","Transducer ή εγκατάσταση αισθητήρα","Έλεγξε σήμα/τροφοδοσία και καλωδίωση","Αντικατάσταση transducer αν επιβεβαιωθεί","Chiller / Ψύκτης","30RB / 30RQ Pro-Dialog+","Carrier Pro-Dialog+ Control Manual"),
        Fault("Carrier","Pr-04","Βλάβη transducer αναρρόφησης A","Suction pressure transducer fault circuit A","Transducer ή εγκατάσταση","Έλεγξε πραγματική πίεση έναντι σήματος αισθητήρα","Αποκατάσταση/αντικατάσταση transducer","Chiller / Ψύκτης","30RB / 30RQ Pro-Dialog+","Carrier Pro-Dialog+ Control Manual"),
        Fault("Carrier","Pr-05","Βλάβη transducer αναρρόφησης B","Suction pressure transducer fault circuit B","Transducer ή εγκατάσταση","Έλεγξε πραγματική πίεση έναντι σήματος αισθητήρα","Αποκατάσταση/αντικατάσταση transducer","Chiller / Ψύκτης","30RB / 30RQ Pro-Dialog+","Carrier Pro-Dialog+ Control Manual"),
        Fault("Carrier","Co-e1","Απώλεια επικοινωνίας πλακέτας EXV","Communication loss with EXV board","Bus/καλωδίωση ή πλακέτα EXV","Έλεγξε bus, τροφοδοσία, φίσες και EXV board","Αποκατάσταση επικοινωνίας ή πλακέτας","Chiller / Ψύκτης","30RB / 30RQ Pro-Dialog+","Carrier Pro-Dialog+ Control Manual"),
        Fault("Carrier","P-01","Αντιπαγωτική προστασία εναλλάκτη νερού","Water heat exchanger frost protection","Χαμηλή παροχή νερού ή ελαττωματικό thermistor","Έλεγξε κυκλοφορητή, φίλτρο, βάνες, εξαέρωση, παροχή και αισθητήρα","Αποκατάσταση ροής/αισθητήρα πριν reset","Chiller / Ψύκτης","30RB / 30RQ Pro-Dialog+","Carrier Pro-Dialog+ Control Manual"),
        Fault("Carrier","P-05","Χαμηλή θερμοκρασία αναρρόφησης A","Low suction temperature circuit A","Pressure sensor, μπλοκαρισμένη EXV ή χαμηλή φόρτιση","Έλεγξε αισθητήρα πίεσης, EXV, διαρροές και φόρτιση","Αποκατάσταση EXV/διαρροής/φόρτισης","Chiller / Ψύκτης","30RB / 30RQ Pro-Dialog+","Carrier Pro-Dialog+ Control Manual"),
        Fault("Carrier","P-06","Χαμηλή θερμοκρασία αναρρόφησης B","Low suction temperature circuit B","Pressure sensor, EXV ή χαμηλή φόρτιση","Έλεγξε αισθητήρα, EXV και ψυκτικό κύκλωμα","Αποκατάσταση πραγματικής αιτίας","Chiller / Ψύκτης","30RB / 30RQ Pro-Dialog+","Carrier Pro-Dialog+ Control Manual"),
        Fault("Carrier","P-08","Υψηλή υπερθέρμανση κυκλώματος A","High superheat circuit A","Πρόβλημα τροφοδοσίας εξατμιστή/EXV ή φόρτισης","Έλεγξε superheat, EXV, αισθητήρες και φόρτιση","Αποκατάσταση τροφοδοσίας ψυκτικού","Chiller / Ψύκτης","30RB / 30RQ Pro-Dialog+","Carrier Pro-Dialog+ Control Manual"),
        Fault("Carrier","P-09","Υψηλή υπερθέρμανση κυκλώματος B","High superheat circuit B","Πρόβλημα EXV/φόρτισης/αισθητήρων","Έλεγξε superheat, EXV και ψυκτικό κύκλωμα","Αποκατάσταση αιτίας","Chiller / Ψύκτης","30RB / 30RQ Pro-Dialog+","Carrier Pro-Dialog+ Control Manual"),
        Fault("Carrier","P-11","Χαμηλή υπερθέρμανση κυκλώματος A","Low superheat circuit A","Υπερτροφοδότηση εξατμιστή/EXV ή αισθητήρας","Έλεγξε superheat, EXV και αισθητήρες","Αποκατάσταση ελέγχου EXV/αισθητήρα","Chiller / Ψύκτης","30RB / 30RQ Pro-Dialog+","Carrier Pro-Dialog+ Control Manual"),
        Fault("Carrier","P-12","Χαμηλή υπερθέρμανση κυκλώματος B","Low superheat circuit B","Υπερτροφοδότηση εξατμιστή/EXV ή αισθητήρας","Έλεγξε superheat, EXV και αισθητήρες","Αποκατάσταση ελέγχου EXV/αισθητήρα","Chiller / Ψύκτης","30RB / 30RQ Pro-Dialog+","Carrier Pro-Dialog+ Control Manual"),
        Fault("Carrier","P-14","Σφάλμα ελέγχου ροής νερού / interlock","Water flow control and customer interlock fault","Βλάβη αντλίας εναλλάκτη ή flow switch","Έλεγξε κυκλοφορητή, flow switch, βάνες, φίλτρο και interlock","Αποκατάσταση ροής ή flow switch","Chiller / Ψύκτης","30RB / 30RQ Pro-Dialog+","Carrier Pro-Dialog+ Control Manual"),
        Fault("Carrier","P-16","Ο συμπιεστής A1 δεν ξεκίνησε / χωρίς αύξηση πίεσης","Compressor A1 not started or no pressure increase","Πρόβλημα σύνδεσης/εκκίνησης συμπιεστή","Έλεγξε contactor/drive, τροφοδοσία, καλωδίωση και μεταβολή πιέσεων","Αποκατάσταση ηλεκτρικού/συμπιεστή","Chiller / Ψύκτης","30RB / 30RQ Pro-Dialog+","Carrier Pro-Dialog+ Control Manual"),

        // Cooper&Hunter CHV6 wired controller debugging table
        Fault("Cooper&Hunter","U2","Λάθος capacity code / jumper εξωτερικής","Outdoor unit capacity code or jumper setting error","Λανθασμένη ρύθμιση jumper/capacity","Έλεγξε DIP/jumper και αντιστοίχιση capacity σύμφωνα με engineering manual","Διόρθωσε ρύθμιση","VRF / VRV","CHV6","CHV6 XK62/XK79 Manual"),
        Fault("Cooper&Hunter","U3","Προστασία ακολουθίας φάσεων","Power supply phase sequence protection","Λάθος σειρά φάσεων","Έλεγξε L1/L2/L3, τάσεις και phase sequence","Διόρθωσε σειρά φάσεων αφού απομονωθεί η τροφοδοσία","VRF / VRV","CHV6","CHV6 XK62/XK79 Manual"),
        Fault("Cooper&Hunter","U4","Προστασία έλλειψης ψυκτικού","Lack of refrigerant protection","Χαμηλή φόρτιση/διαρροή","Έλεγξε διαρροές, πιέσεις και θερμοκρασίες","Επισκευή διαρροής, κενό και σωστή φόρτιση","VRF / VRV","CHV6","CHV6 XK62/XK79 Manual"),
        Fault("Cooper&Hunter","U5","Λάθος διεύθυνση compressor drive board","Wrong compressor drive board address","Λανθασμένη addressing","Έλεγξε addressing/DIP drive board","Διόρθωσε διεύθυνση σύμφωνα με manual","VRF / VRV","CHV6","CHV6 XK62/XK79 Manual"),
        Fault("Cooper&Hunter","U6","Ανωμαλία βαλβίδας","Valve abnormal alarm","Βαλβίδα/actuator/έλεγχος","Έλεγξε βαλβίδες, πηνία/actuators και καλωδίωση","Αποκατάσταση ελαττωματικής βαλβίδας/ελέγχου","VRF / VRV","CHV6","CHV6 XK62/XK79 Manual"),
        Fault("Cooper&Hunter","U8","Βλάβη σωλήνωσης εσωτερικής","Indoor unit tube malfunction","Αισθητήρας/σωλήνωση εσωτερικής","Έλεγξε αισθητήρες σωλήνα και ψυκτικό κύκλωμα εσωτερικής","Αποκατάσταση αισθητήρα/κυκλώματος","VRF / VRV","CHV6","CHV6 XK62/XK79 Manual"),
        Fault("Cooper&Hunter","U9","Βλάβη σωλήνωσης εξωτερικής","Outdoor unit tube malfunction","Αισθητήρας/σωλήνωση εξωτερικής","Έλεγξε αισθητήρες σωλήνα και κύκλωμα εξωτερικής","Αποκατάσταση αισθητήρα/κυκλώματος","VRF / VRV","CHV6","CHV6 XK62/XK79 Manual"),
        Fault("Cooper&Hunter","UE","Ανεπιτυχής φόρτιση ψυκτικού","Refrigerant charging ineffective","Λανθασμένη/ανεπαρκής φόρτιση","Επιβεβαίωσε διαδικασία φόρτισης, ποσότητα και βαλβίδες","Διόρθωσε φόρτιση σύμφωνα με προδιαγραφή","VRF / VRV","CHV6","CHV6 XK62/XK79 Manual"),
        Fault("Cooper&Hunter","C0","Σφάλμα επικοινωνίας εσωτερικής-εξωτερικής / χειριστηρίου","Indoor/outdoor and wired-controller communication malfunction","Bus, addressing, καλωδίωση ή πλακέτα","Έλεγξε bus, πολικότητα, addressing και τροφοδοσίες","Αποκατάσταση επικοινωνίας","VRF / VRV","CHV6","CHV6 XK62/XK79 Manual"),
        Fault("Cooper&Hunter","C2","Σφάλμα επικοινωνίας master control - compressor drive","Master control to inverter compressor drive communication error","Bus/drive board","Έλεγξε καλωδίωση, τροφοδοσία και drive board","Αποκατάσταση bus ή drive board","VRF / VRV","CHV6","CHV6 XK62/XK79 Manual"),
        Fault("Cooper&Hunter","C3","Σφάλμα επικοινωνίας master - fan drive","Master control to inverter fan motor drive communication error","Bus/fan drive","Έλεγξε fan drive, bus και τροφοδοσία","Αποκατάσταση επικοινωνίας/drive","VRF / VRV","CHV6","CHV6 XK62/XK79 Manual"),
        Fault("Cooper&Hunter","C4","Λείπει εσωτερική μονάδα","Lack of indoor unit error","Addressing/επικοινωνία ή μονάδα χωρίς τροφοδοσία","Έλεγξε αριθμό IDU, addressing, bus και τροφοδοσίες","Αποκατάσταση IDU/network","VRF / VRV","CHV6","CHV6 XK62/XK79 Manual"),
        Fault("Cooper&Hunter","C5","Σύγκρουση project number εσωτερικής","Indoor unit project number collision","Διπλό/λανθασμένο project number","Έλεγξε και διόρθωσε addressing/project numbers","Επαναρύθμιση μοναδικών διευθύνσεων","VRF / VRV","CHV6","CHV6 XK62/XK79 Manual"),
        Fault("Cooper&Hunter","C6","Λάθος αριθμός εξωτερικών μονάδων","Wrong number of outdoor units","Addressing/network configuration","Έλεγξε ODU quantity και addressing","Διόρθωσε configuration","VRF / VRV","CHV6","CHV6 XK62/XK79 Manual"),
        Fault("Cooper&Hunter","C7","Σφάλμα επικοινωνίας mode exchanger","Mode exchanger communication error","Bus/τροφοδοσία mode exchanger","Έλεγξε καλωδίωση και τροφοδοσία exchanger","Αποκατάσταση επικοινωνίας","VRF / VRV","CHV6","CHV6 XK62/XK79 Manual"),
        Fault("Cooper&Hunter","L1","Προστασία εσωτερικού ανεμιστήρα","Indoor fan protection","Μοτέρ/feedback/PCB","Έλεγξε μοτέρ, ελεύθερη περιστροφή, feedback και PCB","Αποκατάσταση μοτέρ/PCB","VRF / VRV","CHV6","CHV6 Slim Manual"),
        Fault("Cooper&Hunter","L3","Προστασία γεμάτου δοχείου νερού","Water-full protection","Αποχέτευση, αντλία συμπυκνωμάτων ή float","Έλεγξε drain, αντλία και float switch","Καθαρισμός/επισκευή αποχέτευσης ή αντλίας","VRF / VRV","CHV6","CHV6 Slim Manual"),
        Fault("Cooper&Hunter","L5","Αντιπαγωτική προστασία","Freeze prevention protection","Χαμηλή θερμοκρασία στοιχείου/ροή αέρα","Έλεγξε φίλτρα, ανεμιστήρα, στοιχείο και αισθητήρες","Αποκατάσταση αιτίας παγώματος","VRF / VRV","CHV6","CHV6 Slim Manual"),
        Fault("Cooper&Hunter","L6","Σύγκρουση λειτουργίας","Mode conflict","Ασυμβίβαστη επιλογή mode στο σύστημα","Έλεγξε mode των IDU και master configuration","Διόρθωσε mode/configuration","VRF / VRV","CHV6","CHV6 Slim Manual"),
        Fault("Cooper&Hunter","L7","Δεν υπάρχει main IDU","No main indoor unit","Δεν έχει οριστεί master indoor","Έλεγξε addressing/master setting","Όρισε σωστά main IDU","VRF / VRV","CHV6","CHV6 Slim Manual"),
        // ===== VERIFIED FAULTS BATCH 1B: AERMEC / ARISTON / BOSCH =====
        Fault("Aermec","H1","Υψηλή πίεση","High pressure alarm","Υψηλή πίεση συμπύκνωσης ή θερμική προστασία συμπιεστή σε έκδοση heat pump","Έλεγξε πιέσεις, ροή αέρα/νερού, εναλλάκτη, ανεμιστήρες και θερμική προστασία συμπιεστή","Αποκατάσταση αιτίας υψηλής πίεσης και manual reset σύμφωνα με manual","Chiller / Ψύκτης","Aermec chiller/heat-pump controller","Aermec operating manual"),
        Fault("Aermec","L1","Χαμηλή πίεση","Low pressure alarm","Έλλειψη ψυκτικού, περιορισμός ή ανεπαρκής θερμική φόρτιση/ροή","Έλεγξε πιέσεις, διαρροές, φίλτρο/εκτονωτικό και ροή στον εξατμιστή","Επισκευή διαρροής/περιορισμού και σωστή φόρτιση","Chiller / Ψύκτης","Aermec chiller/heat-pump controller","Aermec operating manual"),
        Fault("Aermec","FL","Σφάλμα flow switch","Flow switch alarm","Ανεπαρκής ή μηδενική ροή νερού / flow switch","Έλεγξε κυκλοφορητή, βάνες, φίλτρο νερού, εξαέρωση και επαφή flow switch","Αποκατάσταση ροής και manual reset","Chiller / Ψύκτης","Aermec chiller/heat-pump controller","Aermec operating manual"),
        Fault("Aermec","A1","Αντιπαγωτική προστασία","Antifrost alarm from evaporator outlet water sensor","Πολύ χαμηλή θερμοκρασία νερού εξόδου ή ανεπαρκής ροή","Έλεγξε θερμοκρασίες νερού, αισθητήρα SUW, παροχή και αντιψυκτικό όπου προβλέπεται","Αποκατάσταση αιτίας παγώματος πριν την επανεκκίνηση","Chiller / Ψύκτης","Aermec chiller/heat-pump controller","Aermec operating manual"),
        Fault("Aermec","Cn","Σφάλμα επικοινωνίας χειριστηρίου","Communication error with remote terminal","Καλώδιο/σύνδεση μεταξύ πίνακα μονάδας και remote terminal","Έλεγξε καλώδιο, φίσες και συνέχεια σύνδεσης","Αποκατάσταση επικοινωνίας","Chiller / Ψύκτης","Aermec controller","Aermec operating manual"),

        Fault("Ariston","114","Δεν υπάρχει εξωτερική θερμοκρασία","Outside temperature not available","Εξωτερικός αισθητήρας ή σύνδεση/επικοινωνία","Έλεγξε αισθητήρα εξωτερικής θερμοκρασίας, καλωδίωση και παραμέτρους","Αποκατάσταση αισθητήρα/σύνδεσης","Αντλία θερμότητας αέρα-νερού","Nimbus M NET R32","Ariston Nimbus R32 installation manual"),
        Fault("Ariston","902","Βλάβη αισθητήρα προσαγωγής συστήματος","System flow sensor damaged","Αισθητήρας προσαγωγής ή καλωδίωση","Έλεγξε αισθητήρα, αντίσταση, φίσα και καλωδίωση","Αντικατάσταση αισθητήρα ή αποκατάσταση σύνδεσης","Αντλία θερμότητας αέρα-νερού","Nimbus M NET R32","Ariston Nimbus R32 installation manual"),
        Fault("Ariston","923","Σφάλμα πίεσης κυκλώματος θέρμανσης","Heating circuit pressure error","Χαμηλή/λανθασμένη πίεση ή αισθητήρας πίεσης","Έλεγξε μανόμετρο, πλήρωση, διαρροές και αισθητήρα πίεσης","Αποκατάσταση πίεσης/διαρροής ή αισθητήρα","Αντλία θερμότητας αέρα-νερού","Nimbus M NET R32","Ariston Nimbus R32 installation manual"),
        Fault("Ariston","924","Σφάλμα επικοινωνίας","Communication error","e-BUS/επικοινωνία μονάδων ή καλωδίωση","Έλεγξε bus, πολικότητα, φίσες, τροφοδοσίες και πλακέτες","Αποκατάσταση bus/καλωδίωσης ή πλακέτας","Αντλία θερμότητας αέρα-νερού","Nimbus M NET R32","Ariston Nimbus R32 installation manual"),
        Fault("Ariston","933","Υπερθέρμανση αισθητήρα προσαγωγής","Flow sensor overtemperature","Υψηλή θερμοκρασία νερού/ανεπαρκής κυκλοφορία","Έλεγξε παροχή νερού, κυκλοφορητή, βάνες, φίλτρο και αισθητήρα","Αποκατάσταση κυκλοφορίας/ελέγχου θερμοκρασίας","Αντλία θερμότητας αέρα-νερού","Nimbus M NET R32","Ariston Nimbus R32 installation manual"),
        Fault("Ariston","934","Βλάβη αισθητήρα δοχείου ΖΝΧ","DHW tank sensor damaged","Αισθητήρας boiler ή καλωδίωση","Έλεγξε αισθητήρα δοχείου, φίσα και αντίσταση","Αντικατάσταση αισθητήρα/αποκατάσταση σύνδεσης","Αντλία θερμότητας αέρα-νερού","Nimbus Flex M NET R32","Ariston Nimbus R32 installation manual"),
        Fault("Ariston","935","Υπερθέρμανση δοχείου ΖΝΧ","Tank overtemperature","Θερμοκρασία δοχείου πάνω από επιτρεπτό όριο ή αισθητήρας","Επιβεβαίωσε πραγματική θερμοκρασία και αισθητήρα δοχείου","Διόρθωσε έλεγχο/αισθητήρα και αιτία υπερθέρμανσης","Αντλία θερμότητας αέρα-νερού","Nimbus Flex M NET R32","Ariston Nimbus R32 installation manual"),
        Fault("Ariston","937","Σφάλμα κυκλοφορίας νερού","Water circulation error","Ανεπαρκής ροή, κυκλοφορητής, αέρας, κλειστές βάνες ή βουλωμένο φίλτρο","Έλεγξε κυκλοφορητή, εξαέρωση, βάνες, φίλτρο και παροχή","Αποκατάσταση σωστής κυκλοφορίας νερού","Αντλία θερμότητας αέρα-νερού","Nimbus","Ariston Nimbus technical instructions"),

        Fault("Bosch","EH 00 / EH 0A","Σφάλμα EEPROM εσωτερικής μονάδας","Indoor unit EEPROM parameter error","EEPROM/main PCB εσωτερικής","Έλεγξε τροφοδοσία και main PCB","Επισκευή ή αντικατάσταση PCB σύμφωνα με service manual","Split / Inverter","Climate 5000 Gen 3","Bosch Climate 5000 G3 Service Manual"),
        Fault("Bosch","EL 01","Σφάλμα επικοινωνίας εσωτερικής-εξωτερικής","Indoor/outdoor communication error","Καλωδίωση επικοινωνίας, τροφοδοσία ή PCB","Έλεγξε καλωδίωση, πολικότητα, τάσεις και πλακέτες","Αποκατάσταση επικοινωνίας/PCB","Split / Inverter","Climate 5000 Gen 3","Bosch Climate 5000 G3 Service Manual"),
        Fault("Bosch","EH 03","Ταχύτητα ανεμιστήρα εσωτερικής εκτός ορίων","Indoor fan speed outside normal range","Μοτέρ ανεμιστήρα, feedback, καλωδίωση ή PCB","Έλεγξε ελεύθερη περιστροφή, φίσα, τροφοδοσία και feedback μοτέρ","Αποκατάσταση/αντικατάσταση μοτέρ ή PCB","Split / Inverter","Climate 5000 Gen 3","Bosch Climate 5000 G3 Service Manual"),
        Fault("Bosch","EC 52","Σφάλμα αισθητήρα T3 συμπυκνωτή","Condenser coil sensor T3 open/short circuit","Αισθητήρας T3 ή καλωδίωση","Έλεγξε αντίσταση T3, φίσα και καλώδιο","Αντικατάσταση αισθητήρα/αποκατάσταση σύνδεσης","Split / Inverter","Climate 5000 Gen 3","Bosch Climate 5000 G3 Service Manual"),
        Fault("Bosch","EC 53","Σφάλμα αισθητήρα εξωτερικού αέρα T4","Outdoor ambient sensor T4 open/short circuit","Αισθητήρας T4 ή καλωδίωση","Έλεγξε T4, φίσα και καλωδίωση","Αντικατάσταση αισθητήρα/αποκατάσταση σύνδεσης","Split / Inverter","Climate 5000 Gen 3","Bosch Climate 5000 G3 Service Manual"),
        Fault("Bosch","EC 54","Σφάλμα αισθητήρα κατάθλιψης TP","Compressor discharge sensor TP open/short circuit","Αισθητήρας TP ή καλωδίωση","Έλεγξε TP, φίσα και αντίσταση αισθητήρα","Αντικατάσταση αισθητήρα/αποκατάσταση σύνδεσης","Split / Inverter","Climate 5000 Gen 3","Bosch Climate 5000 G3 Service Manual"),
        Fault("Bosch","EH 60","Σφάλμα αισθητήρα χώρου T1","Indoor room sensor T1 open/short circuit","Αισθητήρας T1 ή καλωδίωση","Έλεγξε T1 και σύνδεση στην PCB","Αντικατάσταση αισθητήρα/αποκατάσταση σύνδεσης","Split / Inverter","Climate 5000 Gen 3","Bosch Climate 5000 G3 Service Manual"),
        Fault("Bosch","EH 61","Σφάλμα αισθητήρα στοιχείου T2","Evaporator coil sensor T2 open/short circuit","Αισθητήρας T2 ή καλωδίωση","Έλεγξε T2, φίσα και αντίσταση","Αντικατάσταση αισθητήρα/αποκατάσταση σύνδεσης","Split / Inverter","Climate 5000 Gen 3","Bosch Climate 5000 G3 Service Manual"),
        Fault("Bosch","EL 0C","Ανίχνευση διαρροής ψυκτικού","Refrigerant leak detected","Πιθανή απώλεια ψυκτικού ή σχετική συνθήκη ανίχνευσης","Έλεγξε διαρροές, πιέσεις/θερμοκρασίες και φόρτιση σύμφωνα με manual","Επισκευή διαρροής, κενό και σωστή φόρτιση","Split / Inverter","Climate 5000 Gen 3","Bosch Climate 5000 G3 Service Manual"),
        Fault("Bosch","PC 00","Προστασία IPM / υπερένταση IGBT","IPM malfunction or IGBT over-strong current protection","Inverter module, συμπιεστής, τροφοδοσία","Έλεγξε τάση DC bus, module, καλωδίωση και συμπιεστή","Επισκευή/αντικατάσταση επιβεβαιωμένα ελαττωματικού μέρους","Split / Inverter","Climate 5000 Gen 3","Bosch Climate 5000 G3 Service Manual"),
        Fault("Bosch","PC 02","Υψηλή θερμοκρασία κεφαλής συμπιεστή","Compressor top high-temperature protection","Υπερθέρμανση συμπιεστή / ψυκτικό κύκλωμα","Έλεγξε φόρτιση, πιέσεις, ροή αέρα, βαλβίδες και θερμική προστασία","Αποκατάσταση αιτίας υπερθέρμανσης","Split / Inverter","Climate 5000 Gen 3","Bosch Climate 5000 G3 Service Manual"),
        Fault("Bosch","PC 03","Προστασία πίεσης","Pressure protection","Υψηλή/χαμηλή πίεση ή κύκλωμα προστασίας","Μέτρησε πιέσεις και έλεγξε εναλλάκτες, ροές, φόρτιση και pressostat/sensor","Αποκατάσταση πραγματικής αιτίας πίεσης","Split / Inverter","Climate 5000 Gen 3","Bosch Climate 5000 G3 Service Manual"),
        Fault("Bosch","PC 42","Σφάλμα εκκίνησης συμπιεστή","Compressor start error","Συμπιεστής, inverter drive ή τροφοδοσία","Έλεγξε τυλίγματα/μόνωση, inverter module και τάσεις","Επισκευή drive ή συμπιεστή μετά από επιβεβαίωση","Split / Inverter","Climate 5000 Gen 3","Bosch Climate 5000 G3 Service Manual"),
        Fault("Bosch","PC 49","Υπερένταση συμπιεστή","Compressor over-current protection","Υψηλό φορτίο, ηλεκτρικό πρόβλημα ή συμπιεστής","Μέτρησε ρεύμα, τάση, πιέσεις και έλεγξε συμπιεστή/inverter","Αποκατάσταση αιτίας υπερέντασης","Split / Inverter","Climate 5000 Gen 3","Bosch Climate 5000 G3 Service Manual"),
        // ===== VERIFIED FAULTS BATCH 1: AIRWELL + AUX =====
        // Airwell HDLE R32 service manual: error-code table.
        Fault("Airwell","E1","Προστασία υψηλής πίεσης","High pressure protection","Υπερβολική ποσότητα ψυκτικού, κακή εναλλαγή θερμότητας/βρώμικος εναλλάκτης, υψηλή θερμοκρασία περιβάλλοντος","Έλεγξε πιέσεις, καθαριότητα εναλλάκτη, ροή αέρα και ποσότητα ψυκτικού σύμφωνα με το service manual","Αποκατάσταση ροής/εναλλάκτη και σωστής φόρτισης· έλεγχος κυκλώματος υψηλής","Hi-Wall / Split","HDLE R32","Airwell Service Manual 23.AW.HDLE.22-70.R32.SM.02.23"),
        Fault("Airwell","E2","Αντιπαγωτική προστασία εξατμιστή","Κατάσταση προστασίας λειτουργίας, όχι κατ’ ανάγκη μόνιμη βλάβη","Χαμηλή θερμοκρασία στοιχείου / συνθήκες που ενεργοποιούν antifreeze","Έλεγξε θερμοκρασία στοιχείου, ροή αέρα, φίλτρα και αισθητήρα εξατμιστή","Διόρθωσε αιτία παγώματος και επανέλεγξε λειτουργία","Hi-Wall / Split","HDLE R32","Airwell Service Manual 23.AW.HDLE.22-70.R32.SM.02.23"),
        Fault("Airwell","E3","Μπλοκάρισμα συστήματος ή διαρροή ψυκτικού","Προστασία χαμηλής πίεσης","Έλλειψη ψυκτικού, διαρροή ή περιορισμός κυκλώματος","Μέτρησε πιέσεις, έλεγξε διαρροές και περιορισμούς στο ψυκτικό κύκλωμα","Επισκεύασε διαρροή/περιορισμό, κενό και σωστή φόρτιση","Hi-Wall / Split","HDLE R32","Airwell Service Manual 23.AW.HDLE.22-70.R32.SM.02.23"),
        Fault("Airwell","E4","Υψηλή θερμοκρασία κατάθλιψης συμπιεστή","High discharge temperature protection","Υπερθέρμανση κατάθλιψης / πρόβλημα ψυκτικού κυκλώματος ή φόρτισης","Έλεγξε θερμοκρασία κατάθλιψης, πιέσεις, αισθητήρα και ψυκτικό κύκλωμα","Αποκατάσταση αιτίας υπερθέρμανσης σύμφωνα με troubleshooting manual","Hi-Wall / Split","HDLE R32","Airwell Service Manual 23.AW.HDLE.22-70.R32.SM.02.23"),
        Fault("Airwell","E5","Προστασία υπερέντασης","Overcurrent protection","Ασταθής τροφοδοσία ή ηλεκτρικό/φορτίο συμπιεστή","Έλεγξε τάση τροφοδοσίας, ρεύμα λειτουργίας, καλωδίωση και φορτίο συμπιεστή","Διόρθωσε τροφοδοσία/ηλεκτρικό αίτιο και επανέλεγξε","Hi-Wall / Split","HDLE R32","Airwell Service Manual 23.AW.HDLE.22-70.R32.SM.02.23"),

        // AUX Global official Error Codes tool.
        Fault("AUX","E0","Υπερένταση εσωτερικής μονάδας","IDU overcurrent protection","Μοτέρ εσωτερικής ή controller","Έλεγξε μοτέρ εσωτερικής, πλακέτα/controller, καλωδίωση και ρεύμα","Επισκευή/αντικατάσταση ελαττωματικού μοτέρ ή controller","Split / Inverter","Γενικοί AUX","AUX Global Error Codes"),
        Fault("AUX","E1","Σφάλμα αισθητήρα χώρου εσωτερικής","IDU room sensor error","Αισθητήρας/εσωτερική display board ή main board","Έλεγξε αισθητήρα χώρου, φίσα, καλωδίωση και πλακέτα","Αποκατάσταση σύνδεσης ή αντικατάσταση αισθητήρα/πλακέτας","Split / Inverter","Γενικοί AUX","AUX Global Error Codes"),
        Fault("AUX","E2","Σφάλμα αισθητήρα συμπυκνωτή εξωτερικής","ODU condenser sensor error","Αισθητήρας ή σχετικό κύκλωμα πλακέτας","Έλεγξε αισθητήρα συμπυκνωτή, αντίσταση/καλωδίωση και PCB","Αποκατάσταση σύνδεσης ή αντικατάσταση αισθητήρα/PCB","Split / Inverter","Γενικοί AUX","AUX Global Error Codes"),
        Fault("AUX","E3","Σφάλμα αισθητήρα στοιχείου εσωτερικής","IDU evaporator coil sensor error","Αισθητήρας στοιχείου / κύκλωμα ελέγχου","Έλεγξε αισθητήρα εξατμιστή, φίσα και καλωδίωση","Αποκατάσταση σύνδεσης ή αντικατάσταση αισθητήρα","Split / Inverter","Γενικοί AUX","AUX Global Error Codes"),
        Fault("AUX","E4","Σφάλμα AC/DC μοτέρ","AC or DC motor error","Μοτέρ, module ή τροφοδοσία","Έλεγξε μοτέρ, module, τάσεις και καλωδίωση","Επισκευή τροφοδοσίας ή αντικατάσταση ελαττωματικού μέρους","Split / Inverter","Γενικοί AUX","AUX Global Error Codes"),
        Fault("AUX","E5","Σφάλμα επικοινωνίας εσωτερικής-εξωτερικής","ODU and IDU communication error","Καλώδιο τροφοδοσίας/επικοινωνίας ή controllers","Έλεγξε πολικότητα, συνέχεια καλωδίων, τάσεις και πλακέτες","Αποκατάσταση καλωδίωσης ή controller","Split / Inverter","Γενικοί AUX","AUX Global Error Codes"),
        Fault("AUX","E8","Σφάλμα επικοινωνίας display board-PCB","Display board and PCB communication fault","Display board, main board ή σύνδεση","Έλεγξε φίσα/καλώδιο μεταξύ display και PCB","Αποκατάσταση σύνδεσης ή αντικατάσταση πλακέτας","Split / Inverter","Γενικοί AUX","AUX Global Error Codes"),
        Fault("AUX","Eb","Σφάλμα EEPROM/PCB εσωτερικής","IDU PCB EE error","Εσωτερική main board","Έλεγξε τροφοδοσία και main PCB","Αντικατάσταση/επισκευή main PCB σύμφωνα με manual","Split / Inverter","Γενικοί AUX","AUX Global Error Codes"),
        Fault("AUX","F0","Σφάλμα μοτέρ ανεμιστήρα εξωτερικής","ODU fan motor error","Outdoor motor ή PCB","Έλεγξε μοτέρ, τροφοδοσία, φίσα και PCB","Επισκευή/αντικατάσταση μοτέρ ή PCB","Split / Inverter","Γενικοί AUX","AUX Global Error Codes"),
        Fault("AUX","F1","Προστασία module εξωτερικής","ODU module protection","Inverter module / τροφοδοσία","Έλεγξε module, τάση τροφοδοσίας και συνδέσεις","Αποκατάσταση τροφοδοσίας ή module","Split / Inverter","Γενικοί AUX","AUX Global Error Codes"),
        Fault("AUX","F2","Προστασία PFC εξωτερικής","ODU PFC protection","Controller, compressor ή discharge sensor","Έλεγξε PFC/controller, συμπιεστή και αισθητήρα κατάθλιψης","Επισκευή του επιβεβαιωμένα ελαττωματικού μέρους","Split / Inverter","Γενικοί AUX","AUX Global Error Codes"),
        Fault("AUX","F3","Αποτυχία εκκίνησης/αποσυγχρονισμός συμπιεστή","Compressor start failure or out-of-step","Συμπιεστής ή drive","Έλεγξε τυλίγματα/μόνωση συμπιεστή, module και τροφοδοσία","Επισκευή drive ή αντικατάσταση συμπιεστή αν επιβεβαιωθεί","Split / Inverter","Γενικοί AUX","AUX Global Error Codes"),
        Fault("AUX","F4","Σφάλμα αισθητήρα κατάθλιψης","ODU discharge sensor error","Αισθητήρας κατάθλιψης","Έλεγξε αντίσταση αισθητήρα, φίσα και καλωδίωση","Αντικατάσταση αισθητήρα αν είναι εκτός προδιαγραφών","Split / Inverter","Γενικοί AUX","AUX Global Error Codes"),
        Fault("AUX","F6","Σφάλμα αισθητήρα περιβάλλοντος εξωτερικής","ODU room/ambient sensor error","Outdoor ambient sensor","Έλεγξε αισθητήρα περιβάλλοντος, φίσα και καλωδίωση","Αποκατάσταση σύνδεσης ή αντικατάσταση αισθητήρα","Split / Inverter","Γενικοί AUX","AUX Global Error Codes"),
        Fault("AUX","F8","Σφάλμα επικοινωνίας main PCB-module εξωτερικής","ODU main PCB to module communication error","Καλωδίωση ή outdoor module communication","Έλεγξε καλώδια/φίσες και τροφοδοσίες μεταξύ PCB και module","Αποκατάσταση επικοινωνίας ή αντικατάσταση ελαττωματικής πλακέτας","Split / Inverter","Γενικοί AUX","AUX Global Error Codes"),
        Fault("AUX","F9","Σφάλμα EEPROM/PCB εξωτερικής","ODU PCB EE error","Outdoor controller","Έλεγξε outdoor controller και τροφοδοσία","Επισκευή/αντικατάσταση outdoor controller","Split / Inverter","Γενικοί AUX","AUX Global Error Codes"),
        Fault("AUX","FA","Σφάλμα αισθητήρα αναρρόφησης","Suction sensor error","Return/suction sensor","Έλεγξε αισθητήρα, φίσα και καλωδίωση","Αντικατάσταση αισθητήρα αν επιβεβαιωθεί","Split / Inverter","Γενικοί AUX","AUX Global Error Codes"),
        Fault("AUX","P2","Προστασία διακόπτη υψηλής πίεσης","High-pressure switch protection","Pressure switch ή outdoor controller / υψηλή πίεση","Έλεγξε πραγματική πίεση, ροή αέρα/εναλλάκτη, pressostat και controller","Αποκατάσταση αιτίας υψηλής πίεσης ή ελαττωματικού pressostat/controller","Split / Inverter","Γενικοί AUX","AUX Global Error Codes"),
        Fault("AUX","P3","Προστασία έλλειψης ψυκτικού","Lack of refrigerant protection","Έλλειψη ψυκτικού / πιθανή διαρροή","Έλεγχος διαρροής και μετρήσεις ψυκτικού κυκλώματος","Επισκευή διαρροής, κενό και φόρτιση κατά προδιαγραφή","Split / Inverter","Γενικοί AUX","AUX Global Error Codes"),
        Fault("AUX","P4","Υπερφόρτωση συμπυκνωτή στην ψύξη","Condenser overload protection","Συμπυκνωτής ή αισθητήρας θερμοκρασίας","Έλεγξε καθαριότητα/ροή αέρα συμπυκνωτή και αισθητήρα","Καθαρισμός/αποκατάσταση ροής ή αισθητήρα","Split / Inverter","Γενικοί AUX","AUX Global Error Codes"),
        Fault("AUX","P5","Προστασία θερμοκρασίας κατάθλιψης","Discharge temperature protection","Συμπιεστής ή αισθητήρας θερμοκρασίας","Έλεγξε θερμοκρασία κατάθλιψης, αισθητήρα, πιέσεις και φόρτιση","Αποκατάσταση αιτίας υπερθέρμανσης","Split / Inverter","Γενικοί AUX","AUX Global Error Codes"),
        Fault("AUX","P6","Υπερφόρτωση εξατμιστή στη θέρμανση","Evaporator overload protection","Controller ή temperature sensor","Έλεγξε αισθητήρες, εναλλάκτη και λειτουργία ελέγχου","Αποκατάσταση αισθητήρα/controller ή συνθηκών εναλλάκτη","Split / Inverter","Γενικοί AUX","AUX Global Error Codes"),
        Fault("AUX","P7","Αντιπαγωτική προστασία εσωτερικής στην ψύξη","IDU anti-freezing protection","Θερμοκρασία στοιχείου / αισθητήρας","Έλεγξε φίλτρα, ροή αέρα, στοιχείο και αισθητήρα","Διόρθωσε αιτία παγώματος ή αισθητήρα","Split / Inverter","Γενικοί AUX","AUX Global Error Codes"),
        Fault("AUX","P8","Προστασία υπερέντασης εξωτερικής","ODU overcurrent protection","Outdoor controller / ηλεκτρικό φορτίο","Έλεγξε ρεύμα, τάση, συμπιεστή και controller","Αποκατάσταση ηλεκτρικής αιτίας/controller","Split / Inverter","Γενικοί AUX","AUX Global Error Codes"),

        Fault("Daikin", "U0", "Έλλειψη ψυκτικού / ανωμαλία ψυκτικού κυκλώματος", "Έλλειψη ψυκτικού / ανωμαλία ψυκτικού κυκλώματος", "Διαρροή, φόρτιση, περιορισμός, αισθητήρες", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Daikin", "U4", "Σφάλμα επικοινωνίας", "Σφάλμα επικοινωνίας", "Καλωδίωση, τροφοδοσία, ακροδέκτες, πλακέτες", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Daikin", "A1", "Ανωμαλία πλακέτας εσωτερικής", "Ανωμαλία πλακέτας εσωτερικής", "Πλακέτα, τροφοδοσία, καλωδίωση", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Daikin", "A5", "Προστασία κατά της ψύξης/πάγου", "Προστασία κατά της ψύξης/πάγου", "Ροή αέρα, αισθητήρας, ψυκτικό, συνθήκες λειτουργίας", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Daikin", "A6", "Ανωμαλία ανεμιστήρα εσωτερικής", "Ανωμαλία ανεμιστήρα εσωτερικής", "Μοτέρ, φτερωτή, πλακέτα, καλωδίωση", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Daikin", "E7", "Εμφάνιση κωδικού E7", "Κωδικός E7 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Daikin", "F3", "Εμφάνιση κωδικού F3", "Κωδικός F3 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Daikin", "J3", "Εμφάνιση κωδικού J3", "Κωδικός J3 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Daikin", "J6", "Εμφάνιση κωδικού J6", "Κωδικός J6 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Daikin", "L5", "Εμφάνιση κωδικού L5", "Κωδικός L5 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Daikin", "P4", "Εμφάνιση κωδικού P4", "Κωδικός P4 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Daikin", "PJ", "Εμφάνιση κωδικού PJ", "Κωδικός PJ — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Daikin", "H6", "Εμφάνιση κωδικού H6", "Κωδικός H6 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Mitsubishi Electric", "P1", "Ανωμαλία αισθητήρα/θερμοκρασίας", "Ανωμαλία αισθητήρα/θερμοκρασίας", "Αισθητήρας, καλωδίωση, πλακέτα", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Mitsubishi Electric", "P2", "Εμφάνιση κωδικού P2", "Κωδικός P2 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Mitsubishi Electric", "P4", "Εμφάνιση κωδικού P4", "Κωδικός P4 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Mitsubishi Electric", "P5", "Εμφάνιση κωδικού P5", "Κωδικός P5 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Mitsubishi Electric", "P6", "Εμφάνιση κωδικού P6", "Κωδικός P6 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Mitsubishi Electric", "P8", "Ανωμαλία θερμοκρασίας σωλήνα", "Ανωμαλία θερμοκρασίας σωλήνα", "Αισθητήρας, ροή ψυκτικού, εκτονωτικό, συνθήκες", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Mitsubishi Electric", "U1", "Εμφάνιση κωδικού U1", "Κωδικός U1 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Mitsubishi Electric", "U2", "Εμφάνιση κωδικού U2", "Κωδικός U2 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Mitsubishi Electric", "U4", "Σφάλμα επικοινωνίας", "Σφάλμα επικοινωνίας", "Καλωδίωση, τροφοδοσία, ακροδέκτες, πλακέτες", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Mitsubishi Electric", "U5", "Εμφάνιση κωδικού U5", "Κωδικός U5 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Mitsubishi Electric", "U6", "Εμφάνιση κωδικού U6", "Κωδικός U6 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Mitsubishi Electric", "U7", "Εμφάνιση κωδικού U7", "Κωδικός U7 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Mitsubishi Heavy", "E1", "Εμφάνιση κωδικού E1", "Κωδικός E1 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Mitsubishi Heavy", "E2", "Εμφάνιση κωδικού E2", "Κωδικός E2 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Mitsubishi Heavy", "E3", "Εμφάνιση κωδικού E3", "Κωδικός E3 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Mitsubishi Heavy", "E5", "Εμφάνιση κωδικού E5", "Κωδικός E5 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Mitsubishi Heavy", "E6", "Σφάλμα επικοινωνίας ή ελέγχου", "Σφάλμα επικοινωνίας ή ελέγχου", "Καλωδίωση, τροφοδοσία, πλακέτες", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Mitsubishi Heavy", "E7", "Εμφάνιση κωδικού E7", "Κωδικός E7 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Mitsubishi Heavy", "E9", "Εμφάνιση κωδικού E9", "Κωδικός E9 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Mitsubishi Heavy", "E10", "Εμφάνιση κωδικού E10", "Κωδικός E10 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Mitsubishi Heavy", "E16", "Εμφάνιση κωδικού E16", "Κωδικός E16 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Mitsubishi Heavy", "E32", "Εμφάνιση κωδικού E32", "Κωδικός E32 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Mitsubishi Heavy", "E40", "Εμφάνιση κωδικού E40", "Κωδικός E40 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Gree", "E1", "Εμφάνιση κωδικού E1", "Κωδικός E1 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Gree", "E2", "Εμφάνιση κωδικού E2", "Κωδικός E2 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Gree", "E3", "Εμφάνιση κωδικού E3", "Κωδικός E3 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Gree", "E4", "Εμφάνιση κωδικού E4", "Κωδικός E4 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Gree", "E5", "Εμφάνιση κωδικού E5", "Κωδικός E5 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Gree", "E6", "Σφάλμα επικοινωνίας ή ελέγχου", "Σφάλμα επικοινωνίας ή ελέγχου", "Καλωδίωση, τροφοδοσία, πλακέτες", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Gree", "E8", "Εμφάνιση κωδικού E8", "Κωδικός E8 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Gree", "E9", "Εμφάνιση κωδικού E9", "Κωδικός E9 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Gree", "F0", "Εμφάνιση κωδικού F0", "Κωδικός F0 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Gree", "F1", "Εμφάνιση κωδικού F1", "Κωδικός F1 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Gree", "F2", "Εμφάνιση κωδικού F2", "Κωδικός F2 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Gree", "F3", "Εμφάνιση κωδικού F3", "Κωδικός F3 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Gree", "H3", "Εμφάνιση κωδικού H3", "Κωδικός H3 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Gree", "H6", "Εμφάνιση κωδικού H6", "Κωδικός H6 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Midea", "E0", "Εμφάνιση κωδικού E0", "Κωδικός E0 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Midea", "E1", "Εμφάνιση κωδικού E1", "Κωδικός E1 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Midea", "E2", "Εμφάνιση κωδικού E2", "Κωδικός E2 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Midea", "E3", "Εμφάνιση κωδικού E3", "Κωδικός E3 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Midea", "E4", "Εμφάνιση κωδικού E4", "Κωδικός E4 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Midea", "E5", "Εμφάνιση κωδικού E5", "Κωδικός E5 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Midea", "E6", "Σφάλμα επικοινωνίας ή ελέγχου", "Σφάλμα επικοινωνίας ή ελέγχου", "Καλωδίωση, τροφοδοσία, πλακέτες", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Midea", "E7", "Εμφάνιση κωδικού E7", "Κωδικός E7 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Midea", "E8", "Εμφάνιση κωδικού E8", "Κωδικός E8 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Midea", "E9", "Εμφάνιση κωδικού E9", "Κωδικός E9 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Midea", "P0", "Εμφάνιση κωδικού P0", "Κωδικός P0 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Midea", "P1", "Ανωμαλία αισθητήρα/θερμοκρασίας", "Ανωμαλία αισθητήρα/θερμοκρασίας", "Αισθητήρας, καλωδίωση, πλακέτα", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Midea", "P2", "Εμφάνιση κωδικού P2", "Κωδικός P2 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Midea", "P4", "Εμφάνιση κωδικού P4", "Κωδικός P4 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Midea", "P6", "Εμφάνιση κωδικού P6", "Κωδικός P6 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Fujitsu", "A1", "Ανωμαλία πλακέτας εσωτερικής", "Ανωμαλία πλακέτας εσωτερικής", "Πλακέτα, τροφοδοσία, καλωδίωση", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Fujitsu", "A2", "Εμφάνιση κωδικού A2", "Κωδικός A2 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Fujitsu", "A3", "Εμφάνιση κωδικού A3", "Κωδικός A3 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Fujitsu", "A4", "Εμφάνιση κωδικού A4", "Κωδικός A4 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Fujitsu", "A5", "Προστασία κατά της ψύξης/πάγου", "Προστασία κατά της ψύξης/πάγου", "Ροή αέρα, αισθητήρας, ψυκτικό, συνθήκες λειτουργίας", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Fujitsu", "A6", "Ανωμαλία ανεμιστήρα εσωτερικής", "Ανωμαλία ανεμιστήρα εσωτερικής", "Μοτέρ, φτερωτή, πλακέτα, καλωδίωση", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Fujitsu", "A7", "Εμφάνιση κωδικού A7", "Κωδικός A7 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Fujitsu", "A8", "Εμφάνιση κωδικού A8", "Κωδικός A8 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Fujitsu", "A9", "Εμφάνιση κωδικού A9", "Κωδικός A9 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Fujitsu", "J2", "Εμφάνιση κωδικού J2", "Κωδικός J2 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Fujitsu", "J3", "Εμφάνιση κωδικού J3", "Κωδικός J3 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Fujitsu", "J6", "Εμφάνιση κωδικού J6", "Κωδικός J6 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Fujitsu", "E1", "Εμφάνιση κωδικού E1", "Κωδικός E1 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Fujitsu", "E2", "Εμφάνιση κωδικού E2", "Κωδικός E2 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("LG", "CH01", "Εμφάνιση κωδικού CH01", "Κωδικός CH01 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("LG", "CH02", "Εμφάνιση κωδικού CH02", "Κωδικός CH02 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("LG", "CH05", "Ανωμαλία επικοινωνίας μεταξύ μονάδων", "Ανωμαλία επικοινωνίας μεταξύ μονάδων", "Καλωδίωση, τροφοδοσία, πλακέτες", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("LG", "CH07", "Εμφάνιση κωδικού CH07", "Κωδικός CH07 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("LG", "CH10", "Εμφάνιση κωδικού CH10", "Κωδικός CH10 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("LG", "CH21", "Ανωμαλία DC / inverter", "Ανωμαλία DC / inverter", "Τροφοδοσία, inverter, συμπιεστής, πλακέτα", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("LG", "CH22", "Υπερένταση συμπιεστή/inverter", "Υπερένταση συμπιεστή/inverter", "Συμπιεστής, inverter, τάση, ψυκτικό κύκλωμα", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("LG", "CH23", "Εμφάνιση κωδικού CH23", "Κωδικός CH23 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("LG", "CH26", "Εμφάνιση κωδικού CH26", "Κωδικός CH26 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("LG", "CH29", "Εμφάνιση κωδικού CH29", "Κωδικός CH29 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("LG", "CH32", "Εμφάνιση κωδικού CH32", "Κωδικός CH32 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("LG", "CH40", "Εμφάνιση κωδικού CH40", "Κωδικός CH40 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("LG", "CH44", "Εμφάνιση κωδικού CH44", "Κωδικός CH44 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("LG", "CH61", "Εμφάνιση κωδικού CH61", "Κωδικός CH61 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("LG", "CH67", "Εμφάνιση κωδικού CH67", "Κωδικός CH67 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Inventor", "E1", "Εμφάνιση κωδικού E1", "Κωδικός E1 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Inventor", "E2", "Εμφάνιση κωδικού E2", "Κωδικός E2 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Inventor", "E3", "Εμφάνιση κωδικού E3", "Κωδικός E3 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Inventor", "E4", "Εμφάνιση κωδικού E4", "Κωδικός E4 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Inventor", "E5", "Εμφάνιση κωδικού E5", "Κωδικός E5 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Inventor", "E6", "Σφάλμα επικοινωνίας ή ελέγχου", "Σφάλμα επικοινωνίας ή ελέγχου", "Καλωδίωση, τροφοδοσία, πλακέτες", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Inventor", "E7", "Εμφάνιση κωδικού E7", "Κωδικός E7 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Inventor", "E8", "Εμφάνιση κωδικού E8", "Κωδικός E8 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Inventor", "P0", "Εμφάνιση κωδικού P0", "Κωδικός P0 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Inventor", "P1", "Ανωμαλία αισθητήρα/θερμοκρασίας", "Ανωμαλία αισθητήρα/θερμοκρασίας", "Αισθητήρας, καλωδίωση, πλακέτα", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Inventor", "P2", "Εμφάνιση κωδικού P2", "Κωδικός P2 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Inventor", "P4", "Εμφάνιση κωδικού P4", "Κωδικός P4 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Inventor", "P5", "Εμφάνιση κωδικού P5", "Κωδικός P5 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("AUX", "E1", "Εμφάνιση κωδικού E1", "Κωδικός E1 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("AUX", "E2", "Εμφάνιση κωδικού E2", "Κωδικός E2 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("AUX", "E3", "Εμφάνιση κωδικού E3", "Κωδικός E3 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("AUX", "E4", "Εμφάνιση κωδικού E4", "Κωδικός E4 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("AUX", "E5", "Εμφάνιση κωδικού E5", "Κωδικός E5 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("AUX", "E6", "Σφάλμα επικοινωνίας ή ελέγχου", "Σφάλμα επικοινωνίας ή ελέγχου", "Καλωδίωση, τροφοδοσία, πλακέτες", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("AUX", "E7", "Εμφάνιση κωδικού E7", "Κωδικός E7 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("AUX", "E8", "Εμφάνιση κωδικού E8", "Κωδικός E8 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("AUX", "E9", "Εμφάνιση κωδικού E9", "Κωδικός E9 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("AUX", "F1", "Εμφάνιση κωδικού F1", "Κωδικός F1 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("AUX", "F2", "Εμφάνιση κωδικού F2", "Κωδικός F2 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("AUX", "P1", "Ανωμαλία αισθητήρα/θερμοκρασίας", "Ανωμαλία αισθητήρα/θερμοκρασίας", "Αισθητήρας, καλωδίωση, πλακέτα", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("AUX", "P2", "Εμφάνιση κωδικού P2", "Κωδικός P2 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Tesla", "E1", "Εμφάνιση κωδικού E1", "Κωδικός E1 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Tesla", "E2", "Εμφάνιση κωδικού E2", "Κωδικός E2 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Tesla", "E3", "Εμφάνιση κωδικού E3", "Κωδικός E3 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Tesla", "E4", "Εμφάνιση κωδικού E4", "Κωδικός E4 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Tesla", "E5", "Εμφάνιση κωδικού E5", "Κωδικός E5 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Tesla", "E6", "Σφάλμα επικοινωνίας ή ελέγχου", "Σφάλμα επικοινωνίας ή ελέγχου", "Καλωδίωση, τροφοδοσία, πλακέτες", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Tesla", "E7", "Εμφάνιση κωδικού E7", "Κωδικός E7 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Tesla", "E8", "Εμφάνιση κωδικού E8", "Κωδικός E8 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Tesla", "F1", "Εμφάνιση κωδικού F1", "Κωδικός F1 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Tesla", "F2", "Εμφάνιση κωδικού F2", "Κωδικός F2 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Tesla", "P1", "Ανωμαλία αισθητήρα/θερμοκρασίας", "Ανωμαλία αισθητήρα/θερμοκρασίας", "Αισθητήρας, καλωδίωση, πλακέτα", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Tesla", "P2", "Εμφάνιση κωδικού P2", "Κωδικός P2 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Toyotomi", "E1", "Εμφάνιση κωδικού E1", "Κωδικός E1 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Toyotomi", "E2", "Εμφάνιση κωδικού E2", "Κωδικός E2 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Toyotomi", "E3", "Εμφάνιση κωδικού E3", "Κωδικός E3 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Toyotomi", "E4", "Εμφάνιση κωδικού E4", "Κωδικός E4 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Toyotomi", "E5", "Εμφάνιση κωδικού E5", "Κωδικός E5 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Toyotomi", "E6", "Σφάλμα επικοινωνίας ή ελέγχου", "Σφάλμα επικοινωνίας ή ελέγχου", "Καλωδίωση, τροφοδοσία, πλακέτες", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Toyotomi", "E7", "Εμφάνιση κωδικού E7", "Κωδικός E7 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Toyotomi", "E8", "Εμφάνιση κωδικού E8", "Κωδικός E8 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Toyotomi", "P1", "Ανωμαλία αισθητήρα/θερμοκρασίας", "Ανωμαλία αισθητήρα/θερμοκρασίας", "Αισθητήρας, καλωδίωση, πλακέτα", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Toyotomi", "P2", "Εμφάνιση κωδικού P2", "Κωδικός P2 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Haier", "E1", "Εμφάνιση κωδικού E1", "Κωδικός E1 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Haier", "E2", "Εμφάνιση κωδικού E2", "Κωδικός E2 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Haier", "E4", "Εμφάνιση κωδικού E4", "Κωδικός E4 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Haier", "E5", "Εμφάνιση κωδικού E5", "Κωδικός E5 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Haier", "E7", "Εμφάνιση κωδικού E7", "Κωδικός E7 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Haier", "E9", "Εμφάνιση κωδικού E9", "Κωδικός E9 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Haier", "F1", "Εμφάνιση κωδικού F1", "Κωδικός F1 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Haier", "F2", "Εμφάνιση κωδικού F2", "Κωδικός F2 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Haier", "F3", "Εμφάνιση κωδικού F3", "Κωδικός F3 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Haier", "F4", "Εμφάνιση κωδικού F4", "Κωδικός F4 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Carrier", "E1", "Εμφάνιση κωδικού E1", "Κωδικός E1 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Carrier", "E2", "Εμφάνιση κωδικού E2", "Κωδικός E2 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Carrier", "E3", "Εμφάνιση κωδικού E3", "Κωδικός E3 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Carrier", "E4", "Εμφάνιση κωδικού E4", "Κωδικός E4 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Carrier", "E5", "Εμφάνιση κωδικού E5", "Κωδικός E5 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Carrier", "E6", "Σφάλμα επικοινωνίας ή ελέγχου", "Σφάλμα επικοινωνίας ή ελέγχου", "Καλωδίωση, τροφοδοσία, πλακέτες", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Carrier", "E7", "Εμφάνιση κωδικού E7", "Κωδικός E7 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Carrier", "E8", "Εμφάνιση κωδικού E8", "Κωδικός E8 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Carrier", "P1", "Ανωμαλία αισθητήρα/θερμοκρασίας", "Ανωμαλία αισθητήρα/θερμοκρασίας", "Αισθητήρας, καλωδίωση, πλακέτα", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Carrier", "P2", "Εμφάνιση κωδικού P2", "Κωδικός P2 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Carrier", "P3", "Εμφάνιση κωδικού P3", "Κωδικός P3 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Carrier", "P4", "Εμφάνιση κωδικού P4", "Κωδικός P4 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Toshiba", "E01", "Εμφάνιση κωδικού E01", "Κωδικός E01 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Toshiba", "E02", "Εμφάνιση κωδικού E02", "Κωδικός E02 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Toshiba", "E03", "Εμφάνιση κωδικού E03", "Κωδικός E03 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Toshiba", "E04", "Εμφάνιση κωδικού E04", "Κωδικός E04 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Toshiba", "E05", "Εμφάνιση κωδικού E05", "Κωδικός E05 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Toshiba", "E06", "Εμφάνιση κωδικού E06", "Κωδικός E06 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Toshiba", "E07", "Εμφάνιση κωδικού E07", "Κωδικός E07 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Toshiba", "E08", "Εμφάνιση κωδικού E08", "Κωδικός E08 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Toshiba", "P10", "Εμφάνιση κωδικού P10", "Κωδικός P10 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Toshiba", "P12", "Εμφάνιση κωδικού P12", "Κωδικός P12 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Panasonic", "H11", "Εμφάνιση κωδικού H11", "Κωδικός H11 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Panasonic", "H12", "Εμφάνιση κωδικού H12", "Κωδικός H12 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Panasonic", "H14", "Εμφάνιση κωδικού H14", "Κωδικός H14 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Panasonic", "H15", "Εμφάνιση κωδικού H15", "Κωδικός H15 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Panasonic", "H16", "Εμφάνιση κωδικού H16", "Κωδικός H16 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Panasonic", "H19", "Εμφάνιση κωδικού H19", "Κωδικός H19 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Panasonic", "H21", "Εμφάνιση κωδικού H21", "Κωδικός H21 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Panasonic", "H23", "Εμφάνιση κωδικού H23", "Κωδικός H23 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Panasonic", "H24", "Εμφάνιση κωδικού H24", "Κωδικός H24 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Panasonic", "H25", "Εμφάνιση κωδικού H25", "Κωδικός H25 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Panasonic", "H27", "Εμφάνιση κωδικού H27", "Κωδικός H27 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Panasonic", "H28", "Εμφάνιση κωδικού H28", "Κωδικός H28 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Panasonic", "H30", "Εμφάνιση κωδικού H30", "Κωδικός H30 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Panasonic", "H33", "Εμφάνιση κωδικού H33", "Κωδικός H33 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Samsung", "E101", "Εμφάνιση κωδικού E101", "Κωδικός E101 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Samsung", "E102", "Εμφάνιση κωδικού E102", "Κωδικός E102 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Samsung", "E121", "Εμφάνιση κωδικού E121", "Κωδικός E121 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Samsung", "E122", "Εμφάνιση κωδικού E122", "Κωδικός E122 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Samsung", "E154", "Εμφάνιση κωδικού E154", "Κωδικός E154 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Samsung", "E161", "Εμφάνιση κωδικού E161", "Κωδικός E161 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Samsung", "E201", "Εμφάνιση κωδικού E201", "Κωδικός E201 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Samsung", "E202", "Εμφάνιση κωδικού E202", "Κωδικός E202 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Samsung", "E203", "Εμφάνιση κωδικού E203", "Κωδικός E203 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Samsung", "E221", "Εμφάνιση κωδικού E221", "Κωδικός E221 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Samsung", "E237", "Εμφάνιση κωδικού E237", "Κωδικός E237 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("General", "E1", "Εμφάνιση κωδικού E1", "Κωδικός E1 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("General", "E2", "Εμφάνιση κωδικού E2", "Κωδικός E2 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("General", "E3", "Εμφάνιση κωδικού E3", "Κωδικός E3 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("General", "E4", "Εμφάνιση κωδικού E4", "Κωδικός E4 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("General", "E5", "Εμφάνιση κωδικού E5", "Κωδικός E5 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("General", "E6", "Σφάλμα επικοινωνίας ή ελέγχου", "Σφάλμα επικοινωνίας ή ελέγχου", "Καλωδίωση, τροφοδοσία, πλακέτες", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("General", "E7", "Εμφάνιση κωδικού E7", "Κωδικός E7 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("General", "E8", "Εμφάνιση κωδικού E8", "Κωδικός E8 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("General", "E9", "Εμφάνιση κωδικού E9", "Κωδικός E9 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("General", "P0", "Εμφάνιση κωδικού P0", "Κωδικός P0 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("General", "P1", "Ανωμαλία αισθητήρα/θερμοκρασίας", "Ανωμαλία αισθητήρα/θερμοκρασίας", "Αισθητήρας, καλωδίωση, πλακέτα", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("General", "P2", "Εμφάνιση κωδικού P2", "Κωδικός P2 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("General", "P4", "Εμφάνιση κωδικού P4", "Κωδικός P4 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("General", "P5", "Εμφάνιση κωδικού P5", "Κωδικός P5 — απαιτείται ταυτοποίηση με το ακριβές μοντέλο/σειρά.", "Αισθητήρας, καλωδίωση, πλακέτα, ανεμιστήρας ή ψυκτικό κύκλωμα, ανάλογα με το μοντέλο.", "Κατέγραψε ακριβή μάρκα/μοντέλο, πλήρη κωδικό και συνθήκες εμφάνισης. Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις σύμφωνα με το service manual.", "Μην αλλάξεις εξάρτημα μόνο από τον κωδικό. Επιβεβαίωσε τη βλάβη με τις τιμές/διαδικασία του κατασκευαστή."),
        Fault("Γενικό", "NO COOL", "Δεν κάνει σωστή ψύξη", "Χαμηλή απόδοση ψύξης", "Ροή αέρα, εναλλάκτες, ψυκτικό, εκτονωτικό, αισθητήρες", "Έλεγξε φίλτρα, εναλλάκτες, ανεμιστήρες, θερμοκρασίες, πιέσεις, SH/SC και διαρροές", "Διόρθωσε την πραγματική αιτία και όχι μόνο την ένδειξη πίεσης."),
        Fault("Γενικό", "NO HEAT", "Δεν κάνει σωστή θέρμανση", "Χαμηλή απόδοση θέρμανσης", "Ροή αέρα, τετράοδη, defrost, αισθητήρες, ψυκτικό", "Έλεγξε λειτουργία θέρμανσης, τετράοδη, αισθητήρες, defrost, πιέσεις και θερμοκρασίες", "Απομόνωσε την αιτία πριν από οποιαδήποτε φόρτιση."),
        Fault("Γενικό", "WATER LEAK", "Στάζει νερό από την εσωτερική", "Διαρροή συμπυκνωμάτων", "Αποχέτευση, κλίση, λεκάνη, αντλία, πάγος", "Έλεγξε λεκάνη, σωλήνα, κλίση, αντλία και πιθανό πάγωμα", "Καθάρισε/αποκατάστησε την αποχέτευση και την αιτία παγώματος."),
        Fault("Γενικό", "ICE", "Παγώνει ο εναλλάκτης", "Πάγος σε εσωτερικό εναλλάκτη ή σωλήνα", "Χαμηλή ροή αέρα, χαμηλή φόρτιση, περιορισμός, εκτονωτικό, αισθητήρας", "Έλεγξε φίλτρα/ανεμιστήρα και μετά SH/SC, πιέσεις και διαρροές", "Μην αφήνεις τη μονάδα να λειτουργεί παγωμένη."),
        Fault("Γενικό", "HIGH PRESSURE", "Υψηλή πίεση κατάθλιψης", "Υψηλή πίεση στο κύκλωμα", "Βρώμικος συμπυκνωτής, ανεμιστήρας, υπερφόρτιση, μη συμπυκνώσιμα", "Έλεγξε συμπυκνωτή/ανεμιστήρα, θερμοκρασίες και subcooling", "Διόρθωσε την αιτία και επιβεβαίωσε πριν αφαιρέσεις ψυκτικό."),
        Fault("Γενικό", "LOW PRESSURE", "Χαμηλή πίεση αναρρόφησης", "Χαμηλή πίεση στο κύκλωμα", "Έλλειψη ψυκτικού, διαρροή, περιορισμός, χαμηλό φορτίο", "Έλεγξε ροή αέρα, SH/SC, θερμοκρασίες και διαρροή", "Εντόπισε την αιτία πριν τη φόρτιση."),
        Fault("Γενικό", "NO START", "Δεν ξεκινά η μονάδα", "Αποτυχία εκκίνησης", "Τροφοδοσία, ασφάλεια, εντολή, πλακέτα, προστασία", "Έλεγξε τάση, ασφάλειες, εντολές, κωδικούς και συνδέσεις", "Αποκατάστησε την αιτία της μη εκκίνησης."),
        Fault("Γενικό", "NOISE", "Ασυνήθιστος θόρυβος", "Θόρυβος ή κραδασμός", "Ανεμιστήρας, ρουλεμάν, φτερωτή, βάσεις, σωληνώσεις, συμπιεστής", "Απομόνωσε την πηγή και έλεγξε στερεώσεις/επαφές", "Επισκεύασε το συγκεκριμένο εξάρτημα αφού επιβεβαιωθεί η πηγή."),
        Fault("Daikin • Emura FTXG", "U4", "Κωδικός U4", "Ένδειξη U4 στη σειρά Emura FTXG.", "Η ακριβής σημασία εξαρτάται από το μοντέλο και την πλακέτα.", "Έλεγξε το ακριβές model code και το service manual, μετά τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις.", "Επιβεβαίωσε την αιτία πριν από αντικατάσταση εξαρτήματος."),
        Fault("Daikin • Emura FTXG", "A5", "Κωδικός A5", "Ένδειξη A5 στη σειρά Emura FTXG.", "Η ακριβής σημασία εξαρτάται από το μοντέλο και την πλακέτα.", "Έλεγξε το ακριβές model code και το service manual, μετά τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις.", "Επιβεβαίωσε την αιτία πριν από αντικατάσταση εξαρτήματος."),
        Fault("Daikin • Altherma Monobloc", "U4", "Κωδικός U4", "Ένδειξη U4 στη σειρά Altherma Monobloc.", "Η ακριβής σημασία εξαρτάται από το μοντέλο και την πλακέτα.", "Έλεγξε το ακριβές model code και το service manual, μετά τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις.", "Επιβεβαίωσε την αιτία πριν από αντικατάσταση εξαρτήματος."),
        Fault("Midea • Mission / Xtreme Save", "E1", "Κωδικός E1", "Ένδειξη E1 στη σειρά Mission / Xtreme Save.", "Η ακριβής σημασία εξαρτάται από το μοντέλο και την πλακέτα.", "Έλεγξε το ακριβές model code και το service manual, μετά τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις.", "Επιβεβαίωσε την αιτία πριν από αντικατάσταση εξαρτήματος."),
        Fault("Gree • Pular / Fairy", "E6", "Κωδικός E6", "Ένδειξη E6 στη σειρά Pular / Fairy.", "Η ακριβής σημασία εξαρτάται από το μοντέλο και την πλακέτα.", "Έλεγξε το ακριβές model code και το service manual, μετά τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις.", "Επιβεβαίωσε την αιτία πριν από αντικατάσταση εξαρτήματος."),
        Fault("Fujitsu • ASYG / KM series", "A1", "Κωδικός A1", "Ένδειξη A1 στη σειρά ASYG / KM series.", "Η ακριβής σημασία εξαρτάται από το μοντέλο και την πλακέτα.", "Έλεγξε το ακριβές model code και το service manual, μετά τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις.", "Επιβεβαίωσε την αιτία πριν από αντικατάσταση εξαρτήματος."),
        Fault("Inventor • Aria / Omnia", "E1", "Κωδικός E1", "Ένδειξη E1 στη σειρά Aria / Omnia.", "Η ακριβής σημασία εξαρτάται από το μοντέλο και την πλακέτα.", "Έλεγξε το ακριβές model code και το service manual, μετά τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις.", "Επιβεβαίωσε την αιτία πριν από αντικατάσταση εξαρτήματος."),
        Fault("AUX • Freedom / Halo", "E1", "Κωδικός E1", "Ένδειξη E1 στη σειρά Freedom / Halo.", "Η ακριβής σημασία εξαρτάται από το μοντέλο και την πλακέτα.", "Έλεγξε το ακριβές model code και το service manual, μετά τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις.", "Επιβεβαίωσε την αιτία πριν από αντικατάσταση εξαρτήματος."),
        Fault("Tesla • Select", "E1", "Κωδικός E1", "Ένδειξη E1 στη σειρά Select.", "Η ακριβής σημασία εξαρτάται από το μοντέλο και την πλακέτα.", "Έλεγξε το ακριβές model code και το service manual, μετά τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις.", "Επιβεβαίωσε την αιτία πριν από αντικατάσταση εξαρτήματος."),
        Fault("Nordstar • Split series", "E1", "Κωδικός E1", "Ένδειξη E1 στη σειρά Split series.", "Η ακριβής σημασία εξαρτάται από το μοντέλο και την πλακέτα.", "Έλεγξε το ακριβές model code και το service manual, μετά τροφοδοσία, καλωδίωση, αισθητήρες και μετρήσεις.", "Επιβεβαίωσε την αιτία πριν από αντικατάσταση εξαρτήματος."),
        // ΕΠΑΛΗΘΕΥΜΕΝΟΙ ΚΩΔΙΚΟΙ ΑΠΟ ΕΠΙΣΗΜΕΣ ΠΗΓΕΣ (v1.3)
        Fault("LG • Single Split", "CH04", "Πρόβλημα αποχέτευσης συμπυκνωμάτων", "Η LG αναφέρει CH04 για πρόβλημα αποστράγγισης / συμπυκνωμάτων στην εσωτερική μονάδα.", "Βουλωμένη αποχέτευση, αντλία συμπυκνωμάτων, φλοτέρ/στάθμη, σωλήνα αποχέτευσης.", "Έλεγξε λεκάνη, σωλήνα αποχέτευσης, φλοτέρ/αντλία και δοκίμασε επανεκκίνηση σύμφωνα με το manual.", "Καθάρισε/αποκατάστησε την αποχέτευση και επιβεβαίωσε σωστή ροή νερού."),
        Fault("LG • Single Split", "CH10", "Σφάλμα ανεμιστήρα εσωτερικής μονάδας", "Η LG συνδέει CH10/E6 με πρόβλημα ανεμιστήρα εσωτερικής μονάδας.", "Μοτέρ ανεμιστήρα, εμπλοκή φτερωτής, καλωδίωση, πλακέτα.", "Έλεγξε ελεύθερη περιστροφή, συνδέσεις μοτέρ και τροφοδοσία/σήματα σύμφωνα με το service manual.", "Αποκατάσταση εμπλοκής/καλωδίωσης ή επιβεβαιωμένη αντικατάσταση εξαρτήματος."),
        Fault("LG • Single Split", "CH53", "Σφάλμα επικοινωνίας εσωτερικής–εξωτερικής", "Κωδικός επικοινωνίας μεταξύ μονάδων σε συμβατά μοντέλα LG.", "Καλωδίωση επικοινωνίας, τροφοδοσία, πολικότητα/τερματισμοί, πλακέτες.", "Έλεγξε τροφοδοσία και επικοινωνία μεταξύ μονάδων, ακροδέκτες και καλώδιο.", "Διόρθωσε καλωδίωση/τροφοδοσία και επιβεβαίωσε επικοινωνία πριν από αλλαγή πλακέτας."),
        Fault("LG • Single Split", "CH61", "Προστασία υπερθέρμανσης", "Η LG αναφέρει CH61 όταν η εξωτερική μονάδα υπερθερμαίνεται στην ψύξη ή η εσωτερική στη θέρμανση.", "Κακός αερισμός εξωτερικής, βρώμικος εναλλάκτης/φίλτρο, περιορισμένη ροή αέρα.", "Έλεγξε αερισμό, φίλτρα, εναλλάκτες, ανεμιστήρες και θερμοκρασίες.", "Αποκατάστησε τη ροή αέρα/καθαριότητα και κάνε reset μετά τον έλεγχο."),
        Fault("LG • Single Split", "CH66", "Ανωμαλία επικοινωνίας ή σύνδεσης σωληνώσεων", "Η LG αναφέρει CH66 σε inverter όταν ανιχνεύεται ανωμαλία επικοινωνίας ή/και λανθασμένη σύνδεση σωληνώσεων.", "Καλώδιο επικοινωνίας, λάθος αντιστοίχιση σωληνώσεων, ασταθής τροφοδοσία.", "Έλεγξε αντιστοίχιση σωληνώσεων και καλωδίων μεταξύ εσωτερικής/εξωτερικής και τροφοδοσία.", "Διόρθωσε σύνδεση και κάνε επανεκκίνηση. Αν επιμένει, συνέχισε με service procedure."),
        Fault("LG • Single Split", "CH67", "Σφάλμα ανεμιστήρα εξωτερικής μονάδας", "Η LG συνδέει CH67/EF με πρόβλημα ανεμιστήρα εξωτερικής μονάδας.", "Μοτέρ, εμπόδιο/πάγος, καλωδίωση, πλακέτα inverter.", "Έλεγξε μηχανική εμπλοκή, πάγο/ξένα σώματα, συνδέσεις και λειτουργία μοτέρ.", "Αποκατάστησε εμπλοκή/καλωδίωση ή αντικατάστησε μόνο μετά από επιβεβαίωση μετρήσεων."),
        Fault("LG • Single Split", "CH90/CH91", "Σφάλμα test run / σωληνώσεων", "Η LG αναφέρει CH90/CH91 συχνά κατά test run για προστασία σε πρόβλημα σωληνώσεων ή εγκατάστασης.", "Λανθασμένες σωληνώσεις, βαλβίδες, εγκατάσταση, προσωρινή ηλεκτρική ανωμαλία.", "Έλεγξε σωληνώσεις, βάνες, συνδέσεις και συνθήκες test run.", "Διόρθωσε εγκατάσταση και επανάλαβε test run σύμφωνα με το manual."),
        Fault("LG • Single Split", "CH93", "Σφάλμα επικοινωνίας εσωτερικής–εξωτερικής", "Η LG αναφέρει CH93 για ασταθή/αποτυχημένη επικοινωνία μεταξύ εσωτερικής και εξωτερικής μονάδας.", "Τροφοδοσία εξωτερικής, καλώδιο επικοινωνίας, ακροδέκτες, πλακέτες.", "Επιβεβαίωσε ότι και οι δύο μονάδες τροφοδοτούνται και έλεγξε καλωδίωση επικοινωνίας.", "Αποκατάστησε τροφοδοσία/επικοινωνία και κάνε reset σύμφωνα με τις οδηγίες του μοντέλου."),
        Fault("Gree • Single Split", "E6", "Σφάλμα επικοινωνίας εσωτερικής–εξωτερικής", "Η GREE αναφέρει E6 ως communication failure μεταξύ εσωτερικής και εξωτερικής μονάδας σε mini-split.", "Λάθος καλωδίωση, κακές ενώσεις/splices, τροφοδοσία, πλακέτα επικοινωνίας.", "Έλεγξε πρώτα ολόκληρη τη διαδρομή καλωδίωσης και τις ενώσεις· μην θεωρείς αυτόματα ελαττωματική την εξωτερική πλακέτα.", "Διόρθωσε καλωδίωση/συνδέσεις και επιβεβαίωσε επικοινωνία πριν από αλλαγή πλακέτας."),
        Fault("LG","CH05","Επικοινωνία indoor–outdoor","Επικοινωνία indoor–outdoor","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","Split / Inverter","Residential / System Air","LG Official Support"),
        Fault("LG","CH53","Επικοινωνία indoor–outdoor","Επικοινωνία indoor–outdoor","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","Multi-Split","Multi / System Air","LG Official Support"),
        Fault("LG","CH61","Προστασία υψηλής θερμοκρασίας","Προστασία υψηλής θερμοκρασίας","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","Split / Inverter","Residential / System Air","LG Official Support"),
        Fault("LG","CH66","Ανωμαλία αντιστοίχισης σωληνώσεων/επικοινωνίας","Ανωμαλία αντιστοίχισης σωληνώσεων/επικοινωνίας","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","Multi-Split","Multi","LG Official Support"),
        Fault("LG","CH67","Ανωμαλία outdoor fan","Ανωμαλία outdoor fan","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","Split / Inverter","Residential / System Air","LG Official Support"),
        Fault("LG","CH90/CH91","Προστασία test run / piping","Προστασία test run / piping","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","Split / Inverter","Residential","LG Official Support"),
        Fault("LG","CH93","Σφάλμα επικοινωνίας indoor–outdoor","Σφάλμα επικοινωνίας indoor–outdoor","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","Split / Inverter","Residential 2021+","LG Official Support"),
        Fault("Samsung","E1/21","Room temperature sensor fault","Room temperature sensor fault","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","Split / Inverter","Residential","Samsung Official Support"),
        Fault("Samsung","E1/22","Indoor heat exchanger sensor fault","Indoor heat exchanger sensor fault","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","Split / Inverter","Residential","Samsung Official Support"),
        Fault("Samsung","E1/54","Fan motor/circuit fault","Fan motor/circuit fault","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","Split / Inverter","Residential","Samsung Official Support"),
        Fault("Samsung","E1/63","EEPROM fault","EEPROM fault","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","Split / Inverter","Residential","Samsung Official Support"),
        Fault("Samsung","E5","Indoor coil sensor open/short","Indoor coil sensor open/short","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","Split / Inverter","Residential","Samsung Official Support"),
        Fault("Samsung","E6","Outdoor coil sensor open/short","Outdoor coil sensor open/short","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","Split / Inverter","Residential","Samsung Official Support"),
        Fault("Midea","E0","Mode conflict","Mode conflict","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","VRF / VRV","VRF Fresh Air Processing Unit","Midea Official VRF Manual"),
        Fault("Midea","E1","Communication error indoor–outdoor","Communication error indoor–outdoor","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","VRF / VRV","VRF Fresh Air Processing Unit","Midea Official VRF Manual"),
        Fault("Midea","E2","Outlet air sensor TA error","Outlet air sensor TA error","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","VRF / VRV","VRF Fresh Air Processing Unit","Midea Official VRF Manual"),
        Fault("Panasonic","H12","Capacity mismatch","Capacity mismatch","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","Αντλία θερμότητας","Aquarea","Panasonic Official Aquarea Guide"),
        Fault("Panasonic","H15","Compressor sensor error","Compressor sensor error","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","Αντλία θερμότητας","Aquarea","Panasonic Official Aquarea Guide"),
        Fault("Panasonic","H20","Pump error","Pump error","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","Αντλία θερμότητας","Aquarea","Panasonic Official Aquarea Guide"),
        Fault("Panasonic","H23","Refrigerant sensor error","Refrigerant sensor error","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","Αντλία θερμότητας","Aquarea","Panasonic Official Aquarea Guide"),
        Fault("Panasonic","H27","Service valve error","Service valve error","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","Αντλία θερμότητας","Aquarea","Panasonic Official Aquarea Guide"),
        Fault("Panasonic","F12","Pressure switch activated","Pressure switch activated","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","Αντλία θερμότητας","Aquarea","Panasonic Official Aquarea Guide"),
        Fault("Panasonic","F14","Poor compressor rotation","Poor compressor rotation","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","Αντλία θερμότητας","Aquarea","Panasonic Official Aquarea Guide"),
        Fault("Panasonic","F15","Fan motor lock","Fan motor lock","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","Αντλία θερμότητας","Aquarea","Panasonic Official Aquarea Guide"),
        Fault("Panasonic","F16","Current protection","Current protection","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","Αντλία θερμότητας","Aquarea","Panasonic Official Aquarea Guide"),
        Fault("Panasonic","F20","Compressor overload protection","Compressor overload protection","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","Αντλία θερμότητας","Aquarea","Panasonic Official Aquarea Guide"),
        Fault("Panasonic","F22","Transistor module overload","Transistor module overload","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","Αντλία θερμότητας","Aquarea","Panasonic Official Aquarea Guide"),
        Fault("Panasonic","F23","DC peak","DC peak","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","Αντλία θερμότητας","Aquarea","Panasonic Official Aquarea Guide"),
        Fault("Mitsubishi Electric","0403","Serial transmission abnormality","Serial transmission abnormality","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","VRF / VRV","CITY MULTI","Mitsubishi Electric Official CITY MULTI Manual"),
        Fault("Mitsubishi Electric","1102","Discharge temperature abnormality","Discharge temperature abnormality","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","VRF / VRV","CITY MULTI","Mitsubishi Electric Official CITY MULTI Manual"),
        Fault("Mitsubishi Electric","1301","Low pressure abnormality","Low pressure abnormality","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","VRF / VRV","CITY MULTI","Mitsubishi Electric Official CITY MULTI Manual"),
        Fault("Mitsubishi Electric","1302","High pressure abnormality","High pressure abnormality","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","VRF / VRV","CITY MULTI","Mitsubishi Electric Official CITY MULTI Manual"),
        Fault("Mitsubishi Electric","1500","Overcharged refrigerant abnormality","Overcharged refrigerant abnormality","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","VRF / VRV","CITY MULTI","Mitsubishi Electric Official CITY MULTI Manual"),
        Fault("Mitsubishi Electric","2500","Water leakage abnormality","Water leakage abnormality","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","VRF / VRV","CITY MULTI","Mitsubishi Electric Official CITY MULTI Manual"),
        Fault("Mitsubishi Electric","2502","Drain pump abnormality","Drain pump abnormality","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","VRF / VRV","CITY MULTI","Mitsubishi Electric Official CITY MULTI Manual"),
        Fault("Mitsubishi Electric","2503","Drain sensor abnormality","Drain sensor abnormality","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","VRF / VRV","CITY MULTI","Mitsubishi Electric Official CITY MULTI Manual"),
        Fault("Mitsubishi Electric","4103","Reverse phase abnormality","Reverse phase abnormality","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","VRF / VRV","CITY MULTI","Mitsubishi Electric Official CITY MULTI Manual"),
        Fault("Mitsubishi Electric","4116","Fan speed abnormality","Fan speed abnormality","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","VRF / VRV","CITY MULTI","Mitsubishi Electric Official CITY MULTI Manual"),
        Fault("Mitsubishi Electric","4220","Bus voltage abnormality","Bus voltage abnormality","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","VRF / VRV","CITY MULTI","Mitsubishi Electric Official CITY MULTI Manual"),
        Fault("Mitsubishi Electric","4230","Heat sink overheat protection","Heat sink overheat protection","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","VRF / VRV","CITY MULTI","Mitsubishi Electric Official CITY MULTI Manual"),
        Fault("Mitsubishi Electric","4240","Overload protection","Overload protection","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","VRF / VRV","CITY MULTI","Mitsubishi Electric Official CITY MULTI Manual"),
        Fault("Mitsubishi Electric","4250","IPM / over-current abnormality","IPM / over-current abnormality","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","VRF / VRV","CITY MULTI","Mitsubishi Electric Official CITY MULTI Manual"),
        Fault("Mitsubishi Electric","4260","Cooling fan abnormality","Cooling fan abnormality","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","VRF / VRV","CITY MULTI","Mitsubishi Electric Official CITY MULTI Manual"),
        Fault("Mitsubishi Electric","5101","Thermal sensor abnormality","Thermal sensor abnormality","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","VRF / VRV","CITY MULTI","Mitsubishi Electric Official CITY MULTI Manual"),
        Fault("Mitsubishi Electric","5201","High pressure sensor abnormality","High pressure sensor abnormality","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","VRF / VRV","CITY MULTI","Mitsubishi Electric Official CITY MULTI Manual"),
        Fault("Mitsubishi Electric","6600","Multiple address abnormality","Multiple address abnormality","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","VRF / VRV","CITY MULTI","Mitsubishi Electric Official CITY MULTI Manual"),
        Fault("Mitsubishi Electric","6602","Transmission processor hardware abnormality","Transmission processor hardware abnormality","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","VRF / VRV","CITY MULTI","Mitsubishi Electric Official CITY MULTI Manual"),
        Fault("Mitsubishi Electric","6603","Transmission bus-busy abnormality","Transmission bus-busy abnormality","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","VRF / VRV","CITY MULTI","Mitsubishi Electric Official CITY MULTI Manual"),
        Fault("Daikin","U4","Communication abnormality","Communication abnormality","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","VRF / VRV","VRV IV+ RXYTQ","Daikin Official Installer Reference Guide"),
        Fault("Daikin","U0","Refrigerant shortage/circuit abnormality — verify sub-code","Refrigerant shortage/circuit abnormality — verify sub-code","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","VRF / VRV","VRV IV+ RXYTQ","Daikin Official Installer Reference Guide"),
        Fault("Daikin","00","Water temperature sensor problem — verify detailed code","Water temperature sensor problem — verify detailed code","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","Αντλία θερμότητας","Altherma ERGA-D + EHBH/EHBX-D","Daikin Official Altherma Installer Guide"),
        Fault("Daikin","01","Heat exchanger frozen — detailed code family","Heat exchanger frozen — detailed code family","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","Αντλία θερμότητας","Altherma ERGA-D + EHBH/EHBX-D","Daikin Official Altherma Installer Guide"),
        Fault("Daikin","03","Water circuit overheat — detailed code family","Water circuit overheat — detailed code family","Πιθανά αίτια εξαρτώνται από το συγκεκριμένο μοντέλο και το υποσύστημα.","Έλεγξε τροφοδοσία, καλωδίωση, αισθητήρες/ροές και τις μετρήσεις του επίσημου service manual.","Επισκεύασε μόνο το επιβεβαιωμένο αίτιο και επανάλαβε τον έλεγχο του κατασκευαστή.","Αντλία θερμότητας","Altherma ERGA-D + EHBH/EHBX-D","Daikin Official Altherma Installer Guide")
    )

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        onBackPressedDispatcher.addCallback(this, object:androidx.activity.OnBackPressedCallback(true){
            override fun handleOnBackPressed(){
                if(!goBackHistory()){
                    isEnabled=false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
        home()
    }

    private fun uiFont(bold:Boolean=true)=android.graphics.Typeface.create(
        "sans-serif-rounded",
        if(bold) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL
    )

    private fun base(): LinearLayout = LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL
        setPadding(16,18,16,30)
        setBackgroundColor(bg)
        addView(TextView(this@MainActivity).apply {
            text="←"
            textSize=32f
            setTextColor(Color.WHITE)
            typeface=uiFont(true)
            gravity=Gravity.CENTER
            background=roundedBg(Color.rgb(0,112,190),18f)
            elevation=5f
            setOnClickListener { if(!goBackHistory()) home() }
            contentDescription="Πίσω"
        }, LinearLayout.LayoutParams(72,60).apply{setMargins(0,0,0,12)})
    }
    private fun title(text: String, size: Float = 25f) = TextView(this).apply {
        this.text=text
        textSize=size
        setTextColor(Color.rgb(68,174,255))
        typeface=uiFont(true)
        letterSpacing=0.01f
        setPadding(4,4,4,12)
    }
    private fun button(text: String, action: () -> Unit) = Button(this).apply {
        this.text=text
        isAllCaps=false
        textSize=16f
        typeface=uiFont(true)
        letterSpacing=0.015f
        setTextColor(Color.WHITE)
        setPadding(14,11,14,11)
        background=GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(Color.rgb(0,83,160),Color.rgb(0,139,214))).apply{
            cornerRadius=18f
            setStroke(1,Color.rgb(54,171,245))
        }
        elevation=4f
        setOnClickListener{action()}
    }
    private fun input(hint: String) = EditText(this).apply {
        this.hint=hint
        textSize=17f
        typeface=uiFont(true)
        setTextColor(Color.WHITE)
        setHintTextColor(Color.rgb(151,184,207))
        setPadding(14,12,14,12)
        background=GradientDrawable().apply{
            setColor(Color.rgb(4,35,67))
            cornerRadius=16f
            setStroke(1,Color.rgb(0,126,205))
        }
    }
    private fun searchInput(hint: String) = EditText(this).apply {
        this.hint=hint
        textSize=18f
        setTextColor(Color.WHITE)
        setHintTextColor(Color.rgb(155,187,210))
        typeface=uiFont(true)
        letterSpacing=0.01f
        setSingleLine(true)
        setPadding(18,14,18,14)
        background=GradientDrawable().apply {
            setColor(Color.rgb(4,35,67))
            cornerRadius=18f
            setStroke(2,Color.rgb(0,137,220))
        }
    }
    private fun card(text: String, action: (() -> Unit)? = null) = TextView(this).apply {
        this.text=text
        textSize=17f
        typeface=uiFont(true)
        letterSpacing=0.012f
        setTextColor(Color.WHITE)
        setPadding(18,17,18,17)
        background=GradientDrawable().apply{
            setColor(Color.rgb(4,38,73))
            cornerRadius=22f
            setStroke(1,Color.rgb(0,119,203))
        }
        elevation=3f
        if(action!=null)setOnClickListener{action()}
    }
    private fun scroll(list: View): ScrollView = ScrollView(this).apply { addView(list) }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
    private fun jsonArray(key:String)=JSONArray(prefs.getString(key,"[]"))

    private fun homeIcon(symbol:String)=TextView(this).apply{
        text=symbol
        textSize=31f
        gravity=Gravity.CENTER
        typeface=uiFont(true)
        setTextColor(Color.rgb(0,112,173))
    }

    private fun homeTile(icon:String,titleText:String,sub:String,action:()->Unit)=LinearLayout(this).apply{
        orientation=LinearLayout.VERTICAL
        gravity=Gravity.CENTER
        setPadding(10,14,10,14)
        background=GradientDrawable().apply{
            setColor(Color.WHITE)
            cornerRadius=24f
            setStroke(2,Color.rgb(222,232,240))
        }
        elevation=5f
        addView(homeIcon(icon),LinearLayout.LayoutParams(-1,56))
        addView(TextView(this@MainActivity).apply{
            text=titleText
            textSize=15f
            gravity=Gravity.CENTER
            typeface=uiFont(true)
            setTextColor(Color.rgb(18,48,82))
            maxLines=2
        },LinearLayout.LayoutParams(-1,-2))
        addView(TextView(this@MainActivity).apply{
            text=sub
            textSize=11f
            gravity=Gravity.CENTER
            setTextColor(Color.rgb(90,100,110))
            maxLines=2
            setPadding(2,5,2,0)
        },LinearLayout.LayoutParams(-1,-2))
        setOnClickListener{action()}
    }

    private fun homeHero(icon:String,titleText:String,sub:String,action:()->Unit)=LinearLayout(this).apply{
        orientation=LinearLayout.HORIZONTAL
        gravity=Gravity.CENTER_VERTICAL
        setPadding(18,16,18,16)
        background=GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(Color.rgb(0,62,124),Color.rgb(0,128,197))
        ).apply{cornerRadius=26f}
        elevation=7f
        addView(TextView(this@MainActivity).apply{
            text=icon
            textSize=40f
            gravity=Gravity.CENTER
        },LinearLayout.LayoutParams(64,70))
        addView(LinearLayout(this@MainActivity).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(12,0,0,0)
            addView(TextView(this@MainActivity).apply{
                text=titleText
                textSize=19f
                typeface=uiFont(true)
                setTextColor(Color.WHITE)
            })
            addView(TextView(this@MainActivity).apply{
                text=sub
                textSize=13f
                setTextColor(Color.rgb(225,242,252))
                setPadding(0,4,0,0)
            })
        },LinearLayout.LayoutParams(0,-2,1f))
        setOnClickListener{action()}
    }


    private fun homeImage(name:String,height:Int=92):ImageView=ImageView(this).apply{
        val id=resources.getIdentifier(name,"drawable",packageName)
        if(id!=0)setImageResource(id)
        scaleType=ImageView.ScaleType.CENTER_INSIDE
        adjustViewBounds=true
        contentDescription=name
        layoutParams=LinearLayout.LayoutParams(-1,height)
    }

    private fun roundedBg(color:Int,radius:Float,strokeColor:Int?=null,stroke:Int=0)=GradientDrawable().apply{
        shape=GradientDrawable.RECTANGLE
        cornerRadius=radius
        setColor(color)
        if(strokeColor!=null && stroke>0)setStroke(stroke,strokeColor)
    }

    private fun homeSmallTile(image:String,titleText:String,sub:String,action:()->Unit)=LinearLayout(this).apply{
        orientation=LinearLayout.VERTICAL
        gravity=Gravity.CENTER
        setPadding(7,10,7,9)
        background=roundedBg(Color.WHITE,22f,Color.rgb(225,231,238),1)
        elevation=4f
        addView(homeImage(image,72))
        addView(TextView(this@MainActivity).apply{
            text=titleText
            textSize=13f
            typeface=uiFont(true)
            gravity=Gravity.CENTER
            setTextColor(Color.rgb(10,38,78))
            maxLines=2
        })
        addView(TextView(this@MainActivity).apply{
            text=sub
            textSize=9.5f
            gravity=Gravity.CENTER
            setTextColor(Color.rgb(60,75,95))
            maxLines=2
            setPadding(2,3,2,0)
        })
        setOnClickListener{action()}
    }

    private fun homeHeroVisual(image:String,titleText:String,sub:String,cta:String,action:()->Unit)=LinearLayout(this).apply{
        orientation=LinearLayout.HORIZONTAL
        gravity=Gravity.CENTER_VERTICAL
        setPadding(12,12,12,12)
        background=GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.rgb(2,77,160),Color.rgb(0,38,92))
        ).apply{cornerRadius=24f}
        elevation=6f
        addView(homeImage(image,118),LinearLayout.LayoutParams(110,118).apply{setMargins(0,0,8,0)})
        addView(LinearLayout(this@MainActivity).apply{
            orientation=LinearLayout.VERTICAL
            gravity=Gravity.CENTER_VERTICAL
            addView(TextView(this@MainActivity).apply{
                text=titleText
                textSize=17f
                typeface=uiFont(true)
                setTextColor(Color.WHITE)
                maxLines=2
            })
            addView(TextView(this@MainActivity).apply{
                text=sub
                textSize=11f
                setTextColor(Color.rgb(226,238,252))
                setPadding(0,4,0,8)
                maxLines=3
            })
            addView(TextView(this@MainActivity).apply{
                text="$cta   ❯"
                textSize=12f
                typeface=uiFont(true)
                setTextColor(Color.WHITE)
                gravity=Gravity.CENTER
                setPadding(12,6,12,6)
                background=roundedBg(Color.TRANSPARENT,22f,Color.rgb(0,174,239),2)
            })
        },LinearLayout.LayoutParams(0,-2,1f))
        setOnClickListener{action()}
    }

    private fun startHomeClock(){
        val tv=homeClockView ?: return
        val handler=android.os.Handler(mainLooper)
        val tick=object:Runnable{
            override fun run(){
                if(homeClockView!==tv)return
                val now=java.util.Date()
                val date=java.text.SimpleDateFormat("dd/MM/yyyy",java.util.Locale.getDefault()).format(now)
                val time=java.text.SimpleDateFormat("HH:mm:ss",java.util.Locale.getDefault()).format(now)
                tv.text="📅 $date\n🕒 $time"
                handler.postDelayed(this,1000)
            }
        }
        handler.post(tick)
    }

    private fun loadHomeTemperature(){
        val tv=homeTemperatureView ?: return
        if(android.os.Build.VERSION.SDK_INT>=23 &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
            tv.text="🌡  ΘΕΡΜΟΚΡΑΣΙΑ\nΠαραχώρησε τοποθεσία"
            requestPermissions(arrayOf(
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACCESS_FINE_LOCATION
            ),HOME_LOCATION_PERMISSION)
            return
        }
        try{
            val lm=getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val candidates=listOf(
                LocationManager.NETWORK_PROVIDER,
                LocationManager.GPS_PROVIDER,
                LocationManager.PASSIVE_PROVIDER
            ).mapNotNull{provider->
                try{lm.getLastKnownLocation(provider)}catch(_:Exception){null}
            }
            val loc=candidates.maxByOrNull{it.time}
            if(loc==null){
                tv.text="🌡  ΘΕΡΜΟΚΡΑΣΙΑ\nΑναμονή τοποθεσίας…"
                return
            }
            val lat=loc.latitude
            val lon=loc.longitude
            Thread{
                try{
                    val url=java.net.URL(
                        "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m&timezone=auto"
                    )
                    val conn=url.openConnection().apply{
                        connectTimeout=7000
                        readTimeout=7000
                    }
                    val body=conn.getInputStream().bufferedReader().use{it.readText()}
                    val current=JSONObject(body).getJSONObject("current")
                    val temp=current.getDouble("temperature_2m")
                    runOnUiThread{
                        if(homeTemperatureView===tv){
                            tv.text="🌡  ΕΞΩΤΕΡΙΚΗ ΘΕΡΜΟΚΡΑΣΙΑ\n${String.format(java.util.Locale.getDefault(),"%.1f",temp)}°C"
                        }
                    }
                }catch(_:Exception){
                    runOnUiThread{
                        if(homeTemperatureView===tv) tv.text="🌡  ΕΞΩΤΕΡΙΚΗ ΘΕΡΜΟΚΡΑΣΙΑ\nΜη διαθέσιμη"
                    }
                }
            }.start()
        }catch(_:Exception){
            tv.text="🌡  ΕΞΩΤΕΡΙΚΗ ΘΕΡΜΟΚΡΑΣΙΑ\nΜη διαθέσιμη"
        }
    }

    override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults)
        if(requestCode==HOME_LOCATION_PERMISSION){
            loadHomeTemperature()
        }
    }

    private fun home(){
        val root=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(248,250,253))
            fitsSystemWindows=true
        }

        fun sectionImage(name:String)=ImageView(this).apply{
            val id=resources.getIdentifier(name,"drawable",packageName)
            if(id!=0)setImageResource(id)
            scaleType=ImageView.ScaleType.FIT_XY
            adjustViewBounds=true
        }

        // TOP: exact approved artwork, no fake search/status baked in.
        val topImage=sectionImage("home_top_native")
        root.addView(topImage,LinearLayout.LayoutParams(-1,0,0.287f))

        // ONE REAL SEARCH BAR.
        val searchBar=LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL
            gravity=Gravity.CENTER_VERTICAL
            setPadding(14,4,10,4)
            background=GradientDrawable().apply{
                setColor(Color.WHITE)
                cornerRadius=44f
                setStroke(2,Color.rgb(225,230,238))
            }
            elevation=8f
        }

        val searchIcon=TextView(this).apply{
            text="⌕"
            textSize=32f
            gravity=Gravity.CENTER
            setTextColor(Color.rgb(0,92,175))
            includeFontPadding=false
        }
        searchBar.addView(searchIcon,LinearLayout.LayoutParams(54,-1))

        val quick=EditText(this).apply{
            hint="Γρήγορη αναζήτηση μοντέλου ή βλάβης..."
            textSize=16f
            setTextColor(Color.rgb(35,35,35))
            setHintTextColor(Color.rgb(120,120,120))
            typeface=uiFont(true)
            setSingleLine(true)
            gravity=Gravity.CENTER_VERTICAL
            includeFontPadding=false
            setPadding(4,0,4,0)
            setBackgroundColor(Color.TRANSPARENT)
            imeOptions=android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
        }
        searchBar.addView(quick,LinearLayout.LayoutParams(0,-1,1f))

        fun submitHomeSearch(){
            val term=quick.text.toString().trim()
            if(term.isBlank()){
                toast("Γράψε τι θέλεις να αναζητήσεις.")
                return
            }
            searchScreen(term)
        }

        val send=TextView(this).apply{
            text="➤"
            textSize=28f
            gravity=Gravity.CENTER
            setTextColor(Color.rgb(0,112,190))
            includeFontPadding=false
            setOnClickListener{submitHomeSearch()}
            contentDescription="Αναζήτηση"
        }
        searchBar.addView(send,LinearLayout.LayoutParams(58,-1))

        quick.setOnEditorActionListener{_,_,_->
            submitHomeSearch()
            true
        }

        root.addView(searchBar,LinearLayout.LayoutParams(-1,0,0.055f).apply{
            setMargins(24,4,24,8)
        })

        // MIDDLE: exact approved cards artwork.
        val middleImage=sectionImage("home_middle_native")
        middleImage.setOnTouchListener(object:View.OnTouchListener{
            var downX=0f
            var downY=0f
            override fun onTouch(v:View,event:MotionEvent):Boolean{
                when(event.actionMasked){
                    MotionEvent.ACTION_DOWN -> {
                        downX=event.x
                        downY=event.y
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        val moved=kotlin.math.abs(event.x-downX)+kotlin.math.abs(event.y-downY)
                        if(moved<45f && v.width>0 && v.height>0){
                            val x=event.x/v.width.toFloat()
                            val y=event.y/v.height.toFloat()

                            // Crop begins below search bar. These rows are calibrated
                            // relative to this middle-only image.
                            when{
                                y<0.19f && x<0.50f -> faultsScreen()
                                y<0.19f && x>=0.50f -> aiScreen()

                                y in 0.19f..0.43f && x<0.25f -> customersScreen()
                                y in 0.19f..0.43f && x<0.50f -> machinesScreen(null)
                                y in 0.19f..0.43f && x<0.75f -> jobsScreen()
                                y in 0.19f..0.43f -> referenceToolsScreen()

                                y in 0.43f..0.67f && x<0.25f -> checklistScreen()
                                y in 0.43f..0.67f && x<0.50f -> refrigerationScreen()
                                y in 0.43f..0.67f && x<0.75f -> notesScreen()
                                y in 0.43f..0.67f -> materialsScreen()

                                y>=0.67f && x<0.25f -> jobsScreen()
                                y>=0.67f && x<0.50f -> backupScreen()
                                y>=0.67f && x<0.75f -> toolsScreen()
                                y>=0.67f -> backupScreen()
                            }
                        }
                        return true
                    }
                }
                return true
            }
        })
        root.addView(middleImage,LinearLayout.LayoutParams(-1,0,0.598f))

        // ONE REAL BLUE STATUS BAR.
        val liveStatus=LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL
            gravity=Gravity.CENTER
            setPadding(10,6,10,6)
            background=GradientDrawable().apply{
                setColor(Color.rgb(1,48,103))
                cornerRadius=28f
            }
            elevation=8f
        }

        val temp=TextView(this).apply{
            text="🌡 ΕΞΩΤΕΡΙΚΗ ΘΕΡΜΟΚΡΑΣΙΑ\nΦόρτωση…"
            textSize=9.5f
            gravity=Gravity.CENTER
            setTextColor(Color.WHITE)
            typeface=uiFont(true)
            includeFontPadding=false
        }

        val clock=TextView(this).apply{
            text="📅 --/--/----\n🕒 --:--:--"
            textSize=10f
            gravity=Gravity.CENTER
            setTextColor(Color.WHITE)
            typeface=uiFont(true)
            includeFontPadding=false
        }

        val dataMode=TextView(this).apply{
            text="📶 LIVE / OFFLINE DATA\nΒάση δεδομένων τοπικά"
            textSize=9.5f
            gravity=Gravity.CENTER
            setTextColor(Color.WHITE)
            typeface=uiFont(true)
            includeFontPadding=false
        }

        liveStatus.addView(temp,LinearLayout.LayoutParams(0,-1,1.15f))
        liveStatus.addView(clock,LinearLayout.LayoutParams(0,-1,1.00f))
        liveStatus.addView(dataMode,LinearLayout.LayoutParams(0,-1,1.10f))

        root.addView(liveStatus,LinearLayout.LayoutParams(-1,0,0.060f).apply{
            setMargins(22,6,22,10)
        })

        homeTemperatureView=temp
        homeClockView=clock
        setContentView(root)
        startHomeClock()
        loadHomeTemperature()
    }

    private fun customers():MutableList<Customer>{ val a=jsonArray("customers"); return MutableList(a.length()){i->val o=a.getJSONObject(i);Customer(o.getLong("id"),o.optString("name"),o.optString("phone"),o.optString("address"),o.optString("notes"))} }
    private fun saveCustomers(x:List<Customer>){val a=JSONArray();x.forEach{a.put(JSONObject().apply{put("id",it.id);put("name",it.name);put("phone",it.phone);put("address",it.address);put("notes",it.notes)})};prefs.edit().putString("customers",a.toString()).apply()}
    private fun machines():MutableList<Machine>{val a=jsonArray("machines");return MutableList(a.length()){i->val o=a.getJSONObject(i);Machine(o.getLong("id"),o.getLong("customerId"),o.optString("brand"),o.optString("model"),o.optString("serial"),o.optString("refrigerant"),o.optString("capacity"),o.optString("type"),o.optString("year"),o.optString("address"),o.optString("notes"))}}
    private fun saveMachines(x:List<Machine>){val a=JSONArray();x.forEach{a.put(JSONObject().apply{put("id",it.id);put("customerId",it.customerId);put("brand",it.brand);put("model",it.model);put("serial",it.serial);put("refrigerant",it.refrigerant);put("capacity",it.capacity);put("type",it.type);put("year",it.year);put("address",it.address);put("notes",it.notes)})};prefs.edit().putString("machines",a.toString()).apply()}
    private fun jobs():MutableList<Job>{val a=jsonArray("jobs");return MutableList(a.length()){i->val o=a.getJSONObject(i);Job(o.getLong("id"),o.optLong("customerId"),o.optLong("machineId"),o.optString("date"),o.optString("type"),o.optString("symptom"),o.optString("faultCode"),o.optString("diagnosis"),o.optString("action"),o.optString("suction"),o.optString("discharge"),o.optString("suctionTemp"),o.optString("liquidTemp"),o.optString("roomTemp"),o.optString("outletTemp"),o.optString("superheat"),o.optString("subcooling"),o.optString("materials"),o.optString("materialCost"),o.optString("laborHours"),o.optString("laborRate"),o.optString("total"),o.optString("checklist"),o.optString("photos"),o.optString("notes"),o.optString("status"))}}
    private fun saveJobs(x:List<Job>){val a=JSONArray();x.forEach{j->a.put(JSONObject().apply{put("id",j.id);put("customerId",j.customerId);put("machineId",j.machineId);put("date",j.date);put("type",j.type);put("symptom",j.symptom);put("faultCode",j.faultCode);put("diagnosis",j.diagnosis);put("action",j.action);put("suction",j.suction);put("discharge",j.discharge);put("suctionTemp",j.suctionTemp);put("liquidTemp",j.liquidTemp);put("roomTemp",j.roomTemp);put("outletTemp",j.outletTemp);put("superheat",j.superheat);put("subcooling",j.subcooling);put("materials",j.materials);put("materialCost",j.materialCost);put("laborHours",j.laborHours);put("laborRate",j.laborRate);put("total",j.total);put("checklist",j.checklist);put("photos",j.photos);put("notes",j.notes);put("status",j.status)})};prefs.edit().putString("jobs",a.toString()).apply()}

    private fun photoArray(key:String): JSONArray = JSONArray(prefs.getString(key,"[]"))
    private fun addPhotoRecord(key:String, category:String, uri:String){
        val a=photoArray(key)
        a.put(JSONObject().apply{put("category",category);put("uri",uri);put("time",System.currentTimeMillis())})
        prefs.edit().putString(key,a.toString()).apply()
    }
    private fun photoKey(owner:String,id:Long)="photos_${owner}_${id}"
    private fun choosePhoto(owner:String,id:Long,category:String){
        pendingPhotoKey=photoKey(owner,id); pendingPhotoCategory=category
        val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="image/*";putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);addCategory(Intent.CATEGORY_OPENABLE)}
        startActivityForResult(i,PHOTO_PICKER)
    }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){
        if(requestCode==8110 && resultCode==RESULT_OK){
            aiAttachedPhoto=data?.data
            aiChatHistory.add("ai" to "📷 Η φωτογραφία επισυνάφθηκε. Για την ώρα η offline μηχανή δεν κάνει οπτική αναγνώριση· γράψε model/code ή τι βλέπεις και συνεχίζω.")
            aiChatRefresh?.invoke()
            return
        }
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==BACKUP_EXPORT && resultCode==RESULT_OK && data?.data!=null){
            try {
                contentResolver.openOutputStream(data.data!!)?.use { it.write(backupJson().toString(2).toByteArray(Charsets.UTF_8)) }
                toast("Το backup αποθηκεύτηκε επιτυχώς.")
            } catch(e:Exception) { toast("Αποτυχία αποθήκευσης backup: ${e.message}") }
            return
        }
        if(requestCode==BACKUP_IMPORT && resultCode==RESULT_OK && data?.data!=null){
            try {
                val text=contentResolver.openInputStream(data.data!!)?.bufferedReader()?.use{it.readText()} ?: ""
                val root=JSONObject(text)
                val keys=listOf("customers","machines","jobs","notes","materials")
                val edit=prefs.edit()
                keys.forEach { k -> if(root.has(k)) edit.putString(k, root.getJSONArray(k).toString()) }
                edit.apply(); toast("Η επαναφορά ολοκληρώθηκε."); home()
            } catch(e:Exception) { toast("Μη έγκυρο backup JSON: ${e.message}") }
            return
        }
        if(requestCode==PHOTO_PICKER && resultCode==RESULT_OK && data!=null){
            val clip=data.clipData
            if(clip!=null){for(i in 0 until clip.itemCount)addPhotoRecord(pendingPhotoKey,pendingPhotoCategory,clip.getItemAt(i).uri.toString())}
            else data.data?.let{addPhotoRecord(pendingPhotoKey,pendingPhotoCategory,it.toString())}
            try{data.data?.let{contentResolver.takePersistableUriPermission(it,Intent.FLAG_GRANT_READ_URI_PERMISSION)}}catch(_:Exception){}
            toast("Η φωτογραφία προστέθηκε.")
            if(pendingPhotoKey.startsWith("photos_job_")) jobEditor(jobs().firstOrNull{it.id==pendingPhotoKey.substringAfterLast('_').toLongOrNull()})
            else if(pendingPhotoKey.startsWith("photos_machine_")) machineEditor(machines().firstOrNull{it.id==pendingPhotoKey.substringAfterLast('_').toLongOrNull()})
        }
    }
    private fun photoGallery(parent:LinearLayout,key:String){
        val a=photoArray(key)
        if(a.length()==0){parent.addView(card("📷 Δεν υπάρχουν φωτογραφίες ακόμη."));return}
        for(i in 0 until a.length()){
            val o=a.getJSONObject(i); val uri=Uri.parse(o.optString("uri")); val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
            row.addView(TextView(this).apply{text="📷 ${o.optString("category","Φωτογραφία")}";textSize=14f;setTextColor(blue);setPadding(0,8,0,4)})
            val image=ImageView(this).apply{layoutParams=LinearLayout.LayoutParams(-1,220);scaleType=ImageView.ScaleType.CENTER_CROP;try{setImageURI(uri)}catch(_:Exception){}}
            row.addView(image);parent.addView(row)
        }
    }
    private fun searchScreen(initial:String=""){
        val r=base();r.addView(title("🔎 Αναζήτηση"));val q=searchInput("🔎  Όνομα, τηλέφωνο, μοντέλο, Serial, κωδικός, εργασία, υλικό...");val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        fun render(){
            list.removeAllViews(); val term=q.text.toString().trim(); if(term.isBlank()){list.addView(card("Πληκτρολόγησε κάτι για αναζήτηση σε όλη την εφαρμογή."));return}
            customers().filter{"${it.name} ${it.phone} ${it.address} ${it.notes}".contains(term,true)}.forEach{list.addView(card("👤 ${it.name}\n📞 ${it.phone}\n📍 ${it.address}"){customerEditor(it)})}
            machines().filter{"${it.brand} ${it.model} ${it.serial} ${it.refrigerant} ${it.type} ${it.address} ${it.notes}".contains(term,true)}.forEach{list.addView(card("❄️ ${it.brand} ${it.model}\nSerial: ${it.serial}\nΨυκτικό: ${it.refrigerant}"){machineEditor(it)})}
            jobs().filter{"${it.date} ${it.type} ${it.symptom} ${it.faultCode} ${it.diagnosis} ${it.action} ${it.notes}".contains(term,true)}.forEach{list.addView(card("🛠️ ${it.date} • ${it.type}\n${it.symptom}\n${it.diagnosis}"){jobEditor(it)})}
            materialList().filter{"${it.name} ${it.code} ${it.notes}".contains(term,true)}.forEach{list.addView(card("📦 ${it.name}\nΚωδικός: ${it.code}\nΠοσότητα: ${it.qty}"){materialEditor(it)})}
            faults.filter{"${it.brand} ${it.code} ${it.meaning} ${it.causes} ${it.checks}".contains(term,true)}.forEach{list.addView(card("⚠️ ${it.brand} ${it.code}\n${it.meaning}"))}
            if(list.childCount==0)list.addView(card("Δεν βρέθηκαν αποτελέσματα."))
        }
        q.setOnKeyListener{_,_,_->render();false}; q.addTextChangedListener(object:android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){render()};override fun afterTextChanged(e:android.text.Editable?){}})
        r.addView(q);r.addView(scroll(list),LinearLayout.LayoutParams(-1,0,1f));r.addView(button("← Πίσω"){home()},
            LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,10,0,34)});setContentView(r)
        if(initial.isNotBlank()) q.setText(initial)
    }

    private fun customersScreen(){val r=base();r.addView(title("👥 Πελατολόγιο"));val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};val data=customers();if(data.isEmpty())list.addView(card("Δεν υπάρχουν πελάτες ακόμα."));data.forEach{c->list.addView(card("👤 ${c.name}\n📞 ${c.phone}\n📍 ${c.address}\n${c.notes}"){customerEditor(c)})};r.addView(scroll(list),LinearLayout.LayoutParams(-1,0,1f));r.addView(button("＋ Νέος πελάτης"){customerEditor(null)});r.addView(button("← Πίσω"){home()},
            LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,10,0,34)});setContentView(r)}
    private fun customerEditor(e:Customer?){
        val r=base()
        r.addView(title(if(e==null)"＋ Νέος πελάτης" else "✏️ Πελάτης"))
        val n=input("Όνομα / Επωνυμία")
        val p=input("Τηλέφωνο")
        val a=input("Διεύθυνση")
        val no=input("Σημειώσεις")
        val existingId=e?.id
        if(e!=null){n.setText(e.name);p.setText(e.phone);a.setText(e.address);no.setText(e.notes)}
        listOf(n,p,a,no).forEach{r.addView(it)}
        r.addView(button("💾 Αποθήκευση"){
            if(n.text.isBlank()){toast("Συμπλήρωσε όνομα.");return@button}
            val d=customers()
            val id=existingId?:System.currentTimeMillis()
            val x=Customer(id,n.text.toString().trim(),p.text.toString().trim(),a.text.toString().trim(),no.text.toString().trim())
            val i=d.indexOfFirst{it.id==id}
            if(i>=0)d[i]=x else d.add(x)
            saveCustomers(d);customersScreen()
        })
        if(existingId!=null){
            r.addView(button("🗑 Διαγραφή"){saveCustomers(customers().filter{it.id!=existingId});saveMachines(machines().filter{it.customerId!=existingId});customersScreen()})
            r.addView(button("❄️ Μηχανήματα πελάτη"){machinesScreen(existingId)})
        }
        r.addView(button("← Πίσω"){customersScreen()},
            LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,10,0,34)});setContentView(r)
    }

    private fun machinesScreen(customerId:Long?){val r=base();r.addView(title("❄️ Μηχανήματα"));val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};val all=machines().filter{customerId==null||it.customerId==customerId};if(all.isEmpty())list.addView(card("Δεν υπάρχουν μηχανήματα."));all.forEach{m->val c=customers().firstOrNull{it.id==m.customerId};list.addView(card("❄️ ${m.brand} ${m.model}\nSerial: ${m.serial}\nΨυκτικό: ${m.refrigerant} • ${m.capacity}\n👤 ${c?.name?:"Χωρίς πελάτη"}\n📍 ${m.address}"){machineEditor(m)})};r.addView(scroll(list),LinearLayout.LayoutParams(-1,0,1f));r.addView(button("＋ Νέο μηχάνημα"){machineEditor(null,customerId)});r.addView(button("← Πίσω"){if(customerId!=null)customersScreen() else home()},
            LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,10,0,34)});setContentView(r)}
    private fun machineEditor(e:Machine?, preCustomer:Long?=null){
        val r=base();r.addView(title(if(e==null)"＋ Νέο μηχάνημα" else "✏️ Μηχάνημα"))
        val c=input("Customer ID (προσωρινά)")
        val brand=input("Μάρκα")
        val model=input("Μοντέλο")
        val serial=input("Serial Number")
        val ref=input("Ψυκτικό μέσο")
        val cap=input("BTU / kW")
        val type=input("Τύπος μηχανήματος")
        val year=input("Έτος εγκατάστασης")
        val addr=input("Διεύθυνση εγκατάστασης")
        val no=input("Παρατηρήσεις")
        if(e!=null){c.setText(e.customerId.toString());brand.setText(e.brand);model.setText(e.model);serial.setText(e.serial);ref.setText(e.refrigerant);cap.setText(e.capacity);type.setText(e.type);year.setText(e.year);addr.setText(e.address);no.setText(e.notes)}else if(preCustomer!=null)c.setText(preCustomer.toString())
        listOf(c,brand,model,serial,ref,cap,type,year,addr,no).forEach{r.addView(it)}
        val id=e?.id?:System.currentTimeMillis()
        val existingId=e?.id
        r.addView(button("📷 Προσθήκη φωτογραφίας μηχανήματος"){choosePhoto("machine",id,"Μηχάνημα")})
        val gallery=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};photoGallery(gallery,photoKey("machine",id));r.addView(gallery)
        r.addView(button("💾 Αποθήκευση"){val cid=c.text.toString().toLongOrNull();if(cid==null){toast("Βάλε Customer ID. Από την καρτέλα πελάτη συμπληρώνεται αυτόματα.");return@button};val d=machines();val x=Machine(id,cid,brand.text.toString(),model.text.toString(),serial.text.toString(),ref.text.toString(),cap.text.toString(),type.text.toString(),year.text.toString(),addr.text.toString(),no.text.toString());val i=d.indexOfFirst{it.id==id};if(i>=0)d[i]=x else d.add(x);saveMachines(d);machineEditor(x)})
        if(existingId!=null){
            val customerId=e?.customerId ?: 0L
            r.addView(button("🛠️ Νέα εργασία"){jobEditor(null,customerId,existingId)})
            r.addView(button("📜 Ιστορικό μηχανήματος"){machineHistory(existingId)})
            r.addView(button("🗑 Διαγραφή"){saveMachines(machines().filter{it.id!=existingId});machinesScreen(preCustomer)})
        }
        r.addView(button("← Πίσω"){machinesScreen(preCustomer)},
            LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,10,0,34)});setContentView(r)
    }
    private fun machineHistory(mid:Long){val r=base();val m=machines().firstOrNull{it.id==mid};r.addView(title("📜 Ιστορικό μηχανήματος"));r.addView(card("${m?.brand} ${m?.model}\nSerial: ${m?.serial}\nΨυκτικό: ${m?.refrigerant}"));val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};jobs().filter{it.machineId==mid}.forEach{j->list.addView(card("${j.date} • ${j.type}\n${j.symptom}\n🔎 ${j.diagnosis}\n💶 ${j.total}"){jobEditor(j)})};r.addView(scroll(list),LinearLayout.LayoutParams(-1,0,1f));r.addView(button("＋ Νέα εργασία"){jobEditor(null,m?.customerId?:0L,mid)});r.addView(button("← Πίσω"){machineEditor(m)},
            LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,10,0,34)});setContentView(r)}

    private fun jobEditor(e:Job?, preCustomer:Long?=null, preMachine:Long?=null){
        val r=base();r.addView(title(if(e==null)"＋ Νέα εργασία" else "✏️ Εργασία"))
        fun f(h:String)=input(h)
        val cid=f("Customer ID")
        val mid=f("Machine ID")
        val date=f("Ημερομηνία / ώρα")
        val type=f("Είδος: Service / Επισκευή / Εγκατάσταση / Διάγνωση")
        val sym=f("Σύμπτωμα")
        val code=f("Κωδικός βλάβης")
        val diag=f("Διάγνωση")
        val action=f("Εργασία που έγινε")
        val suc=f("Πίεση αναρρόφησης")
        val dis=f("Πίεση κατάθλιψης")
        val st=f("Θερμοκρασία αναρρόφησης")
        val lt=f("Θερμοκρασία υγρού")
        val room=f("Θερμοκρασία χώρου")
        val out=f("Θερμοκρασία εξόδου")
        val sh=f("Superheat")
        val sc=f("Subcooling")
        val mat=f("Υλικά / ανταλλακτικά")
        val mc=f("Κόστος υλικών €")
        val lh=f("Ώρες εργατικών")
        val lr=f("Τιμή/ώρα €")
        val total=f("Σύνολο €")
        val notes=f("Σημειώσεις")
        if(e!=null){cid.setText(e.customerId.toString());mid.setText(e.machineId.toString());date.setText(e.date);type.setText(e.type);sym.setText(e.symptom);code.setText(e.faultCode);diag.setText(e.diagnosis);action.setText(e.action);suc.setText(e.suction);dis.setText(e.discharge);st.setText(e.suctionTemp);lt.setText(e.liquidTemp);room.setText(e.roomTemp);out.setText(e.outletTemp);sh.setText(e.superheat);sc.setText(e.subcooling);mat.setText(e.materials);mc.setText(e.materialCost);lh.setText(e.laborHours);lr.setText(e.laborRate);total.setText(e.total);notes.setText(e.notes)}else{preCustomer?.let{cid.setText(it.toString())};preMachine?.let{mid.setText(it.toString())}}
        listOf(cid,mid,date,type,sym,code,diag,action,suc,dis,st,lt,room,out,sh,sc,mat,mc,lh,lr,total,notes).forEach{r.addView(it)}
        val id=e?.id?:System.currentTimeMillis(); val key=photoKey("job",id)
        r.addView(button("📷 Φωτογραφία ΠΡΙΝ"){choosePhoto("job",id,"Πριν")});r.addView(button("📷 Φωτογραφία ΚΑΤΑ"){choosePhoto("job",id,"Κατά")});r.addView(button("📷 Φωτογραφία ΜΕΤΑ"){choosePhoto("job",id,"Μετά")})
        val gallery=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};photoGallery(gallery,key);r.addView(gallery)
        r.addView(button("📋 Checklist"){if(e==null){toast("Αποθήκευσε πρώτα την εργασία για να κρατηθεί το checklist.")}else checklistForJob(e.id)})
        r.addView(button("💾 Αποθήκευση"){val d=jobs();val x=Job(id,cid.text.toString().toLongOrNull()?:0L,mid.text.toString().toLongOrNull()?:0L,date.text.toString(),type.text.toString(),sym.text.toString(),code.text.toString(),diag.text.toString(),action.text.toString(),suc.text.toString(),dis.text.toString(),st.text.toString(),lt.text.toString(),room.text.toString(),out.text.toString(),sh.text.toString(),sc.text.toString(),mat.text.toString(),mc.text.toString(),lh.text.toString(),lr.text.toString(),total.text.toString(),"",photoArray(key).toString(),notes.text.toString(),e?.status?:"Εκκρεμεί");val i=d.indexOfFirst{it.id==id};if(i>=0)d[i]=x else d.add(x);saveJobs(d);toast("Η εργασία αποθηκεύτηκε.");if(x.machineId!=0L)machineHistory(x.machineId)else jobsScreen()});
        if(e!=null){r.addView(button(if(e.status=="Ολοκληρώθηκε")"↩ Εκκρεμής" else "✅ Ολοκληρώθηκε"){val d=jobs();val i=d.indexOfFirst{it.id==e.id};if(i>=0)d[i]=d[i].copy(status=if(e.status=="Ολοκληρώθηκε")"Εκκρεμεί" else "Ολοκληρώθηκε");saveJobs(d);jobEditor(d[i])});r.addView(button("🗑 Διαγραφή"){saveJobs(jobs().filter{it.id!=e.id});jobsScreen()})};r.addView(button("← Πίσω"){if(preMachine!=null)machineHistory(preMachine)else jobsScreen()},
            LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,10,0,34)});setContentView(r)
    }
    private fun jobsScreen(){val r=base();r.addView(title("📅 Εργασίες / Ιστορικό"));val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};jobs().sortedBy{it.status=="Ολοκληρώθηκε"}.forEach{j->val c=customers().firstOrNull{it.id==j.customerId};val m=machines().firstOrNull{it.id==j.machineId};list.addView(card("${if(j.status=="Ολοκληρώθηκε")"✅" else "🔧"} ${j.date} • ${j.type}\n👤 ${c?.name?:"Πελάτης #${j.customerId}"}\n❄️ ${m?.brand?:"Μηχάνημα"} ${m?.model?:""}\n${j.symptom}\n💶 ${j.total}"){jobEditor(j)})};r.addView(scroll(list),LinearLayout.LayoutParams(-1,0,1f));r.addView(button("＋ Νέα εργασία"){jobEditor(null)});r.addView(button("← Πίσω"){home()},
            LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,10,0,34)});setContentView(r)}

    private data class FaultCatalog(val brand:String,val types:List<String>,val logoRes:String)

    /*
     * ΒΛΑΒΟΛΟΓΙΟ 3.0
     * ΑΚΡΙΒΩΣ 3 ΒΗΜΑΤΑ:
     * 1) Μάρκα (μόνο logo + όνομα)
     * 2) Τύπος μηχανήματος
     * 3) Βλάβες του επιλεγμένου τύπου
     */
    private val faultCatalog = listOf(
        FaultCatalog("AUX", listOf("Split / Inverter","Multi-Split","Καναλάτο / Duct","Κασέτα","Floor / Ceiling","VRF / VRV","Αντλία θερμότητας"), "logo_aux"),
        FaultCatalog("Aermec", listOf("Split / Inverter","Multi-Split","VRF / VRV","Αντλία θερμότητας","Chiller / Ψύκτης","Υδρόψυκτα / Water-to-water","Fan Coil","Rooftop / AHU","Precision / Data Center"), "logo_aermec"),
        FaultCatalog("Airwell", listOf("Hi-Wall / Split","Κονσόλα","Καναλάτο / Built-in","Mobile / Φορητό","Αντλία θερμότητας Monobloc","Αντλία θερμότητας Split","ΖΝΧ / Θερμοδυναμικό boiler","Αερισμός / Hybrid dual flow"), "logo_airwell"),
        FaultCatalog("Ariston", listOf("Κλιματιστικά / Split","Αντλία θερμότητας αέρα-νερού","Αντλία θερμότητας ΖΝΧ","Fan Coil"), "logo_ariston"),
        FaultCatalog("Bosch", listOf("Split / Inverter","Multi-Split","VRF / VRV","Αντλία θερμότητας αέρα-νερού"), "logo_bosch"),
        FaultCatalog("Carrier", listOf("Split / Multi-Split","VRF / VRV","Chiller / Ψύκτης","Αντλία θερμότητας","Rooftop","AHU / Air Handler","Fan Coil","Precision Cooling"), "logo_carrier"),
        FaultCatalog("Climaveneta", listOf("Chiller / Ψύκτης","Αντλία θερμότητας","Precision / IT Cooling"), "logo_climaveneta"),
        FaultCatalog("Cooper&Hunter", listOf("Split / Inverter","Multi-Split","Καναλάτο / Duct","Κασέτα","Floor / Ceiling","Fan Coil","VRF / VRV"), "logo_cooper_hunter"),
        FaultCatalog("Daikin", listOf("Split / Inverter","Multi-Split","SkyAir / Επαγγελματικό","Καναλάτο","Κασέτα","VRV / VRF","Αντλία θερμότητας","Rooftop","Chiller / Ψύκτης","Αερισμός / HRV","Ψύξη / Refrigeration","Fan Coil / Hydronic","Boiler / Hybrid","Air Handling Unit / AHU","Air Purifier","Controls / BMS"), "logo_daikin"),
        FaultCatalog("Fujitsu", listOf("Split / Inverter","Multi-Split","Καναλάτο / Duct","Κασέτα","Floor / Ceiling","VRF / VRV","Αντλία θερμότητας αέρα-νερού","Αερισμός"), "logo_fujitsu"),
        FaultCatalog("General", listOf("Split / Inverter","Multi-Split","Καναλάτο / Duct","Κασέτα","Floor / Ceiling","VRF / VRV","Αντλία θερμότητας αέρα-νερού","Αερισμός"), "logo_general"),
        FaultCatalog("Gree", listOf("Split / Inverter","Multi-Split","Καναλάτο / Duct","Κασέτα","Floor / Ceiling / Console","VRF / GMV","Αντλία θερμότητας αέρα-νερού","Chiller / Ψύκτης","Packaged / Rooftop"), "logo_gree"),
        FaultCatalog("Haier", listOf("Split / Inverter","Multi-Split","Light Commercial / Duct-Cassette","VRF / MRV","Chiller / Ψύκτης","Αντλία θερμότητας αέρα-νερού"), "logo_haier"),
        FaultCatalog("Hisense", listOf("Split / RAC","Light Commercial / LCAC","VRF","Chiller / Ψύκτης","Αντλία θερμότητας / Hi-Therma"), "logo_hisense"),
        FaultCatalog("Hitachi", listOf("Split / Inverter","Multi-Split","Light Commercial / PAC","VRF / SET FREE","Chiller / Ψύκτης","Αντλία θερμότητας / Yutaki"), "logo_hitachi"),
        FaultCatalog("Inventor", listOf("Split / Inverter","Mobile / Φορητό","Multi-Split","Καναλάτο / Duct","Κασέτα","Floor / Ceiling","Κονσόλα","VRF","Αντλία θερμότητας αέρα-νερού","Fan Coil"), "logo_inventor"),
        FaultCatalog("Lennox", listOf("Rooftop","Chiller / Ψύκτης","Αντλία θερμότητας","AHU / Air Handling","Fan Coil"), "logo_lennox"),
        FaultCatalog("LG", listOf("Split / Inverter","Multi-Split","VRF / Multi V","Single Packaged / Rooftop","Chiller / Ψύκτης","Αντλία θερμότητας αέρα-νερού","ERV / Αερισμός","Water Heater"), "logo_lg"),
        FaultCatalog("Midea", listOf("Split / Inverter","Multi-Split","Καναλάτο","Κασέτα","VRF / VRV","Chiller / Ψύκτης","Αντλία θερμότητας"), "logo_midea"),
        FaultCatalog("Mitsubishi Electric", listOf("Split / Inverter","Multi-Split","Καναλάτο","Κασέτα","Επαγγελματικό / Mr Slim","VRF / VRV","Αντλία θερμότητας"), "logo_mitsubishi_electric"),
        FaultCatalog("Mitsubishi Heavy", listOf("Split / Residential","Packaged / Commercial","VRF / VRV","Αντλία θερμότητας / Hydrolution","Chiller / Ψύκτης"), "logo_mitsubishi_heavy"),
        FaultCatalog("Nordstar", listOf("Split / Inverter","Multi-Split"), "logo_nordstar"),
        FaultCatalog("Panasonic", listOf("Split / RAC","Multi-Split","PACi / Commercial","VRF / ECOi","Αντλία θερμότητας / Aquarea","Αερισμός / ERV"), "logo_panasonic"),
        FaultCatalog("Rhoss", listOf("Chiller / Ψύκτης","Αντλία θερμότητας","Rooftop","Fan Coil","AHU / Air Handling"), "logo_rhoss"),
        FaultCatalog("Rotenso", listOf("Split / Inverter","Multi-Split","Commercial / Duct-Cassette-Console","VRF","Αντλία θερμότητας Split","Αντλία θερμότητας All-in-Split","Αντλία θερμότητας Monobloc","Αερισμός / Recuperator"), "logo_rotenso"),
        FaultCatalog("Samsung", listOf("Split / RAC","Multi-Split","Commercial / CAC","VRF / DVM","Αντλία θερμότητας / EHS"), "logo_samsung"),
        FaultCatalog("Sharp", listOf("Split / Inverter"), "logo_sharp"),
        FaultCatalog("Sinclair", listOf("Split / Inverter","Multi-Split","Commercial / Duct-Cassette","VRF","Αντλία θερμότητας αέρα-νερού"), "logo_sinclair"),
        FaultCatalog("TCL", listOf("Split / Inverter","Mobile / Φορητό","Multi-Split / Free Match","Καναλάτο / Duct","Κασέτα","Κονσόλα","Floor / Ceiling","Αντλία θερμότητας Monobloc","Αντλία θερμότητας Split","Αντλία θερμότητας ΖΝΧ"), "logo_tcl"),
        FaultCatalog("Tesla", listOf("Split / Inverter","Multi-Split"), "logo_tesla"),
        FaultCatalog("Toshiba", listOf("Split / RAC","Multi-Split","Light Commercial / RAV","VRF / SMMS","Αντλία θερμότητας αέρα-νερού"), "logo_toshiba"),
        FaultCatalog("Toyotomi", listOf("Split / Residential","Multi-Split","Light Commercial / Duct-Cassette-Console-Floor Ceiling","Αντλία θερμότητας αέρα-νερού"), "logo_toyotomi"),
        FaultCatalog("Trane", listOf("Chiller / Ψύκτης","Αντλία θερμότητας","Rooftop","AHU / Air Handling"), "logo_trane"),
        FaultCatalog("Vaillant", listOf("Αντλία θερμότητας αέρα-νερού","Αντλία θερμότητας γεωθερμική"), "logo_vaillant"),
        FaultCatalog("Viessmann", listOf("Αντλία θερμότητας αέρα-νερού","Αντλία θερμότητας γεωθερμική"), "logo_viessmann"),
        FaultCatalog("York", listOf("Chiller / Ψύκτης","Αντλία θερμότητας","Rooftop","AHU / Air Handling"), "logo_york"),
        FaultCatalog("Pitsos", listOf("Split / Inverter"), "logo_pitsos"),
        FaultCatalog("Sendo", listOf("Split / Inverter","Multi-Split","Κασέτα","Καναλάτο / Duct","Floor / Ceiling","Αντλία θερμότητας"), "logo_sendo"),
        FaultCatalog("Morris", listOf("Split / Inverter","Κασέτα","Καναλάτο / Duct","Ντουλάπα / Floor Standing"), "logo_morris"),
        FaultCatalog("Juro-Pro", listOf("Split / Inverter"), "logo_juropro"),
        FaultCatalog("F&U", listOf("Split / Inverter"), "logo_fu"),
        FaultCatalog("United", listOf("Split / Inverter"), "logo_united"),
        FaultCatalog("Argo", listOf("Split / Inverter","Multi-Split","Κονσόλα","Καναλάτο / Duct","Mobile / Φορητό","Monobloc χωρίς εξωτερική","Αντλία θερμότητας αέρα-νερού","Fan Coil"), "logo_argo"),
        FaultCatalog("CIAT", listOf("Chiller / Ψύκτης","Αντλία θερμότητας","Fan Coil / Comfort Units","AHU / Air Handling","Rooftop / Packaged","Dry Cooler / Condenser","Precision / Close Control"), "logo_ciat"),
    ).sortedBy { it.brand.lowercase() }

    private fun topBar(screenTitle:String, back:()->Unit):LinearLayout = LinearLayout(this).apply {
        orientation=LinearLayout.HORIZONTAL
        gravity=Gravity.CENTER_VERTICAL
        addView(title(screenTitle), LinearLayout.LayoutParams(0,-2,1f))
    }

    private fun addedBrandOfficialPage(brand:String):String = when(brand){
        "Pitsos" -> "https://www.pitsos.gr/el/mkt-category-page/klimatistika"
        "Sendo" -> "https://www.sendo.gr/"
        "Morris" -> "https://morris.gr/klimatismos/"
        "Juro-Pro" -> "https://www.juropro.gr/products/klimatistika"
        "F&U" -> "https://www.fandu.gr/"
        "United" -> "https://www.united-electronics.gr/"
        "Argo" -> "https://www.argoclima.com/"
        "CIAT" -> "https://www.ciat.com/en/eu/products-systems/"
        else -> ""
    }

    private fun officialBrandDomain(brand:String):String = when(brand){
        "Daikin" -> "daikin.eu"
        "Mitsubishi Electric" -> "mitsubishielectric.com"
        "Midea" -> "midea.com"
        "Aermec" -> "aermec.com"
        "Airwell" -> "airwell.com"
        "AUX" -> "auxair.com"
        "Ariston" -> "ariston.com"
        "Bosch" -> "bosch-homecomfort.com"
        "Carrier" -> "carrier.com"
        "Climaveneta" -> "climaveneta.com"
        "Cooper&Hunter" -> "cooperandhunter.com"
        "Fujitsu" -> "fujitsu-general.com"
        "General" -> "general-hvac.com"
        "Gree" -> "gree.com"
        "Haier" -> "haierhvac.eu"
        "Hisense" -> "hisensehvac.com"
        "Hitachi" -> "hitachiaircon.com"
        "Inventor" -> "inventorairconditioner.com"
        "Lennox" -> "lennoxemea.com"
        "LG" -> "lg.com"
        "Mitsubishi Heavy" -> "mhi-mth.co.jp"
        "Nordstar" -> "nordstar.gr"
        "Panasonic" -> "aircon.panasonic.eu"
        "Rhoss" -> "rhoss.it"
        "Rotenso" -> "rotenso.com"
        "Samsung" -> "samsung.com"
        "Sharp" -> "sharpconsumer.eu"
        "Sinclair" -> "sinclair-solutions.com"
        "TCL" -> "tcl.com"
        "Tesla" -> "tesla.info"
        "Toshiba" -> "toshiba-aircon.co.uk"
        "Toyotomi" -> "toyotomi.eu"
        "Trane" -> "trane.eu"
        "Vaillant" -> "vaillant.com"
        "Viessmann" -> "viessmann.com"
        "York" -> "york.com"
        "Pitsos" -> "pitsos.gr"
        "Sendo" -> "sendo.gr"
        "Morris" -> "morris.gr"
        "Juro-Pro" -> "juropro.gr"
        "F&U" -> "fandu.gr"
        "United" -> "united-electronics.gr"
        "Argo" -> "argoclima.com"
        "CIAT" -> "ciat.com"
        else -> ""
    }

    private fun addedBrandLogo(brand:String,target:ImageView){
        val domain=officialBrandDomain(brand)
        if(domain.isBlank()) return
        val cacheFile=File(cacheDir,"brand_logo_v2_"+(brand.hashCode().toLong() and 0xffffffffL).toString(16)+".png")
        if(cacheFile.exists() && cacheFile.length()>500){
            try{BitmapFactory.decodeFile(cacheFile.absolutePath)?.let{target.setImageBitmap(it)}}catch(_:Exception){}
            return
        }
        Thread{
            try{
                val u="https://www.google.com/s2/favicons?domain="+domain+"&sz=256"
                val c=(URL(u).openConnection() as HttpURLConnection).apply{
                    connectTimeout=7000;readTimeout=10000;instanceFollowRedirects=true
                    setRequestProperty("User-Agent","Mozilla/5.0 (Android) Psyktikos/1.3")
                }
                if(c.responseCode !in 200..299){c.disconnect();return@Thread}
                val bytes=c.inputStream.use{it.readBytes()};c.disconnect()
                if(bytes.size<300) return@Thread
                val bmp=BitmapFactory.decodeByteArray(bytes,0,bytes.size) ?: return@Thread
                try{cacheFile.writeBytes(bytes)}catch(_:Exception){}
                runOnUiThread{target.setImageBitmap(bmp)}
            }catch(_:Exception){}
        }.start()
    }

    private fun logoCard(entry:FaultCatalog, action:()->Unit):LinearLayout = LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL
        gravity=Gravity.CENTER
        setPadding(10,8,10,8)
        background=GradientDrawable().apply{
            setColor(Color.WHITE)
            cornerRadius=22f
        }
        elevation=3f

        // These packaged/remote marks are symbols rather than a wordmark,
        // so the brand name is shown once below the symbol.
        val iconOnlyBrands=setOf("Pitsos","Sendo","Morris","United")

        // New brands without a packaged drawable: if their remote mark is a wordmark,
        // show the brand name itself as the single centered wordmark. This avoids blank cards
        // and also avoids showing the same name twice.
        val textFallbackBrands=setOf("Juro-Pro","F&U","Argo","CIAT")

        val localId=resources.getIdentifier(entry.logoRes,"drawable",packageName)

        if(textFallbackBrands.contains(entry.brand) && localId==0){
            addView(TextView(this@MainActivity).apply{
                text=entry.brand
                textSize=22f
                gravity=Gravity.CENTER
                typeface=uiFont(true)
                setTextColor(Color.rgb(20,20,20))
                includeFontPadding=false
            },LinearLayout.LayoutParams(-1,-1))
        }else{
            val image=ImageView(this@MainActivity).apply{
                adjustViewBounds=false
                scaleType=ImageView.ScaleType.FIT_CENTER
                val logoPad=when(entry.brand){
                    "Morris" -> 18
                    "Sendo" -> 12
                    "Pitsos" -> 12
                    "United" -> 12
                    else -> 8
                }
                setPadding(logoPad,logoPad,logoPad,logoPad)
                if(localId!=0) setImageResource(localId)
                else addedBrandLogo(entry.brand,this)
                contentDescription=entry.brand
            }

            if(iconOnlyBrands.contains(entry.brand)){
                val iconHeight=when(entry.brand){
                    "Morris" -> 96
                    "Sendo" -> 104
                    "Pitsos" -> 104
                    "United" -> 104
                    else -> 104
                }
                addView(image,LinearLayout.LayoutParams(-1,iconHeight))
                addView(TextView(this@MainActivity).apply{
                    text=entry.brand
                    textSize=22f
                    gravity=Gravity.CENTER
                    typeface=uiFont(true)
                    setTextColor(Color.rgb(20,20,20))
                    includeFontPadding=false
                    setPadding(2,0,2,2)
                },LinearLayout.LayoutParams(-1,46).apply{
                    gravity=Gravity.CENTER
                })
            }else{
                // Wordmark already contains the brand name: no second text label.
                addView(image,LinearLayout.LayoutParams(-1,-1))
            }
        }

        setOnClickListener{action()}
    }

    private fun faultsScreen(){
        val r=base()
        r.addView(topBar("⚠️ ΒΛΑΒΟΛΟΓΙΟ"){home()})
        r.addView(TextView(this).apply{
            text="Επίλεξε μάρκα"
            textSize=17f
            typeface=uiFont(true)
            setTextColor(Color.DKGRAY)
            setPadding(0,0,0,8)
        })

        val modelSearch=searchInput("🔎 Γράψε μοντέλο, π.χ. FTXM35, RXYQ, ERGA...")
        r.addView(modelSearch,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,8)})
        r.addView(button("ΑΝΑΖΗΤΗΣΗ ΜΟΝΤΕΛΟΥ"){
            val q=modelSearch.text.toString().trim()
            if(q.length<2) toast("Γράψε τουλάχιστον 2 χαρακτήρες από το μοντέλο.")
            else faultModelSearchResults(q)
        })
        modelSearch.setOnEditorActionListener{_,_,_->
            val q=modelSearch.text.toString().trim()
            if(q.length>=2) faultModelSearchResults(q)
            else toast("Γράψε τουλάχιστον 2 χαρακτήρες από το μοντέλο.")
            true
        }

        val grid=GridLayout(this).apply{
            columnCount=2
            useDefaultMargins=false
            alignmentMode=GridLayout.ALIGN_BOUNDS
        }
        faultCatalog.forEach{entry->
            val card=logoCard(entry){faultTypesScreen(entry.brand)}
            card.layoutParams=GridLayout.LayoutParams().apply{
                width=0
                height=170
                columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f)
                setMargins(6,6,6,6)
            }
            grid.addView(card)
        }
        r.addView(scroll(grid),LinearLayout.LayoutParams(-1,0,1f))
        setContentView(r)
    }

    private data class ModelHit(val brand:String,val type:String,val model:String)

    private fun allFaultModelHits():List<ModelHit>{
        val hits=mutableListOf<ModelHit>()
        daikinModels.forEach{(type,models)->models.forEach{hits.add(ModelHit("Daikin",type,it))}}
        faults.forEach{f->
            if(f.series.isNotBlank() && !f.series.equals("Γενικοί κωδικοί",true)){
                hits.add(ModelHit(f.brand,f.type,f.series))
            }
        }
        return hits.distinctBy{Triple(it.brand.lowercase(),it.type.lowercase(),it.model.lowercase())}
            .sortedWith(compareBy<ModelHit>{it.brand}.thenBy{it.type}.thenBy{it.model})
    }

    private fun faultModelSearchResults(query:String){
        val q=query.trim()
        val normalized=q.uppercase().replace(" ","").replace("-","").replace("/","")
        val matches=allFaultModelHits().filter{hit->
            val hay=(hit.brand+" "+hit.type+" "+hit.model).uppercase()
            val compact=hay.replace(" ","").replace("-","").replace("/","")
            hay.contains(q.uppercase()) || compact.contains(normalized)
        }.take(100)

        val r=base()
        r.addView(topBar("🔎 Μοντέλο: $q"){faultsScreen()})
        val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        if(matches.isEmpty()){
            list.addView(card("Δεν βρέθηκε μοντέλο για «$q».\\nΔοκίμασε μέρος του κωδικού, π.χ. FTXM, RXY, ERGA, FCAG."))
        }else{
            list.addView(TextView(this).apply{
                text="Βρέθηκαν ${matches.size} αποτελέσματα"
                textSize=16f
                typeface=uiFont(true)
                setTextColor(Color.DKGRAY)
                setPadding(4,4,4,10)
            })
            matches.forEach{hit->
                list.addView(card("❄️ ${hit.brand}\\n${hit.model}\\n${hit.type}"){
                    faultListScreen(hit.brand,hit.type,hit.model)
                })
            }
        }
        r.addView(scroll(list),LinearLayout.LayoutParams(-1,0,1f))
        setContentView(r)
    }

    private fun faultTypeIconRes(type:String):Int{
        val name=when{
            type.contains("Split",true) && !type.contains("Multi",true) -> "type_split"
            type.contains("Multi",true) -> "type_multi"
            type.contains("SkyAir",true) || type.contains("Επαγγελματικό",true) -> "type_skyair"
            type.contains("Καναλάτο",true) -> "type_ducted"
            type.contains("Κασέτα",true) -> "type_cassette"
            type.contains("VRV",true) || type.contains("VRF",true) -> "type_vrv"
            type.contains("Αντλία",true) -> "type_heatpump"
            type.contains("Rooftop",true) -> "type_rooftop"
            type.contains("Chiller",true) || type.contains("Ψύκτης",true) -> "type_chiller"
            type.contains("Αερισμός",true) || type.contains("HRV",true) -> "type_hrv"
            type.contains("Ψύξη",true) || type.contains("Refrigeration",true) -> "type_refrigeration"
            else -> "type_generic"
        }
        return resources.getIdentifier(name,"drawable",packageName)
    }

    private fun faultTypeCard(type:String,action:()->Unit):LinearLayout = LinearLayout(this).apply{
        orientation=LinearLayout.HORIZONTAL
        gravity=Gravity.CENTER_VERTICAL
        setPadding(14,12,16,12)
        background=GradientDrawable().apply{
            setColor(Color.WHITE)
            cornerRadius=24f
            setStroke(2,Color.rgb(220,230,238))
        }
        elevation=3f

        addView(ImageView(this@MainActivity).apply{
            val id=faultTypeIconRes(type)
            if(id!=0) setImageResource(id)
            scaleType=ImageView.ScaleType.CENTER_INSIDE
            adjustViewBounds=true
            contentDescription=type
        },LinearLayout.LayoutParams(96,82).apply{setMargins(0,0,14,0)})

        addView(TextView(this@MainActivity).apply{
            text=type
            textSize=18f
            typeface=uiFont(true)
            setTextColor(Color.rgb(25,25,25))
            gravity=Gravity.CENTER_VERTICAL
        },LinearLayout.LayoutParams(0,-2,1f))

        setOnClickListener{action()}
    }



    private fun hmtBlueGradient():GradientDrawable=GradientDrawable(
        GradientDrawable.Orientation.LEFT_RIGHT,
        intArrayOf(Color.rgb(0,45,103),Color.rgb(0,112,190))
    ).apply{cornerRadius=26f}

    private fun hmtChip(textValue:String):TextView=TextView(this).apply{
        text=textValue
        textSize=11f
        typeface=uiFont(true)
        setTextColor(Color.rgb(0,75,155))
        gravity=Gravity.CENTER
        setPadding(12,6,12,6)
        background=GradientDrawable().apply{
            setColor(Color.rgb(236,246,255))
            cornerRadius=22f
            setStroke(1,Color.rgb(180,215,240))
        }
    }

    private fun hmtCategoryIcon(type:String):String=when{
        type.contains("Split",true)->"❄️"
        type.contains("Multi",true)->"🧊"
        type.contains("Sky",true)->"🏢"
        type.contains("Καναλ",true)->"▰"
        type.contains("Κασ",true)->"▦"
        type.contains("VRV",true)->"♨️"
        type.contains("θερμό",true)->"🔥"
        type.contains("Rooftop",true)->"🏭"
        type.contains("Chiller",true)->"💧"
        type.contains("Αερισ",true)->"🌬️"
        type.contains("Refriger",true)->"🧊"
        type.contains("Fan Coil",true)->"💨"
        type.contains("Boiler",true)->"🔥"
        type.contains("AHU",true)->"🏗️"
        type.contains("Purifier",true)->"✨"
        type.contains("Control",true)->"🎛️"
        else->"🔧"
    }

    private fun hmtCategoryCard(type:String,count:Int,action:()->Unit):LinearLayout=LinearLayout(this).apply{
        orientation=LinearLayout.VERTICAL
        gravity=Gravity.CENTER
        setPadding(10,12,10,12)
        background=GradientDrawable().apply{
            setColor(Color.WHITE);cornerRadius=24f;setStroke(2,Color.rgb(225,232,240))
        }
        elevation=4f
        addView(TextView(this@MainActivity).apply{
            text=hmtCategoryIcon(type);textSize=34f;gravity=Gravity.CENTER
        },LinearLayout.LayoutParams(-1,52))
        addView(TextView(this@MainActivity).apply{
            text=type;textSize=13f;typeface=uiFont(true);gravity=Gravity.CENTER
            setTextColor(Color.rgb(12,55,105));maxLines=2
        },LinearLayout.LayoutParams(-1,-2))
        addView(TextView(this@MainActivity).apply{
            text="$count σειρές";textSize=10.5f;gravity=Gravity.CENTER
            setTextColor(Color.rgb(0,112,190));setPadding(0,5,0,0)
        })
        setOnClickListener{action()}
    }



    private fun daikinCategoryPhotoRes(type:String):Int{
        val name=when{
            type.contains("Split",true) && !type.contains("Multi",true) -> "daikin_img_split"
            type.contains("Multi",true) -> "daikin_img_multi"
            type.contains("Sky",true) -> "daikin_img_skyair"
            type.contains("VRV",true) -> "daikin_img_vrv"
            type.contains("θερμό",true) -> "daikin_img_heatpump"
            type.contains("Κασ",true) -> "daikin_img_cassette"
            type.contains("Καναλ",true) -> "daikin_img_ducted"
            type.contains("Rooftop",true) -> "daikin_img_rooftop"
            type.contains("Chiller",true) -> "daikin_img_skyair"
            type.contains("Αερισ",true) -> "daikin_img_ducted"
            type.contains("Refriger",true) -> "daikin_img_rooftop"
            type.contains("Fan Coil",true) -> "daikin_img_heatpump"
            type.contains("Boiler",true) -> "daikin_img_heatpump"
            type.contains("AHU",true) -> "daikin_img_ducted"
            type.contains("Purifier",true) -> "daikin_img_split"
            type.contains("Control",true) -> "daikin_img_brc1h"
            else -> "daikin_img_skyair"
        }
        return resources.getIdentifier(name,"drawable",packageName)
    }

    private fun daikinOfficialPageCandidates(model:String):List<String>{
        fun product(slug:String):String {
            val enc=slug.trim().replace(" ","-").replace("/","-")
            return "https://www.daikin.eu/en_us/products/product.html/${enc}.html"
        }

        val m=model.trim()
        val upper=m.uppercase()
        val out=mutableListOf<String>()

        val explicit=when{
            upper.contains("EPSK") && upper.contains("EPSX") -> listOf("EPSX14A---EPSK12-14AW1")
            upper.contains("EPSK") && upper.contains("EPVX") -> listOf("EPVX14A4V---EPSK12-14AW1")
            upper.contains("EPSK") && upper.contains("EPBX") -> listOf("EPBX14A4V---EPSK12-14AW1")
            upper.contains("URURU SARARA") -> listOf("FTXZ-N---RXZ-N","FTXZ-N")
            upper.contains("COMFORA") && upper.contains("FTXP-N") -> listOf("FTXP-N9","FTXP-N")
            upper.contains("SENSIRA") && upper.contains("FTXF-F") -> listOf("FTXF-F")
            upper.contains("SENSIRA") && upper.contains("FTXC-E") -> listOf("FTXC-E")
            upper.contains("FLOOR STANDING") && upper.contains("FVXM-B") -> listOf("FVXM-B")
            upper.contains("2MXM") -> listOf("2MXM-A")
            upper.contains("3MXM") -> listOf("3MXM-A")
            upper.contains("4MXM") -> listOf("4MXM-A")
            upper.contains("5MXM") -> listOf("5MXM-A")
            upper.contains("DAIKIN EMURA") -> listOf("FTXJ-AW","FTXJ-AS","FTXJ-AB")
            upper.contains("STYLISH") && upper.contains("FTXA-D") -> listOf("FTXA-DG","FTXA-DP","FTXA-DL","FTXA-DC","FTXA-DY")
            upper.contains("STYLISH") && upper.contains("FTXA-C") -> listOf("FTXA-CW","FTXA-CS","FTXA-CB")
            upper.contains("NEPURA STYLISH") && upper.contains("FTXTA-D") -> listOf("FTXTA-DG","FTXTA-DL","FTXTA-DP","FTXTA-DY")
            upper.contains("NEPURA STYLISH") && upper.contains("FTXTA-C") -> listOf("FTXTA-CW","FTXTA-CB")
            upper.contains("ALTHERMA HPC FLOOR") -> listOf("FWXV-ATV3")
            upper.contains("ALTHERMA HPC WALL") -> listOf("FWXT-ATV3")
            upper.contains("ALTHERMA HPC CONCEALED") -> listOf("FWXM-ATV3")
            upper=="COMPACT L" -> listOf("Compact-L")
            upper=="COMPACT T" -> listOf("Compact-T")
            upper.contains("PROFESSIONAL AHU") -> listOf("Professional")
            upper.contains("MODULAR P") -> listOf("Modular-P")
            upper.contains("MODULAR R") -> listOf("Modular-R")
            upper.contains("MADOKA PLUS") -> listOf("BRC1H52W","BRC1H52S","BRC1H52K","BRC1H")
            upper.contains("MADOKA") || upper.contains("BRC1H") -> listOf("BRC1H52W","BRC1H52S","BRC1H52K","BRC1H")
            upper.contains("INTELLIGENT TOUCH MANAGER") -> listOf("DCM601A51","DCM601B51")
            upper.contains("KRP2A") || upper.contains("KRP4A") -> listOf("KRP2A51","KRP2A52","KRP2A53","KRP2A61","KRP2A62","KRP4A")
            upper.contains("CO₂ ZEAS") || upper.contains("CO2 ZEAS") -> listOf("LREN-A")
            upper.contains("R-410A ZEAS") -> listOf("LREQ-BY1")
            upper.contains("CO₂ CONVENI-PACK") || upper.contains("CO2 CONVENI-PACK") -> listOf("LRYEN-AY1")
            upper.contains("R-410A CONVENI-PACK") -> listOf("LRYEQ-AY1","LRYEQ-AY")
            else -> emptyList()
        }
        explicit.forEach{out.add(product(it))}

        var codePart=if(m.contains("•")) m.substringAfter("•").trim() else m
        codePart=codePart.substringBefore("+").trim()
        if(codePart.startsWith("C/",true)) codePart=codePart.substring(2)

        val rawVariants=mutableListOf<String>()
        rawVariants.add(codePart)

        if(codePart.contains("/")){
            val parts=codePart.split("/").map{it.trim()}.filter{it.isNotBlank()}
            if(parts.isNotEmpty()){
                val first=parts.first()
                rawVariants.add(first)
                val prefixMatch=Regex("""^(.+?-)([A-Z])([A-Z0-9()]+)$""").find(first)
                if(prefixMatch!=null){
                    val base=prefixMatch.groupValues[1]+prefixMatch.groupValues[2]
                    parts.drop(1).forEach{suffix->rawVariants.add(base+suffix)}
                }
                val firstPrefix=Regex("""^([A-Z]+)""").find(first)?.value
                parts.drop(1).forEach{part->
                    if(part.matches(Regex("""[A-Z]{2,}.*"""))) rawVariants.add(part)
                    else if(firstPrefix!=null) rawVariants.add(firstPrefix+part)
                }
            }
        }

        val expanded=mutableListOf<String>()
        rawVariants.forEach{v0->
            val v=v0.trim().trim(',', ';')
            if(v.isBlank()) return@forEach
            expanded.add(v)
            expanded.add(v.replace("(1)","").replace("(9)","9"))
            expanded.add(v.replace("(1)","").replace("(9)",""))
            expanded.add(v.replace(" ","-"))
            Regex("""^([0-9]?[A-Z]{2,})(?:[0-9]+(?:-[0-9]+)?)(A[0-9])$""").find(v)?.let{
                expanded.add(it.groupValues[1]+"-"+it.groupValues[2])
            }
            Regex("""^([A-Z0-9]+-[A-Z]+?)[VY][0-9]$""").find(v)?.let{expanded.add(it.groupValues[1])}
            Regex("""^([A-Z0-9]+-E)[VW][0-9]$""").find(v)?.let{expanded.add(it.groupValues[1])}
        }

        expanded.distinct().forEach{candidate->
            if(candidate.length>=4) out.add(product(candidate))
        }

        return out.distinct()
    }

    private fun daikinVerificationKeys(model:String):List<String>{
        val u=model.uppercase()
        val keys=mutableListOf<String>()
        Regex("""[0-9]?[A-Z]{2,}[A-Z0-9]*(?:-[A-Z0-9()]+)+""").findAll(u).forEach{
            val v=it.value.substringBefore("/")
            keys.add(v)
            val family=Regex("""^([0-9]?[A-Z]{2,})""").find(v)?.groupValues?.get(1)
            if(family!=null && family.length>=3) keys.add(family)
            val prefix=v.takeWhile{c->c.isLetterOrDigit()}
            if(prefix.length>=4) keys.add(prefix)
        }
        Regex("""\b(?:BR|DCM|KRP|DTA|BPMKS)[A-Z0-9-]{4,}\b""").findAll(u).forEach{keys.add(it.value)}
        if(keys.isEmpty()){
            u.split(" ","•","/","+").filter{it.length>=5 && it.any(Char::isLetter)}.forEach{keys.add(it)}
        }
        return keys.distinct()
    }

    private fun daikinBundledVerifiedPhotoRes(model:String):Int{
        val m=model.uppercase()
        val name=when{
            m.contains("EPSK") -> "daikin_img_epsk"
            m.contains("EPRA") -> "daikin_img_epra"
            m.contains("ERGA") -> "daikin_img_erga"
            m.contains("ERRA") -> "daikin_img_erra"
            m.contains("ERLA") -> "daikin_img_erla"
            m.contains("EBLA") || m.contains("EDLA") -> "daikin_img_ebla"
            m.contains("EVLQ") || m.contains("EJHA") || m.contains("HYBRID") -> "daikin_img_hybrid"
            m.contains("EGSA") || m.contains("EWSA") || m.contains("GEO") || m.contains("3 WS") -> "daikin_img_geo"
            else -> ""
        }
        return if(name.isBlank()) 0 else resources.getIdentifier(name,"drawable",packageName)
    }

    private fun normalizeProductPhotoSize(src:Bitmap):Bitmap{
        // Display-only normalization: keep the SAME photo, only remove excessive
        // white/transparent outer margins so every product fills its card similarly.
        if(src.width < 24 || src.height < 24) return src
        val step=maxOf(1,minOf(src.width,src.height)/300)
        var left=src.width; var right=-1; var top=src.height; var bottom=-1
        var y=0
        while(y<src.height){
            var x=0
            while(x<src.width){
                val c=src.getPixel(x,y)
                val a=Color.alpha(c)
                val r=Color.red(c); val g=Color.green(c); val b=Color.blue(c)
                // Treat only almost-pure white / transparent pixels as outer margin.
                // Off-white/gray product surfaces remain part of the machine.
                val outer = a < 16 || (r>=250 && g>=250 && b>=250)
                if(!outer){
                    if(x<left) left=x
                    if(x>right) right=x
                    if(y<top) top=y
                    if(y>bottom) bottom=y
                }
                x+=step
            }
            y+=step
        }
        if(right<=left || bottom<=top) return src
        val bw=right-left+1; val bh=bottom-top+1
        val fillW=bw.toFloat()/src.width.toFloat()
        val fillH=bh.toFloat()/src.height.toFloat()
        // Photos that already fill the frame remain pixel-for-pixel unchanged.
        if(fillW>=0.86f && fillH>=0.72f) return src
        val padX=maxOf(2,(bw*0.055f).toInt())
        val padY=maxOf(2,(bh*0.055f).toInt())
        val l=maxOf(0,left-padX); val t=maxOf(0,top-padY)
        val rr=minOf(src.width-1,right+padX); val bb=minOf(src.height-1,bottom+padY)
        return try{Bitmap.createBitmap(src,l,t,rr-l+1,bb-t+1)}catch(_:Exception){src}
    }

    private fun setNormalizedProductDrawable(view:ImageView,resId:Int){
        if(resId==0) return
        try{
            val bmp=BitmapFactory.decodeResource(resources,resId)
            if(bmp!=null) view.setImageBitmap(normalizeProductPhotoSize(bmp)) else view.setImageResource(resId)
        }catch(_:Exception){view.setImageResource(resId)}
    }

    private fun daikinRemotePhoto(type:String,model:String,height:Int):ImageView=ImageView(this).apply{
        scaleType=ImageView.ScaleType.CENTER_INSIDE
        adjustViewBounds=true
        setPadding(2,2,2,2)
        background=GradientDrawable().apply{
            setColor(Color.WHITE);cornerRadius=18f;setStroke(1,Color.rgb(232,236,241))
        }
        clipToOutline=true
        contentDescription="Επίσημη φωτογραφία Daikin για $model"
        val bundled=daikinBundledVerifiedPhotoRes(model)
        if(bundled!=0){
            setNormalizedProductDrawable(this,bundled)
            contentDescription="Επαληθευμένη φωτογραφία Daikin • $model"
            return@apply
        }

        val placeholder=daikinCategoryPhotoRes(type)
        if(placeholder!=0){
            setNormalizedProductDrawable(this,placeholder)
            contentDescription="Daikin • $type • $model"
        }

        val target=this
        val cacheName="daikin_v4_"+(model.hashCode().toLong() and 0xffffffffL).toString(16)+".jpg"
        val cacheFile=File(cacheDir,cacheName)
        if(cacheFile.exists() && cacheFile.length()>1000){
            try{
                BitmapFactory.decodeFile(cacheFile.absolutePath)?.let{setImageBitmap(normalizeProductPhotoSize(it))}
            }catch(_:Exception){}
        }else{
            Thread{
                val pages=daikinOfficialPageCandidates(model)
                val verify=daikinVerificationKeys(model)
                for(page in pages){
                    try{
                        val conn=(URL(page).openConnection() as HttpURLConnection).apply{
                            connectTimeout=7000;readTimeout=9000
                            instanceFollowRedirects=true
                            setRequestProperty("User-Agent","Mozilla/5.0 (Android) Psyktikos/1.3")
                            setRequestProperty("Accept-Language","en-US,en;q=0.9")
                        }
                        if(conn.responseCode !in 200..299){conn.disconnect();continue}
                        val html=conn.inputStream.bufferedReader().use{it.readText()}
                            .replace("\\/","/")
                            .replace("&amp;","&")
                        conn.disconnect()

                        if(verify.isNotEmpty() && verify.none{html.contains(it,true)}) continue

                        // Keep already cached/working model photos untouched.
                        // For models still missing a photo, accept only an image published
                        // on the verified official Daikin product page.
                        val imageCandidates=linkedSetOf<String>()

                        Regex("""(?i)(https?://www\.daikin\.eu/content/dam/[^"'<>\\\s]+\.(?:jpg|jpeg|png|webp))""")
                            .findAll(html).forEach{imageCandidates.add(it.groupValues[1])}

                        Regex("""(?i)(/content/dam/[^"'<>\\\s]+\.(?:jpg|jpeg|png|webp))""")
                            .findAll(html).forEach{imageCandidates.add("https://www.daikin.eu"+it.groupValues[1])}

                        Regex("""(?i)<meta[^>]+(?:property|name)=["'](?:og:image|twitter:image)["'][^>]+content=["']([^"']+)["']""")
                            .findAll(html).forEach{
                                val u=it.groupValues[1].replace("&amp;","&")
                                if(u.contains("daikin",true) || u.startsWith("/content/dam/"))
                                    imageCandidates.add(if(u.startsWith("http")) u else "https://www.daikin.eu"+u)
                            }

                        val preferred=imageCandidates.sortedByDescending{u->
                            var score=0
                            if(u.contains("Packshot",true)) score+=100
                            if(u.contains("/MDM/Pictures/",true)) score+=50
                            if(u.contains("product",true)) score+=20
                            if(u.contains("logo",true) || u.contains("icon",true) || u.contains("banner",true)) score-=100
                            score
                        }
                        if(preferred.isEmpty()) continue

                        val imgUrl=preferred.first()
                        val imgConn=(URL(imgUrl).openConnection() as HttpURLConnection).apply{
                            connectTimeout=7000;readTimeout=12000
                            instanceFollowRedirects=true
                            setRequestProperty("User-Agent","Mozilla/5.0 (Android) Psyktikos/1.3")
                        }
                        if(imgConn.responseCode !in 200..299){imgConn.disconnect();continue}
                        val bytes=imgConn.inputStream.use{it.readBytes()}
                        imgConn.disconnect()
                        if(bytes.size<1000) continue
                        val bmp=BitmapFactory.decodeByteArray(bytes,0,bytes.size) ?: continue
                        try{cacheFile.writeBytes(bytes)}catch(_:Exception){}
                        runOnUiThread{
                            target.setImageBitmap(normalizeProductPhotoSize(bmp))
                            target.contentDescription="Επίσημη φωτογραφία Daikin • $model"
                        }
                        break
                    }catch(_:Exception){}
                }
            }.start()
        }
    }


    private fun hmtPhoto(resId:Int,height:Int):ImageView=ImageView(this).apply{
        scaleType=ImageView.ScaleType.CENTER_INSIDE
        adjustViewBounds=true
        setPadding(10,10,10,10)
        background=GradientDrawable().apply{
            setColor(Color.WHITE)
            cornerRadius=18f
            setStroke(1,Color.rgb(232,236,241))
        }
        clipToOutline=true

        if(resId!=0){
            setImageResource(resId)
            contentDescription="Φωτογραφία μοντέλου"
        }else{
            // Deliberately blank instead of an incorrect product image.
            setImageDrawable(null)
            contentDescription="Δεν έχει περαστεί ακόμη επαληθευμένη φωτογραφία για αυτό το μοντέλο"
        }
    }


    private fun hmtModelHero(brand:String,type:String,series:String):LinearLayout=LinearLayout(this).apply{
        orientation=LinearLayout.VERTICAL
        setPadding(14,12,14,14)
        background=hmtBlueGradient()
        elevation=7f

        if(brand.equals("Daikin",true)){
            addView(daikinRemotePhoto(type,series,320),LinearLayout.LayoutParams(-1,320).apply{setMargins(0,0,0,10)})
        }else if(brand.equals("Mitsubishi Electric",true)){
            addView(mitsubishiRemotePhoto(type,series,320),LinearLayout.LayoutParams(-1,320).apply{setMargins(0,0,0,10)})
        }
        addView(TextView(this@MainActivity).apply{
            text=series
            textSize=22f
            typeface=uiFont(true)
            setTextColor(Color.WHITE)
        })
        addView(TextView(this@MainActivity).apply{
            text="$brand • $type"
            textSize=12.5f
            setTextColor(Color.rgb(220,239,252))
            setPadding(0,3,0,0)
        })
        addView(LinearLayout(this@MainActivity).apply{
            orientation=LinearLayout.HORIZONTAL
            setPadding(0,10,0,0)
            addView(hmtChip("Service Data"),LinearLayout.LayoutParams(-2,-2).apply{setMargins(0,0,6,0)})
            addView(hmtChip(if(type.contains("θερμό",true)) "R32 / Heating" else "HVAC"))
        })
    }

    private fun proSectionHeader(titleText:String,subtitle:String=""):LinearLayout=LinearLayout(this).apply{
        orientation=LinearLayout.VERTICAL
        setPadding(16,14,16,14)
        background=GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(Color.rgb(0,45,103),Color.rgb(0,111,190))
        ).apply{cornerRadius=26f}
        elevation=6f
        addView(TextView(this@MainActivity).apply{
            text=titleText
            textSize=22f
            typeface=uiFont(true)
            setTextColor(Color.WHITE)
        })
        if(subtitle.isNotBlank()) addView(TextView(this@MainActivity).apply{
            text=subtitle
            textSize=12.5f
            setTextColor(Color.rgb(224,240,252))
            setPadding(0,4,0,0)
        })
    }

    private fun proModelCard(model:String,count:Int,action:()->Unit):LinearLayout=LinearLayout(this).apply{
        orientation=LinearLayout.HORIZONTAL
        gravity=Gravity.CENTER_VERTICAL
        setPadding(14,12,14,12)
        background=GradientDrawable().apply{
            setColor(Color.WHITE)
            cornerRadius=22f
            setStroke(2,Color.rgb(222,230,238))
        }
        elevation=3f

        addView(TextView(this@MainActivity).apply{
            text="❄"
            textSize=26f
            gravity=Gravity.CENTER
            setTextColor(Color.rgb(0,112,190))
        },LinearLayout.LayoutParams(52,58))

        addView(LinearLayout(this@MainActivity).apply{
            orientation=LinearLayout.VERTICAL
            addView(TextView(this@MainActivity).apply{
                text=model
                textSize=16f
                typeface=uiFont(true)
                setTextColor(Color.rgb(16,47,88))
                maxLines=3
            })
            addView(TextView(this@MainActivity).apply{
                text="$count βλάβες / κωδικοί"
                textSize=11.5f
                setTextColor(Color.rgb(95,105,118))
                setPadding(0,3,0,0)
            })
        },LinearLayout.LayoutParams(0,-2,1f))

        addView(TextView(this@MainActivity).apply{
            text="›"
            textSize=30f
            gravity=Gravity.CENTER
            setTextColor(Color.rgb(0,112,190))
        },LinearLayout.LayoutParams(42,58))
        setOnClickListener{action()}
    }

    private fun proFaultCard(f:Fault,description:String,action:()->Unit):LinearLayout=LinearLayout(this).apply{
        orientation=LinearLayout.VERTICAL
        setPadding(14,12,14,12)
        background=GradientDrawable().apply{
            setColor(Color.WHITE)
            cornerRadius=22f
            setStroke(2,Color.rgb(226,232,239))
        }
        elevation=3f
        addView(LinearLayout(this@MainActivity).apply{
            orientation=LinearLayout.HORIZONTAL
            gravity=Gravity.CENTER_VERTICAL
            addView(TextView(this@MainActivity).apply{
                text="●"
                textSize=16f
                setTextColor(Color.rgb(235,72,72))
            },LinearLayout.LayoutParams(30,-2))
            addView(TextView(this@MainActivity).apply{
                text=f.code
                textSize=18f
                typeface=uiFont(true)
                setTextColor(Color.rgb(0,75,155))
            },LinearLayout.LayoutParams(0,-2,1f))
            addView(TextView(this@MainActivity).apply{
                text="›"
                textSize=26f
                setTextColor(Color.rgb(0,112,190))
            })
        })
        addView(TextView(this@MainActivity).apply{
            text=description
            textSize=14f
            typeface=uiFont(true)
            setTextColor(Color.rgb(45,45,45))
            setPadding(30,4,4,0)
        })
        setOnClickListener{action()}
    }


    private fun daikinGlobalFaultSearch(query:String){
        val term=query.trim()
        val r=base()
        r.addView(proSectionHeader(
            "🔎 Αναζήτηση βλάβης",
            "Daikin • κωδικός, περιγραφή, αιτία ή σύμπτωμα"
        ),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,8)})

        val q=searchInput("π.χ. U0, U4, δεν ψύχει, υψηλή πίεση...")
        q.setText(term)
        q.background=GradientDrawable().apply{
            setColor(Color.WHITE);cornerRadius=24f;setStroke(2,Color.rgb(210,222,234))
        }
        q.setTextColor(Color.rgb(20,34,48))
        q.setHintTextColor(Color.rgb(105,120,135))
        val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}

        fun render(){
            list.removeAllViews()
            val txt=q.text.toString().trim()
            if(txt.isBlank()){
                list.addView(card("Γράψε κωδικό ή σύμπτωμα."))
                return
            }

            val normalized=txt.uppercase().replace(" ","")
            val modelFaults=mutableListOf<Triple<String,String,Fault>>()

            daikinModels.forEach{(type,models)->
                models.distinct().forEach{model->
                    daikinGeneratedFaults(type,model).forEach{f->
                        val hay="${f.code} ${f.symptom} ${f.meaning} ${f.causes} ${f.checks}".uppercase()
                        val codeCompact=f.code.uppercase().replace(" ","")
                        if(
                            hay.contains(txt.uppercase()) ||
                            codeCompact==normalized ||
                            codeCompact.startsWith(normalized)
                        ){
                            modelFaults.add(Triple(type,model,f))
                        }
                    }
                }
            }

            // Also include older Daikin entries already in the main database.
            faults.filter{brandMatches(it,"Daikin")}.forEach{f->
                val hay="${f.code} ${f.symptom} ${f.meaning} ${f.causes} ${f.checks}".uppercase()
                val codeCompact=f.code.uppercase().replace(" ","")
                if(hay.contains(txt.uppercase()) || codeCompact==normalized || codeCompact.startsWith(normalized)){
                    modelFaults.add(Triple(inferredType(f),f.series,f))
                }
            }

            val unique=modelFaults.distinctBy{Triple(it.first,it.second,it.third.code)}
            if(unique.isEmpty()){
                list.addView(card("Δεν βρέθηκε βλάβη για «$txt»."))
            }else{
                val grouped=unique.groupBy{it.third.code}
                grouped.toSortedMap().forEach{(code,rows)->
                    val first=rows.first().third
                    val desc=faultGreek(if(first.meaning.isNotBlank()) first.meaning else first.symptom)
                    val models=rows.map{it.second}.distinct()
                    val types=rows.map{it.first}.distinct()
                    list.addView(LinearLayout(this).apply{
                        orientation=LinearLayout.VERTICAL
                        setPadding(14,12,14,12)
                        background=GradientDrawable().apply{
                            setColor(Color.WHITE);cornerRadius=22f;setStroke(2,Color.rgb(225,232,240))
                        }
                        elevation=3f
                        addView(TextView(this@MainActivity).apply{
                            text="⚠️  $code"
                            textSize=20f
                            typeface=uiFont(true)
                            setTextColor(Color.rgb(0,75,155))
                        })
                        addView(TextView(this@MainActivity).apply{
                            text=desc
                            textSize=15f
                            typeface=uiFont(true)
                            setTextColor(Color.rgb(35,35,35))
                            setPadding(0,5,0,5)
                        })
                        addView(TextView(this@MainActivity).apply{
                            text="${models.size} μοντέλα / σειρές • ${types.joinToString(", ")}"
                            textSize=11f
                            setTextColor(Color.rgb(90,100,112))
                        })
                        setOnClickListener{
                            val target=rows.first()
                            faultListScreen("Daikin",target.first,target.second)
                        }
                    },LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,5,0,5)})
                }
            }
        }

        q.addTextChangedListener(object:android.text.TextWatcher{
            override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}
            override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){render()}
            override fun afterTextChanged(s:android.text.Editable?){}
        })

        r.addView(q,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,8)})
        r.addView(scroll(list),LinearLayout.LayoutParams(-1,0,1f))
        setContentView(r)
        render()
    }

    private fun mitsubishiGlobalFaultSearch(termRaw:String){
        val term=termRaw.trim()
        if(term.isBlank()){ toast("Γράψε κωδικό ή σύμπτωμα."); return }

        fun norm(x:String)=x.uppercase()
            .replace(" ","").replace("-","").replace("/","").replace(".","").replace("_","")

        val wanted=norm(term)
        data class Hit(val type:String,val model:String,val fault:Fault)

        val hits=mutableListOf<Hit>()
        mitsubishiModels.forEach{(type,models)->
            models.distinct().forEach{model->
                mitsubishiGeneratedFaults(type,model).forEach{f->
                    val hay="${f.code} ${f.symptom} ${f.meaning} ${f.causes} ${f.checks} ${f.action} $model $type"
                    val codeNorm=norm(f.code)
                    if(hay.contains(term,true) || codeNorm==wanted || codeNorm.contains(wanted) || norm(hay).contains(wanted)){
                        hits.add(Hit(type,model,f))
                    }
                }
            }
        }

        val unique=hits.distinctBy{"${it.type}|${it.model}|${it.fault.code}|${it.fault.meaning}"}
        val r=base()
        r.addView(proSectionHeader(
            "Mitsubishi Electric • Αναζήτηση βλάβης",
            if(unique.isEmpty()) "Δεν βρέθηκε: $term" else "${unique.map{it.fault.code}.distinct().size} κωδικοί • ${unique.size} αντιστοιχίσεις για «$term»"
        ))
        val q=searchInput("🔎 Κωδικός ή σύμπτωμα...").apply{
            setText(term)
            setTextColor(Color.rgb(20,34,48))
            setHintTextColor(Color.rgb(105,120,135))
            background=GradientDrawable().apply{
                setColor(Color.WHITE);cornerRadius=24f;setStroke(2,Color.rgb(210,222,234))
            }
            setSelection(text.length)
            setOnEditorActionListener{_,_,_->
                mitsubishiGlobalFaultSearch(text.toString()); true
            }
        }
        r.addView(q,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,8,0,8)})

        val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        if(unique.isEmpty()){
            list.addView(TextView(this).apply{
                text="Δεν βρέθηκε βλάβη. Δοκίμασε π.χ. U4, E7, P1, 0403, υψηλή πίεση."
                textSize=16f;setTextColor(Color.rgb(35,48,62));setPadding(16,20,16,20)
            })
        }else unique.forEach{h->
            list.addView(LinearLayout(this).apply{
                orientation=LinearLayout.VERTICAL
                setPadding(16,14,16,14)
                background=GradientDrawable().apply{
                    setColor(Color.WHITE);cornerRadius=18f;setStroke(1,Color.rgb(215,225,235))
                }
                addView(TextView(this@MainActivity).apply{
                    text=h.fault.code
                    textSize=21f;typeface=uiFont(true);setTextColor(Color.rgb(0,93,170))
                })
                addView(TextView(this@MainActivity).apply{
                    text="${h.fault.meaning}\n${h.model} • ${h.type}"
                    textSize=14f;setTextColor(Color.rgb(30,42,55))
                })
                setOnClickListener{ faultListScreen("Mitsubishi Electric",h.type,h.model) }
            },LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,8)})
        }
        r.addView(ScrollView(this).apply{addView(list)},LinearLayout.LayoutParams(-1,0,1f))
        setContentView(r)
    }

    // AERMEC: fixed direct product-image URLs. No HTML scraping, no cache, no generic search.
    // Each category points to one verified Aermec product family image.
    private fun aermecDirectImageUrl(type:String):String = when(type){
        // 9 visually verified Aermec product photos, one per category.
        "Split / Inverter" -> "https://gimli.freetls.fastly.net/tavolla/fs-n/product/210278/850x850/aermec-spg250w-spg-r32-unita-interna-a-parete-mono-multisplit-9000-btu.jpg"
        "Multi-Split" -> "https://global.aermec.com/units_image/MPG.jpg"
        "VRF / VRV" -> "https://www.expoclima.net/thumb/1200/2021/02/focus_2694_1.jpg"
        "Αντλία θερμότητας" -> "https://img.edilportale.com/products/ANKI-AERMEC-290763-relfef1e3d6.jpg"
        "Chiller / Ψύκτης" -> "https://www.expoclima.net/thumb/800/2023/04/25.png"
        "Υδρόψυκτα / Water-to-water" -> "https://ecotherm.ma/wp-content/uploads/2023/12/40.png"
        "Fan Coil" -> "https://www.acquaclick.com/20661-superlarge_default/ventilo-convecteur-au-sol-aermec-fcz100act.jpg"
        "Rooftop / AHU" -> "https://www.expoclima.net/thumb/800/2021/10/prodotti_2407_3.png"
        "Precision / Data Center" -> "https://www.jayateknik.com/web/image/18464/PAC_G.jpg"
        else -> ""
    }

    private fun aermecOfficialProductPhoto(type:String,height:Int):ImageView=ImageView(this).apply{
        scaleType=ImageView.ScaleType.CENTER_INSIDE
        adjustViewBounds=true
        setPadding(3,3,3,3)
        background=GradientDrawable().apply{setColor(Color.WHITE);cornerRadius=18f;setStroke(1,Color.rgb(232,236,241))}
        clipToOutline=true
        contentDescription="Aermec • $type"
        val target=this
        val imageUrl=aermecDirectImageUrl(type)
        if(imageUrl.isBlank()) return@apply
        Thread{
            try{
                val c=(URL(imageUrl).openConnection() as HttpURLConnection).apply{
                    connectTimeout=15000;readTimeout=20000;instanceFollowRedirects=true
                    setRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/140 Mobile Safari/537.36")
                    setRequestProperty("Accept","image/avif,image/webp,image/apng,image/*,*/*;q=0.8")
                }
                if(c.responseCode !in 200..299){c.disconnect();return@Thread}
                val bytes=c.inputStream.use{it.readBytes()};c.disconnect()
                if(bytes.size<2000) return@Thread
                val bmp=BitmapFactory.decodeByteArray(bytes,0,bytes.size) ?: return@Thread
                runOnUiThread{target.setImageBitmap(normalizeProductPhotoSize(bmp))}
            }catch(_:Exception){}
        }.start()
    }

    private fun aermecSearchPhoto(type:String,model:String?,height:Int):ImageView =
        if(model.isNullOrBlank()) aermecOfficialProductPhoto(type,height) else aermecModelPhoto(type,model,height)
    private fun aermecCategoryPhoto(type:String,height:Int):ImageView = aermecOfficialProductPhoto(type,height)

    // AERMEC MODEL PHOTOS: direct official Aermec unit images, using the same loader as category cards.
    // Model variants that share the same physical series intentionally share that series' official product photo.
    private fun aermecModelImageCode(model:String):String {
        val m=model.trim()
        return when {
            m.startsWith("NRB 0800 / 2406 with shell",true) -> "NRB"
            m.startsWith("NRG Free Cooling",true) -> "NRG"
            m.startsWith("NRG Glycol-Free",true) -> "NRG"
            m.startsWith("NRB Free Cooling",true) -> "NRB"
            m.startsWith("NRB Glycol-Free",true) -> "NRB"
            m.startsWith("NRV Free Cooling",true) -> "NRV"
            m.startsWith("NSM Free Cooling",true) -> "NSM"
            m.startsWith("NSM Glycol-Free",true) -> "NSM"
            m.startsWith("NSMI Free Cooling",true) -> "NSMI"
            m.startsWith("NSMJ Free Cooling",true) -> "NSMJ"
            m.startsWith("TBA Free Cooling",true) -> "TBA"
            m.startsWith("TBG Free Cooling",true) -> "TBG"
            m.startsWith("Omnia Slim Inverter",true) -> "OMNIA_SLIM"
            m.startsWith("Omnia Slim",true) -> "OMNIA_SLIM"
            m.startsWith("Omnia UL",true) -> "OMNIA_UL"
            m.startsWith("Omnia ULI",true) -> "OMNIA_ULI"
            m.startsWith("FCZ-H",true) -> "FCZ_H"
            m.startsWith("FCZ-ASW",true) -> "FCZ_ASW"
            m.startsWith("FCZI-H",true) -> "FCZI_H"
            m.startsWith("FCZI-ASW",true) -> "FCZI_ASW"
            m.startsWith("FCZI",true) -> "FCZI"
            m.startsWith("FCZ",true) -> "FCZ"
            m.startsWith("FCW",true) -> "FCW"
            m.startsWith("FCWI",true) -> "FCWI"
            m.startsWith("FCLI",true) -> "FCLI"
            m.startsWith("FCL",true) -> "FCL"
            m.startsWith("FCYI",true) -> "FCYI"
            m.startsWith("FCY",true) -> "FCY"
            m.startsWith("NRGI",true) -> "NRGI"
            m.startsWith("NRG",true) -> "NRG"
            m.startsWith("NRB",true) -> "NRB"
            m.startsWith("NRP",true) -> "NRP"
            m.startsWith("NRL",true) -> "NRL"
            m.startsWith("NRV",true) -> "NRV"
            m.startsWith("NRK",true) -> "NRK"
            m.startsWith("ANL",true) -> "ANL"
            m.startsWith("HMI",true) -> "HMI"
            m.startsWith("HMG-P",true) -> "HMG_P"
            m.startsWith("HMG",true) -> "HMG"
            m.startsWith("NXW",true) -> "NXW"
            m.startsWith("WRL",true) -> "WRL"
            m.startsWith("MVBHR",true) -> "MVBHR"
            m.startsWith("MVBM",true) -> "MVBM"
            m.equals("MVA",true) || m.startsWith("MVAS",true) -> "MVAS"
            else -> m.substringBefore(" ").substringBefore("/").replace("-","_")
        }
    }

    private fun aermecModelImageUrl(model:String):String =
        "https://global.aermec.com/units_image/${aermecModelImageCode(model)}.jpg"

    // Only used when the model's normal Aermec image endpoint is empty/unavailable.
    // Existing working images are never replaced. These fallbacks are verified photos of the same Aermec family.
    private fun aermecVerifiedFallbackUrl(type:String,model:String):String {
        val m=model.trim()
        return when {
            // VRF: verified real Aermec MVA outdoor VRF unit. Used only if the model's normal image is unavailable.
            type.equals("VRF / VRV",true) -> "https://www.expoclima.net/thumb/1200/2021/02/focus_2694_1.jpg"
            m.startsWith("ANKI",true) -> "https://img.edilportale.com/products/ANKI-AERMEC-290763-rel2e425fb.jpg"
            m.startsWith("HMI",true) -> "https://www.didatto.it/public/ImgProd/Big/990-1162433663-HMI.jpg"
            m.startsWith("ANLI",true) -> "https://gimli.freetls.fastly.net/tavolla/fs-n/product/84596/850x850/aermec-anli-pompa-di-calore-inverter-tavolla.jpg"
            m.startsWith("ANK",true) -> "https://static-data2.manualslib.com/product-images/c8f/1256294/aermec-ank030-h-heat-pump.jpg"
            m.startsWith("PRM",true) || m.startsWith("PRG",true) -> "https://thermocontrol.no/wp-content/uploads/2025/03/Aermec-PRG.webp"
            m.startsWith("NRG",true) -> "https://www.expoclima.net/thumb/800/2023/04/25.png"
            m.startsWith("BHP",true) -> "https://img.edilportale.com/csmartnews/img/574931_img03.jpg"
            m.startsWith("NRK",true) -> "https://gimli.freetls.fastly.net/tavolla/Products/Images/94633/o_aermec-nrk-0090-0150-pompa-di-calore-reversibile-condensata-ad-aria-tavolla.jpg"
            // Remaining Aermec families seen blank in the app: use a verified Aermec machine photo
            // only as a last-resort fallback; any primary image that already works remains untouched.
            m.startsWith("SHW",true) -> "https://img.edilportale.com/products/ANKI-AERMEC-290763-rel2e425fb.jpg"
            m.startsWith("NRL",true) || m.startsWith("NRV",true) || m.startsWith("NRB",true) -> "https://www.expoclima.net/thumb/800/2023/04/25.png"
            m.startsWith("HMG",true) -> "https://thermocontrol.no/wp-content/uploads/2025/03/Aermec-PRG.webp"
            m.startsWith("WRL",true) || m.startsWith("WWM",true) || m.startsWith("NXW",true) ||
            m.startsWith("NGW",true) || m.equals("WS",true) || m.startsWith("HWS",true) ||
            m.startsWith("HWF",true) || m.startsWith("HWFG",true) || m.startsWith("WFN",true) ||
            m.startsWith("WFI",true) || m.startsWith("WFG",true) -> "https://ecotherm.ma/wp-content/uploads/2023/12/40.png"
            m.startsWith("MIC",true) || m.startsWith("CL",true) || m.startsWith("NLC",true) ||
            m.startsWith("NS",true) || m.startsWith("TBA",true) || m.startsWith("TBG",true) -> "https://www.expoclima.net/thumb/800/2023/04/25.png"
            m.equals("MVAS",true) || m.startsWith("MVA",true) || m.startsWith("MVB",true) -> "https://www.expoclima.net/thumb/1200/2021/02/focus_2694_1.jpg"
            m.equals("COMPACT",true) -> "https://gimli.freetls.fastly.net/tavolla/fs-n/product/210278/850x850/aermec-spg250w-spg-r32-unita-interna-a-parete-mono-multisplit-9000-btu.jpg"
            else -> ""
        }
    }

    private fun aermecModelPhoto(type:String,model:String,height:Int):ImageView=ImageView(this).apply{
        scaleType=ImageView.ScaleType.CENTER_INSIDE
        adjustViewBounds=true
        setPadding(3,3,3,3)
        background=GradientDrawable().apply{setColor(Color.WHITE);cornerRadius=18f;setStroke(1,Color.rgb(232,236,241))}
        clipToOutline=true
        contentDescription="Aermec • $model"
        val target=this
        val primaryUrl=aermecModelImageUrl(model)
        val fallbackUrl=aermecVerifiedFallbackUrl(type,model)
        Thread{
            val candidates=listOf(primaryUrl,fallbackUrl).filter{it.isNotBlank()}.distinct()
            for(imageUrl in candidates){
                try{
                    val c=(URL(imageUrl).openConnection() as HttpURLConnection).apply{
                        connectTimeout=15000;readTimeout=20000;instanceFollowRedirects=true
                        setRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/140 Mobile Safari/537.36")
                        setRequestProperty("Accept","image/avif,image/webp,image/apng,image/*,*/*;q=0.8")
                    }
                    if(c.responseCode !in 200..299){c.disconnect();continue}
                    val bytes=c.inputStream.use{it.readBytes()};c.disconnect()
                    if(bytes.size<2000) continue
                    val bmp=BitmapFactory.decodeByteArray(bytes,0,bytes.size) ?: continue
                    runOnUiThread{target.setImageBitmap(normalizeProductPhotoSize(bmp))}
                    break
                }catch(_:Exception){}
            }
        }.start()
    }

    private fun genericCategoryPhotoFromPage(page:String,label:String,height:Int):ImageView=ImageView(this).apply{
        scaleType=ImageView.ScaleType.CENTER_INSIDE
        adjustViewBounds=true
        setPadding(3,3,3,3)
        background=GradientDrawable().apply{setColor(Color.WHITE);cornerRadius=18f;setStroke(1,Color.rgb(232,236,241))}
        clipToOutline=true
        contentDescription=label
        val target=this
        // v6 intentionally invalidates every old generic cache: old files may contain banners/logos/wrong brands.
        val cacheFile=File(cacheDir,"catphoto_verified_v8_"+(label.hashCode().toLong() and 0xffffffffL).toString(16)+".jpg")
        if(cacheFile.exists() && cacheFile.length()>2500){
            try{BitmapFactory.decodeFile(cacheFile.absolutePath)?.let{setImageBitmap(normalizeProductPhotoSize(it))}}catch(_:Exception){}
            return@apply
        }
        Thread{
            try{
                val base=URL(page)
                val c=(base.openConnection() as HttpURLConnection).apply{
                    connectTimeout=8000;readTimeout=12000;instanceFollowRedirects=true
                    setRequestProperty("User-Agent","Mozilla/5.0 (Android) Psyktikos/1.3")
                }
                if(c.responseCode !in 200..299){c.disconnect();return@Thread}
                val html=c.inputStream.bufferedReader().use{it.readText()}.replace("\\/","/").replace("&amp;","&")
                c.disconnect()
                val brand=label.substringBefore("•").trim().lowercase()
                val type=label.substringAfter("•","").trim().lowercase()
                val wanted=when{
                    "multi" in type -> listOf("multi","multisplit","multi-split","outdoor")
                    "vrf" in type || "vrv" in type || "mrv" in type || "gmv" in type -> listOf("vrf","vrv","mrv","gmv","air flux","outdoor")
                    "αντλ" in type || "heat pump" in type || "νερού" in type -> listOf("heat pump","pump","monobloc","monoblock","hydro","aqua")
                    "καναλ" in type || "duct" in type -> listOf("duct","ducted","canal")
                    "κασ" in type || "cassette" in type -> listOf("cassette")
                    "floor" in type || "ceiling" in type || "δαπέ" in type || "οροφ" in type -> listOf("floor","ceiling","console")
                    "chiller" in type || "ψύκ" in type -> listOf("chiller")
                    "precision" in type || "it cooling" in type -> listOf("precision","it cooling","close control")
                    else -> listOf("split","air conditioner","climate","wall")
                }
                data class Cand(val url:String,val score:Int)
                val candidates=mutableListOf<Cand>()
                val re=Regex("""(?is)<img[^>]+(?:src|data-src)=[\"']([^\"']+)[\"'][^>]*>""")
                for(m in re.findAll(html)){
                    val raw=m.groupValues[1]
                    val u=try{URL(base,raw).toString()}catch(_:Exception){continue}
                    val ctx=html.substring(maxOf(0,m.range.first-700),minOf(html.length,m.range.last+700)).lowercase()
                    val lu=u.lowercase()
                    // Never accept an image served by an unrelated third-party/ad site.
                    // This is what allowed AELIYA/other foreign banners to appear in HVAC cards.
                    val imgHost=try{URL(u).host.lowercase()}catch(_:Exception){continue}
                    val pageHost=base.host.lowercase()
                    val brandToken=brand.replace("&","and").replace(" ","").replace("-","")
                    val hostCompact=imgHost.replace("-","").replace(".","")
                    val hostAllowed = imgHost==pageHost || imgHost.endsWith("."+pageHost) ||
                        pageHost.endsWith("."+imgHost) || (brandToken.length>=3 && brandToken in hostCompact) ||
                        imgHost.contains("bosch-homecomfort") || imgHost.contains("auxair") ||
                        imgHost.contains("climaveneta") || imgHost.contains("carrier")
                    if(!hostAllowed) continue
                    val wantedHits=wanted.count{it in ctx || it in lu}
                    if(wantedHits==0) continue
                    var score=0
                    if(brand.isNotBlank() && (brand in ctx || brand.replace("&","and") in ctx || brand in lu)) score+=25
                    score += wantedHits*35
                    if("product" in ctx || "product" in lu) score+=15
                    if("logo" in lu || "logo" in ctx || "icon" in lu || "sprite" in lu || "banner" in lu || "hero" in lu || "comparison" in ctx || " vs " in ctx) score-=180
                    if(score>20) candidates.add(Cand(u,score))
                }
                for(cand in candidates.distinctBy{it.url}.sortedByDescending{it.score}.take(18)){
                    try{
                        val ic=(URL(cand.url).openConnection() as HttpURLConnection).apply{
                            connectTimeout=7000;readTimeout=12000;instanceFollowRedirects=true
                            setRequestProperty("User-Agent","Mozilla/5.0 (Android) Psyktikos/1.3")
                            setRequestProperty("Referer",page)
                        }
                        if(ic.responseCode !in 200..299){ic.disconnect();continue}
                        val bytes=ic.inputStream.use{it.readBytes()};ic.disconnect()
                        if(bytes.size<7000) continue
                        val bmp=BitmapFactory.decodeByteArray(bytes,0,bytes.size) ?: continue
                        if(bmp.width<220 || bmp.height<120) continue
                        // reject extreme banners; product photos are not ultra-wide strips
                        val ratio=bmp.width.toFloat()/bmp.height.toFloat()
                        if(ratio>3.0f || ratio<0.28f) continue
                        try{cacheFile.writeBytes(bytes)}catch(_:Exception){}
                        runOnUiThread{target.setImageBitmap(normalizeProductPhotoSize(bmp))}
                        return@Thread
                    }catch(_:Exception){}
                }
            }catch(_:Exception){}
        }.start()
    }


    private fun exactVerifiedCategoryPhoto(url:String,label:String,height:Int):ImageView=ImageView(this).apply{
        scaleType=ImageView.ScaleType.CENTER_INSIDE
        adjustViewBounds=true
        setPadding(3,3,3,3)
        background=GradientDrawable().apply{setColor(Color.WHITE);cornerRadius=18f;setStroke(1,Color.rgb(232,236,241))}
        clipToOutline=true
        contentDescription=label
        val target=this
        val cacheFile=File(cacheDir,"catphoto_exact_v2_"+(label.hashCode().toLong() and 0xffffffffL).toString(16)+".jpg")
        if(cacheFile.exists() && cacheFile.length()>2500){
            try{BitmapFactory.decodeFile(cacheFile.absolutePath)?.let{setImageBitmap(normalizeProductPhotoSize(it));return@apply}}catch(_:Exception){}
        }
        Thread{
            try{
                val c=(URL(url).openConnection() as HttpURLConnection).apply{
                    connectTimeout=9000;readTimeout=15000;instanceFollowRedirects=true
                    setRequestProperty("User-Agent","Mozilla/5.0 (Android) Psyktikos/1.3")
                    setRequestProperty("Accept","image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8")
                }
                if(c.responseCode !in 200..299){c.disconnect();return@Thread}
                val ct=c.contentType.orEmpty().lowercase()
                val bytes=c.inputStream.use{it.readBytes()};c.disconnect()
                if(bytes.size<3000 || (ct.isNotBlank() && !ct.startsWith("image/"))) return@Thread
                val bmp=BitmapFactory.decodeByteArray(bytes,0,bytes.size) ?: return@Thread
                if(bmp.width<180 || bmp.height<100) return@Thread
                try{cacheFile.writeBytes(bytes)}catch(_:Exception){}
                runOnUiThread{target.setImageBitmap(normalizeProductPhotoSize(bmp))}
            }catch(_:Exception){}
        }.start()
    }

    private fun airwellCategoryPhoto(type:String,height:Int):ImageView=ImageView(this).apply{
        scaleType=ImageView.ScaleType.CENTER_INSIDE
        adjustViewBounds=true
        setPadding(3,3,3,3)
        background=GradientDrawable().apply{setColor(Color.WHITE);cornerRadius=18f;setStroke(1,Color.rgb(232,236,241))}
        clipToOutline=true
        contentDescription="Airwell • $type"
        val target=this
        val imageUrl=when(type){
            "Hi-Wall / Split" -> "https://www.airwell.com/wp-content/uploads/2021/02/harmonia_produit.png"
            "Κονσόλα" -> "https://www.direct-store.com/cdn/shop/files/unite-interieure-console-airwell-hemera-xdlf-3-5-3-8kw.png?v=1770300806&width=1445"
            "Καναλάτο / Built-in" -> "https://www.airwell.com/wp-content/uploads/2024/04/DDMX-IMG-686-x-486-px-N.png"
            "Mobile / Φορητό" -> "https://www.hellopro.fr/images/produit-2/6/2/2/climatiseur-monobloc-pac-mobile-monophase-maui-2-93-kw-airwell-8991226.jpg"
            "Αντλία θερμότητας Monobloc" -> "https://www.airwell.com/wp-content/uploads/2021/02/monobloc_produit.png"
            "Αντλία θερμότητας Split" -> "https://www.airwell.com/wp-content/uploads/2021/02/split_produit.png"
            "ΖΝΧ / Θερμοδυναμικό boiler" -> "https://img.archiexpo.com/images_ae/photo-g/312-15802425.jpg"
            "Αερισμός / Hybrid dual flow" -> "https://www.airwell.com/wp-content/uploads/2021/03/airflow_hotspot.png"
            else -> ""
        }
        if(imageUrl.isBlank()) return@apply
        Thread{
            try{
                val c=(URL(imageUrl).openConnection() as HttpURLConnection).apply{
                    connectTimeout=15000;readTimeout=20000;instanceFollowRedirects=true
                    setRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/140 Mobile Safari/537.36")
                    setRequestProperty("Accept","image/avif,image/webp,image/apng,image/*,*/*;q=0.8")
                    setRequestProperty("Referer","https://www.airwell.com/")
                }
                if(c.responseCode !in 200..299){c.disconnect();return@Thread}
                val bytes=c.inputStream.use{it.readBytes()};c.disconnect()
                if(bytes.size<2000) return@Thread
                val bmp=BitmapFactory.decodeByteArray(bytes,0,bytes.size) ?: return@Thread
                runOnUiThread{target.setImageBitmap(normalizeProductPhotoSize(bmp))}
            }catch(_:Exception){}
        }.start()
    }

    private fun verifiedBrandCategoryPhoto(brand:String,type:String,height:Int):ImageView{
        val t=type.lowercase()

        // Exact, hand-verified manufacturer image URLs for categories that previously
        // showed unrelated banners/other brands. These bypass HTML scraping completely.
        if(brand.equals("AUX",true)){
            val exact=when{
                "multi" in t -> "https://auxcool.com/wp-content/uploads/2025/08/830.png"
                "καναλ" in t || "duct" in t -> "https://auxcool.com/wp-content/uploads/2025/02/duc1.webp"
                "κασ" in t || "cassette" in t -> "https://auxcool.com/wp-content/uploads/2025/02/case1.webp"
                "floor" in t || "ceiling" in t -> "https://auxcool.com/wp-content/uploads/2025/02/floo01.webp"
                "vrf" in t || "vrv" in t -> "https://auxcool.com/wp-content/uploads/2025/02/arv7front2-1024x341.png"
                "αντλ" in t || "heat pump" in t -> "https://auxcool.com/wp-content/uploads/2024/07/split-1.webp"
                else -> ""
            }
            if(exact.isNotBlank()) return exactVerifiedCategoryPhoto(exact,"AUX • $type",height)
        }
        if(brand.equals("Bosch",true)){
            // Fixed direct product images — same method used for the working Aermec/Airwell cards.
            val boschImageUrl=when{
                "vrf" in t || "vrv" in t -> "https://www.proidea.ro/robert-bosch-srl-home-comfort-228592/unitate-exterioara-bosch-air-flux-5300-374004/a_81_d_14_1723640584438_bosch_sistem_comercial_vrf_unitate_exterioara_air_flux_5300_preview.png"
                "multi" in t -> "https://cdn.idealo.com/folder/Product/204795/4/204795421/s1_produktbild_max_1/bosch-wandgeraete-set-climate-5000-m-2-0-kw-3-5-kw.jpg"
                "αντλ" in t || "heat pump" in t || "νερού" in t -> "https://media.elektrobode.nl/images/product/bosch-compress-5000-aw-compress-5000-aw-22-o-8738212189.jpg"
                else -> "https://cdn.cimri.io/image/1200x1200/bosch-climate-5000i-a-12000-btu-wifi-ozellikli-r32-split-duvar-tipi-klima_423635867.jpg"
            }
            return exactVerifiedCategoryPhoto(boschImageUrl,"Bosch • $type",height)
        }
        val page=when {
            brand.equals("AUX",true) && ("multi" in t) -> "https://us.auxair.com/products"
            brand.equals("AUX",true) && ("vrf" in t || "vrv" in t) -> "https://www.auxair.com/sa/products"
            brand.equals("AUX",true) && ("αντλ" in t || "heat pump" in t) -> "https://www.auxair.com/global/new-events/aux-air-conditioner-ai-smart-strategy-canton-fair-2026.html"
            brand.equals("AUX",true) && ("καναλ" in t || "duct" in t || "κασ" in t || "cassette" in t || "floor" in t || "ceiling" in t) -> "https://us.auxair.com/products"
            brand.equals("AUX",true) -> "https://www.auxair.com/global/product.html"

            brand.equals("Bosch",true) && ("multi" in t) -> "https://www.bosch-homecomfort.com/pt/pt/servicos-e-suporte/documentacao-e-downloads/catalogos-de-produtos/ar-condicionado/"
            brand.equals("Bosch",true) && ("vrf" in t || "vrv" in t) -> "https://www.bosch-homecomfort.com/pt/pt/servicos-e-suporte/documentacao-e-downloads/catalogos-de-produtos/ar-condicionado/"
            brand.equals("Bosch",true) && ("αντλ" in t || "heat pump" in t || "νερού" in t) -> "https://www.bosch-homecomfort.com/pt/pt/servicos-e-suporte/documentacao-e-downloads/catalogos-de-produtos/ar-condicionado/"
            brand.equals("Bosch",true) -> "https://www.bosch-homecomfort.com/pt/pt/servicos-e-suporte/documentacao-e-downloads/catalogos-de-produtos/ar-condicionado/"

            brand.equals("Gree",true) && ("αντλ" in t || "νερού" in t) -> "https://gree.gr/product-category/antlies-thermotitas/"
            brand.equals("Gree",true) && ("vrf" in t || "gmv" in t) -> "https://gree.gr/product-category/kentrikos-klimatismos-systimata-vrf/"
            brand.equals("Gree",true) && ("multi" in t) -> "https://gree.gr/product-category/multi-split/"
            brand.equals("Gree",true) && ("καναλ" in t || "κασ" in t || "floor" in t || "ceiling" in t || "packaged" in t || "rooftop" in t) -> "https://gree.gr/product-category/imikentrikos-klimatismos/"
            brand.equals("Gree",true) -> "https://gree.gr/product-category/oikiakos-klimatismos/"

            brand.equals("Haier",true) && ("vrf" in t || "mrv" in t) -> "https://haierhvac.eu/products/mrv"
            brand.equals("Haier",true) && ("αντλ" in t || "νερού" in t) -> "https://haierhvac.eu/products/heat-pumps"
            brand.equals("Haier",true) && ("multi" in t) -> "https://haierhvac.eu/products/multi-split"
            brand.equals("Haier",true) && ("καναλ" in t || "κασ" in t || "light commercial" in t) -> "https://haierhvac.eu/products/commercial"
            brand.equals("Haier",true) -> "https://haierhvac.eu/products/residential"

            brand.equals("Climaveneta",true) && ("precision" in t || "it cooling" in t) -> "https://www.climaveneta.com/en/stories/404/w-next3"
            brand.equals("Climaveneta",true) && ("αντλ" in t || "heat pump" in t) -> "https://www.climaveneta.com/en/stories/590/i-bx2-g07-and-i-bx2-n-g07"
            brand.equals("Climaveneta",true) && ("chiller" in t || "ψύκ" in t) -> "https://www.climaveneta.com/en/products/2990/chiller-air-source-for-outdoor-installation"

            else -> when(brand){
                "AUX" -> "https://www.auxair.com/global/product.html"
                "Ariston" -> "https://www.ariston.com/"
                "Bosch" -> "https://www.bosch-homecomfort.com/"
                "Carrier" -> "https://www.carrier.com/commercial/en/eu/products/"
                "Climaveneta" -> "https://www.climaveneta.com/"
                "Cooper&Hunter" -> "https://www.cooperandhunter.com/"
                "Fujitsu" -> "https://www.fujitsu-general.com/global/products/"
                "General" -> "https://www.general-hvac.com/global/products/"
                "Hisense" -> "https://www.hisensehvac.com/"
                "Hitachi" -> "https://www.hitachiaircon.com/"
                "Inventor" -> "https://www.inventorairconditioner.com/"
                "Lennox" -> "https://www.lennoxemea.com/"
                "LG" -> "https://www.lg.com/global/business/hvac/"
                "Midea" -> "https://www.midea.com/global/hvac"
                "Mitsubishi Heavy" -> "https://www.mhi-mth.co.jp/en/products/residential-and-commercial-air-conditioners/"
                "Nordstar" -> "https://www.nordstar.gr/"
                "Panasonic" -> "https://www.aircon.panasonic.eu/"
                "Rhoss" -> "https://www.rhoss.it/"
                "Rotenso" -> "https://rotenso.com/en/"
                "Samsung" -> "https://www.samsung.com/business/climate/"
                "Sharp" -> "https://www.sharpconsumer.eu/"
                "Sinclair" -> "https://www.sinclair-solutions.com/"
                "TCL" -> "https://www.tcl.com/eu/en/air-conditioners"
                "Tesla" -> "https://tesla.info/en/air-conditioning/"
                "Toshiba" -> "https://www.toshiba-aircon.co.uk/"
                "Toyotomi" -> "https://www.toyotomi.eu/air-conditioning/"
                "Trane" -> "https://trane.eu/"
                "Vaillant" -> "https://www.vaillant.com/"
                "Viessmann" -> "https://www.viessmann.com/"
                "York" -> "https://www.york.com/commercial-equipment/"
                else -> addedBrandOfficialPage(brand).ifBlank{"https://www.google.com/"}
            }
        }
        return genericCategoryPhotoFromPage(page,"$brand • $type",height)
    }


    private fun categoryCoverModelsForBrand(brand:String):Map<String,List<String>> = when {
        brand.equals("Aermec",true) -> aermecModels
        brand.equals("Airwell",true) -> airwellModels
        brand.equals("Argo",true) -> argoModels
        brand.equals("Ariston",true) -> aristonModels
        brand.equals("AUX",true) -> auxModels
        brand.equals("Bosch",true) -> boschModels
        brand.equals("Carrier",true) -> carrierModels
        brand.equals("CIAT",true) -> ciatModels
        brand.equals("Climaveneta",true) -> climavenetaModels
        brand.equals("Cooper&Hunter",true) -> cooperHunterModels
        brand.equals("Fujitsu",true) -> fujitsuModels
        brand.equals("General",true) -> generalModels
        brand.equals("Gree",true) -> greeModels
        brand.equals("Haier",true) -> haierModels
        brand.equals("Hisense",true) -> hisenseModels
        brand.equals("Hitachi",true) -> hitachiModels
        brand.equals("Inventor",true) -> inventorModels
        brand.equals("Lennox",true) -> lennoxModels
        brand.equals("LG",true) -> lgModels
        brand.equals("Midea",true) -> mideaModels
        brand.equals("Mitsubishi Heavy",true) -> mitsubishiHeavyModels
        brand.equals("Nordstar",true) -> nordstarModels
        brand.equals("Panasonic",true) -> panasonicModels
        brand.equals("Rhoss",true) -> rhossModels
        brand.equals("Rotenso",true) -> rotensoModels
        brand.equals("Samsung",true) -> samsungModels
        brand.equals("Sharp",true) -> sharpModels
        brand.equals("Sinclair",true) -> sinclairModels
        brand.equals("TCL",true) -> tclModels
        brand.equals("Tesla",true) -> teslaModels
        brand.equals("Toshiba",true) -> toshibaModels
        brand.equals("Toyotomi",true) -> toyotomiModels
        brand.equals("Trane",true) -> traneModels
        brand.equals("Vaillant",true) -> vaillantModels
        brand.equals("Viessmann",true) -> viessmannModels
        brand.equals("York",true) -> yorkModels
        brand.equals("Pitsos",true) -> pitsosModels
        brand.equals("Sendo",true) -> sendoModels
        brand.equals("Morris",true) -> morrisModels
        brand.equals("Juro-Pro",true) -> juroProModels
        brand.equals("F&U",true) -> fuModels
        brand.equals("United",true) -> unitedModels
        else -> emptyMap()
    }

    private fun categorySearchTerms(type:String):String {
        val t=type.lowercase()
        return when {
            "multi" in t -> "multi split outdoor unit"
            "vrf" in t || "vrv" in t || "mrv" in t || "gmv" in t || "smms" in t || "dvm" in t || "ecoi" in t -> "VRF outdoor unit"
            "chiller" in t || "ψύκ" in t -> "chiller unit"
            "precision" in t || "data center" in t || "close control" in t || "it cooling" in t -> "precision air conditioner"
            "fan coil" in t -> "fan coil unit"
            "rooftop" in t || "packaged" in t -> "rooftop packaged unit"
            "ahu" in t || "air handling" in t -> "air handling unit"
            "dry cooler" in t || "condenser" in t -> "dry cooler condenser"
            "γεωθερ" in t -> "ground source heat pump"
            "αντλ" in t || "heat pump" in t || "hydro" in t || "aquarea" in t || "yutaki" in t || "hi-therma" in t -> "heat pump unit"
            "ζνχ" in t || "water heater" in t || "boiler" in t -> "heat pump water heater"
            "αερισ" in t || "erv" in t || "hrv" in t || "recuper" in t || "airflow" in t -> "ventilation unit"
            "καναλ" in t || "duct" in t || "built-in" in t -> "ducted indoor unit"
            "κασ" in t || "cassette" in t -> "cassette indoor unit"
            "console" in t || "κονσό" in t -> "floor console indoor unit"
            "floor" in t || "ceiling" in t || "ντουλάπα" in t -> "floor ceiling indoor unit"
            "mobile" in t || "φορη" in t -> "portable air conditioner"
            "monobloc χωρίς" in t -> "monoblock air conditioner without outdoor unit"
            "commercial" in t || "light commercial" in t || "paci" in t || "pac" in t || "mr slim" in t || "skyair" in t -> "commercial air conditioner"
            else -> "wall split air conditioner"
        }
    }

    private fun officialBingCategoryPhoto(brand:String,type:String,height:Int):ImageView=ImageView(this).apply{
        scaleType=ImageView.ScaleType.CENTER_INSIDE
        adjustViewBounds=true
        setPadding(3,3,3,3)
        background=GradientDrawable().apply{setColor(Color.WHITE);cornerRadius=18f;setStroke(1,Color.rgb(232,236,241))}
        clipToOutline=true
        contentDescription="$brand • $type"
        val target=this
        val representative=categoryCoverModelsForBrand(brand)[type].orEmpty().firstOrNull().orEmpty()
        val domain=officialBrandDomain(brand).ifBlank { return@apply }
        // New cache namespace: never reuse any image chosen by the old generic/Mitsubishi pipelines.
        val cacheKey=(brand+"|"+type+"|"+representative).hashCode().toLong() and 0xffffffffL
        val cacheFile=File(cacheDir,"brand_category_official_v10_"+cacheKey.toString(16)+".jpg")
        if(cacheFile.exists() && cacheFile.length()>3500){
            try{BitmapFactory.decodeFile(cacheFile.absolutePath)?.let{setImageBitmap(normalizeProductPhotoSize(it));return@apply}}catch(_:Exception){}
        }
        Thread{
            try{
                fun officialSourceHost(url:String):Boolean{
                    return try{
                        val h=URL(url).host.lowercase().removePrefix("www.")
                        val d=domain.lowercase().removePrefix("www.")
                        h==d || h.endsWith(".$d") || d.endsWith(".$h")
                    }catch(_:Exception){false}
                }
                fun decodeJsonUrl(x:String)=x
                    .replace("\\u002F","/").replace("\\/","/")
                    .replace("\\u003A",":").replace("\\u003F","?")
                    .replace("\\u003D","=").replace("\\u0026","&")
                    .replace("&amp;","&").replace("&quot;","\"")

                val terms=categorySearchTerms(type)
                val queries=mutableListOf<String>()
                if(representative.isNotBlank()) queries.add("site:$domain $brand $representative $terms")
                queries.add("site:$domain $brand $terms")

                data class BingCand(val imageUrl:String,val sourceUrl:String,val score:Int)
                val all=mutableListOf<BingCand>()
                for(queryText in queries){
                    val q=java.net.URLEncoder.encode(queryText,"UTF-8")
                    val searchUrl="https://www.bing.com/images/search?q=$q&form=HDRSC3&first=1"
                    val c=(URL(searchUrl).openConnection() as HttpURLConnection).apply{
                        connectTimeout=9000;readTimeout=14000;instanceFollowRedirects=true
                        setRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/138 Mobile Safari/537.36")
                        setRequestProperty("Accept-Language","en-US,en;q=0.9")
                    }
                    if(c.responseCode !in 200..299){c.disconnect();continue}
                    val html=c.inputStream.bufferedReader().use{it.readText()};c.disconnect()
                    // Bing stores the original image URL and the source product page in the m= JSON attribute.
                    val blocks=Regex("""(?is)\bm=[\"']([^\"']*(?:murl|purl)[^\"']*)[\"']""").findAll(html)
                    for(b in blocks){
                        val raw=b.groupValues[1].replace("&quot;","\"").replace("&amp;","&")
                        val murl=Regex("""(?i)\"murl\"\s*:\s*\"([^\"]+)\"""").find(raw)?.groupValues?.get(1)?.let(::decodeJsonUrl) ?: continue
                        val purl=Regex("""(?i)\"purl\"\s*:\s*\"([^\"]+)\"""").find(raw)?.groupValues?.get(1)?.let(::decodeJsonUrl) ?: continue
                        if(!officialSourceHost(purl)) continue
                        val low=(raw+" "+murl+" "+purl).lowercase()
                        if(listOf("logo","icon","banner","brochure","catalogue cover","catalog cover","comparison"," vs ","people","woman","family","lifestyle").any{it in low}) continue
                        var score=100
                        if(representative.isNotBlank() && representative.lowercase().replace(" ","") in low.replace(" ","")) score+=90
                        categorySearchTerms(type).split(" ").filter{it.length>3}.forEach{if(it in low) score+=15}
                        all.add(BingCand(murl,purl,score))
                    }
                    if(all.isNotEmpty()) break
                }

                for(cand in all.distinctBy{it.imageUrl}.sortedByDescending{it.score}.take(30)){
                    try{
                        val ic=(URL(cand.imageUrl).openConnection() as HttpURLConnection).apply{
                            connectTimeout=9000;readTimeout=15000;instanceFollowRedirects=true
                            setRequestProperty("User-Agent","Mozilla/5.0 (Android) Psyktikos/1.3")
                            setRequestProperty("Referer",cand.sourceUrl)
                            setRequestProperty("Accept","image/avif,image/webp,image/apng,image/*,*/*;q=0.8")
                        }
                        if(ic.responseCode !in 200..299){ic.disconnect();continue}
                        val ct=ic.contentType.orEmpty().lowercase()
                        val bytes=ic.inputStream.use{it.readBytes()};ic.disconnect()
                        if(bytes.size<6000 || (ct.isNotBlank() && !ct.startsWith("image/"))) continue
                        val bmp=BitmapFactory.decodeByteArray(bytes,0,bytes.size) ?: continue
                        if(bmp.width<220 || bmp.height<120) continue
                        val ratio=bmp.width.toFloat()/bmp.height.toFloat()
                        if(ratio>2.8f || ratio<0.32f) continue
                        try{cacheFile.writeBytes(bytes)}catch(_:Exception){}
                        runOnUiThread{target.setImageBitmap(normalizeProductPhotoSize(bmp))}
                        return@Thread
                    }catch(_:Exception){}
                }
            }catch(_:Exception){}
        }.start()
    }

    private fun hasCategoryCoverLikeMitsubishi(brand:String):Boolean =
        !brand.equals("Daikin",true) &&
        !brand.equals("Mitsubishi Electric",true) &&
        !brand.equals("Midea",true)

    private fun categoryCoverLikeMitsubishi(brand:String,type:String,height:Int):ImageView {
        // AUX/Bosch keep their hand-picked official images where supplied.
        if(brand.equals("AUX",true)){
            val t=type.lowercase()
            if("multi" in t || "καναλ" in t || "duct" in t || "κασ" in t || "cassette" in t || "floor" in t || "ceiling" in t || "vrf" in t || "vrv" in t || "αντλ" in t || "heat pump" in t){
                return verifiedBrandCategoryPhoto(brand,type,height)
            }
        }
        // Every other brand/category now searches ONLY images whose SOURCE PAGE is on
        // the manufacturer's official domain, with the category and representative model
        // in the query. It never falls back to another brand, a generic Google image, or
        // the Mitsubishi loader.
        return officialBingCategoryPhoto(brand,type,height)
    }

    private fun faultTypesScreen(brand:String){
        val r=base()
        val entry=faultCatalog.firstOrNull{it.brand.equals(brand,true)}
        val types=entry?.types ?: listOf("Split / Inverter")
        val researchedBrand=setOf("AUX","Ariston","Bosch","Carrier","Climaveneta","Cooper&Hunter","Fujitsu","General","Gree","Haier","Hisense","Hitachi","Inventor","Lennox","LG","Mitsubishi Heavy","Nordstar","Panasonic","Rhoss","Rotenso","Samsung","Sharp","Sinclair","TCL","Tesla","Toshiba","Toyotomi","Trane","Vaillant","Viessmann","York").any{it.equals(brand,true)}

        val head=LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL
            gravity=Gravity.CENTER_VERTICAL
            setPadding(14,12,14,12)
            background=hmtBlueGradient()
            elevation=6f
        }
        val logoId=when{ brand.equals("Daikin",true)->resources.getIdentifier("logo_daikin","drawable",packageName); brand.equals("Mitsubishi Electric",true)->resources.getIdentifier("logo_mitsubishi_electric","drawable",packageName); else->0 }
        if(logoId!=0) head.addView(ImageView(this).apply{
            setImageResource(logoId);scaleType=ImageView.ScaleType.CENTER_INSIDE
        },LinearLayout.LayoutParams(110,72).apply{setMargins(0,0,12,0)})
        head.addView(LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            addView(TextView(this@MainActivity).apply{
                text="$brand • ΒΛΑΒΟΛΟΓΙΟ 2.0";textSize=20f;typeface=uiFont(true);setTextColor(Color.WHITE)
            })
            addView(TextView(this@MainActivity).apply{
                val models=when{ brand.equals("Daikin",true)->daikinModels.values.flatten().distinct().size; brand.equals("Mitsubishi Electric",true)->mitsubishiModels.values.flatten().distinct().size; else->0 }
                text=if(brand.equals("Daikin",true) || brand.equals("Mitsubishi Electric",true)) "$models σειρές • offline service database" else "Επίλεξε κατηγορία"
                textSize=11f;setTextColor(Color.rgb(220,239,252))
            })
        },LinearLayout.LayoutParams(0,-2,1f))
        r.addView(head,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,8)})

        val q=searchInput(if(brand.equals("Daikin",true) || brand.equals("Mitsubishi Electric",true)) "🔎  Μοντέλο ή βλάβη..." else "🔎  Αναζήτηση κατηγορίας...")
        q.background=GradientDrawable().apply{
            setColor(Color.WHITE);cornerRadius=24f;setStroke(2,Color.rgb(210,222,234))
        }
        q.setTextColor(Color.rgb(20,34,48))
        q.setHintTextColor(Color.rgb(105,120,135))
        r.addView(q,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,6)})
        if(brand.equals("Daikin",true) || brand.equals("Mitsubishi Electric",true)){
            r.addView(TextView(this).apply{
                text="Αναζήτηση βλάβης / κωδικού  →"
                textSize=12f
                typeface=uiFont(true)
                setTextColor(Color.rgb(0,112,190))
                gravity=Gravity.END
                setPadding(8,2,8,8)
                setOnClickListener{
                    val term=q.text.toString().trim()
                    if(term.isBlank()) toast("Γράψε πρώτα κωδικό ή σύμπτωμα.")
                    else if(brand.equals("Daikin",true)) daikinGlobalFaultSearch(term)
                    else mitsubishiGlobalFaultSearch(term)
                }
            })
        }

        if(brand.equals("Mitsubishi Electric",true)){
            q.setOnEditorActionListener{_,_,_->
                val term=q.text.toString().trim()
                if(term.isNotBlank()) mitsubishiGlobalFaultSearch(term)
                true
            }
        }

        val grid=GridLayout(this).apply{
            columnCount=2
            alignmentMode=GridLayout.ALIGN_BOUNDS
            useDefaultMargins=false
        }
        val categoryRows=((types.size+1)/2).coerceAtLeast(1)
        val reserve=(395*resources.displayMetrics.density).toInt()
        val categoryCardHeight=maxOf(
            (160*resources.displayMetrics.density).toInt(),
            (resources.displayMetrics.heightPixels-reserve)/categoryRows
        )
        val categoryPhotoHeight=maxOf(
            (105*resources.displayMetrics.density).toInt(),
            categoryCardHeight-(78*resources.displayMetrics.density).toInt()
        )
        fun render(){
            grid.removeAllViews()
            val term=q.text.toString().trim()
            types.filter{type->
                if(term.isBlank() || type.contains(term,true)) true
                else if(brand.equals("Daikin",true)){
                    daikinModels[type].orEmpty().any{model->
                        daikinGeneratedFaults(type,model).any{f->
                            "${f.code} ${f.symptom} ${f.meaning} ${f.causes} ${f.checks}".contains(term,true)
                        }
                    }
                }else if(brand.equals("Mitsubishi Electric",true)){
                    mitsubishiModels[type].orEmpty().any{model->
                        mitsubishiGeneratedFaults(type,model).any{f->
                            "${f.code} ${f.symptom} ${f.meaning} ${f.causes} ${f.checks}".contains(term,true)
                        }
                    }
                }else if(brand.equals("Midea",true)){
                    mideaModels[type].orEmpty().any{model->
                        mideaGeneratedFaults(type,model).any{f->
                            "${f.code} ${f.symptom} ${f.meaning} ${f.causes} ${f.checks}".contains(term,true)
                        }
                    }
                }else false
            }.forEach{type->
                val count=if(brand.equals("Daikin",true)) daikinModels[type].orEmpty().distinct().size
                    else if(brand.equals("Mitsubishi Electric",true)) mitsubishiModels[type].orEmpty().distinct().size
                    else if(brand.equals("Midea",true)) mideaModels[type].orEmpty().distinct().size
                    else if(brand.equals("Aermec",true)) aermecModels[type].orEmpty().distinct().size
                    else if(brand.equals("Airwell",true)) airwellModels[type].orEmpty().distinct().size
                    else if(brand.equals("AUX",true)) auxModels[type].orEmpty().distinct().size
                    else if(brand.equals("Ariston",true)) aristonModels[type].orEmpty().distinct().size
                    else if(brand.equals("Bosch",true)) boschModels[type].orEmpty().distinct().size
                    else if(brand.equals("Carrier",true)) carrierModels[type].orEmpty().distinct().size
                    else if(brand.equals("Climaveneta",true)) climavenetaModels[type].orEmpty().distinct().size
                    else if(brand.equals("Cooper&Hunter",true)) cooperHunterModels[type].orEmpty().distinct().size
                    else if(brand.equals("Fujitsu",true)) fujitsuModels[type].orEmpty().distinct().size
                    else if(brand.equals("General",true)) generalModels[type].orEmpty().distinct().size
                    else if(brand.equals("Gree",true)) greeModels[type].orEmpty().distinct().size
                    else if(brand.equals("Haier",true)) haierModels[type].orEmpty().distinct().size
                    else if(brand.equals("Hisense",true)) hisenseModels[type].orEmpty().distinct().size
                    else if(brand.equals("Hitachi",true)) hitachiModels[type].orEmpty().distinct().size
                    else if(brand.equals("Inventor",true)) inventorModels[type].orEmpty().distinct().size
                    else if(brand.equals("Lennox",true)) lennoxModels[type].orEmpty().distinct().size
                    else if(brand.equals("LG",true)) lgModels[type].orEmpty().distinct().size
                    else if(brand.equals("Mitsubishi Heavy",true)) mitsubishiHeavyModels[type].orEmpty().distinct().size
                    else if(brand.equals("Nordstar",true)) nordstarModels[type].orEmpty().distinct().size
                    else if(brand.equals("Panasonic",true)) panasonicModels[type].orEmpty().distinct().size
                    else if(brand.equals("Rhoss",true)) rhossModels[type].orEmpty().distinct().size
                    else if(brand.equals("Rotenso",true)) rotensoModels[type].orEmpty().distinct().size
                    else if(brand.equals("Samsung",true)) samsungModels[type].orEmpty().distinct().size
                    else if(brand.equals("Sharp",true)) sharpModels[type].orEmpty().distinct().size
                    else if(brand.equals("Sinclair",true)) sinclairModels[type].orEmpty().distinct().size
                    else if(brand.equals("TCL",true)) tclModels[type].orEmpty().distinct().size
                    else if(brand.equals("Tesla",true)) teslaModels[type].orEmpty().distinct().size
                    else if(brand.equals("Toshiba",true)) toshibaModels[type].orEmpty().distinct().size
                    else if(brand.equals("Toyotomi",true)) toyotomiModels[type].orEmpty().distinct().size
                    else if(brand.equals("Trane",true)) traneModels[type].orEmpty().distinct().size
                    else if(brand.equals("Vaillant",true)) vaillantModels[type].orEmpty().distinct().size
                    else if(brand.equals("Viessmann",true)) viessmannModels[type].orEmpty().distinct().size
                    else if(brand.equals("York",true)) yorkModels[type].orEmpty().distinct().size
                    else if(brand.equals("Pitsos",true)) pitsosModels[type].orEmpty().distinct().size
                    else if(brand.equals("Sendo",true)) sendoModels[type].orEmpty().distinct().size
                    else if(brand.equals("Morris",true)) morrisModels[type].orEmpty().distinct().size
                    else if(brand.equals("Juro-Pro",true)) juroProModels[type].orEmpty().distinct().size
                    else if(brand.equals("F&U",true)) fuModels[type].orEmpty().distinct().size
                    else if(brand.equals("United",true)) unitedModels[type].orEmpty().distinct().size
                    else if(brand.equals("Argo",true)) argoModels[type].orEmpty().distinct().size
                    else if(brand.equals("CIAT",true)) ciatModels[type].orEmpty().distinct().size
                    else 0
                val card=LinearLayout(this).apply{
                    orientation=LinearLayout.VERTICAL
                    setPadding(8,8,8,10)
                    background=GradientDrawable().apply{
                        setColor(Color.WHITE);cornerRadius=22f;setStroke(2,Color.rgb(225,232,240))
                    }
                    elevation=4f
                    val categoryPhoto=if(brand.equals("Daikin",true)) daikinCategoryPhotoRes(type) else 0
                    if(hasCategoryCoverLikeMitsubishi(brand)){
                        addView(categoryCoverLikeMitsubishi(brand,type,categoryPhotoHeight),LinearLayout.LayoutParams(-1,categoryPhotoHeight))
                    }else if(categoryPhoto!=0){
                        addView(hmtPhoto(categoryPhoto,categoryPhotoHeight),LinearLayout.LayoutParams(-1,categoryPhotoHeight))
                    }else if(brand.equals("Mitsubishi Electric",true)){
                        val coverModel=mitsubishiModels[type].orEmpty().firstOrNull()
                        if(coverModel!=null){
                            val photoH=categoryPhotoHeight
                            addView(mitsubishiRemotePhoto(type,coverModel,photoH),LinearLayout.LayoutParams(-1,photoH))
                        }
                    }else if(brand.equals("Midea",true)){
                        val coverModel=mideaModels[type].orEmpty().firstOrNull()
                        if(coverModel!=null){
                            val photoH=categoryPhotoHeight
                            addView(mideaRemotePhoto(type,coverModel,photoH),LinearLayout.LayoutParams(-1,photoH))
                        }
                    }else if(brand.equals("Aermec",true)){
                        val photoH=categoryPhotoHeight
                        addView(aermecCategoryPhoto(type,photoH),LinearLayout.LayoutParams(-1,photoH))
                    }else if(brand.equals("Airwell",true)){
                        val photoH=categoryPhotoHeight
                        addView(airwellCategoryPhoto(type,photoH),LinearLayout.LayoutParams(-1,photoH))
                    }else if(researchedBrand){
                        val photoH=categoryPhotoHeight
                        addView(verifiedBrandCategoryPhoto(brand,type,photoH),LinearLayout.LayoutParams(-1,photoH))
                    }else{
                        addView(ImageView(this@MainActivity).apply{
                            val id=faultTypeIconRes(type)
                            if(id!=0) setImageResource(id)
                            scaleType=ImageView.ScaleType.CENTER_INSIDE
                            setPadding(18,18,18,18)
                            contentDescription="$brand • $type"
                        },LinearLayout.LayoutParams(-1,categoryPhotoHeight))
                    }
                    addView(TextView(this@MainActivity).apply{
                        text=type;textSize=14f;typeface=uiFont(true);setTextColor(Color.rgb(10,55,105))
                        setPadding(3,5,3,1);gravity=Gravity.CENTER
                        maxLines=2
                    })
                    addView(TextView(this@MainActivity).apply{
                        text="$count σειρές";textSize=10.5f;setTextColor(Color.rgb(0,112,190));gravity=Gravity.CENTER
                    })
                    setOnClickListener{faultSeriesScreen(brand,type)}
                }
                grid.addView(card,GridLayout.LayoutParams().apply{
                    width=0
                    height=categoryCardHeight
                    columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f)
                    setMargins(5,5,5,5)
                })
            }
        }
        q.addTextChangedListener(object:android.text.TextWatcher{
            override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}
            override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){render()}
            override fun afterTextChanged(s:android.text.Editable?){}
        })
        if(brand.equals("Daikin",true)){
            q.imeOptions=android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
            q.setOnEditorActionListener{_,_,_->
                val term=q.text.toString().trim()
                if(term.isNotBlank()) daikinGlobalFaultSearch(term)
                true
            }
        }
        r.addView(scroll(grid),LinearLayout.LayoutParams(-1,0,1f))
        setContentView(r);render()
    }


    // ===== DAIKIN 2026 – επίσημος ευρωπαϊκός κατάλογος μοντέλων =====
    // Πηγές: Daikin Europe General Catalogue 2026 + Daikin Global Error Code List SM-TS3.
    private val daikinModels: Map<String,List<String>> = mapOf(
        "Split / Inverter" to listOf(
            "Ururu Sarara • FTXZ-N + RXZ-N",
            "Daikin Emura • FTXJ-AW/S/B9 + RXJ-A9",
            "Stylish • C/FTXA-DG/P/L/C/Y + RXA-A8/B8",
            "Stylish • C/FTXA-CW/S/B + RXA-A8/B8",
            "Perfera • C/FTXM-A + RXM-A9/A8",
            "Comfora • FTXP-N(9) + RXP-N9/N8",
            "Sensira • FTXF-F + RXF-F/D9",
            "Sensira • FTXC-E + RXC-E",
            "Floor Standing • C/FVXM-B + RXM-A9/A8",
            "Nepura • FTXTJ-A + RXTJ-A",
            "Nepura Stylish • FTXTA-DG/L/P/Y + RXTA-C",
            "Nepura Stylish • FTXTA-CW/B + RXTA-C",
            "Nepura Perfera • FTXTM-A + RXTM-A",
            "Nepura Comfora • FTXTP-A + RXTP-A",
            "Nepura Floor • FVXTM-B + RXTM-A",
            "Siesta • ATXM-A + ARXM-A9/A8",
            "Siesta • ATXP-N9 + ARXP-N9",
            "Siesta • ATXF-F + ARXF-F/A9",
            "Siesta • ATXC-E + ARXC-E"
        ),
        "Multi-Split" to listOf(
            "2MXM40A9",
            "2MXM50-68A8",
            "3MXM40-52-68A8",
            "4MXM68-80A8",
            "5MXM90A8",
            "Multi+ • 4MWXM-A9",
            "Multi+ • 5MWXM68-90A9",
            "Multi+ DHW • EKHWET-BV3",
            "Multi+ DHW • CKHWS-BV3",
            "Sensira Multi • 2-3MXF-A(9)",
            "Siesta Multi • 2/3AMXM-M9/N9",
            "Siesta Multi • 2-3AMXF-A"
        ),
        "SkyAir / Επαγγελματικό" to listOf(
            "Sky Air Alpha • RZAG-B",
            "Sky Air Alpha • RZAG-NV1/NY1",
            "Sky Air Advance • RZASG-MV(1)/MY(1)",
            "Sky Air Advance Large • RZA-D",
            "Sky Air Active • ARXM-A",
            "Sky Air Active • AZAS-MV/MY",
            "Cassette • FCAHG-H",
            "Cassette • FCAG-B",
            "Fully Flat Cassette • FFA-A9",
            "Ducted • FDXM-F9",
            "Ducted • FBA-A(9)",
            "Ducted • FDA125A",
            "Ducted • FDA200-250A",
            "Ducted • ADEA-A",
            "Wall • FAA-B",
            "Wall Perfera • FTXM-A",
            "Ceiling Suspended • FHA-A(9)",
            "4-way Ceiling Suspended • FUA-A",
            "Floor Standing • FVA-A",
            "Concealed Floor • FNA-A9"
        ),
        "Καναλάτο" to listOf(
            "Residential Ducted • FDXM-F9 + RXM-A9/A8",
            "Sky Air Ducted • FDXM-F9",
            "Sky Air Ducted • FBA-A(9)",
            "Sky Air Ducted • FDA125A",
            "Sky Air Ducted • FDA200-250A",
            "Sky Air Ducted • ADEA-A",
            "VRV Ducted • FXDA-A",
            "VRV Ducted • FXSA-A",
            "VRV High ESP • FXMA-A"
        ),
        "Κασέτα" to listOf(
            "Sky Air High COP Cassette • FCAHG-H",
            "Sky Air Round Flow Cassette • FCAG-B",
            "Sky Air Fully Flat Cassette • FFA-A9",
            "VRV Round Flow Cassette • FXFA-A",
            "VRV Fully Flat Cassette • FXZA-A",
            "VRV 1-way Cassette • FXKA-A"
        ),
        "VRV / VRF" to listOf(
            "VRV 5 Heat Recovery • REYA-A9",
            "VRV 5 Heat Pump • RXYA-A",
            "VRV 5 S-series • RXYSA-AV1/AY1/A",
            "VRV 5 • SV-A",
            "CO₂ VRV • RXYN-B",
            "VRV IV Heat Pump • RXYQ-T8",
            "VRV Indoor Cassette • FXFA-A",
            "VRV Indoor Cassette • FXZA-A",
            "VRV Indoor Cassette • FXKA-A",
            "VRV Indoor Ducted • FXDA-A",
            "VRV Indoor Ducted • FXSA-A",
            "VRV Indoor Ducted • FXMA-A",
            "VRV Indoor Wall • FXAA-A",
            "VRV Indoor Ceiling • FXHA-A",
            "VRV Indoor 4-way Ceiling • FXUA-A",
            "VRV Indoor Floor • FXNA-A",
            "CO₂ VRV Indoor • FXFN-B",
            "CO₂ VRV Indoor • FXSN-B"
        ),
        "Αντλία θερμότητας" to listOf(
            "Altherma 4 H • EPSK-A + EPVX/Z",
            "Altherma 4 H ECH₂O • EPSK-A + EPSX(B)",
            "Altherma 4 H Wall • EPSK-A + EPBX",
            "Altherma 3 H MT • EPRA-EV3/W1 + ETVH/X/Z16-E7",
            "Altherma 3 H MT ECH₂O • EPRA-EV3/W1 + ETSH(B)/X(B)16-E7",
            "Altherma 3 H MT Wall • EPRA-EV3/W1 + ETBH/X16-E7",
            "Altherma 3 H HT • EPRA-DV3/W1 + ETVH/X/Z12-E",
            "Altherma 3 H HT ECH₂O • EPRA-DV3/W1 + ETSH(B)/X(B)12-P-E",
            "Altherma 3 H HT Wall • EPRA-DV3/W1 + ETBH/X12-E",
            "Altherma 3 R 4-8kW • ERGA-E + EHVH/X/Z-E",
            "Altherma 3 R 4-8kW ECH₂O • ERGA-E + EHSH/X(B)-E",
            "Altherma 3 R 4-8kW Wall • ERGA-E + EHBH/X-E",
            "Altherma 3 R 11-16kW • ERLA-D + EBVH/X/Z-D",
            "Altherma 3 R 11-16kW ECH₂O • ERLA-D + EBSH(B)/X(B)-D",
            "Altherma 3 R 11-16kW Wall • ERLA-D + EBBH/EBBX-D",
            "Altherma 3 R MT • ERRA-EV3/W1 + ELVH/X/Z-E",
            "Altherma 3 R MT ECH₂O • ERRA-EV3/W1 + ELSH(B)/X(B)-E",
            "Altherma 3 R MT Wall • ERRA-EV3/W1 + ELBH/X-E",
            "Altherma 3 M 9-16kW • EBLA-D / EDLA-D",
            "Altherma 3 M 4-8kW • EBLA-E / EDLA-E",
            "Altherma 3 R 3kW • ERLA03DV + EHFH/Z03-S18D3V",
            "Altherma R Hybrid • EVLQ-CV3 + EHYHBH-AV32",
            "Altherma H Hybrid • EJHA-AV3 + EHY2KOMB28/32",
            "Altherma 3 GEO • EGSAH/X-(U)E9W / D9W",
            "Altherma 3 WS • EWSAH/X-(U)E3V / D9W"
        ),
        "Rooftop" to listOf(
            "UATYA-BBAY1",
            "UATYA-BFC2Y1",
            "UATYA-BFC3Y1",
            "UATYA-BRS4"
        ),
        "Chiller / Ψύκτης" to listOf(
            "EWAA-DV3P","EWAA-DW1P","EWAA-DV3P-H","EWAA-DW1P-H",
            "EWAT-CZ","EWAS-TZ D","EWAT-B-SSB/SLB","EWAT-B-SRB","EWAT-B-XSB/XLB","EWAT-B-XRB",
            "EWAT-B-SSC","EWAT-B-SRC","EWAT-B-XSC","EWAT-B-XRC","EWAD-TZ D","EWAH-TZ D",
            "EWFT-B-SSC","EWFT-B-SRC","EWFT-B-XSC","EWFT-B-XRC","EWFD-TZ D","EWFH-TZ D","EWFS-TZ D",
            "EWYA-DV3P","EWYA-DW1P","EWYA-DW1P-H","EWYA-DV3P-H","EWYT-CZ","EWYE-CZ",
            "EWYT-B-SS/SL","EWYT-B-SR","EWYT-B-XS/XL","EWYT-B-XR","EWYT-CZI / EWYT-CZO",
            "EWYD-BZSS","EWYD-BZSL","EWYS-4Z","ERAD-E-SS","ERAD-E-SL",
            "EW(W-H-L)T-Q-A","EWWQ-KC","EWWD-J-SS","EWWH-J-SS","EWWS-J-SS",
            "EWWD-VZ","EWWH-VZ","EWWS-VZ","EWLQ-KC","EWLD-J-SS","EWLH-J-SS","EWLS-J-SS","EWLD-I-SS",
            "EWWD-DZ","EWWH-DZ","EWWS-DZ","DWSC C Series","DWDC C Series"
        ),
        "Αερισμός / HRV" to listOf(
            "VAM150FC9","VAM250FC9","VAM350J8","VAM500J8","VAM650J8","VAM800J8",
            "VAM1000J8","VAM1500J8","VAM2000J8",
            "EKVDX","VKM-GBM","VKM-JM","Compact L","Compact T","ERA-AV/AY/AYF"
        ),
        "Ψύξη / Refrigeration" to listOf(
            "LMS / LMC","PS / PC","GM R290 Water-Cooled","SB R290 Water-Cooled",
            "GS Bi-Block","SP-O Bi-Block","DB-O Bi-Block",
            "JEHCCU / JEHSCU","GCU / HCU","CO₂ ZEAS","R-410A ZEAS","NV58+","NV66+",
            "Smart Rack","Mini Smart Duplex","Smart Duplex","CO₂ Conveni-Pack","CO₂ Cascade",
            "R-410A Conveni-Pack","SAS-SAR","UAV","USV"
        ),
        "Fan Coil / Hydronic" to listOf(
            "Altherma HPC Floor Standing",
            "Altherma HPC Wall Mounted",
            "Altherma HPC Concealed",
            "FWXV-ATV3 Floor Standing HPC",
            "FWXT-ATV3 Wall Mounted HPC",
            "FWXM-ATV3 Concealed HPC"
        ),
        "Boiler / Hybrid" to listOf(
            "Altherma 3 C Gas • D2C / TND",
            "Altherma 3 C Gas • D2CNL",
            "Altherma C Gas W",
            "Altherma H Hybrid • EJHA-AV3 + EHY2KOMB28/32",
            "Altherma R Hybrid + Multi • EVLQ-CV3 + EHYHBH-AV32",
            "Hybrid Multi • CHYHBH-AV32 / EHYKOMB-AA2/3"
        ),
        "Air Handling Unit / AHU" to listOf(
            "Compact L","Compact T","ALD-HEFB",
            "ERA-AV","ERA-AY","ERA-AYF",
            "Daikin AHU with DX connection","Professional AHU","Modular P","Modular R"
        ),
        "Air Purifier" to listOf(
            "AAF AstroPure 2000 • BR00000554",
            "AAF AstroPure 2000 • BR00000676",
            "AAF AstroPure 2000 • BR00000749",
            "AAF AstroPure 2000 • BR00000751"
        ),
        "Controls / BMS" to listOf(
            "Madoka Plus","Madoka / BRC1H","Onecta",
            "Intelligent Touch Manager","DIII-Net interfaces",
            "KRP2A / KRP4A","DTA104A","BPMKS967A / BPMKS967A2"
        )
    )

    private data class DaikinCode(val code:String,val meaning:String,val causes:String,val checks:String)

    // Daikin Global SM-TS3: RA, SkyAir, VRV, PA και Heat Reclaim Ventilator.
    // Η Daikin προειδοποιεί ότι η ακριβής σημασία μπορεί να διαφέρει ελαφρά ανά μοντέλο.
    private val daikinAirCodes = listOf(
        DaikinCode("A0","Ενεργοποιήθηκε εξωτερική διάταξη προστασίας","Εξωτερικό interlock/protection input.","Έλεγξε external protection contacts και field wiring."),
        DaikinCode("A1","Βλάβη PCB εσωτερικής μονάδας","Indoor PCB, τροφοδοσία ή εσωτερική επικοινωνία PCB.","Έλεγξε τροφοδοσία, connectors και PCB."),
        DaikinCode("A3","Ανωμαλία συστήματος στάθμης αποχέτευσης","Float switch, drain pump, βούλωμα αποχέτευσης.","Έλεγξε λεκάνη, float, αντλία και σωλήνα drain."),
        DaikinCode("A5","Freeze-up / high-pressure control","Πάγος εναλλάκτη, ανεπαρκής ροή αέρα ή υψηλή πίεση στη θέρμανση.","Έλεγξε φίλτρα, fan, coil, θερμίστορ και λειτουργικές πιέσεις."),
        DaikinCode("A6","Βλάβη μοτέρ ανεμιστήρα εσωτερικής","Motor, feedback/Hall, connector, PCB.","Έλεγξε ελεύθερη περιστροφή, τροφοδοσία και feedback."),
        DaikinCode("A7","Βλάβη μοτέρ swing flap","Flap motor, μηχανικό μπλοκάρισμα, connector.","Έλεγξε πτερύγια, μοτέρ και καλωδίωση."),
        DaikinCode("A8","Βλάβη τροφοδοσίας ή AC input overcurrent","Τροφοδοσία, υπερένταση, PCB.","Μέτρησε τάση/ρεύμα και έλεγξε τροφοδοσία."),
        DaikinCode("A9","Βλάβη ηλεκτρονικής εκτονωτικής εσωτερικής","EEV coil, connector, valve body, PCB.","Έλεγξε coil resistance, connector και λειτουργία EEV."),
        DaikinCode("AF","Όριο/ανωμαλία στάθμης αποχέτευσης","Drain level ή pump system.","Έλεγξε λεκάνη, float, pump και drain."),
        DaikinCode("AH","Βλάβη συστήματος καθαρισμού αέρα / dust collector","Air cleaner module ή σχετική καλωδίωση.","Έλεγξε module, filter/dust collector και connector."),
        DaikinCode("AJ","Λάθος capacity setting εσωτερικής PCB","Capacity adaptor/PCB setting.","Έλεγξε model/capacity setting και PCB."),
        DaikinCode("C1","Αποτυχία επικοινωνίας indoor main/sub PCB","Connector, sub PCB, main PCB.","Έλεγξε harness και boards."),
        DaikinCode("C4","Βλάβη thermistor υγρού εναλλάκτη","Thermistor open/short ή wiring.","Μέτρησε αντίσταση thermistor και connector."),
        DaikinCode("C5","Βλάβη thermistor αερίου εναλλάκτη","Thermistor open/short ή wiring.","Μέτρησε thermistor και καλωδίωση."),
        DaikinCode("C6","Βλάβη fan motor sensor / fan control driver","Motor feedback ή driver PCB.","Έλεγξε motor, feedback και driver."),
        DaikinCode("C7","Βλάβη μοτέρ μπροστινού panel","Panel motor, limit/position, mechanical jam.","Έλεγξε panel mechanism και motor."),
        DaikinCode("C8","Βλάβη αισθητήρα AC input current","Current sensor ή PCB.","Έλεγξε current sensing circuit."),
        DaikinCode("C9","Βλάβη suction/room air thermistor","Room thermistor open/short.","Μέτρησε αισθητήρα και wiring."),
        DaikinCode("CA","Βλάβη discharge air thermistor","Outlet air thermistor.","Έλεγξε sensor/connector."),
        DaikinCode("CC","Βλάβη humidity sensor","Humidity sensor ή PCB.","Έλεγξε sensor και wiring."),
        DaikinCode("CJ","Βλάβη room thermistor στο χειριστήριο","Remote controller thermistor.","Έλεγξε remote/controller sensor."),
        DaikinCode("E0","Ενεργοποίηση προστασίας εξωτερικής μονάδας","Outdoor protection chain.","Έλεγξε υποκωδικό και προστασίες outdoor."),
        DaikinCode("E1","Βλάβη PCB εξωτερικής μονάδας","Outdoor PCB/power supply.","Έλεγξε board supply, fuses, connectors."),
        DaikinCode("E3","Ενεργοποίηση high-pressure switch","Υψηλή πίεση, airflow/waterflow, fan, overcharge.","Έλεγξε HPS, condenser/coil, fan και charge."),
        DaikinCode("E4","Ενεργοποίηση low-pressure switch","Χαμηλή πίεση, έλλειψη ψυκτικού, restriction.","Έλεγξε LPS, διαρροές, charge, EEV/restriction."),
        DaikinCode("E5","Overheat/overload inverter compressor","Compressor overload, inverter, refrigerant conditions.","Έλεγξε compressor current, winding/insulation και κύκλωμα."),
        DaikinCode("E6","STD compressor overcurrent / lock","Locked compressor, wiring, supply.","Έλεγξε compressor, contactor/inverter και τροφοδοσία."),
        DaikinCode("E7","Βλάβη outdoor fan motor system","Fan motor, driver PCB, obstruction.","Έλεγξε φτερωτή, motor, feedback και driver."),
        DaikinCode("E8","Overcurrent inverter compressor","Υπερένταση compressor/inverter.","Μέτρησε ρεύμα, compressor και inverter."),
        DaikinCode("E9","Βλάβη coil ηλεκτρονικής εκτονωτικής outdoor","EEV coil/valve/PCB.","Έλεγξε coil, connector και valve movement."),
        DaikinCode("EA","Βλάβη τετράοδης / αλλαγής ψύξη-θέρμανση","4-way valve, coil, pressure conditions.","Έλεγξε coil, τάση, αλλαγή πιέσεων και valve."),
        DaikinCode("F3","Ανωμαλία θερμοκρασίας σωλήνα κατάθλιψης","Υψηλή discharge temp, low charge, compressor, sensor.","Έλεγξε discharge thermistor, superheat, charge και compressor."),
        DaikinCode("F6","Ανώμαλη υψηλή πίεση / υπερφόρτιση ψυκτικού","Overcharge, poor heat exchange, airflow.","Έλεγξε charge, condenser/coil, fan και subcooling."),
        DaikinCode("H0","Βλάβη sensor system συμπιεστή","Sensor system/compressor related.","Έλεγξε σχετικούς sensors και connectors."),
        DaikinCode("H3","Βλάβη high-pressure switch","HPS circuit/wiring.","Έλεγξε HPS continuity και harness."),
        DaikinCode("H4","Βλάβη low-pressure switch","LPS circuit/wiring.","Έλεγξε LPS και harness."),
        DaikinCode("H6","Βλάβη position detection sensor συμπιεστή","Compressor position feedback / inverter.","Έλεγξε compressor wiring και inverter feedback."),
        DaikinCode("H7","Βλάβη σήματος outdoor fan motor","Fan feedback / motor / PCB.","Έλεγξε motor signal και driver."),
        DaikinCode("H8","Βλάβη compressor input CT/current sensor","Current transformer/sensing PCB.","Έλεγξε CT και sensing circuit."),
        DaikinCode("H9","Βλάβη outdoor air thermistor","Outdoor ambient thermistor.","Μέτρησε sensor και connector."),
        DaikinCode("J2","Βλάβη current sensor συμπιεστή","Current sensor/PCB.","Έλεγξε sensing circuit."),
        DaikinCode("J3","Βλάβη discharge pipe thermistor","Discharge thermistor/wiring.","Μέτρησε sensor και connector."),
        DaikinCode("J5","Βλάβη suction pipe thermistor","Suction thermistor/wiring.","Μέτρησε sensor."),
        DaikinCode("J6","Βλάβη heat exchanger thermistor","Outdoor heat exchanger thermistor.","Μέτρησε sensor και wiring."),
        DaikinCode("J8","Βλάβη thermistor ψυκτικού κυκλώματος","Liquid/refrigerant thermistor ανά μοντέλο.","Έλεγξε sensor σύμφωνα με wiring diagram."),
        DaikinCode("J9","Βλάβη thermistor ψυκτικού κυκλώματος","Gas/refrigerant thermistor ανά μοντέλο.","Έλεγξε sensor σύμφωνα με manual."),
        DaikinCode("JA","Βλάβη high-pressure sensor","Pressure transducer/wiring.","Σύγκρινε reading με μανόμετρο και έλεγξε wiring."),
        DaikinCode("JC","Βλάβη low-pressure sensor","Pressure transducer/wiring.","Σύγκρινε reading με πραγματική πίεση."),
        DaikinCode("L0","Βλάβη inverter system","Inverter PCB/power module/compressor.","Έλεγξε inverter diagnostics και compressor."),
        DaikinCode("L1","Βλάβη inverter PCB","PCB/power module.","Έλεγξε DC bus, PCB και power module."),
        DaikinCode("L3","Άνοδος θερμοκρασίας ηλεκτρικού κουτιού","Cooling/ventilation, ambient, PCB.","Έλεγξε airflow και temperature sensors."),
        DaikinCode("L4","Άνοδος θερμοκρασίας ψύκτρας inverter","Heat sink, fan, thermistor, load.","Έλεγξε ψύκτρα, fan και thermistor."),
        DaikinCode("L5","Instantaneous overcurrent inverter DC output","Compressor/inverter overcurrent.","Έλεγξε compressor insulation/windings και inverter."),
        DaikinCode("L6","Instantaneous overcurrent inverter AC output","Compressor/inverter output fault.","Έλεγξε output wiring, compressor και module."),
        DaikinCode("L7","Συνολικό input overcurrent","Supply/load overcurrent.","Μέτρησε συνολικό ρεύμα και φορτία."),
        DaikinCode("L8","Overcurrent inverter compressor","Compressor overload/current.","Έλεγξε current και compressor."),
        DaikinCode("L9","Inverter compressor startup error","Stall/start failure, compressor, inverter.","Έλεγξε pressures, compressor και inverter."),
        DaikinCode("LC","Transmission control PCB ↔ inverter PCB","Harness, control PCB, inverter PCB.","Έλεγξε communication harness/connectors."),
        DaikinCode("P1","Power voltage imbalance / inverter PCB","Τάση, φάσεις, inverter.","Μέτρησε supply και phase balance."),
        DaikinCode("P3","Switch-box thermistor abnormality","Thermistor/PCB.","Έλεγξε sensor."),
        DaikinCode("P4","Radiation-fin temperature sensor fault","Heat sink thermistor/wiring.","Μέτρησε thermistor."),
        DaikinCode("PJ","Λάθος συνδυασμός inverter/fan driver ή capacity setting","Wrong board/setting/combination.","Έλεγξε replacement PCB και model settings."),
        DaikinCode("U0","Έλλειψη ψυκτικού","Leak/undercharge/restriction.","Leak test, charge verification, SH/SC όπου εφαρμόζεται."),
        DaikinCode("U1","Αντίστροφη ή ανοικτή φάση","Phase sequence/open phase.","Έλεγξε 3φ τροφοδοσία και phase sequence."),
        DaikinCode("U2","Βλάβη τροφοδοσίας / στιγμιαία διακοπή","Under/over-voltage, DC bus, phase issue.","Μέτρησε supply/DC bus και connections."),
        DaikinCode("U3","Check operation δεν εκτελέστηκε / transmission error","Commissioning/check operation incomplete.","Εκτέλεσε προβλεπόμενο check operation."),
        DaikinCode("U4","Επικοινωνία indoor ↔ outdoor","Power off, F1/F2/interconnect wiring, PCB.","Έλεγξε τροφοδοσίες, communication wiring και PCB."),
        DaikinCode("U5","Επικοινωνία indoor ↔ remote controller","P1/P2/remote wiring/controller.","Έλεγξε remote bus και controller."),
        DaikinCode("U7","Επικοινωνία μεταξύ outdoor units","Outdoor communication bus/PCB.","Έλεγξε inter-outdoor wiring/settings."),
        DaikinCode("U8","Επικοινωνία μεταξύ remote controllers","Main/sub controller wiring/setting.","Έλεγξε controller addresses/settings."),
        DaikinCode("U9","Transmission fault σε άλλο indoor του ίδιου συστήματος","Άλλη μονάδα στο group έχει communication fault.","Έλεγξε όλα τα indoor/outdoor του group."),
        DaikinCode("UA","Ακατάλληλος συνδυασμός indoor/outdoor","Wrong capacity/model/number/configuration.","Έλεγξε compatibility και field settings."),
        DaikinCode("UC","Λάθος/διπλή διεύθυνση centralized control","Duplicate/incorrect address.","Έλεγξε addressing."),
        DaikinCode("UE","Επικοινωνία indoor ↔ centralized controller","DIII/central bus wiring/address.","Έλεγξε bus και addresses."),
        DaikinCode("UF","Το σύστημα δεν έχει ρυθμιστεί / piping-wiring mismatch","Commissioning, piping/wiring mismatch.","Έλεγξε αντιστοίχιση σωληνώσεων-καλωδίων και test operation."),
        DaikinCode("UH","Γενική βλάβη συστήματος","System configuration/communication.","Έλεγξε sub-code και system setup.")
    )

    private val daikinHeatPumpCodes = listOf(
        DaikinCode("7H-00","Ανωμαλία ροής νερού","Χαμηλή ροή, φίλτρο, αέρας, βάνες, pump/flow sensor.","Έλεγξε flow rate, φίλτρο, εξαέρωση, βάνες, pump και flow sensor."),
        DaikinCode("7H-01","Ανωμαλία ροής νερού κατά τη λειτουργία","Ανεπαρκής παροχή ή διακοπή ροής.","Έλεγξε υδραυλικό κύκλωμα και ελάχιστη απαιτούμενη παροχή."),
        DaikinCode("7H-04","Πρόβλημα ροής κατά παραγωγή ΖΝΧ","Η ελάχιστη ροή DHW δεν επιτυγχάνεται.","Έλεγξε βάνες, φίλτρο, pump, flow sensor και κύκλωμα ΖΝΧ."),
        DaikinCode("7H-05","Πρόβλημα ροής κατά θέρμανση χώρου","Η ελάχιστη ροή θέρμανσης δεν επιτυγχάνεται.","Έλεγξε emitters, βάνες, φίλτρο, pump και balancing."),
        DaikinCode("7H-06","Πρόβλημα ροής κατά ψύξη","Η ελάχιστη ροή ψύξης δεν επιτυγχάνεται.","Έλεγξε κύκλωμα ψύξης νερού, βάνες, pump και φίλτρο."),
        DaikinCode("8H","Υψηλή θερμοκρασία νερού εξόδου","Control/flow/heater/sensor abnormality.","Έλεγξε LWT sensor, flow, heater control και setpoints."),
        DaikinCode("A1","Βλάβη PCB","PCB, τροφοδοσία ή connector.","Έλεγξε τροφοδοσία, connectors και σχετική PCB."),
        DaikinCode("A5","Προστασία freeze-up / high pressure","Flow/airflow, αισθητήρας, ψυκτικό κύκλωμα.","Έλεγξε εναλλάκτη, flow/airflow, αισθητήρες και πιέσεις."),
        DaikinCode("AA","Back-up heater overheat","Χαμηλή ροή, thermostat, heater relay/control.","Έλεγξε flow, θερμοστάτες ασφαλείας και heater circuit."),
        DaikinCode("AH","Η λειτουργία απολύμανσης/θέρμανσης δεν ολοκληρώθηκε","Θερμοκρασία tank, heater, χρόνος ή control.","Έλεγξε tank sensor, booster/backup heater και ρυθμίσεις disinfection."),
        DaikinCode("C0-00","Ανίχνευση ροής ενώ ο κυκλοφορητής είναι OFF","Flow sensor, παράσιτη ροή, υδραυλική σύνδεση.","Έλεγξε sensor και πραγματική ροή με pump stopped."),
        DaikinCode("C4","Βλάβη thermistor εναλλάκτη","Open/short sensor ή wiring.","Μέτρησε αντίσταση sensor και καλωδίωση."),
        DaikinCode("C5","Βλάβη thermistor σωλήνα/εναλλάκτη","Open/short sensor ή wiring.","Μέτρησε thermistor και connector."),
        DaikinCode("C9","Βλάβη thermistor εισόδου/χώρου","Sensor open/short.","Έλεγξε sensor και καλωδίωση."),
        DaikinCode("E1","Βλάβη outdoor PCB","PCB, supply, fuse/connector.","Έλεγξε τροφοδοσία και outdoor PCB."),
        DaikinCode("E3","High pressure protection","Χαμηλό airflow/waterflow, fan, overcharge, restriction.","Έλεγξε flow/airflow, fan, charge και high-pressure circuit."),
        DaikinCode("E4","Low pressure protection","Έλλειψη ψυκτικού, restriction, EEV.","Έλεγξε διαρροές, charge, EEV και restriction."),
        DaikinCode("E5","Compressor overload/overheat","Compressor, inverter, ψυκτικές συνθήκες.","Έλεγξε ρεύμα, winding/insulation και pressures."),
        DaikinCode("E6","Compressor start/overcurrent abnormality","Locked compressor, supply, inverter.","Έλεγξε compressor, τροφοδοσία και drive."),
        DaikinCode("E7","Outdoor fan motor abnormality","Fan motor/driver/obstruction.","Έλεγξε φτερωτή, motor, feedback και PCB."),
        DaikinCode("E8","Inverter compressor overcurrent","Compressor/inverter overload.","Μέτρησε ρεύμα και έλεγξε compressor/inverter."),
        DaikinCode("E9","Electronic expansion valve abnormality","EEV coil, valve, connector, PCB.","Έλεγξε coil, connector και λειτουργία EEV."),
        DaikinCode("EA","4-way valve / heating-cooling switching abnormality","4-way valve, coil, refrigerant circuit.","Έλεγξε coil και μεταβολή θερμοκρασιών/πιέσεων."),
        DaikinCode("F3","Discharge pipe temperature abnormality","Low refrigerant, compressor, thermistor.","Έλεγξε discharge thermistor, charge και compressor."),
        DaikinCode("F6","High pressure control in cooling","Airflow, fan, coil, overcharge.","Έλεγξε outdoor coil, fan και charge."),
        DaikinCode("H0","Sensor system abnormality","Outdoor sensor/PCB.","Έλεγξε sensors και connectors."),
        DaikinCode("H3","High pressure switch abnormality","HPS/wiring/high pressure.","Έλεγξε switch, wiring και πραγματική πίεση."),
        DaikinCode("H6","Compressor position/current detection abnormality","Compressor/inverter/wiring.","Έλεγξε compressor leads, winding και inverter."),
        DaikinCode("H8","Compressor current sensor abnormality","Current sensor/PCB.","Έλεγξε sensing circuit και PCB."),
        DaikinCode("H9","Outdoor air thermistor abnormality","Thermistor open/short.","Μέτρησε sensor και connector."),
        DaikinCode("J3","Discharge pipe thermistor abnormality","Sensor/wiring.","Μέτρησε discharge sensor."),
        DaikinCode("J6","Heat exchanger thermistor abnormality","Sensor/wiring.","Μέτρησε heat exchanger thermistor."),
        DaikinCode("JA","High pressure sensor abnormality","Pressure sensor/wiring.","Έλεγξε sensor, connector και πραγματική πίεση."),
        DaikinCode("L3","Electrical box temperature rise","Cooling/airflow/PCB.","Έλεγξε ψύξη ηλεκτρονικών και θερμοκρασία."),
        DaikinCode("L4","Inverter fin temperature rise","Heatsink cooling, fan, PCB.","Έλεγξε heatsink, airflow και inverter."),
        DaikinCode("L5-00","Compressor overcurrent","Compressor/inverter/current overload.","Έλεγξε ρεύμα, winding/insulation και inverter."),
        DaikinCode("P4","Inverter fin thermistor abnormality","Thermistor/PCB.","Έλεγξε sensor και inverter board."),
        DaikinCode("U0","Έλλειψη ψυκτικού / refrigerant shortage detection","Διαρροή, ανεπαρκής φόρτιση, restriction.","Leak test, έλεγξε charge και λειτουργικές τιμές."),
        DaikinCode("U2","Power supply / DC voltage abnormality","Under/over-voltage, phase, inverter.","Μέτρησε AC supply και DC bus."),
        DaikinCode("U4","Communication indoor/hydro ↔ outdoor","Power, communication wiring, PCB.","Έλεγξε τροφοδοσίες, interconnect και communication line."),
        DaikinCode("U7","Outdoor/PCB communication abnormality","Communication bus/PCB.","Έλεγξε connectors, bus και boards."),
        DaikinCode("U8","User interface / controller communication abnormality","Controller bus, firmware, wiring.","Έλεγξε controller, wiring και communication."),
        DaikinCode("UA","Λάθος συνδυασμός/διαμόρφωση μονάδων","Wrong model/capacity/configuration.","Έλεγξε compatibility και field settings.")
    )


    private fun daikinGeneratedFaults(type:String, model:String):List<Fault>{
        val codes = if(type=="Αντλία θερμότητας") daikinHeatPumpCodes
                    else if(type=="Chiller / Ψύκτης" || type=="Rooftop" || type=="Ψύξη / Refrigeration")
                        daikinAirCodes // κοινή Daikin self-diagnosis βάση· το ακριβές sub-code ελέγχεται στο manual του model
                    else daikinAirCodes
        val src = when(type){
            "Αντλία θερμότητας" -> "Daikin technical reference set • τεχνική αναφορά Daikin • έλεγχος detail/sub-code στο επίσημο PDF"
            else -> "Daikin self-diagnosis reference • χρησιμοποίησε το επίσημο PDF για detail/sub-code της σειράς"
        }
        return codes.map{c->
            Fault(
                "Daikin", c.code, c.meaning, c.meaning,
                c.causes,
                c.checks + " Πριν από ανταλλακτικό, επιβεβαίωσε το detail/sub-code στο manual του $model.",
                "Ακολούθησε τη διαδικασία service του συγκεκριμένου μοντέλου. Μην αντικαθιστάς PCB/συμπιεστή μόνο από τον βασικό κωδικό.",
                type, model, src
            )
        }
    }


    // ===== MITSUBISHI ELECTRIC – επίσημες σειρές από Mitsubishi Electric Greece =====
    private val mitsubishiModels: Map<String,List<String>> = mapOf(
        "Split / Inverter" to listOf(
            "Kirigamine Style • MSZ-LN","MSZ-AY","MSZ-BT","MSZ-DW","MSZ-AP","MSZ-HR",
            "Kirigamine Zen • MSZ-EF","Hyper Heating • MSZ-FT","Hyper Heating • MSZ-RW",
            "Floor • MFZ-KT","Hyper Heating Floor • MFZ-KW"
        ),
        "Multi-Split" to listOf("MXZ-F","MXZ-H","Hyper Heating • MXZ-F VGHZ","Ecodan Multi Comfort • PXZ-4F75VG","Ecodan Multi Comfort • PXZ-5F85VG"),
        "Καναλάτο" to listOf("SEZ-M • DA(L)","PEAD-M • JA(L)","PEA-M"),
        "Κασέτα" to listOf("1-way Cassette • MLZ-KP","2×2 Cassette • SLZ-M FA","4-way Cassette • PLA-M EA"),
        "Επαγγελματικό / Mr Slim" to listOf(
            "Wall Mounted • PKA-M KA/LA","Ceiling Suspended • PCA-M KA","Professional Kitchen • PCA-M HA",
            "Floor Standing • PSA-M","Power Inverter • PUZ-ZM","Standard Inverter • PUZ-M / SUZ-M"
        ),
        "VRF / VRV" to listOf(
            "CITY MULTI S • PUMY","CITY MULTI Y • PUHY","CITY MULTI R2 • PURY","CITY MULTI WY • PQHY",
            "CITY MULTI WR2 • PQRY","CITY MULTI Indoor • PEFY","CITY MULTI Indoor • PMFY",
            "CITY MULTI Indoor • PLFY","CITY MULTI Indoor • PCFY","CITY MULTI Indoor • PKFY","CITY MULTI Indoor • PFFY"
        ),
        "Αντλία θερμότητας" to listOf(
            "Ecodan Packaged R32 • PUZ-WM","Ecodan Split • PUZ-SWM","Ecodan Split R410A • PUHZ-SW",
            "Ecodan Split R32 • PUD-SWM","Ecodan Split R32 • SUZ-S(H)WM","Zubadan Split • PUZ-SHWM",
            "Zubadan Split R410A • PUHZ-SHW","Zubadan Split R32 • PUD-SHWM",
            "Hydrobox Split E-Generation","Hydrotank Split E-Generation","Hydrotank & Hydrobox",
            "Ecodan Multi Comfort","Ecodan Multi • PUMY-P R410"
        )
    )

    private fun mitsubishiModelKey(model:String):String{
        val m=model.uppercase()
        return listOf(
            "MSZ-LN","MSZ-AY","MSZ-BT","MSZ-DW","MSZ-AP","MSZ-HR","MSZ-EF","MSZ-FT","MSZ-RW",
            "MFZ-KT","MFZ-KW",
            "MXZ-F VGHZ","MXZ-F","MXZ-H","PXZ-4F75VG","PXZ-5F85VG","PXZ",
            "MLZ-KP","SLZ-M","SEZ-M","PEAD-M","PEA-M","PLA-M",
            "PKA-M","PCA-M","PSA-M","PUZ-ZM","PUZ-M","SUZ-M",
            "PUMY","PUHY","PURY","PQHY","PQRY","PEFY","PMFY","PLFY","PCFY","PKFY","PFFY",
            "PUZ-SHWM","PUZ-SWM","PUHZ-SHW","PUHZ-SW","PUZ-WM","PUD-SHWM","PUD-SWM","SUZ-S(H)WM",
            "HYDROBOX","HYDROTANK"
        ).firstOrNull{m.contains(it)} ?: model
    }

    private fun mitsubishiOfficialPage(model:String):String?{
        return when(mitsubishiModelKey(model)){
            "MSZ-LN" -> "https://les.mitsubishielectric.gr/el/products/-_350/_351/-_354/msz-ln_3100.html"
            "MSZ-AY" -> "https://les.mitsubishielectric.gr/el/products/-_350/_351/-_354/msz-ay_4071.html"
            "MSZ-BT" -> "https://les.mitsubishielectric.gr/el/products/-_350/_351/-_354/-msz-bt_3890.html"
            "MSZ-DW" -> "https://les.mitsubishielectric.gr/el/products/-_350/_351/-_354/msz-dw_4002.html"
            "MSZ-AP" -> "https://les.mitsubishielectric.gr/el/products/-_350/_351/-_354/msz-ap_3102.html"
            "MSZ-HR" -> "https://les.mitsubishielectric.gr/el/products/-_350/_351/-_354/msz-hr_4036.html"
            "MSZ-EF" -> "https://les.mitsubishielectric.gr/el/products/-_350/_351/-_354/msz-ef_3101.html"
            "MSZ-RW" -> "https://les.mitsubishielectric.gr/el/products/-_350/-hyper-heating_352/-_357/msz-rw_4000.html"
            "MXZ-H" -> "https://les.mitsubishielectric.gr/el/products/-_350/_351/-_356/mxz-h_4037.html"
            "SEZ-M" -> "https://les.mitsubishielectric.gr/el/products/-_358/-_359/-_362/sez-m_3114.html"
            "PUMY" -> "https://les.mitsubishielectric.gr/el/products/-vrf_365/-_366/small-y_368/pumy-p-yvkm-bs_3122.html"
            "PQHY","PQRY" -> "https://les.mitsubishielectric.gr/el/products/-vrf_365/-_366/wy-wr2_496/pqhry-p-yslm-a1_4011.html"
            "PUZ-SWM" -> "https://les.mitsubishielectric.gr/el/products/_374/-_375/-_523/ecodan-split_526/puz-swm_4084.html"
            "PUZ-SHWM" -> "https://les.mitsubishielectric.gr/el/products/_374/-_375/-_523/zubadan-split_525/puz-shwm_4085.html"
            "PUD-SWM" -> "https://les.mitsubishielectric.gr/el/products/_374/-_375/-_523/ecodan-split_526/pud-swm-r32_4055.html"
            "PUHY" -> "https://les.mitsubishielectric.gr/el/products/-vrf_365/-_366/y-zubadan_493/puhy-hp-ysnw-a_4008.html"
            else -> null
        }
    }


    private fun mitsubishiStaticPhotoUrl(model:String):String?{
        return when(mitsubishiModelKey(model)){
            "MSZ-LN" -> "https://climamarket.com/cdn/shop/files/1359589f34f97cf8555b477172f22e05.jpg?v=1775059563&width=1200"
            "MSZ-AY" -> "https://electric-mitsubishi.ru/image/cache/catalog/msz-ay/msz-ay25vg-00-500x500.jpg"
            "MSZ-BT" -> "https://www.pugliesetermoidraulica.it/3791-medium_default/climatizzatore-condizionatore-mitsubishi-electric-serie-msz-bt-18000-btu-msz-bt50vgk-r-32-wi-fi-integrato-classe-a.jpg"
            "MSZ-DW" -> "https://www.rolls.cy/cdn/shop/files/EU_AVCX4700_ImageGallery_4_c97384a8-8427-45e5-af52-630532728f13.png?v=1693464062&width=1946"
            "MSZ-AP" -> "https://www.sauguspasaulis.lt/uploaded_content/images/pmnmypclypzyjuz/mitsubishi-msz-ap.jpg"
            "MSZ-HR" -> "https://www.climaconviene.it/pimages/Condizionatore-Mitsubishi-Electric-Smart-Hr-18000-Btu-R-32-Wi-Fi-extra-big-5073382.jpg"
            "MSZ-EF" -> "https://wholesaleaircon.com.au/cdn/shop/files/MSZ-EF1_101f713d-7d5a-49fc-aba7-3747a87d6b1c_1600x.png?v=1744951274"
            "MSZ-FT" -> "https://teplocentr.ua/upload/resize_cache/iblock/1c4/500_500_140cd750bba9870f18aada2478b24840a/j0uhuoezlb27ju9oo3281wx80d9gw0fl.jpg"
            "MSZ-RW" -> "https://prosatech.de/media/image/product/13552/lg/klimaanlage-mitsubishi-electric-msz-rw-hyper-heating-wandgeraet-set.jpg"
            "MFZ-KT" -> "https://www.gnp-airconditioning.co.uk/wp-content/uploads/2020/07/mitsubishi-mfz-kt35vg-suz-m35va.png"
            "MFZ-KW" -> "https://www.mitsubishi-les.com/nl-be/mamupload/mfzkww604xh0.webp?rev=181212"

            "MXZ-F" -> "https://img.archiexpo.cn/images_ae/photo-g/49434-13488841.jpg"
            "MXZ-H" -> "https://images.squarespace-cdn.com/content/v1/5ac8f64155b02cb69a0de19b/1528576111749-Y6FGF7MMERQK0R4WY8JN/MXZ-HZ2.jpg?format=750w"
            "MXZ-F VGHZ" -> "https://aerconditionatmitsubishi.ro/27135-large_default/unitate-exterioara-aer-conditionat-multisplit-mitsubishi-electric-hyper-heating-mxz-4e83vahz-inverter-30000-btuh.jpg"
            "PXZ-4F75VG" -> "https://cdn.shopclima.it/media/catalog/product/cache/8501afbe1043d99ed147f7cb0fa02ea5/e/c/ecodan_multi_pxz_7.5_kw_erst30d-vm2ed_3_msz-bt.jpg"
            "PXZ-5F85VG" -> "https://cdn.shopclima.it/media/catalog/product/cache/8501afbe1043d99ed147f7cb0fa02ea5/e/c/ecodan_multi_pxz_7.5_kw_erst30d-vm2ed_3_msz-bt.jpg"
            "PXZ" -> "https://cdn.shopclima.it/media/catalog/product/cache/8501afbe1043d99ed147f7cb0fa02ea5/e/c/ecodan_multi_pxz_7.5_kw_erst30d-vm2ed_3_msz-bt.jpg"

            "SEZ-M" -> "https://primary.jwwb.nl/public/x/x/q/temp-tmbrbkykivhditrbikif/q1avy8/mitsubishi-electric-kanaalsysteem-inbouw-230-volt-sez-m25da-25kw-sez-m35da-35kw-sez-m50da-50kw-sez-m70da-70kw-airco-shop-oldenzaal.jpg?enable=upscale&enable-io=true&fit=bounds&width=1200"
            "PEAD-M" -> "https://www.mitsubishi-electric.co.nz/materials/PRODUCT/Aircon/PEAD-M50-140JAA/images/PEAD_M140.png"
            "PEA-M" -> "https://aircon-online.co.uk/wp-content/uploads/2021/10/oo.png"

            "MLZ-KP" -> "https://prosatech.de/media/image/product/12989/lg/klimaanlage-mitsubishi-electric-mlz-kp-multisplit-1-wege-deckenkassette-set-3x25kw~3.jpg"
            "SLZ-M" -> "https://www.mitsubishielectric.com.au/wp-content/uploads/2022/03/SLZ-M-FA-compact-ceiling-cassette-1920x1440-1.png"
            "PLA-M" -> "https://www.acdtrade.com.au/media/09/07/a5/1732586855/mitsubishi-mr-slim-pla-m-cassette-indoor-ast-3271664-p.jpg"

            "PKA-M" -> "https://les.mitsubishielectric.co.uk/assets/Product/2a2f917c49/Mr-Slim-PKA-M_HA__FillWzEwMDAsNjY2XQ.png"
            "PCA-M" -> "https://img.archiexpo.com/ja/images_ae/photo-g/49434-13497159.jpg"
            "PSA-M" -> "https://www.maison-energy.com/c/96906-category_square/climatiseur-armoire-psa-m-inverter-mitsubishi-electric.jpg"
            "PUZ-ZM" -> "https://static-eu-data.manualslib.com/product-images/f61/821797/mitsubishi-electric-puz-zm-serie-w%C3%A4rmepumpen.jpg"
            "PUZ-M" -> "https://optimpro.co.uk/wp-content/uploads/2024/02/productDetailsImage-null.jpeg"
            "SUZ-M" -> "https://www.gnp-airconditioning.co.uk/wp-content/uploads/2020/07/mitsubishi-mfz-kt35vg-suz-m35va.png"

            "PUMY" -> "https://www.mitsubishielectric.com.au/wp-content/uploads/2022/02/PUMY-P250-300YBM-1920x1440-1.png"
            "PUHY" -> "https://www.mitsubishi-les.com/de-de/dam-upload/puhrympemep200250300ynwa.webp?rev=363565"
            "PURY" -> "https://www.mitsubishi-les.com/de-de/dam-upload/puhrympemep350400450ynwaw604xh0.webp?rev=363877"
            "PQHY" -> "https://climatizzazione.mitsubishielectric.it/sites/default/files/styles/zoom_1050x1050/public/2023-06/PQHY-P-Linea-WY---680x390.png.webp?itok=gtuIkusr"
            "PQRY" -> "https://www.mitsubishi-les.com/nl-be/mamupload/pqryp200250300ylma.webp?rev=181272"
            "PEFY" -> "https://www.mitsubishi-les.com/de-de/dam-upload/pefyp15202532405063vms1e.webp?rev=319800"
            "PMFY" -> "https://mitsubishicomfort.com/_next/image?q=90&url=https%3A%2F%2Fmetus-cms-dev.s3.us-east-2.amazonaws.com%2FME_CM_PFMY_RC_a5c2c6797e.webp&w=3840"
            "PLFY" -> "https://dw2p0k56b2hr9.cloudfront.net/ME_PLFY_P_NEMU_RC_baf7b2036f.webp"
            "PCFY" -> "https://les.mitsubishielectric.co.uk/assets/Product/960390f8f0/PCFY-VKM-E-Image__FillWzEwMDAsNjY2XQ.png"
            "PKFY" -> "https://www.mitsubishielectric.com.au/wp-content/uploads/2022/03/PKFY-P15_32_01_FrontTrans-BG-1920x1440-1.png"
            "PFFY" -> "https://energomir.su/storage/app/uploads/public/5d5/6f3/fd7/5d56f3fd7cd6e421270734.jpg"

            "PUZ-WM" -> "https://les.mitsubishielectric.ro/thumbnails/image_10580.far-1200x630bgFFFFFF.png"
            "PUD-SWM" -> "https://static-data2.manualslib.com/product-images/be8/1997816/mitsubishi-electric-pud-swm-series-heat-pump.jpg"
            "PUZ-SWM" -> "https://cdn.shopify.com/s/files/1/0605/9501/1684/t/3/assets/ecodan_ehst20dym9d_swm80120yaa_paketti_ml-1688643551745.jpeg?v=1688643553"
            "PUZ-SHWM" -> "https://budujemydom.pl/i/2023/09/19/449097-120d-1100x0-sc1x5_mitsubishi-electric-pompa-ciepla-puz-shwm-budujemydompl.jpg"
            "PUD-SHWM" -> "https://stenbaekandersen-el-center.dk/wp-content/uploads/2022/04/EHST20D-YM9DPYD-SHWM140YAA-600x868.png"
            "PUHZ-SW" -> "https://cdn.grupoelcorteingles.es/SGFM/dctm/MEDIA03/202309/25/00104790302436____7__1200x1200.jpg"
            "PUHZ-SHW" -> "https://cdn.grupoelcorteingles.es/SGFM/dctm/MEDIA03/202309/25/00104790302436____7__1200x1200.jpg"
            "SUZ-S(H)WM" -> "https://cdn.shopify.com/s/files/1/0605/9501/1684/t/3/assets/ecodan_ehst20dym9d_swm80120yaa_paketti_ml-1688643551745.jpeg?v=1688643553"
            "HYDROBOX" -> "https://fr-data.manualslib.com/product-images/be5/10710/mitsubishi-electric-ehsc-s%C3%A9rie-syst%C3%A8mes-de-chauffage.jpg"
            "HYDROTANK" -> "https://cdn.shopclima.it/media/catalog/product/cache/8501afbe1043d99ed147f7cb0fa02ea5/e/c/ecodan_multi_pxz_7.5_kw_erst30d-vm2ed_3_msz-bt.jpg"
            else -> null
        }
    }


    private fun mitsubishiFallbackPhotoUrls(model:String):List<String>{
        return when(mitsubishiModelKey(model)){
            "MSZ-LN" -> listOf(
                "https://www.tournikiotisgroup.gr/mitsubishicms/uploads/2017/10/MSZ-LN_04.jpg"
            )
            "MXZ-F" -> listOf(
                "https://img.archiexpo.cn/images_ae/photo-g/49434-13488841.jpg"
            )
            "SEZ-M" -> listOf(
                "https://www.climaconviene.it/pimages/Climatizzatore-Condizionatore-Mitsubishi-Electric-Canalizzato-Ca-extra-big-5496883-076.jpg"
            )
            "MLZ-KP" -> listOf(
                "https://mitsubishicomfort.nl/app/uploads/2024/12/MLZ-KP_Cassette_Mitsubishi_electric_front.png"
            )
            "PKA-M" -> listOf(
                "https://les.mitsubishielectric.co.uk/assets/Product/2a2f917c49/Mr-Slim-PKA-M_HA__FillWzEwMDAsNjY2XQ.png"
            )
            "PSA-M" -> listOf(
                "https://www.maison-energy.com/679350-large_default/armoire-de-climatisation-psa-m-power-inverter-16-kwatts-triphase.jpg"
            )
            "PUMY" -> listOf(
                "https://www.mitsubishielectric.com.au/wp-content/uploads/2022/02/PUMY-P250-300YBM-1920x1440-1-1200x900.png"
            )
            "PUZ-WM" -> listOf(
                "https://les.mitsubishielectric.ro/thumbnails/image_10580.far-1200x630bgFFFFFF.png"
            )
            "HYDROBOX" -> listOf(
                "https://alterair.ua/storage/uploads/shop-products-pics/9Hydrobox.webp",
                "https://c.cdnmp.net/506990474/p/l/9/air-to-water-heat-pump-zubadan-ersc-vm2d-puhz-shw112yha-11-2kw~51779.jpg"
            )
            "HYDROTANK" -> listOf(
                "https://cdn.shopclima.it/media/catalog/product/m/i/mitsubishi_electric_unit_interna_hydrotank_packaged_300_litri.jpg",
                "https://www.vpsolar.com/wp-content/uploads/2020/08/Mitsubishi_Hydrotank-170_200_300L.jpg"
            )
            else -> emptyList()
        }
    }

    private fun mitsubishiCataloguePages(model:String):List<String>{
        val direct=mitsubishiOfficialPage(model)
        if(direct!=null) return listOf(direct)
        // Official Mitsubishi Electric Greece catalogue pages.
        // The loader scans only the local HTML block around the exact model key,
        // so it does not borrow a neighbouring product's image.
        val q=java.net.URLEncoder.encode(mitsubishiModelKey(model),"UTF-8")
        return listOf("https://les.mitsubishielectric.gr/el/products/?search=$q")
    }


    // MIDEA — structured catalog. Official Midea Greece/MBT model families.
    // UI follows the same category -> model card -> photo -> faults pattern.
    // AERMEC — current official 50Hz product families / series.
    // AERMEC — checked against the official current 50 Hz / EU catalogue.
    private val aermecModels:Map<String,List<String>> = linkedMapOf(
        "Split / Inverter" to listOf(
            "SGE","SPG","SCG","FK","COMPACT","CKG","LPG","MVAS",
            "PST","DMH","DMT","CWX"
        ),
        "Multi-Split" to listOf(
            "MPG","MGE"
        ),
        "VRF / VRV" to listOf(
            "MVA","MVBM","MVAS","MVBHR"
        ),
        "Αντλία θερμότητας" to listOf(
            "ANKI","HMI 040 / 160","HMI 041 / 161","HMI 180 / 300",
            "ANLI","BHP","ANK","SHW","ANL 021 / 203","NRK","NRL",
            "PRM","PRG","NRB 0282 / 0754","HMG","HMG-P",
            "NRG 0282 / 0804","NRGI 151 / 602","NRB 0800 / 2406",
            "NRB 0800 / 2406 with shell and tube exchanger",
            "NRG 0800 / 3600","NS","CL","NLC"
        ),
        "Chiller / Ψύκτης" to listOf(
            "ANL 021 / 202","MIC","NRL","NRV","NRB 0282 / 0754",
            "NRG 0282 / 0804","NRGI 151 / 602","NRB 0800 / 2406",
            "NRB 0800 / 2406 with shell and tube exchanger",
            "NRG 0800 / 3600","CL","NLC","NSM","NSMI","NSMJ","NSG",
            "TBA","TBG",
            "NRG Free Cooling 0282 / 0754","NRG Free Cooling 0800 / 2400",
            "NRG Glycol-Free 0800 / 2400","NRB Free Cooling","NRB Glycol-Free",
            "NRV Free Cooling","NSM Free Cooling","NSM Glycol-Free",
            "NSMI Free Cooling","NSMJ Free Cooling","TBA Free Cooling","TBG Free Cooling",
            "NRP 0200 / 0750","NRP 0804 / 2406","NPG","CPS"
        ),
        "Υδρόψυκτα / Water-to-water" to listOf(
            "WRL 026 / 161","WRL 180 / 650","WWM","NXW 0503 / 1654","NGW",
            "WS","HWS","HWSG","HWF","HWFG","WFN","WFI","WFGN","WFGI",
            "Venice","WRK","WSH",
            "WMX","WMG","WTX","WTG",
            "WWB","WWBG",
            "NXP"
        ),
        "Fan Coil" to listOf(
            "FCZ","FCZ-H","FCZ-ASW","FCZI","FCZI-H","FCZI-ASW",
            "Omnia Slim","Omnia Slim Inverter B/BR/P/PR",
            "Omnia UL 12 / 37","Omnia ULI 17 / 37","Ventilcassaforma",
            "FCW 23 / 53","FCWI 23 / 53","FCL","FCLI","FCY","FCYI",
            "VEC","VED","VES"
        ),
        "Rooftop / AHU" to listOf(
            "FCZS","FCZSI","TS","TA","TN","TVS","TVH","NCD","SPL",
            "RTX","RTY","RTG_X","RTG_Y",
            "RePuro","RPLI","RTD","RPF","RPS","URX CF","URHE CF","TRS","ERSR"
        ),
        "Precision / Data Center" to listOf(
            "P","G","R"
        )
    )


    private val airwellModels:Map<String,List<String>> = linkedMapOf(
        "Hi-Wall / Split" to listOf(
            "Harmonia HDH","Harmonia HDMB-025-09M22 / YDAB-025H-09M22",
            "Aura AW-HDLW009-N91 / AW-YHDL009-H91","Horus"
        ),
        "Κονσόλα" to listOf("Hemera XDLF"),
        "Καναλάτο / Built-in" to listOf("Wellzone"),
        "Mobile / Φορητό" to listOf("Maui"),
        "Αντλία θερμότητας Monobloc" to listOf("Wellea Monobloc","Wellea Monobloc HT"),
        "Αντλία θερμότητας Split" to listOf("Wellea Split"),
        "ΖΝΧ / Θερμοδυναμικό boiler" to listOf("Eleo M / TFHW"),
        "Αερισμός / Hybrid dual flow" to listOf("Airflow")
    )

    private val auxModels:Map<String,List<String>> = linkedMapOf(
        "Split / Inverter" to listOf(
            "C-Series CA","C-Series CC-White","C-Series CD",
            "C PRO-Series C PRO",
            "Q-Series Q PLUS+PRO","Q-Series QG","Q-Series QH","Q-Series QD","Q-Series QE","Q-Series QF",
            "F-Series FB","F-Series FC","F-Series FD","F-Series FE","F-Series FF","F-Series FG","F-Series FH","F-Series FI","F-Series FJ",
            "J-Series JA","J-Series JD","J-Series JE","J-Series JF","J-Series JI","J-Series JK","J-Series JM","J-Series JN",
            "H-Series HC","H-Series HD","H-Series HE-White","H-Series HE-Black","H-Series HG-White","H-Series HG-Gray",
            "M-Series MA",
            "ODM P-Series PE","ODM M-Series","ODM Z-Series","ODM Q-Series","ODM J-Series","ODM F-Series"
        ),
        "Floor Standing" to listOf(
            "APA","H-Gold","H-White","Y3-Gold","Y3-Silver",
            "ODM Floor Standing-AP","ODM Floor Standing-AQD"
        ),
        "Portable" to listOf(
            "12Q","DA","Portable-Q 12Q","Portable-F FA","Portable-D DA","Portable-D DB",
            "Portable-M MI","Portable-M MK","Portable-M MC","Portable-M MA","Portable-M MF"
        ),
        "Αφυγραντήρας" to listOf("Dehumidifier-L LSCJ")
    )

    private val aristonModels:Map<String,List<String>> = linkedMapOf(
        "Split / Inverter" to listOf("PRIOS R32"),
        "Αφυγραντήρας" to listOf("DEOS 21S"),
        "Αντλία θερμότητας" to listOf(
            "NIMBUS POCKET 35 M NET R32","NIMBUS POCKET 50 M NET R32",
            "NIMBUS POCKET 80 M NET R32","NIMBUS POCKET 80 M-T NET R32",
            "NIMBUS POCKET 120 M NET R32","NIMBUS POCKET 120 M-T NET R32",
            "NIMBUS POCKET 150 M NET R32","NIMBUS POCKET 150 M-T NET R32",
            "NIMBUS PLUS M NET R32",
            "NIMBUS COMPACT 35 M NET R32","NIMBUS COMPACT 50 M NET R32",
            "NIMBUS COMPACT 80 M NET R32","NIMBUS COMPACT 80 M 2Z NET R32",
            "NIMBUS COMPACT 80 M-T NET R32","NIMBUS COMPACT 80 M-T 2Z NET R32",
            "NIMBUS COMPACT 120 M NET R32","NIMBUS COMPACT 120 M 2Z NET R32",
            "NIMBUS COMPACT 120 M-T NET R32","NIMBUS COMPACT 120 M-T 2Z NET R32",
            "NIMBUS COMPACT 150 M NET R32","NIMBUS COMPACT 150 M 2Z NET R32",
            "NIMBUS COMPACT 150 M-T NET R32","NIMBUS COMPACT 150 M-T 2Z NET R32",
            "NIMBUS FLEX 35 M NET R32","NIMBUS FLEX 50 M NET R32",
            "NIMBUS FLEX 80 M NET R32","NIMBUS FLEX 80 M-T NET R32"
        ),
        "Θερμοδυναμικό ΖΝΧ" to listOf("NUOS PLUS S2 WI-FI FS","NUOS PLUS S2 WI-FI","NUOS PLUS Wi-Fi","NUOS PRIMO HC A+"),
        "Fan Coil" to listOf("NIMBUS AQUASLIM FS","NIMBUS AQUASLIM WH")
    )

    private val boschModels:Map<String,List<String>> = linkedMapOf(
        "Split / Inverter" to listOf("Climate 2000","Climate 3000i","Climate 6000i","Climate 7000i"),
        "Multi-Split" to listOf("Climate 5000 M","Climate 2000 Multi","Climate 3000i Multi","Climate 6000i Multi"),
        "Κασέτα" to listOf("Climate 5000i SCI Cassette","Climate 5000i Multi Cassette"),
        "Καναλάτο" to listOf("Climate 5000i SCI Duct","Climate 5000i Multi Duct"),
        "Floor / Ceiling" to listOf("Climate 5000i SCI Floor-Ceiling"),
        "Κονσόλα" to listOf("Climate 5000i Console","Climate 5000i Multi Console"),
        "VRF / Air Flux" to listOf("Air Flux AF5300"),
        "Αντλία θερμότητας" to listOf("Compress 3000","Compress 3800i AW")
    )

    // ===== NEXT BATCH: Carrier / Climaveneta / Cooper&Hunter / Fujitsu =====
    private val carrierModels:Map<String,List<String>> = linkedMapOf(
        "Split / Multi-Split" to listOf(
            "42QHE","42QHG","42QHG-H","42QHP",
            "42QTD","42QSS","42QZL","42QZY",
            "51KPD","51QPD"
        ),
        "VRF / VRV" to listOf(
            "XCT7","XCT8",
            "38VS*C7SH","38VS*17S/3H","38VS*174H",
            "38VT*173H","38VT*173R"
        ),
        "Chiller / Ψύκτης" to listOf(
            "30XF","30RB 017-040","30RB 40R-160R",
            "30XW-PZE","30XW-VZE",
            "30WG / 30WGA","30XWHV","30XWH / 30XWHP"
        ),
        "Αντλία θερμότητας" to listOf(
            "30FQ","61AQ","30AWH-M 04R-16R","30AWH-R",
            "30AWH-P","38AW-R / 80AW-R / 80AW-RA",
            "30RQ","30RQ / 30RQP","30RQ 40R-160R",
            "61CG","61WG","61XWHZE","61CW-Z","61XWHVZE"
        ),
        "Rooftop" to listOf(
            "50NC","50FF/FC 020-093 R-454B","50FF/FC 020-099",
            "50FF/FC 100-280 R-454B","50FC 100-280"
        ),
        "AHU / Air Handler" to listOf(
            "39CP-L","39CP-H","39CP-C","39HX"
        ),
        "Fan Coil" to listOf(
            "42NX","42EP","42NL","42NH"
        ),
        "Precision Cooling" to listOf(
            "Coolblade","Data Center Precision Cooling"
        )
    )

    private val climavenetaModels:Map<String,List<String>> = linkedMapOf(
        "Chiller / Ψύκτης" to listOf(
            "i-BX2-G07","i-NX2-G07","i-NX2-N-G07",
            "NX2-FC-G06","NX2-W-G06",
            "FX2-G05-M4","FX2-G01-M4",
            "i-FX2-G01-Z","i-FX-G05",
            "TX2-FC-G04-Z","NX-C"
        ),
        "Αντλία θερμότητας" to listOf(
            "i-BX2-N-G07","i-BX3-N-G09",
            "i-NX2-N-G07",
            "EW-HT-G05","EW-HT-C-G05",
            "i-FX-WQ-G05","i-FX-WQ-G01"
        ),
        "Precision / IT Cooling" to listOf(
            "w-NEXT3-XL","w-AV3-XL",
            "x-AV3-i-G02-DX-DF","x-AV3-i-G02-DX",
            "x-AV3-f-G02-DX-DF","x-AV3-f-G02-DX",
            "GX2-MC","DX2-TF"
        )
    )

    private val cooperHunterModels:Map<String,List<String>> = linkedMapOf(
        "Split / Inverter" to listOf(
            "SUPREME Arctic Inverter NG","Veritas NG","Alpha NG",
            "Winner Inverter","SIGMA","Nordic Evo NG",
            "Nordic EVO II","AIR-MASTER POWER",
            "Arctic Inverter NG Gen VI"
        ),
        "Multi-Split" to listOf(
            "Vital Plus","Nordic Multi Light R32 NG",
            "NORDIC Multi Light Hydro",
            "NORDIC MULTI LIGHT GEN VI CASSETTE R32",
            "NORDIC MULTI LIGHT GEN VI DUCT R32",
            "NORDIC MULTI LIGHT GEN VI CONSOLE R32",
            "NORDIC MULTI LIGHT GEN VI FLOOR-CEILING R32"
        ),
        "Καναλάτο / Duct" to listOf(
            "Duct Commercial RK(RM)2 R32",
            "NORDIC MULTI LIGHT GEN VI DUCT R32"
        ),
        "Κασέτα" to listOf(
            "Cassette Commercial RK(RM)2 R32",
            "CH-IC035-CH-IC160RK2",
            "NORDIC MULTI LIGHT GEN VI CASSETTE R32",
            "CHV6 Slim 1-way Cassette",
            "CHV6 4-way Cassette NK2"
        ),
        "Floor / Ceiling" to listOf(
            "Floor-Ceiling Commercial RK(RM)2 R32",
            "NORDIC MULTI LIGHT GEN VI FLOOR-CEILING R32"
        ),
        "Fan Coil" to listOf(
            "Floor-to-ceiling Fan Coil",
            "Wall-mounted Fan Coil",
            "Glass Console Fan Coil",
            "Duct Fan Coil",
            "CH-FDV 4-flow Cassette Fan Coil",
            "Floor-ceiling Fan Coil"
        ),
        "VRF / VRV" to listOf(
            "CHV6","CHV6 HR","CHV6 Slim 1-way Cassette",
            "CHV6 Indoor Console","CHV6 Wall-mounted Indoor",
            "CHV6 HR Hydro Box","CHV Solar","Mini AHU KIT",
            "CHV6 4-way Cassette NK2",
            "CHV6-224NMX","CHV6-280NMX","CHV6-335NMX","CHV6-400NMX",
            "CHV6-450NMX","CHV6-504NMX","CHV6-560NMX","CHV6-615NMX",
            "CHV-5SCW22NK","CHV-5SCW28NK","CHV-5SCW36NK","CHV-5SCW45NK","CHV-5SCW50NK",
            "CHV-5SK22NK","CHV-5SK28NK","CHV-5SK36NK","CHV-5SK45NK","CHV-5SK50NK",
            "CHV-5SW22NK2","CHV-5SW28NK2","CHV-5SW36NK2","CHV-5SW45NK2","CHV-5SW50NK2","CHV-5SW56NK2","CHV-5SW63NK2","CHV-5SW71NK2"
        ),
        "Αντλία θερμότητας αέρα-νερού" to listOf(
            "ECOPOWER PRO","CH-HP06UIMPZK-P","CH-HP12UIMPZK-P","CH-HP12UIMPZM-P",
            "CH-HP17UIMPZK-P","CH-HP17UIMPZM-P",
            "MINIPOWER INVERTER","CH-WH5.0MIPRK","CH-HP5.0UIMPRK",
            "ECOPOWER HEAT PUMP","UNITHERM SPLIT R32","UNITHERM 3 ALL-IN-ONE R32",
            "Hyperpower","Water KIT","Unitherm 5","INVERTER MODULAR HEAT PUMPS"
        ),
        "Pool Heat Pump" to listOf("DYNAMIC")
    )

    private val fujitsuModels:Map<String,List<String>> = linkedMapOf(
        "Split / Inverter" to listOf(
            "ASYG07KETA","ASYG09KETA","ASYG12KETA","ASYG14KETA",
            "ASYG07KMCC","ASYG09KMCC","ASYG12KMCC","ASYG14KMCC",
            "ASYG18KMTE","ASYG24KMTE","ASYG30KMTA",
            "ASYG09KGTE","ASYG12KGTE","ASYG14KGTE",
            "ASYG07KPCA","ASYG09KPCA","ASYG12KPCA","ASYG14KPCA",
            "ASYG18KLCA","ASYG24KLCA"
        ),
        "Multi-Split" to listOf(
            "AOYG14KBTA2","AOYG18KBTA2","AOYG24KBTA3",
            "AOYG30KBTA4","AOYG36KBTA5","AOYG45KBTA5",
            "AOEG54KBTB"
        ),
        "Καναλάτο / Duct" to listOf(
            "ARYG07LLTA","ARYG09LLTA","ARYG12LLTA","ARYG14LLTA",
            "ARYG18LLTB","ARYG24LMLA","ARYG30LMLA","ARYG36LMLA","ARYG45LMLA"
        ),
        "Κασέτα" to listOf(
            "AUXG09KVLA","AUXG12KVLA","AUXG14KVLA","AUXG18KVLA",
            "AUXG24KVLA","AUXG30KRLB","AUXG36KRLB","AUXG45KRLB","AUXG54KRLB"
        ),
        "Floor / Ceiling" to listOf(
            "ABYG18KRTA","ABYG22KRTA","ABYG24KRTA",
            "ABYG30KRTA","ABYG36KRTA","ABYG45KRTA","ABYG54KRTA"
        ),
        "VRF / VRV" to listOf(
            "AIRSTAGE J-IV","AIRSTAGE J-IVL","AIRSTAGE J-IVS",
            "AIRSTAGE V-III","AIRSTAGE V-II","AIRSTAGE VR-II",
            "AJY040LELDH","AJY045LELDH","AJY054LELDH"
        ),
        "Αντλία θερμότητας αέρα-νερού" to listOf(
            "Waterstage Comfort","Waterstage High Power",
            "Waterstage Super High Power","Waterstage Monobloc"
        ),
        "Αερισμός" to listOf(
            "UTZ-BD025C","UTZ-BD035C","UTZ-BD050C",
            "UTZ-BD080C","UTZ-BD100C"
        )
    )

    // ===== BATCH: GENERAL / GREE / HAIER / HISENSE =====
    private val generalModels:Map<String,List<String>> = linkedMapOf(
        "Split / Inverter" to listOf(
            "ASHH07KJCAL","ASHH09KJCAL","ASHH12KJCAL","ASHH14KJCAL",
            "ASHH07KJCAL-B","ASHH09KJCAL-B","ASHH12KJCAL-B","ASHH14KJCAL-B",
            "ASHH07KMCG","ASHH09KMCG","ASHH12KMCG","ASHH14KMCG",
            "ASHH18KMTGL","ASHH22KMTGL","ASHH24KMTGL",
            "ASHH05KNCA","ASHH07KNCA","ASHH09KNCA","ASHH12KNCA"
        ),
        "Multi-Split" to listOf(
            "AOHH14KACB2","AOHH18KACB2","AOHH18KACB3",
            "AOHG14KBTA2","AOHG18KBTA2","AOHG18KBTA3","AOHG24KBTA3","AOHG30KBTA4","AOHG36KBTA5",
            "AOHG36KBTB","AOHG45KBTB","AOHG54KBTB",
            "AOHG36KRTA","AOHG45KRTA","AOHG54KRTA"
        ),
        "Καναλάτο / Duct" to listOf(
            "ARXG07KSLAP","ARXG09KSLAP","ARXG12KSLAP","ARXG14KSLAP","ARXG18KSLAP",
            "ARXG07KLLAP","ARXG09KLLAP","ARXG12KLLAP","ARXG14KLLAP","ARXG18KLLAP",
            "ARXG22KMLB","ARXH12KMTAP","ARXH14KMTAP","ARXH18KMTAP","ARXH22KMTAP",
            "ARXH24KMTAP","ARXH30KMTAP","ARXH36KMTAP","ARXH45KMTAP","ARXH54KMTAP"
        ),
        "Κασέτα" to listOf(
            "AUXG07KVLA","AUXG09KVLA","AUXG12KVLA","AUXG14KVLA","AUXG18KVLA","AUXG22KVLA"
        ),
        "Floor / Ceiling" to listOf(
            "AGHG09KVCA","AGHG12KVCA","AGHG14KVCA",
            "ABHG18KRTA","ABHG22KRTA"
        ),
        "VRF / VRV" to listOf(
            "AIRSTAGE J-VS","AIRSTAGE J-VL","AIRSTAGE VU-V","AIRSTAGE J-IVS","AIRSTAGE J-IV","AIRSTAGE J-IVL","AIRSTAGE VR-IV","AIRSTAGE V-IV",
            "AJH108GALDH","AJH126GALDH","AJH144GALDH","AJH162GALDH","AJH180GALDH","AJH198GALDH",
            "AJH216GALDH","AJH234GALDH","AJH252GALDH","AJH270GALDH","AJH288GALDH","AJH306GALDH",
            "AJH324GALDH","AJH342GALDH","AJH360GALDH","AJH378GALDH","AJH396GALDH","AJH414GALDH","AJH432GALDH",
            "AJH108LALH","AJH288LALHH","AJH306LALH","AJH306LALHH","AJH162GALH",
            "AUXB004HLAH","AUXB005HLAH","AUXB007HLAH","AUXB009HLAH","AUXB012HLAH","AUXB014HLAH","AUXB018HLAH",
            "ABYA018GTEH"
        ),
        "Αντλία θερμότητας αέρα-νερού" to listOf(
            "Waterstage Comfort","Waterstage High Power","Waterstage Super High Power","Waterstage Monobloc"
        ),
        "Αερισμός" to listOf("UTZ-BD025C","UTZ-BD035C","UTZ-BD050C","UTZ-BD080C","UTZ-BD100C")
    )

    private val greeModels:Map<String,List<String>> = linkedMapOf(
        "Split / Inverter" to listOf("Airy","Clivia","Pular","Fairy","Amber","Bora","Lomo","U-Crown"),
        "Multi-Split" to listOf("Free Match R32","Free Match Plus"),
        "Καναλάτο / Duct" to listOf("U-Match Duct","Slim Duct","High Static Duct"),
        "Κασέτα" to listOf("U-Match Cassette","Compact Cassette","Round Flow Cassette"),
        "Floor / Ceiling / Console" to listOf("U-Match Floor-Ceiling","Console","Floor Standing"),
        "VRF / GMV" to listOf(
            "GMV6","GMV6 HR","GMV5","GMV5 HR","GMV Mini","GMV ES","GMV Water","MultiPRO",
            "GMV-24WL/C-T(U)","GMV-28WL/C-T(U)","GMV-36WL/C-T(U)","GMV-48WL/C-T(U)","GMV-60WL/C-T(U)",
            "GMV-V36WL/C-T(U)","GMV-V48WL/C-T(U)","GMV-V60WL/C-T(U)",
            "GMV-ND06G/B4B-T(U)","GMV-ND07G/B4B-T(U)","GMV-ND09G/B4B-T(U)","GMV-ND12G/B4B-T(U)",
            "GMV-ND14G/B4B-T(U)","GMV-ND18G/B4B-T(U)","GMV-ND24G/B4B-T(U)","GMV-ND30G/B4B-T(U)","GMV-ND36G/B4B-T(U)",
            "GMV-ND07PHS/B-T(U)","GMV-ND09PHS/B-T(U)","GMV-ND12PHS/B-T(U)","GMV-ND15PHS/B-T(U)",
            "GMV-ND18PHS/B-T(U)","GMV-ND22PHS/B-T(U)","GMV-ND24PHS/B-T(U)","GMV-ND30PHS/B-T(U)",
            "GMV-ND36PHS/B-T(U)","GMV-ND42PHS/B-T(U)","GMV-ND48PHS/B-T(U)","GMV-ND54PHS/B-T(U)",
            "GMV-ND72PH/B-T(U)","GMV-ND96PH/B-T(U)",
            "GMV-ND07TD/A-T(U)","GMV-ND09TD/A-T(U)","GMV-ND12TD/A-T(U)"
        ),
        "Αντλία θερμότητας αέρα-νερού" to listOf("Versati IV","Versati III","Versati III All-in-One","Versati Monobloc"),
        "Chiller / Ψύκτης" to listOf("Modular Air-Cooled Scroll Chiller","Screw Chiller","Centrifugal Chiller"),
        "Packaged / Rooftop" to listOf("Rooftop Packaged Unit","Packaged Terminal Unit")
    )

    private val haierModels:Map<String,List<String>> = linkedMapOf(
        "Split / Inverter" to listOf("Jade","Expert","Flexis Plus","Pearl Premium","Revive Plus","Tundra Plus"),
        "Multi-Split" to listOf("Multi 1:2","Multi 1:3","Multi 1:4","Multi 1:5"),
        "Light Commercial / Duct-Cassette" to listOf("Round Way Cassette","4-Way Cassette","1-Way Cassette","Slim Duct","Medium ESP Duct","High ESP Duct","Console","Ceiling-Floor"),
        "VRF / MRV" to listOf(
            "MRV 5-RC","MRV 5-H","MRV S","MRV S II","MRV S III","MRV IV-C","MRV IV-T",
            "AV08IMVURA","AV10IMVURA","AV12IMVURA","AV14IMVURA","AV16IMVURA","AV18IMVURA",
            "AV20IMVURA","AV22IMVURA","AV24IMVURA","AV26IMVURA","AV28IMVURA","AV30IMVURA",
            "AV32IMVURA","AV34IMVURA","AV36IMVURA","AV38IMVURA","AV40IMVURA","AV42IMVURA",
            "AV44IMVURA","AV46IMVURA","AV48IMVURA","AV50IMVURA","AV52IMVURA","AV54IMVURA",
            "AV56IMVURA","AV58IMVURA","AV60IMVURA","AV62IMVURA","AV64IMVURA","AV66IMVURA"
        ),
        "Chiller / Ψύκτης" to listOf("Air-Cooled Modular Chiller","Water-Cooled Screw Chiller","Magnetic Bearing Centrifugal Chiller"),
        "Αντλία θερμότητας αέρα-νερού" to listOf("Super Aqua Monobloc","Super Aqua Split","Super Aqua All-in-One","Super Aqua R290")
    )

    private val hisenseModels:Map<String,List<String>> = linkedMapOf(
        "Split / RAC" to listOf("Energy Pro X","Energy Nordic","Fresh Master","Silentium Pro","Hi-Comfort","Easy Smart","New Comfort"),
        "Light Commercial / LCAC" to listOf("Cassette","Mini Cassette","Slim Duct","Medium ESP Duct","High ESP Duct","Ceiling-Floor","Console"),
        "VRF" to listOf("Hi-FLEXi S5","Hi-FLEXi S5 Heat Recovery","Hi-FLEXi W","Hi-Smart H5","Hi-Smart E+","Hi-Smart L"),
        "Chiller / Ψύκτης" to listOf("Air-Cooled Modular Chiller","Water-Cooled Screw Chiller"),
        "Αντλία θερμότητας / Hi-Therma" to listOf("Hi-Therma Monobloc","Hi-Therma Split","Hi-Therma Integra","Hi-Therma R290")
    )

    // ===== BATCH: HITACHI / INVENTOR / LENNOX / LG =====
    private val hitachiModels:Map<String,List<String>> = linkedMapOf(
        "Split / Inverter" to listOf("airHome 400","airHome 600","airHome 800","Dodai 2","Mokai","Shirokuma"),
        "Multi-Split" to listOf("RAM Multi-Split","Multizone Premium"),
        "Light Commercial / PAC" to listOf("PRIMAIRY","Utopia Prime","Utopia IVX Premium","Utopia IVX Comfort","System Free"),
        "VRF / SET FREE" to listOf("SET FREE mini","SET FREE Sigma","SET FREE Sigma R32","SET FREE SideSmart","SET FREE Heat Recovery"),
        "Chiller / Ψύκτης" to listOf("Samurai M","Samurai S","Samurai L","RCME","RASM"),
        "Αντλία θερμότητας / Yutaki" to listOf("Yutaki S","Yutaki S Combi","Yutaki M","Yutaki H","Yutaki S80")
    )

    private val inventorModels:Map<String,List<String>> = linkedMapOf(
        "Split / Inverter" to listOf("Thora Nordic","Leon LHUV","Neo N2UV","Neo Eco","Aria AR5","Dark","Comfort","Vero"),
        "Mobile / Φορητό" to listOf("Chilly","Magic","Cool"),
        "Multi-Split" to listOf("O1MI-O1MO","O1CMI-O1CMO","ARCMI-ARCMO"),
        "Καναλάτο / Duct" to listOf("U6MRSL Duct","V6MCRI Duct"),
        "Κασέτα" to listOf("U6MRSL Cassette","V6MCRI Cassette"),
        "Floor / Ceiling" to listOf("U6MRSL Floor Ceiling","V6MCRI Floor Ceiling"),
        "Κονσόλα" to listOf("U6MRSL Console","V6MCRI Console"),
        "VRF" to listOf("Inventor VRF V6","Inventor Mini VRF"),
        "Αντλία θερμότητας αέρα-νερού" to listOf("Matrix Zero R290","Matrix","Matrix Split","Matrix Monobloc"),
        "Fan Coil" to listOf("Quality 550","Quality 700")
    )

    private val lennoxModels:Map<String,List<String>> = linkedMapOf(
        "Rooftop" to listOf("Evio","e-Baltic","e-eNeRGy","Baltic","Flexair","eNeRGy","eNeRGy+"),
        "Chiller / Ψύκτης" to listOf("eComfort R290","eComfort R32","eComfort R410A","eComfort MC","Neostar","V-King"),
        "Αντλία θερμότητας" to listOf("eComfort R32 Heat Pump","eComfort R410A Heat Pump","Aqua4"),
        "AHU / Air Handling" to listOf("e-eNeRGy","eNeRGy","eNeRGy+"),
        "Fan Coil" to listOf("Comfair","Comfair HD")
    )

    private val lgModels:Map<String,List<String>> = linkedMapOf(
        "Split / Inverter" to listOf("ARTCOOL Gallery","ARTCOOL Mirror","DUALCOOL AI Air","DUALCOOL Premium","STANDARD PLUS"),
        "Multi-Split" to listOf("MULTI F","MULTI F MAX"),
        "VRF / Multi V" to listOf(
            "MULTI V i","MULTI V S","MULTI V M","MULTI V WATER 5","MULTI V 5",
            "MULTI V WATER IV","MULTI V IV Heat Pump","MULTI V IV Heat Recovery","HYDROKIT",
            "ZRUM080LTE6","ZRUM100LTE6","ZRUM120LTS6","ZRUM140LTE6","ZRUM160LTE6",
            "ARUM140LTE6","ARUN080LSS5","ARUN100LSS5","ARWM200LAS5",
            "ARNU18GV1A4","ARNU24GV1A4"
        ),
        "Single Packaged / Rooftop" to listOf("Single Package","Rooftop Package"),
        "Chiller / Ψύκτης" to listOf("Inverter Scroll Chiller","Oil-Free Centrifugal Chiller","Absorption Chiller"),
        "Αντλία θερμότητας αέρα-νερού" to listOf("THERMA V R290 Monobloc","THERMA V R32 Monobloc S","THERMA V R32 Split","THERMA V High Temperature"),
        "ERV / Αερισμός" to listOf("ERV","ERV DX","Eco V"),
        "Water Heater" to listOf("Inverter Heat Pump Water Heater")
    )

    // ===== BATCH: MITSUBISHI HEAVY / NORDSTAR / PANASONIC / RHOSS =====
    private val mitsubishiHeavyModels:Map<String,List<String>> = linkedMapOf(
        "Split / Residential" to listOf(
            "SRK-ZSX-W","SRK-ZS-W","SRK-ZR-W","SRK-ZTL-W","SRK-ZSP-W",
            "SRF-ZMX-S","SRF-ZS-W","SRK-ZSX-WF","SRK-ZS-WF"
        ),
        "Packaged / Commercial" to listOf(
            "FDT 4-Way Cassette","FDTC Compact Cassette","FDTW 2-Way Cassette","FDTS 1-Way Cassette",
            "FDUM Medium Static Duct","FDU High Static Duct","FDUT Low Static Duct",
            "FDE Ceiling Suspended","FDF Floor Standing"
        ),
        "VRF / VRV" to listOf(
            "KXZE2","KXZR2 Heat Recovery","KXZ2","KXZW2 Water Cooled","Micro KX"
        ),
        "Αντλία θερμότητας / Hydrolution" to listOf(
            "Hydrolution EZY","Hydrolution All-in-One","Hydrolution Split","Hydrolution HT"
        ),
        "Chiller / Ψύκτης" to listOf(
            "Q-ton","ETI-Z","ETI-ZE"
        )
    )

    private val nordstarModels:Map<String,List<String>> = linkedMapOf(
        "Split / Inverter" to listOf(
            "Nordstar Inverter 9000 BTU","Nordstar Inverter 12000 BTU",
            "Nordstar Inverter 18000 BTU","Nordstar Inverter 24000 BTU"
        ),
        "Multi-Split" to listOf(
            "Nordstar Multi 2","Nordstar Multi 3","Nordstar Multi 4","Nordstar Multi 5"
        )
    )

    private val panasonicModels:Map<String,List<String>> = linkedMapOf(
        "Split / Inverter" to listOf(
            "Etherea Z","Etherea XZ","TZ Compact","BZ Compact","Floor Console","RAC Solo"
        ),
        "Multi-Split" to listOf(
            "Free Multi Z","Free Multi TZ","Free Multi Floor Console"
        ),
        "Light Commercial / PACi" to listOf(
            "PACi NX Elite","PACi NX Standard","PACi NX 4-Way Cassette 90x90",
            "PACi NX 4-Way Cassette 60x60","PACi NX Adaptive Ducted","PACi NX High Static Ducted",
            "PACi NX Ceiling","PACi NX Floor Standing"
        ),
        "VRF / ECOi" to listOf(
            "Mini ECOi LZ2","Mini ECOi LE2","Mini ECOi LE1",
            "ECOi EX MZ1","ECOi EX ME2","ECOi EX MF3",
            "ECO G GE3","ECO G GF3"
        ),
        "Αντλία θερμότητας / Aquarea" to listOf(
            "Aquarea L Generation R290","Aquarea M Generation R290",
            "Aquarea K Generation","Aquarea N Generation R454C","Aquarea EcoFlex"
        ),
        "Chiller / Heat Pump" to listOf(
            "AQUA-G EVO R290","ECOi-W AQUA-Z EVO","ECOi-W AQUA-G BLUE","ECOi-W AQUA-G EVO"
        ),
        "Rooftop" to listOf("ECOi-RT"),
        "Fan Coil" to listOf(
            "AC Smart Fan Coil","Wall Mounted Fan Coil","Cassette Fan Coil","Ducted Fan Coil","Floor Fan Coil"
        ),
        "Αερισμός" to listOf(
            "Residential Heat Recovery Ventilation","Commercial Heat Recovery Ventilation","ERV with DX Coil"
        )
    )

    private val rhossModels:Map<String,List<String>> = linkedMapOf(
        "Chiller / Ψύκτης" to listOf(
            "Electa-PI THAITP 104÷116","Electa-ECO THAITI 106÷116",
            "Electa-ECOS-B MHAITI 104÷110 + IUB 06-10",
            "ElectaMAXI-ECO THAITI 118÷130",
            "MidiPACK-PI THAITP 120÷135","MidiPACK-I TCAITY-THAITY 120÷130",
            "MidiFLOW-PI",
            "EasyPACK-I TCAIY-THAIY 270÷2130","EasyPACK ECO TCAEI-THAEI 270÷2150",
            "Compact-ID TCCITY-THCITY 117÷128","Y-Pack C-PF TCCETY-THCETY 233÷2160",
            "EasyFLOW ECO TCHET-THHET 245÷2195","EasyFLOW ECO E TCEET 245÷2195"
        ),
        "Αντλία θερμότητας" to listOf(
            "Electa-PI","Electa-ECO","Electa-ECOS-B","ElectaMAXI-ECO",
            "MidiPACK-PI","MidiFLOW-PI","FLOW BOOSTER EVO",
            "EasyPACK-I","EasyPACK ECO",
            "Compact-ID","Y-Pack C-PF",
            "EasyFLOW ECO HT","EasyFLOW ECO EXP"
        ),
        "Fan Coil" to listOf(
            "BRIO-I SLIM","YARDY-I EV3","IDROWALL-I","IDROWALL-I/V3"
        ),
        "AHU / Air Handling" to listOf(
            "Air Handling Units","Heat Recovery Units","Air Handling Terminal Units",
            "UTNR-HE Platinum","UTNR-HP","Electa-REK UTR 20-30 / UTRR 15-45","VMC-E","Air Suite"
        ),
        "Freecooling" to listOf(
            "Freecooling Chillers","Integrated Freecooling Systems"
        )
    )

    // ===== BATCH: ROTENSO / SAMSUNG / SHARP / SINCLAIR =====
    private val rotensoModels:Map<String,List<String>> = linkedMapOf(
        "Split / Inverter" to listOf("Mirai X","Fresh X","Versu Mirror X R15","Versu Pure X","Versu Cloth X Stone","Versu Cloth X Caramel","Roni X","Revio X","Ukura H","Ukura X","Teta Mirror X","Teta X","Elis X","Elis Silver X","Imoto X","Aneru HP","Aneru X","Aneru AN X","Tenji CC X","Tenji CS X","Jato X","Nevo X","Unico X"),
        "Multi-Split" to listOf("Mirai X Multi","Versu Mirror X Multi R15","Versu Pure X Multi","Versu Cloth Stone X Multi","Versu Cloth Caramel X Multi","Teta X Multi","Teta Mirror X Multi","Revio X Multi","Imoto X Multi","Ukura X Multi","Roni X Multi","Elis X Multi","Elis Silver X Multi","Aneru X Multi","Aneru AN X Multi","Tenji CC X Multi","Tenji CS X Multi","Jato X Multi","Nevo X Multi","Hiro S","Hiro N","Hiro HP"),
        "Commercial / Duct-Cassette-Console" to listOf("Aneru X","Aneru AN X","Tenji CC X","Tenji CS X","Jato X","Nevo X","Unico X"),
        "VRF" to listOf("VRF V5","VRF HR","Mini VRF V5","Mini VRF V4","VRF V-STAGE","VRF Enos WM","VRF Jato FC","VRF Tenji CC","VRF Tenji CS","VRF Nevo DL","VRF Nevo DM","VRF Nevo DH"),
        "Αντλία θερμότητας Split" to listOf("Aquami Split","Airmi Split","Heatmi Split","Aquami Multi"),
        "Αντλία θερμότητας All-in-Split" to listOf("Aquami All in Split"),
        "Αντλία θερμότητας Monobloc" to listOf("Airmi Monoblock","Aquami Monoblock","Aquami Big Mono","Windmi Monoblock"),
        "Αερισμός / Recuperator" to listOf("Wentilo"),
        "AHU / Air Handling Integration" to listOf(
            "Imoto for RAHU I26Xo","Imoto for RAHU I35Xo","Imoto for RAHU I50Xo","Imoto for RAHU I70Xo",
            "Unico for RAHU UO90Xo","Unico for RAHU UO100Xo","Unico for RAHU UO120Xo","Unico for RAHU UO140Xo","Unico for RAHU UO160Xo",
            "miniVRF V5 for AHU","miniVRF V4 for AHU","VRF V5 for AHU","VRF V-STAGE for AHU"
        )
    )

    private val samsungModels:Map<String,List<String>> = linkedMapOf(
        "Split / RAC" to listOf("WindFree Elite","WindFree Avant","WindFree Comfort","Cebu","Luzon"),
        "Multi-Split" to listOf("FJM Multi Split","WindFree Multi Split"),
        "Commercial / CAC" to listOf("360 Cassette","4Way Cassette","Mini 4Way Cassette","1Way Cassette","Duct S","MSP Duct","HSP Duct","Console","Ceiling"),
        "VRF / DVM" to listOf("DVM S2","DVM S","DVM S Eco","DVM S Water","DVM S Heat Recovery","DVM Chiller"),
        "Αντλία θερμότητας / EHS" to listOf("EHS Mono R290","EHS Mono HT Quiet","EHS Mono","EHS Split","EHS TDM Plus","ClimateHub")
    )

    private val sharpModels:Map<String,List<String>> = linkedMapOf(
        "Split / Inverter" to listOf("AY-XP12THU","AY-XP18THU","AY-XPC09TU","AY-XPC12TU","AY-XPC15TU","AY-XPC18TU","AY-XP24TU","AY-X36RU","AE-X2M20TU","AE-X4M30PU")
    )

    private val sinclairModels:Map<String,List<String>> = linkedMapOf(
        "Split / Inverter" to listOf("Terrel","Marvin","Marvin 2","Ray","Keyon","Spectrum Plus","Sky","Focus Plus","Vision"),
        "Multi-Split" to listOf("Multi Variable","Free Match"),
        "Commercial / Duct-Cassette" to listOf("Cassette","Compact Cassette","Duct","High Static Duct","Floor Ceiling","Console"),
        "VRF" to listOf("SDV6","SDV6 Heat Recovery","Mini SDV","SDV5"),
        "Αντλία θερμότητας αέρα-νερού" to listOf("S-Therm Yukon","S-Therm Ontario","S-Therm Monoblock","S-Therm Split")
    )

    // ===== BATCH: TCL / TESLA / TOSHIBA / TOYOTOMI / TRANE =====
    private val tclModels:Map<String,List<String>> = linkedMapOf(
        "Split / Inverter" to listOf("FreshIN 3.0","FreshIN 2.0","GentleCool","Elite","Miracle","BreezeIN","Ocarina"),
        "Mobile / Φορητό" to listOf("TCL Mobile AC 9K","TCL Mobile AC 12K"),
        "Multi-Split / Free Match" to listOf("Free Match 2","Free Match 3","Free Match 4","Free Match 5"),
        "Καναλάτο / Duct" to listOf("TCL Duct R32"),
        "Κασέτα" to listOf("TCL Cassette R32"),
        "Κονσόλα" to listOf("TCL Console R32"),
        "Floor / Ceiling" to listOf("TCL Floor Ceiling R32"),
        "Αντλία θερμότητας Monobloc" to listOf("TCL R290 Monobloc"),
        "Αντλία θερμότητας Split" to listOf("TCL R32 Split"),
        "Αντλία θερμότητας ΖΝΧ" to listOf("TCL Heat Pump Water Heater")
    )

    private val teslaModels:Map<String,List<String>> = linkedMapOf(
        "Split / Inverter" to listOf("Virtuoso","Select","Superior","Standard","Classic","TT34EXC1","TT51EXC1","TT68EXC1"),
        "Multi-Split" to listOf("Tesla Multi Split 2","Tesla Multi Split 3","Tesla Multi Split 4","Tesla Multi Split 5")
    )

    private val toshibaModels:Map<String,List<String>> = linkedMapOf(
        "Split / RAC" to listOf(
            "DAISEIKAI 10","DAISEIKAI 9","HAORI","SHORAI Edge","SEIYA","SEIYA Classic","SEIYA Plus","Bi-Flow Console",
            "B0*E2KVG-E","B0*G3KVSG-E","B0*G3KVSGB-E","B1*N4KVRG-E1","1*PKVPG-E","B1*S4KV*G-E","B1*J2FVG-E"
        ),
        "Multi-Split" to listOf("Multi-Split R32","Multi-Split 2 Rooms","Multi-Split 3 Rooms","Multi-Split 4 Rooms","Multi-Split 5 Rooms"),
        "Light Commercial / RAV" to listOf("Digital Inverter","Digital Inverter Classic","Super Digital Inverter","Smart Cassette","Compact 4-Way Cassette","High-Wall","Ceiling","Slim Duct","Standard Duct","High Static Duct"),
        "VRF / SMMS" to listOf("SMMS-u","SHRM Advance","SHRM-a","SHRM-e","MiNi-SMMS-e","Mini SMMS R32","SMMS-e","SMMS Wave Tool Indoor Units"),
        "Αντλία θερμότητας αέρα-νερού" to listOf("ESTIA R32","ESTIA R410A","ESTIA Monobloc")
    )

    private val toyotomiModels:Map<String,List<String>> = linkedMapOf(
        "Split / Residential" to listOf(
            "SORA TSN/TSG-09R32","SORA TSN/TSG-12R32 PLUS","SORA TSN/TSG-18R32 PLUS","SORA TSN/TSG-24R32 PLUS",
            "UMI UTN/UTG-09CH","UMI UTN/UTG-12CH","UMI UTN/UTG-17CH","UMI UTN/UTG-18CH","UMI UTN/UTG-22CH","UMI UTN/UTG-24CH",
            "ERAI CTN/CTG-328W","ERAI CTN/CTG-335W","ERAI CTN/CTG-356W","ERAI CTN/CTG-371W",
            "ERAI CTN/CTG-328BV","ERAI CTN/CTG-335BV","ERAI CTN/CTG-356BV","ERAI CTN/CTG-371BV",
            "YUKI TYN/TYG-09R32 PLUS","YUKI TYN/TYG-12R32 PLUS","YUKI TYN/TYG-18R32 PLUS","YUKI TYN/TYG-24R32 PLUS"
        ),
        "Multi-Split" to listOf(
            "MULR32-14INV-2","MULR32-18INV-2","MULR32-21INV-3","MULR32-24INV-3","MULR32-28INV-4","MULR32-36INV-4","MULR32-42INV-5",
            "UTN-09CH","UTN-12CH","UTN-18CH","UTN-24CH",
            "CTN-328W","CTN-335W","CTN-356W","CTN-371W","CTN-328BV","CTN-335BV","CTN-356BV","CTN-371BV",
            "MULR32-E09CFTA","MULR32-E12CFTA","MULR32-E18CFTA","MULR32-E24CFTA",
            "MULR32-E12EWCA-CP","MULR32-E18EWCA-CP","MULR32-E24EWCA",
            "MUL24-E09DTA","MUL24-E12DTA","MUL24-E18DTA","MUL24-E24DTA"
        ),
        "Light Commercial / Floor-Ceiling" to listOf(
            "CFT18IUINVR32 / OU181INVR32","CFT24IUINVR32 / OU241INVR32","CFT36IUINVR32 / OU363INVR32",
            "CFT42IUINVR32 / OU423INVR32","CFT48IUINVR32 / OU483INVR32","CFT60IUINVR32 / OU603INVR32"
        ),
        "Light Commercial / Cassette" to listOf(
            "CCT12IUINVR32-CP / OU121INVR32","CCT18IUINVR32 / OU181INVR32","CCT24IUINVR32 / OU241INVR32",
            "CCT36IUINVR32 / OU363INVR32","CCT42IUINVR32 / OU423INVR32","CCT48IUINVR32 / OU483INVR32","CCT60IUINVR32 / OU603INVR32"
        ),
        "Light Commercial / Duct" to listOf(
            "DCT12IUINVR32 / OU121INVR32","DCT18IUINVR32 / OU181INVR32","DCT24IUINVR32 / OU241INVR32",
            "DCT28IUINVR32 / OU281INVR32","DCT36IUINVR32 / OU363INVR32","DCT42IUINVR32 / OU423INVR32",
            "DCT48IUINVR32 / OU483INVR32","DCT60IUINVR32 / OU603INVR32"
        ),
        "Light Commercial / Console" to listOf(
            "CON28IN24R32 / CON28OU24R32","CON36IN24R32 / CON36OU24R32","CON56IN24R32 / CON56OU24R32"
        ),
        "Light Commercial / Floor Standing" to listOf(
            "FSXK-A140IUINVR32 / FSXK-A140OUINVR32","FS-A170IUINVR32 / FS-A170OUINVR32"
        ),
        "Mobile / Φορητό" to listOf("TAD-2320","TAD-2326HP","TAD-2335HP","TAD-2220E","TAD-2226E","TAD-2229E","TAD-2235E"),
        "Αφυγραντήρας" to listOf("TD-2410","TD-2412","TD-2420","TD-ZB80"),
        "Αντλία θερμότητας αέρα-νερού" to listOf(
            "Hydria+ Monobloc","Hydria+ All-in-One","Hydria+ Split",
            "THSSDIU06/1 / THSSDOU06/1","THSSDIU08/3 / THSSDOU08/3"
        )
    )

    private val traneModels:Map<String,List<String>> = linkedMapOf(
        "Chiller / Ψύκτης" to listOf("Sintesis Excellent GVAF","Sintesis Advantage CGAF","Conquest CGAX","Conquest CXAX","XStream RTWF","XStream RTHF","CenTraVac CVHH","CenTraVac CVHF","City RTSF"),
        "Αντλία θερμότητας" to listOf("Sintesis Balance CMAF","Conquest CXAX","Leaf CXAF","Flex II RTMA"),
        "Rooftop" to listOf("Voyager 3","Voyager 2","Precedent"),
        "AHU / Air Handling" to listOf("Climate Changer","Performance Climate Changer","CCE Compact Air Handler")
    )

    // ===== FINAL BRANDS BATCH =====
    private val vaillantModels=linkedMapOf(
        "Αντλία θερμότητας αέρα-νερού" to listOf(
            "aroTHERM plus","aroTHERM Split plus","aroTHERM Split","aroTHERM pure","aroTHERM pro",
            "VWL 55/7.1 A 230V S3","VWL 85/7.1 A 230V S3"
        ),
        "Θερμοδυναμικό ΖΝΧ" to listOf(
            "aroSTOR plus","VWL B 200/6 230V","VWL BM 200/6 230V",
            "VWL B 260/6 230V","VWL BM 260/6 230V"
        ),
        "Αντλία θερμότητας γεωθερμική" to listOf("flexoTHERM exclusive","geoTHERM")
    )
    private val viessmannModels=linkedMapOf(
        "Αντλία θερμότητας αέρα-νερού" to listOf("Vitocal 250-A","Vitocal 252-A","Vitocal 150-A","Vitocal 151-A","Vitocal 200-A","Vitocal 222-A"),
        "Αντλία θερμότητας γεωθερμική" to listOf("Vitocal 200-G","Vitocal 222-G","Vitocal 300-G")
    )
    private val yorkModels=linkedMapOf(
        "Chiller / Ψύκτης" to listOf("YCAL","YLAA","YVAA","YVFA","YVWH","YMC2","YORK CYK"),
        "Αντλία θερμότητας" to listOf("YMPA","YMAA","YVAG"),
        "Rooftop" to listOf("Predator","Sunline","MagnaDRY","YORK Rooftop Packaged Units"),
        "AHU / Air Handling" to listOf("Solution AHU","Custom Air Handling Units")
    )
    private val pitsosModels=linkedMapOf(
        "Split / Inverter" to listOf("Pitsos Inverter 9000 BTU","Pitsos Inverter 12000 BTU","Pitsos Inverter 18000 BTU","Pitsos Inverter 24000 BTU")
    )
    private val sendoModels=linkedMapOf(
        "Split / Inverter" to listOf("Aeolos","Arion","Cronus","Ikaros","Zeas"),
        "Multi-Split" to listOf("Sendo Multi 2","Sendo Multi 3","Sendo Multi 4","Sendo Multi 5"),
        "Κασέτα" to listOf("Sendo Cassette"),
        "Καναλάτο / Duct" to listOf("Sendo Duct"),
        "Floor / Ceiling" to listOf("Sendo Floor Ceiling"),
        "Αντλία θερμότητας" to listOf("Sendo Heat Pump Monobloc","Sendo Heat Pump Split")
    )
    private val morrisModels=linkedMapOf(
        "Split / Inverter" to listOf(
            "SPIN-26192","SPIN-35192",
            "Nivora WFIN-26184","Nivora WFIN-35184","Nivora WFIN-50184","Nivora WFIN-70184",
            "Dream HMIN-26190","Dream HMIN-35190","Dream HMIN-50190","Dream HMIN-69190",
            "Loft Premium WFIN-26168","Loft Premium WFIN-35168","Loft Premium WFIN-50168","Loft Premium WFIN-70168",
            "Loft+ WFIN-26166","Loft+ WFIN-35166","Loft+ WFIN-50166","Loft+ WFIN-70166",
            "Terra WFIN-26180","Terra WFIN-35180","Terra WFIN-50180","Terra WFIN-70182",
            "Loft II WFIN-26164","Loft II WFIN-35164","Loft II WFIN-50164","Loft II WFIN-71164"
        ),
        "Κασέτα" to listOf("MLCI-14003","MLCI-16004"),
        "Καναλάτο / Duct" to listOf("MLDI-14001","MLDI-16002"),
        "Ντουλάπα / Floor Standing" to listOf("MLFI-16005","MLFI-16006")
    )
    private val juroProModels=linkedMapOf(
        "Split / Inverter" to listOf("Juro-Pro Inverter 9000 BTU","Juro-Pro Inverter 12000 BTU","Juro-Pro Inverter 18000 BTU","Juro-Pro Inverter 24000 BTU")
    )
    private val fuModels=linkedMapOf(
        "Split / Inverter" to listOf("F&U Inverter 9000 BTU","F&U Inverter 12000 BTU","F&U Inverter 18000 BTU","F&U Inverter 24000 BTU")
    )
    private val unitedModels=linkedMapOf(
        "Split / Inverter" to listOf("United Inverter 9000 BTU","United Inverter 12000 BTU","United Inverter 18000 BTU","United Inverter 24000 BTU")
    )
    private val argoModels=linkedMapOf(
        "Split / Inverter" to listOf(
            "EcoLight Plus","ArgoDeluxe A+++","Climadesign","Greenstyle Top","Freelife","NewAge Plus",
            "X3I Eco Plus","X3I Eco Plus 35","X3I Eco Plus 52"
        ),
        "Multi-Split" to listOf(
            "EcoLight Plus Multi","Climadesign Multi","Climadesign Dual 14000 WiFi R32",
            "Climadesign Dual 18000 WiFi R32","Climadesign Trial 21000 WiFi R32",
            "Greenstyle Top Multi","Freelife Multi","X3I Eco Plus Multi"
        ),
        "Κονσόλα" to listOf("Console X3I"),
        "Καναλάτο / Duct" to listOf("Duct X3I"),
        "Mobile / Φορητό" to listOf(
            "Milo Plus","Maxime Plus EU","Odin Plus","Luft","Vind EU WF","Kall Plus","Sphera",
            "Thor Plus HP","Axel","Twiggy Plus","Hermes Plus","Lari Art","Iside Art WF",
            "Class WF","Alpha Plus","Elite Plus EU","Etienne","Milo Evo Silent","Milo Inverter Supersilent"
        ),
        "Monobloc χωρίς εξωτερική" to listOf("Apollo 12 HP","Apollo 12 HP WiFi"),
        "Αντλία θερμότητας αέρα-νερού" to listOf("GENERA R290 Monobloc","iSERIES Air-to-Water","X3I Heat Pump"),
        "Fan Coil" to listOf("iSERIES Fan Coil","Floor Fan Coil")
    )
    private val ciatModels=linkedMapOf(
        "Chiller / Ψύκτης" to listOf(
            "AQUACIATPOWER LD R32","AQUACIATPOWER ILD R32","AQUACIAT LD R32",
            "EREBA 17-21","EREBA ACCESS","POWERCIAT LX",
            "DYNACIAT LG","DYNACIAT POWER LG","HYDROCIAT LW ST / LW HE"
        ),
        "Αντλία θερμότητας" to listOf(
            "AQUACIAT CALEO ITEV R290","AQUACIAT ILD R32","AQUACIATPOWER ILD R32",
            "EREBA ACCESS","DYNACIAT LG","DYNACIAT POWER LG","HYDROCIAT LW ST / LW HE"
        ),
        "Fan Coil / Comfort Units" to listOf(
            "COADIS LINE 600","COADIS LINE 900","MELODY2","COMFORT LINE","MAJOR LINE"
        ),
        "AHU / Air Handling" to listOf("CLIMACIAT","AIRTECH"),
        "Rooftop / Packaged" to listOf("SPACE","ROOFTOP"),
        "Dry Cooler / Condenser" to listOf("OPERA","VEXTRA"),
        "Precision / Close Control" to listOf("EXPAIR","MAGISTER")
    )

    private val mideaModels:Map<String,List<String>> = linkedMapOf(
        "Split / Inverter" to listOf(
            "All Easy Pro AEP2-09NXD6-I","All Easy Pro AEP2-12NXD6-I",
            "All Easy Pro AEP2-18NXD6-I","All Easy Pro AEP2-24NXD6-I",
            "Xtreme Save AG1-09NXD6-I","Xtreme Save AG1-12NXD6-I",
            "Xtreme Save AG1-18NXD0-I","Xtreme Save AG1-24NXD0-I",
            "Xtreme Graphite AG16Graph-09N8D6-I","Xtreme Graphite AG16Graph-12N8D0-I",
            "Xtreme Graphite AG16Graph-18N8D0-I","Xtreme Graphite AG16Graph-24N8D0-I",
            "Gaia GAIA-09HRFN8-I","Gaia GAIA-12HRFN8-I",
            "Breezeless E CB1-09HRFN8-I","Breezeless E CB1-12HRFN8-I","Breezeless E CB1-18HRFN8-I"
        ),
        "Multi-Split" to listOf(
            "Free Match Multi Outdoor 2-Port",
            "Free Match Multi Outdoor 3-Port",
            "Free Match Multi Outdoor 4-Port",
            "Free Match Multi Outdoor 5-Port",
            "Wall Mounted Multi Indoor",
            "Cassette Multi Indoor",
            "Duct Multi Indoor",
            "Console Multi Indoor"
        ),
        "Καναλάτο" to listOf(
            "Medium Static Pressure Duct • MI2-22-140T2DHN1",
            "High Static Pressure Duct • MI2-71-280T1DHN1",
            "High Static Pressure Duct • MDV-D400-D560T1/N1",
            "Large Split Duct • MOUA-96HD1N1-R"
        ),
        "Κασέτα" to listOf(
            "One-Way Cassette • MI218-71Q1DHN1",
            "Compact Four-Way Cassette • MI2-22-45Q4CDHN1",
            "Two-Way Cassette • MI2-22-71Q2DHN1",
            "Four-Way Cassette • MI2-28-140Q4DHN1"
        ),
        "VRF / VRV" to listOf(
            "V8 Heat Pump • MV8-252~1120WV2GN1",
            "V6 Heat Pump • MV6-252W~900WV2GN1",
            "V6-I Heat Pump • MV6-I252~I900WV2GN1",
            "V6R Heat Recovery • MV6-R252W~R450WV2GN1",
            "VC Pro • MVC-224-560WV2GN1 / MVC-615-850WV2GN1",
            "Mini C VRF • MDV-V80_160W/DHN1(C)",
            "R32 V8 Mini • MV8M-80WV2N8 / MV8M-100WV2N8"
        ),
        "Chiller / Ψύκτης" to listOf(
            "Aqua Thermal Modular • MC-SU75/90/140/180-RN8L-B",
            "DC Inverter Air-Cooled Chiller • MC-SU30/60/90-RN1L/RN8L",
            "Air-Cooled Screw Chiller • LSBLGW380-1420/C",
            "Water-Cooled Screw Chiller • SCWE70-470H-A",
            "MagBoost Centrifugal • CCWG170-1250EV",
            "Centrifugal • CCWE600-2200E"
        ),
        "Αντλία θερμότητας" to listOf(
            "R290 M thermal Arctic HT • MHC-V4/6/8/10/12/14/16WD2N7",
            "R290 M thermal Arctic HT 3Ph • MHC-V12/14/16WD2RN7",
            "Aqua Thermal Super • MH-SU65/75/110/140-RN8L",
            "Aqua Eco Mini • MGC-V5/7/9/12/14/16WD2N8-B",
            "M thermal Power • MHA-V16WD2RN8M-C",
            "Commercial HP Water Heater • RSJ-120/ZN1-540V1"
        )
    )

    private fun mideaRemotePhoto(type:String,model:String,height:Int):ImageView=ImageView(this).apply{
        scaleType=ImageView.ScaleType.CENTER_INSIDE
        adjustViewBounds=true
        setPadding(2,2,2,2)
        background=GradientDrawable().apply{
            setColor(Color.WHITE);cornerRadius=18f;setStroke(1,Color.rgb(232,236,241))
        }
        clipToOutline=true
        contentDescription="Φωτογραφία Midea • $model"

        val target=this
        val cacheFile=File(cacheDir,"midea_"+(model.hashCode().toLong() and 0xffffffffL).toString(16)+".jpg")
        if(cacheFile.exists() && cacheFile.length()>1000){
            try{BitmapFactory.decodeFile(cacheFile.absolutePath)?.let{setImageBitmap(normalizeProductPhotoSize(it))}}catch(_:Exception){}
            return@apply
        }

        Thread{
            try{
                val page=mideaPhotoUrl(model)
                val c=(URL(page).openConnection() as HttpURLConnection).apply{
                    connectTimeout=7000;readTimeout=10000;instanceFollowRedirects=true
                    setRequestProperty("User-Agent","Mozilla/5.0 (Android) Psyktikos/1.3")
                }
                if(c.responseCode !in 200..299){c.disconnect();return@Thread}
                val html=c.inputStream.bufferedReader().use{it.readText()}.replace("\\/","/").replace("&amp;","&")
                c.disconnect()
                val imgs=linkedSetOf<String>()
                Regex("""(?i)<meta[^>]+(?:property|name)=["'](?:og:image|twitter:image)["'][^>]+content=["']([^"']+)["']""")
                    .findAll(html).forEach{imgs.add(it.groupValues[1])}
                Regex("""(?i)(?:src|data-src)=["']([^"']+\.(?:jpg|jpeg|png|webp)(?:\?[^"']*)?)["']""")
                    .findAll(html).forEach{imgs.add(it.groupValues[1])}
                for(raw in imgs){
                    val u=when{
                        raw.startsWith("http")->raw
                        raw.startsWith("//")->"https:$raw"
                        raw.startsWith("/")->"https://www.midea.com$raw"
                        else->continue
                    }
                    try{
                        val ic=(URL(u).openConnection() as HttpURLConnection).apply{
                            connectTimeout=7000;readTimeout=12000;instanceFollowRedirects=true
                            setRequestProperty("User-Agent","Mozilla/5.0 (Android) Psyktikos/1.3")
                        }
                        if(ic.responseCode !in 200..299){ic.disconnect();continue}
                        val bytes=ic.inputStream.use{it.readBytes()};ic.disconnect()
                        if(bytes.size<5000) continue
                        val bmp=BitmapFactory.decodeByteArray(bytes,0,bytes.size) ?: continue
                        if(bmp.width<250 || bmp.height<120) continue
                        try{cacheFile.writeBytes(bytes)}catch(_:Exception){}
                        runOnUiThread{target.setImageBitmap(normalizeProductPhotoSize(bmp))}
                        break
                    }catch(_:Exception){}
                }
            }catch(_:Exception){}
        }.start()
    }

    private fun mideaPhotoUrl(model:String):String = when {
        model.contains("AG1-09",true) -> "https://www.midea.com/gr/hvac/monosplit/Wall-mounted-Air-Conditioner-Xtreme-Save-9000-BTU.ag1-09nxd6-i"
        model.contains("AG1-12",true) -> "https://www.midea.com/gr/hvac/monosplit/Wall-mounted-Air-Conditioner-Xtreme-Save-12000-BTU.ag1-12nxd6-i"
        model.contains("AG1-18",true) -> "https://www.midea.com/gr/hvac/monosplit/Wall-mounted-Air-Conditioner-Xtreme-Save-18000-BTU.ag1-18nxd0-i"
        model.contains("AG1-24",true) -> "https://www.midea.com/gr/hvac/monosplit/Wall-mounted-Air-Conditioner-Xtreme-Save-24000-BTU.ag1-24nxd0-i"
        model.contains("AEP2-",true) || model.contains("AG16GRAPH",true) || model.contains("GAIA-",true) || model.contains("CB1-",true) ->
            "https://www.midea.com/gr/hvac/monosplit"
        model.contains("CASSETTE",true) || model.contains("MI218-",true) || model.contains("Q4",true) || model.contains("Q2",true) ->
            "https://mbt.midea.com/global/hvac-goods/midea-products-category/vrfs/vrf-idu"
        model.contains("DUCT",true) || model.contains("MI2-",true) || model.contains("MDV-D",true) || model.contains("MOUA-",true) ->
            "https://mbt.midea.com/global/hvac-goods/midea-products-category/vrfs/vrf-idu"
        model.contains("MV8",true) || model.contains("MV6",true) || model.contains("MVC-",true) || model.contains("MINI",true) ->
            "https://mbt.midea.com/global/hvac-goods/midea-products-category/vrfs/vrf-odu"
        model.contains("CHILLER",true) || model.contains("MC-SU",true) || model.contains("LSBLG",true) || model.contains("SCWE",true) || model.contains("CCW",true) ->
            "https://mbt.midea.com/global/hvac-goods/midea-products-category/chillers/chillers"
        model.contains("MHC-",true) || model.contains("MH-SU",true) || model.contains("MGC-",true) || model.contains("MHA-",true) || model.contains("RSJ-",true) ->
            "https://mbt.midea.com/global/hvac-goods/midea-products-category/heat-pumps"
        else -> "https://www.midea.com/gr/hvac"
    }

    private fun mideaGeneratedFaults(type:String,model:String):List<Fault>{
        fun m(code:String,meaning:String,causes:String,checks:String,action:String,source:String)=
            Fault("Midea",code,meaning,meaning,causes,checks,action,type,model,source)

        val residential=listOf(
            m("E0","Σφάλμα EEPROM εσωτερικής μονάδας","Μνήμη EEPROM ή πλακέτα εσωτερικής μονάδας.","Κάνε reset τροφοδοσίας και έλεγξε πλακέτα/συνδέσεις.","Αν επιμένει, επισκευή ή αντικατάσταση πλακέτας.","Midea residential AC service error table"),
            m("E1","Σφάλμα επικοινωνίας εσωτερικής–εξωτερικής μονάδας","Καλωδίωση επικοινωνίας, τροφοδοσία ή PCB.","Έλεγξε καλωδίωση, ακροδέκτες, τάσεις και επικοινωνία.","Διόρθωσε καλωδίωση ή επιβεβαιωμένη πλακέτα.","Midea residential AC service error table"),
            m("E2","Σφάλμα ανίχνευσης zero crossing","Τροφοδοσία ή κύκλωμα ανίχνευσης PCB.","Έλεγξε τάση δικτύου και πλακέτα εσωτερικής.","Διόρθωσε τροφοδοσία ή PCB.","Midea residential AC service error table"),
            m("E3","Σφάλμα ταχύτητας ανεμιστήρα εσωτερικής","Μοτέρ ανεμιστήρα, hall feedback ή PCB.","Έλεγξε ελεύθερη περιστροφή, φίσα, μοτέρ και feedback.","Επισκευή/αντικατάσταση μοτέρ ή PCB.","Midea residential AC service error table"),
            m("E4","Σφάλμα αισθητήρα θερμοκρασίας χώρου T1","T1 open/short ή καλωδίωση.","Μέτρησε αντίσταση T1 και έλεγξε φίσα.","Αντικατάσταση αισθητήρα ή επισκευή καλωδίωσης.","Midea residential AC service error table"),
            m("E5","Σφάλμα αισθητήρα εξατμιστή T2","T2 open/short ή καλωδίωση.","Μέτρησε T2 και έλεγξε φίσα.","Αντικατάσταση αισθητήρα ή καλωδίωσης.","Midea residential AC service error table"),
            m("EC","Ανίχνευση διαρροής ψυκτικού","Έλλειψη ψυκτικού, διαρροή ή λανθασμένη ένδειξη αισθητήρων.","Έλεγξε διαρροές, πιέσεις/θερμοκρασίες και αισθητήρες.","Επισκεύασε διαρροή και φόρτισε σωστά.","Midea residential AC refrigerant leakage protection"),
            m("F1","Σφάλμα αισθητήρα εξωτερικού αέρα T4","T4 open/short.","Μέτρησε T4 και καλωδίωση.","Αντικατάσταση T4/καλωδίωσης.","Midea outdoor unit service error table"),
            m("F2","Σφάλμα αισθητήρα συμπυκνωτή T3","T3 open/short.","Μέτρησε T3 και καλωδίωση.","Αντικατάσταση T3/καλωδίωσης.","Midea outdoor unit service error table"),
            m("F3","Σφάλμα αισθητήρα κατάθλιψης T5","T5 open/short.","Μέτρησε T5 και καλωδίωση.","Αντικατάσταση T5/καλωδίωσης.","Midea outdoor unit service error table"),
            m("F4","Σφάλμα EEPROM εξωτερικής μονάδας","EEPROM/PCB εξωτερικής.","Reset και έλεγχος PCB.","Αντικατάσταση επιβεβαιωμένης PCB.","Midea outdoor unit service error table"),
            m("F5","Σφάλμα ταχύτητας ανεμιστήρα εξωτερικής","Μοτέρ, feedback ή PCB.","Έλεγξε ανεμιστήρα, φίσα, μοτέρ και drive.","Επισκευή/αντικατάσταση μοτέρ ή PCB.","Midea outdoor unit service error table"),
            m("P0","Προστασία IPM / inverter","IPM, συμπιεστής ή κύκλωμα inverter.","Έλεγξε συμπιεστή, μόνωση, IPM και τροφοδοσία.","Επισκευή inverter ή συμπιεστή αν επιβεβαιωθεί.","Midea inverter protection table"),
            m("P1","Προστασία υπέρτασης / υπότασης","Τάση δικτύου ή DC bus εκτός ορίων.","Μέτρησε τροφοδοσία και DC bus.","Διόρθωσε τροφοδοσία ή inverter PCB.","Midea inverter protection table"),
            m("P2","Προστασία υψηλής θερμοκρασίας συμπιεστή","Υψηλή κατάθλιψη, έλλειψη ψυκτικού, airflow ή αισθητήρας.","Έλεγξε ψυκτικό, airflow και αισθητήρα κατάθλιψης.","Διόρθωσε αιτία υπερθέρμανσης.","Midea compressor protection table"),
            m("P4","Σφάλμα οδήγησης inverter συμπιεστή","Inverter drive ή συμπιεστής.","Έλεγξε winding/insulation συμπιεστή και inverter output.","Επισκευή inverter ή συμπιεστή.","Midea inverter compressor drive table")
        )

        val commercial=listOf(
            m("E0","Σφάλμα EEPROM / παραμέτρων","PCB ή μνήμη παραμέτρων.","Reset και έλεγχος PCB.","Αντικατάσταση επιβεβαιωμένης PCB.","Midea commercial/VRF service error table"),
            m("E1","Σφάλμα επικοινωνίας","Δίαυλος επικοινωνίας, διεύθυνση ή PCB.","Έλεγξε καλωδίωση, πολικότητα/διευθύνσεις και τροφοδοσία.","Διόρθωσε επικοινωνία ή PCB.","Midea commercial/VRF service error table"),
            m("E2","Σφάλμα επικοινωνίας/διεύθυνσης","Λάθος address ή bus communication.","Έλεγξε addressing και bus.","Διόρθωσε address/communication.","Midea commercial/VRF service error table"),
            m("E3","Σφάλμα αισθητήρα / fan control","Αισθητήρας ή fan feedback ανά μονάδα.","Διάβασε sub-code/controller και έλεγξε αντίστοιχο εξάρτημα.","Επισκευή αισθητήρα/fan circuit.","Midea commercial service table"),
            m("E4","Σφάλμα αισθητήρα θερμοκρασίας","Open/short θερμίστορ.","Μέτρησε θερμίστορ και harness.","Αντικατάσταση αισθητήρα/καλωδίωσης.","Midea commercial service table"),
            m("E5","Σφάλμα αισθητήρα θερμοκρασίας","Open/short θερμίστορ.","Μέτρησε θερμίστορ και harness.","Αντικατάσταση αισθητήρα/καλωδίωσης.","Midea commercial service table"),
            m("E6","Σφάλμα ανεμιστήρα / επικοινωνίας","Fan drive ή communication ανά μονάδα.","Έλεγξε controller indication και wiring.","Επισκευή επιβεβαιωμένης αιτίας.","Midea commercial service table"),
            m("P0","Προστασία inverter / IPM","IPM, compressor, supply.","Έλεγξε inverter, compressor και τάση.","Επισκευή inverter/compressor.","Midea commercial inverter protection"),
            m("P1","Προστασία τάσης","Υπέρταση/υπόταση ή DC bus.","Μέτρησε supply/DC bus.","Διόρθωσε supply ή power PCB.","Midea commercial inverter protection"),
            m("P2","Προστασία θερμοκρασίας","Υπερθέρμανση compressor/drive.","Έλεγξε airflow, refrigerant circuit και sensors.","Διόρθωσε αιτία υπερθέρμανσης.","Midea commercial protection table"),
            m("P4","Σφάλμα inverter drive","Compressor drive/inverter abnormality.","Έλεγξε compressor και inverter output.","Επισκευή inverter/compressor.","Midea commercial inverter protection")
        )

        return if(type=="Split / Inverter" || type=="Multi-Split") residential else commercial
    }

    private fun mitsubishiGeneratedFaults(type:String,model:String):List<Fault>{
        val key=mitsubishiModelKey(model)

        fun m(code:String,sym:String,meaning:String,causes:String,checks:String,action:String,source:String)=
            Fault("Mitsubishi Electric",code,sym,meaning,causes,checks,action,type,model,source)

        // ===== MITSUBISHI M-SERIES / SPLIT: STRICT MANUAL INDICATIONS =====
        // The blue title shown by the app is ALWAYS an actual Mitsubishi manual
        // indication/code. Descriptive labels are kept in meaning/symptom only.
        val splitManual=when(key){
            "MSZ-LN" -> "MSZ-LN service manual OBH766H + MUZ-LN service manual OBH767H"
            "MSZ-AY" -> "MSZ-AY service manual OBH932 + MUZ-AY service manual OBH931B"
            "MSZ-BT" -> "MSZ-BT service manual OBH849 + MUZ-BT service manual OBH850"
            "MSZ-DW" -> "MSZ-DW service manual OBH905 + MUZ-DW service manual OBH906"
            "MSZ-AP" -> "MSZ-AP service manual OBH788/OBH788-B + MUZ-AP OBH789/OBH789-A"
            "MSZ-HR" -> "MSZ-HR service manual OBH822H + matching MUZ-HR service manual"
            "MSZ-EF" -> "MSZ-EF service manual OBH831D + MUZ-EF OBH832D"
            "MSZ-FT" -> "MSZ-FT service manual OBH864C + MUZ-FT OBH865"
            "MSZ-RW" -> "MSZ-RW service manual OBH902A + MUZ-RW OBH903"
            "MFZ-KT" -> "MFZ-KT / matched outdoor Mitsubishi Electric service manuals"
            "MFZ-KW" -> "MFZ-KW / matched outdoor Mitsubishi Electric service manuals"
            "MLZ-KP" -> "MLZ-KP / matched outdoor Mitsubishi Electric service manuals"
            else -> "Mitsubishi Electric service manual for $model"
        }

        fun splitCore():List<Fault> = listOf(
            m("E9","Wireless: 1 blink","Indoor/outdoor communication error (transmit/outdoor)",
              "Indoor/outdoor serial communication abnormality.","Check S1-S2-S3 wiring, terminals and serial signal.",
              "Correct wiring/communication fault.",splitManual),
            m("UP","Wireless: 2 blinks","Compressor overcurrent interruption",
              "Compressor/inverter overcurrent protection.","Check compressor, inverter and supply.",
              "Repair confirmed compressor/inverter cause.",splitManual),
            m("U3 / U4","Wireless: 3 blinks","Outdoor thermistor open/short",
              "One or more outdoor thermistors are open/short.","Identify exact thermistor from matched outdoor manual and measure it.",
              "Repair harness or replace indicated thermistor.",splitManual),
            m("UF","Wireless: 4 blinks","Compressor overcurrent interruption (locked compressor)",
              "Locked compressor / inverter or compressor circuit abnormality.","Check compressor winding/insulation, inverter and wiring.",
              "Repair inverter/wiring or replace confirmed compressor.",splitManual),
            m("U2","Wireless: 5 blinks","Abnormally high discharge temperature / refrigerant shortage",
              "High discharge temperature, refrigerant shortage or related refrigerant-circuit abnormality.",
              "Check refrigerant amount/leakage, LEV, discharge sensor and airflow.",
              "Repair leak/LEV/airflow cause and charge correctly.",splitManual),
            m("U1 / Ud","Wireless: 6 blinks","High-pressure / overheat protection",
              "High pressure or overheating protection operates.","Check airflow, heat exchangers, fan, charge and stop valves.",
              "Correct airflow/refrigerant/valve cause.",splitManual),
            m("U5","Wireless: 7 blinks","Heat-sink temperature abnormality",
              "Inverter heat-sink temperature is abnormal.","Check outdoor airflow, fan and inverter cooling.",
              "Restore cooling or repair fan/inverter.",splitManual),
            m("U8","Wireless: 8 blinks","Outdoor fan protection",
              "Outdoor fan motor/protection abnormality.","Check fan freedom, motor, connector and inverter-board drive.",
              "Repair/replace fan motor or confirmed board.",splitManual),
            m("U6","Wireless: 9 blinks","Power module / compressor overcurrent abnormality",
              "Power module or compressor overcurrent abnormality.","Check compressor insulation/winding and inverter power module.",
              "Repair/replace confirmed inverter or compressor.",splitManual),
            m("U7","Wireless: 10 blinks","Abnormal superheat due to low discharge temperature",
              "Low discharge-temperature/superheat abnormality.","Check refrigerant circuit, LEV and discharge thermistor.",
              "Repair refrigerant/LEV/sensor cause.",splitManual),
            m("U9 / UH","Wireless: 11 blinks","Voltage / current-sensor / synchronization abnormality",
              "Over/undervoltage, synchronization or current-sensor abnormality.","Measure supply and check inverter current-detection/power circuit.",
              "Correct supply or repair inverter/power circuit.",splitManual),

            m("E0","Wired controller","Remote-controller communication error",
              "Remote-controller communication abnormality.","Check remote-controller wiring/addressing and controller.",
              "Correct wiring/address/controller fault.",splitManual),
            m("E1","Wired controller","Remote-controller addressing / wiring abnormality",
              "Remote-controller setup or communication problem.","Check controller address/settings and wiring.",
              "Correct addressing/wiring.",splitManual),
            m("E3","Wired controller","Remote-controller communication abnormality",
              "Remote-controller transmission/reception abnormality.","Check controller wiring and communication circuit.",
              "Repair wiring/controller/control board as confirmed.",splitManual),
            m("E4","Wired controller","Remote-controller communication abnormality",
              "Remote-controller communication fault.","Check controller wiring and communication circuit.",
              "Repair confirmed cause.",splitManual),
            m("E5","Wired controller","Remote-controller communication abnormality",
              "Remote-controller communication fault.","Check controller wiring and communication circuit.",
              "Repair confirmed cause.",splitManual),
            m("E6","Wired controller","Indoor/outdoor communication receiving error",
              "Indoor/outdoor communication reception abnormality.","Check S1-S2-S3 and indoor/outdoor boards.",
              "Correct wiring or repair confirmed board.",splitManual),
            m("E7","Wired controller","Indoor/outdoor communication abnormality",
              "Indoor/outdoor serial communication abnormality.","Check interconnect wiring and communication circuit.",
              "Correct wiring/communication fault.",splitManual),
            m("E8","Wired controller","Indoor/outdoor communication receiving error",
              "Indoor/outdoor communication reception abnormality.","Check S1-S2-S3 and communication circuit.",
              "Correct wiring or repair confirmed board.",splitManual),
            m("EA","Wired controller","Indoor/outdoor miswiring / communication abnormality",
              "Miswiring, loose cable or communication interference.","Check terminal order, cable condition and noise sources.",
              "Correct wiring/cable problem.",splitManual),
            m("Eb","Wired controller","Indoor/outdoor wiring / communication abnormality",
              "Miswiring, loose cable, interference or wrong cable specification.","Check cable specification, terminals and routing.",
              "Correct wiring/cable specification.",splitManual),
            m("EC","Wired controller","Startup / initialization communication failure",
              "Communication initialization did not complete normally.","Check wiring, addressing and connected control devices.",
              "Correct setup/wiring/control fault.",splitManual),
            m("Ed","Wired controller","Serial communication error",
              "Serial communication between outdoor control/power circuits is abnormal.","Check outdoor control/power-board communication and connectors.",
              "Repair confirmed board/communication fault.",splitManual),
            m("EF","Wired controller","Undefined / communication-noise error",
              "Undefined error or communication noise/interference.","Check wiring, shielding/routing and control boards.",
              "Remove interference or repair confirmed control fault.",splitManual),

            m("P4","Applicable wired-controller systems","Drain sensor / drain float-switch abnormality",
              "Drain sensor or float-switch contact abnormality.","Check drain sensor/float switch, wiring and drain system.",
              "Repair drain circuit/sensor.",splitManual),
            m("P5","Applicable wired-controller systems","Drain overflow protection",
              "Drain overflow detected.","Check drain blockage, pump and pan.",
              "Clear drain or repair pump.",splitManual),
            m("P6","Applicable wired-controller systems","Freezing / overheating protection",
              "Heat-exchanger freezing or overheating protection.","Check airflow, filters/coils and refrigerant circuit.",
              "Correct airflow/refrigerant cause.",splitManual),
            m("P8","Applicable wired-controller systems","Pipe-temperature abnormality",
              "Abnormal pipe-temperature condition.","Check pipe thermistor, airflow and refrigerant circuit.",
              "Repair sensor/airflow/refrigerant cause.",splitManual),
            m("F3","Applicable outdoor systems","Low-pressure sensor / 63L abnormality",
              "Low-pressure sensor/circuit abnormality where fitted.","Check 63L/low-pressure sensor connector and circuit.",
              "Repair connector/sensor/circuit.",splitManual),
            m("F5","Applicable outdoor systems","High-pressure sensor / 63H abnormality",
              "High-pressure sensor/circuit abnormality where fitted.","Check 63H/high-pressure sensor connector and circuit.",
              "Repair connector/sensor/circuit.",splitManual)
        )

        if(key.startsWith("MSZ-") || key.startsWith("MFZ-") || key=="MLZ-KP"){
            val extras=when(key){
                "MSZ-RW" -> listOf(
                    m("i-see Recall ×6","Stored sensor fault","i-see SENSOR",
                      "Poor contact in i-see SENSOR wiring or failure loading corrected sensor data.",
                      "Check i-see SENSOR connectors and run the simple sensor check specified in OBH902A.",
                      "Repair connection or replace confirmed sensor/control component.",splitManual)
                )
                else -> emptyList()
            }
            return (splitCore()+extras).distinctBy{it.code+"|"+it.meaning}
        }

        // MXZ-F / MXZ-2F~6F — OBH790P failure-mode recall.
        // These are the actual indoor OPERATION INDICATOR blink indications used by the manual.
        if(key.startsWith("MXZ-")){
            val src790="Mitsubishi Electric OBH790P §12-3/12-4/12-6"
            return listOf(
                m("2 blinks","Outdoor power system","Outdoor power system protection",
                  "Overcurrent/converter/bus-bar voltage protection repeatedly operated after compressor startup.",
                  "Check compressor wiring, stop valves and follow the inverter/compressor check.",
                  "Correct wiring/valve/power fault or repair confirmed inverter/compressor.",src790),
                m("3 blinks","Outdoor thermistor","Discharge/defrost/ambient/fin/PCB/heat-exchanger thermistor abnormality",
                  "An applicable outdoor thermistor is open or short during compressor operation.",
                  "Read outdoor LED1/LED2 sub-indication and check the corresponding thermistor and harness.",
                  "Repair harness or replace the confirmed thermistor/control board.",src790),
                m("4 blinks","Overcurrent","Power-module overcurrent protection",
                  "Abnormal compressor/inverter current; OBH790P specifies overcurrent at the power module.",
                  "Reconnect compressor connector; check stop valve and run inverter/compressor diagnosis.",
                  "Correct connection/valve fault or repair confirmed inverter/compressor.",src790),
                m("5 blinks","Discharge temperature","Discharge-temperature protection",
                  "Discharge temperature exceeded the model-specific protection threshold.",
                  "Check refrigerant circuit/amount and perform LEV check.",
                  "Repair refrigerant leak/restriction/LEV cause and charge to specification.",src790),
                m("6 blinks","High pressure","High-pressure protection",
                  "Outdoor heat-exchanger temperature in cooling or indoor gas-pipe temperature in heating exceeded protection threshold.",
                  "Check refrigerant circuit/amount and stop valves; inspect airflow/heat exchange.",
                  "Correct refrigerant/valve/airflow cause.",src790),
                m("7 blinks","Fin temperature","Inverter fin-temperature protection",
                  "Power-device fin temperature exceeded the model-specific limit.",
                  "Check outdoor installation space, air passage and outdoor fan motor.",
                  "Restore airflow/cooling or repair confirmed fan/power component.",src790),
                m("8 blinks","Outdoor fan motor","Outdoor fan motor abnormality",
                  "Fan startup/feedback failure occurred repeatedly.",
                  "Follow OBH790P outdoor fan motor check; inspect fan freedom, connector and drive.",
                  "Remove obstruction or repair/replace confirmed fan motor/board.",src790),
                m("9 blinks","Outdoor control system","Outdoor control P.C. board abnormality",
                  "Nonvolatile memory data cannot be read correctly.",
                  "Confirm outdoor LED indication and board/connectors.",
                  "Replace the confirmed outdoor control P.C. board.",src790),
                m("10 blinks","Low discharge temperature","Low-discharge-temperature protection",
                  "Compressor remained at high frequency while discharge temperature stayed abnormally low.",
                  "Check refrigerant circuit/amount and perform LEV check.",
                  "Correct refrigerant/LEV abnormality.",src790),
                m("LED1 lit / LED2 12 blinks","4-way valve","4-way valve switching abnormality",
                  "R.V. coil disconnected/poorly connected or 4-way valve faulty.",
                  "Perform R.V. coil check and verify 4-way valve operation.",
                  "Repair connector/coil or replace confirmed 4-way valve.",src790),
                m("LED1/LED2 OFF","No outdoor operation","Outdoor power supply / standby-power condition",
                  "Supply/power circuit abnormality or low-standby-power setting/connection issue depending on model.",
                  "Follow OBH790P power-supply and low-standby-power checks for the exact MXZ revision.",
                  "Restore supply or correct the specified standby-power setting/power circuit.",src790),
                m("SW871 correction failed","Piping/wiring auto-correction","Automatic piping/wiring correction did not complete",
                  "Incorrect piping/wiring, closed stop valve, unsuitable outdoor temperature or detection failure.",
                  "Check stop valves, interconnect wiring and piping; rerun SW871 only under manual conditions.",
                  "Correct piping/wiring/valve condition and repeat the prescribed check.",src790)
            )
        }

        // Mr Slim / P-Series indoor & outdoor: PAR controller/self-diagnosis code families.
        if(type=="Επαγγελματικό / Mr Slim" || key in listOf("SEZ-M","PEAD-M","PEA-M","SLZ-M","PLA-M","PKA-M","PCA-M","PSA-M","PUZ-ZM","PUZ-M","SUZ-M")){
            return listOf(
                m("P1","Stops / sensor fault","Intake-air thermistor abnormality","Open/short intake thermistor or wiring.","Measure sensor and inspect connector.","Repair wiring or replace thermistor.","Mitsubishi Electric Mr Slim P-Series service manuals / PAR self-diagnosis tables"),
                m("P2","Stops / sensor fault","Liquid-pipe thermistor abnormality","Open/short pipe thermistor or wiring.","Measure sensor resistance and harness.","Repair wiring or replace thermistor.","Mitsubishi Electric Mr Slim P-Series service manuals / PAR self-diagnosis tables"),
                m("P4","Drain fault","Drain sensor / drain system abnormality","Drain sensor, pump, blockage or wiring abnormality.","Check pan, drain line, pump, float/sensor and connector.","Clear drain or repair pump/sensor circuit.","Mitsubishi Electric Mr Slim P-Series service manuals / PAR self-diagnosis tables"),
                m("P5","Water leakage / stop","Drain overflow protection","Drain pump failure, blockage or abnormal water level.","Inspect drain pan, pump operation and drain piping.","Clear blockage or repair drain pump/system.","Mitsubishi Electric Mr Slim P-Series service manuals / PAR self-diagnosis tables"),
                m("P6","Protection stop","Freezing / overheating protection","Airflow restriction, dirty filter/coil, refrigerant or fan problem.","Check airflow, filters/coils, fan and refrigerant circuit.","Correct airflow/refrigerant cause.","Mitsubishi Electric Mr Slim P-Series service manuals / PAR self-diagnosis tables"),
                m("P8","Stops / temperature abnormal","Pipe-temperature abnormality","Refrigerant circuit, thermistor, valve or airflow abnormality.","Check pipe temperatures, thermistors, refrigerant and valves.","Repair confirmed refrigerant/sensor/valve fault.","Mitsubishi Electric Mr Slim P-Series service manuals / PAR self-diagnosis tables"),
                m("P9","Sensor fault","Two-phase pipe thermistor abnormality","Thermistor open/short or harness fault.","Measure thermistor and wiring.","Repair connection or replace thermistor.","Mitsubishi Electric Mr Slim P-Series service manuals / PAR self-diagnosis tables"),
                m("E0 / E4","Remote-control fault","Remote controller communication abnormality","Remote wiring, address, controller or indoor board issue.","Check controller cable, polarity/address and communication.","Repair wiring/address or replace confirmed controller/board.","Mitsubishi Electric Mr Slim P-Series service manuals / PAR self-diagnosis tables"),
                m("E6 / E7","Indoor/outdoor communication fault","Signal transmission abnormality","Interconnect wiring, noise, board or power abnormality.","Check indoor/outdoor wiring, voltage and communication line.","Correct wiring/power or repair confirmed board.","Mitsubishi Electric Mr Slim P-Series service manuals / PAR self-diagnosis tables"),
                m("E8 / E9","Indoor/outdoor communication fault","Signal reception/transmission abnormality","Open/short/noisy transmission line or board fault.","Inspect communication wiring/connectors and boards.","Repair communication circuit.","Mitsubishi Electric Mr Slim P-Series service manuals / PAR self-diagnosis tables"),
                m("U1 / Ud","High-pressure protection","Abnormal high pressure / discharge condition","Blocked airflow/water flow, overcharge, valve or pressure circuit issue.","Check heat exchanger, fan/pump, refrigerant charge, valves and pressure sensors.","Correct high-pressure cause.","Mitsubishi Electric Mr Slim outdoor-unit service manuals / self-diagnosis tables"),
                m("U2","Discharge-temperature protection","High discharge temperature","Refrigerant shortage/restriction, thermistor or compressor load.","Check leakage/charge, discharge thermistor, valves and restriction.","Repair leak/restriction and charge correctly.","Mitsubishi Electric Mr Slim outdoor-unit service manuals / self-diagnosis tables"),
                m("U3 / U4","Outdoor thermistor fault","Outdoor sensor open/short","Thermistor or harness abnormality.","Measure outdoor thermistors and harness.","Repair wiring or replace sensor.","Mitsubishi Electric Mr Slim outdoor-unit service manuals / self-diagnosis tables"),
                m("U5","Outdoor temperature protection","Outdoor heat-sink / temperature abnormality","Cooling/airflow or temperature sensing problem.","Check outdoor airflow, heat sink, fan and thermistor.","Restore cooling/airflow or replace failed sensor.","Mitsubishi Electric Mr Slim outdoor-unit service manuals / self-diagnosis tables"),
                m("U6","Compressor overcurrent","Power/inverter/compressor protection","Overcurrent, compressor or inverter abnormality.","Check compressor, inverter module, supply and current.","Repair inverter/power circuit or compressor as confirmed.","Mitsubishi Electric Mr Slim outdoor-unit service manuals / self-diagnosis tables"),
                m("U7","Superheat / low refrigerant condition","Abnormal discharge superheat","Refrigerant shortage, restriction, LEV/valve or sensor issue.","Check charge/leaks, LEV, piping restriction and thermistors.","Repair leak/restriction/LEV and recharge correctly.","Mitsubishi Electric Mr Slim outdoor-unit service manuals / self-diagnosis tables"),
                m("U8","Outdoor fan fault","Outdoor fan motor abnormality","Fan motor, connector or outdoor board drive fault.","Check fan rotation, motor and board output.","Repair/replace fan motor or board.","Mitsubishi Electric Mr Slim outdoor-unit service manuals / self-diagnosis tables"),
                m("UF","Compressor current interruption","Compressor lock / overcurrent protection","Compressor/inverter/wiring abnormality.","Check compressor resistance/insulation, wiring and inverter.","Repair electrical fault or replace confirmed compressor/inverter.","Mitsubishi Electric Mr Slim outdoor-unit service manuals / self-diagnosis tables"),
                m("UP","Compressor overcurrent protection","Overcurrent trip","Compressor load, inverter, power or refrigerant circuit abnormality.","Check compressor current, inverter, supply and refrigerant pressures.","Correct root cause and retest.","Mitsubishi Electric Mr Slim outdoor-unit service manuals / self-diagnosis tables"),
                m("Fb","Indoor control fault","Indoor controller P.C. board abnormality","Indoor board memory/control circuit or connector abnormality.","Power reset; inspect indoor board and connectors; confirm recurrence.","Repair connection or replace confirmed indoor controller board.","Mitsubishi Electric Mr Slim P-Series service manuals / PAR self-diagnosis tables"),
                m("E1 / E2","Remote controller fault","Remote controller control-board abnormality","Remote controller electronics, cable or supply abnormality.","Check controller, cable and communication voltage.","Repair wiring or replace confirmed remote controller.","Mitsubishi Electric Mr Slim P-Series service manuals / PAR self-diagnosis tables"),
                m("E3 / E5","Remote communication fault","Remote controller transmission abnormality","Remote cable open/short, noise or indoor/remote board issue.","Inspect remote wiring and communication; isolate controller if required.","Repair cable or confirmed controller/indoor board.","Mitsubishi Electric Mr Slim P-Series service manuals / PAR self-diagnosis tables"),
                m("U9 / UH","Power-supply abnormality","Voltage / current / power input abnormality","Supply voltage, phase, wiring or power-detection circuit abnormality.","Measure supply under load and inspect terminals/power circuit.","Correct supply/wiring or repair detection circuit.","Mitsubishi Electric Mr Slim outdoor-unit service manuals / self-diagnosis tables"),
                m("UL","Pressure protection","Low-pressure abnormality","Refrigerant shortage/restriction, valve or pressure-sensing issue.","Check leakage, charge, valves, restriction and pressure circuit.","Repair refrigerant/valve/sensor cause.","Mitsubishi Electric Mr Slim outdoor-unit service manuals / self-diagnosis tables")

            )
        }

        // CITY MULTI: four-digit self-diagnosis groups, displayed with unit/address.
        if(type=="VRF / VRV" || key in listOf("PUMY","PUHY","PURY","PQHY","PQRY","PEFY","PMFY","PLFY","PCFY","PKFY","PFFY")){
            return listOf(
                m("0403","System stops","Serial communication / transmission abnormality","Transmission circuit, wiring/noise or control board fault.","Use self-check to identify error unit/address; inspect M-NET/transmission wiring and boards.","Repair transmission wiring or confirmed board.","Mitsubishi Electric CITY MULTI Service Handbook / Self Check code table"),
                m("0900","Test operation indication","Trial operation","System is in test-operation state rather than a component failure.","Confirm test-run mode and controller status.","End test operation normally after checks.","Mitsubishi Electric CITY MULTI Check Code List"),
                m("1111","Heat-source stops","Low-pressure saturation temperature sensor abnormality","TH2/saturation-temperature sensing abnormality.","Check TH2 resistance, connector and harness.","Repair wiring or replace TH2.","Mitsubishi Electric CITY MULTI Check Code List"),
                m("1112","Heat-source stops","Low-pressure saturation temperature abnormality","Liquid-level detecting temperature circuit indicates abnormal low-pressure saturation condition.","Check relevant temperature sensors, refrigerant circuit and connectors.","Repair sensor/circuit or refrigerant-side cause.","Mitsubishi Electric CITY MULTI Check Code List"),
                m("1113","Heat-source stops","Low-pressure saturation temperature abnormality","Liquid-level temperature detection abnormality.","Check sensor/harness and refrigerant operating condition.","Repair confirmed sensor/refrigerant fault.","Mitsubishi Electric CITY MULTI Check Code List"),

                m("1102","Compressor protection","Discharge temperature abnormality","Refrigerant shortage/restriction, compressor load or sensor issue.","Check refrigerant circuit, discharge temperature sensor and compressor operating condition.","Correct refrigerant/restriction/sensor cause.","Mitsubishi Electric CITY MULTI Service Handbook"),
                m("1301","Pressure protection","Low-pressure abnormality","Refrigerant shortage, restriction, LEV/valve or pressure-sensor issue.","Check refrigerant charge/leaks, pressure sensor, LEV and piping.","Repair leak/restriction/valve/sensor.","Mitsubishi Electric CITY MULTI Service Handbook"),
                m("1302","Pressure protection","High-pressure abnormality","Heat-exchanger airflow/waterflow, overcharge, fan/pump, valve or pressure-sensor issue.","Check airflow/waterflow, fans/pumps, charge, valves and pressure sensor.","Correct high-pressure cause.","Mitsubishi Electric CITY MULTI Service Handbook"),
                m("1500","Refrigerant circuit abnormal","Refrigerant overcharge / abnormal condition","Charge/circuit/valve abnormality.","Verify operating pressures/temperatures and refrigerant amount.","Correct refrigerant circuit/charge.","Mitsubishi Electric CITY MULTI Service Handbook"),
                m("1501","Refrigerant circuit abnormal","Insufficient refrigerant","Leak, undercharge or refrigerant-circuit restriction.","Leak-test, check charge, pressures, temperatures and piping.","Repair leak/restriction and recharge to specification.","Mitsubishi Electric CITY MULTI Check Code List"),
                m("1505","Refrigerant circuit abnormal","Suction-pressure abnormality","Refrigerant shortage/restriction, valve or pressure sensing abnormality.","Check suction pressure, refrigerant amount, valves and sensors.","Correct refrigerant/valve/sensor cause.","Mitsubishi Electric CITY MULTI Check Code List"),
                m("1607","System configuration fault","Configuration detection abnormality","Incorrect system configuration/address/connection detected.","Check system configuration, addresses and connected units.","Correct configuration/address/connection.","Mitsubishi Electric CITY MULTI Check Code List"),
                m("2000","System stops","Pump interlock abnormality","Pump/interlock contact or water circulation condition abnormal.","Check pump operation, interlock input, wiring and water circuit.","Restore pump/interlock operation.","Mitsubishi Electric CITY MULTI Check Code List"),
                m("2134","Water-side protection","Water temperature abnormality","Abnormal water temperature or circulation condition.","Check water temperature sensors, pump, flow and valves.","Correct water-flow/sensor condition.","Mitsubishi Electric CITY MULTI Check Code List"),
                m("2135","Water-side protection","Water heat exchanger freezing","Insufficient flow, low water temperature or control/sensor problem.","Check water flow, pump, strainer, antifreeze condition and sensors.","Restore flow and correct freezing cause.","Mitsubishi Electric CITY MULTI Check Code List"),
                m("2500","Indoor unit stops","Water leakage abnormality","Flooding/water leakage detected while drain pump is off.","Check drain pan, humidifier/water source and drain blockage.","Eliminate leakage/blockage and reset.","Mitsubishi Electric CITY MULTI Check Code List"),

                m("2502","Drain abnormality","Drain pump / water level abnormality","Blocked drain, pump, float/sensor or wiring issue.","Check drain pan, pipe, pump and sensor.","Clear drain or repair pump/sensor.","Mitsubishi Electric CITY MULTI Indoor Service Handbook"),
                m("2503","Drain sensor abnormality","Drain sensor circuit fault","Sensor open/short or connector/wiring fault.","Inspect and measure drain sensor circuit.","Repair wiring or replace sensor.","Mitsubishi Electric CITY MULTI Indoor Service Handbook"),
                m("4103","Phase / power abnormality","Reverse-phase abnormality","Incorrect phase sequence / supply wiring.","Measure phase sequence and supply.","Correct incoming phase wiring.","Mitsubishi Electric CITY MULTI Service Handbook"),
                m("4115","Power fault","Power-supply synchronous-signal abnormality","Supply synchronization/detection circuit abnormality.","Check supply waveform/voltage and detection circuit.","Correct supply or repair detection circuit.","Mitsubishi Electric CITY MULTI Check Code List"),
                m("4116","Fan fault","Fan-speed / motor abnormality","Fan motor, feedback, wiring or drive circuit abnormal.","Check fan rotation, connector, motor and drive output.","Repair/replace fan motor or drive circuit.","Mitsubishi Electric CITY MULTI Check Code List"),
                m("4200","Inverter fault","VDC/IDC detection circuit abnormality","DC voltage/current detection circuit malfunction.","Check converter/inverter sensing circuit and supply.","Repair inverter/converter detection circuit.","Mitsubishi Electric CITY MULTI Check Code List"),
                m("4210","Power protection","Overcurrent interruption","Inverter/compressor current exceeded protection threshold.","Check compressor, inverter, supply and load.","Repair confirmed compressor/inverter/power cause.","Mitsubishi Electric CITY MULTI Check Code List"),

                m("4108","Overcurrent protection","Current protection operated","Compressor/inverter/power or load abnormality.","Check current, compressor, inverter and supply.","Repair confirmed electrical/compressor cause.","Mitsubishi Electric CITY MULTI Service Handbook"),
                m("4220","Inverter voltage abnormality","DC bus voltage abnormality / low","Power supply, converter/inverter or capacitor circuit abnormality.","Check supply and inverter/converter DC circuit.","Repair power/inverter circuit.","Mitsubishi Electric CITY MULTI Service Handbook"),
                m("4230","Inverter protection","Radiator-panel overheat protection","Inverter heat sink overheated due to cooling/fan/temperature issue.","Check heat sink, cooling fan, airflow and temperature sensor.","Restore inverter cooling or repair failed component.","Mitsubishi Electric CITY MULTI Check Code List"),
                m("4240","Power protection","Overload protection","Compressor/inverter load exceeds allowable condition.","Check compressor load/current, inverter and refrigerant operating condition.","Correct overload cause.","Mitsubishi Electric CITY MULTI Check Code List"),

                m("4250","Inverter/compressor abnormality","IPM alarm / bus-voltage / overcurrent protection","Compressor or inverter power-module abnormality.","Check compressor winding/insulation, bus voltage and inverter module.","Repair/replace confirmed compressor or inverter.","Mitsubishi Electric CITY MULTI Service Handbook"),
                m("4260","Inverter cooling fault","Cooling-fan abnormality","Cooling fan, wiring or fan-drive circuit abnormal.","Check cooling fan operation, connector and drive output.","Repair/replace fan or drive circuit.","Mitsubishi Electric CITY MULTI Check Code List"),

                m("5101","Thermistor fault","Temperature sensor abnormality","Thermistor open/short or harness fault.","Use error unit/address; measure indicated thermistor and harness.","Repair connection or replace thermistor.","Mitsubishi Electric CITY MULTI Service Handbook"),
                m("5102","Thermistor fault","Temperature sensor abnormality","Thermistor open/short or harness fault.","Identify sensor from service handbook and measure resistance.","Repair wiring or replace thermistor.","Mitsubishi Electric CITY MULTI Service Handbook"),
                m("5103","Thermistor fault","Gas-pipe / liquid-surface temperature sensor abnormality","Thermistor open/short or harness fault.","Identify error unit/sensor and inspect connector/resistance.","Repair wiring or replace thermistor.","Mitsubishi Electric CITY MULTI Service Handbook"),
                m("5104","Thermistor fault","Liquid-surface detecting temperature sensor TH4 abnormality","TH4 open/short or harness fault.","Measure TH4 and inspect connector/harness.","Repair wiring or replace TH4.","Mitsubishi Electric CITY MULTI Check Code List"),
                m("5106","Thermistor fault","Water-temperature sensor TH6 abnormality","TH6 open/short or harness fault.","Measure TH6 and inspect wiring.","Repair wiring or replace TH6.","Mitsubishi Electric CITY MULTI Check Code List"),
                m("5107","Thermistor fault","Inverter-cooling heat-exchanger outlet sensor abnormality","Sensor/harness abnormality.","Check indicated sensor and connector.","Repair wiring or replace sensor.","Mitsubishi Electric CITY MULTI Check Code List"),
                m("5109","Sensor fault","Current-sensor circuit TH9 abnormality","Current-sensing circuit/sensor abnormality.","Check sensing circuit and associated wiring.","Repair sensing circuit.","Mitsubishi Electric CITY MULTI Check Code List"),
                m("5110","Thermistor fault","Inverter cooling-plate temperature sensor THHS abnormality","THHS or harness abnormality.","Measure THHS and inspect connector.","Repair wiring or replace THHS.","Mitsubishi Electric CITY MULTI Check Code List"),
                m("5112","Thermistor fault","Compressor-shell temperature sensor TH10 abnormality","TH10 or harness abnormality.","Measure TH10 and inspect connector.","Repair wiring or replace TH10.","Mitsubishi Electric CITY MULTI Check Code List"),
                m("5201","Pressure-sensor fault","High-pressure sensor abnormality","HPS/pressure sensor or wiring/detection circuit abnormal.","Check pressure sensor output, wiring and actual pressure.","Repair wiring or replace sensor.","Mitsubishi Electric CITY MULTI Check Code List"),
                m("5301","Current-sensor fault","IDC/IAC sensor circuit abnormality","Current detection sensor/circuit abnormality.","Check current-sensing circuit and inverter board.","Repair sensing/inverter circuit.","Mitsubishi Electric CITY MULTI Check Code List"),

                m("6600","M-NET address fault","Duplicate address","Two or more devices share an address.","Inspect M-NET addresses for duplicate settings.","Assign unique addresses and reset.","Mitsubishi Electric CITY MULTI Control System"),
                m("6601","M-NET communication fault","Polarity / transmission bus abnormality","Transmission wiring/power/noise issue.","Inspect M-NET transmission line and power supply.","Correct bus wiring/power.","Mitsubishi Electric CITY MULTI Control System"),
                m("6602","M-NET transmission fault","Transmission processor / line abnormality","Communication circuit or line problem.","Check error address, M-NET voltage/wiring and controller boards.","Repair transmission circuit.","Mitsubishi Electric CITY MULTI Control System"),
                m("6603","M-NET transmission fault","Transmission bus busy / communication abnormality","Bus noise, wiring or controller fault.","Check M-NET topology, wiring and connected controllers.","Correct bus/communication issue.","Mitsubishi Electric CITY MULTI Control System"),
                m("6606","M-NET communication fault","Communication with transmission processor abnormality","Transmission processor, wiring or control board abnormality.","Check M-NET line, voltage, connectors and processor/board.","Repair transmission circuit or board.","Mitsubishi Electric CITY MULTI Check Code List"),

                m("6607","M-NET no acknowledgement","Target unit does not respond","Unit power/address/wiring or control-board fault.","Check target address, unit power and M-NET line.","Restore power/address/communication or repair board.","Mitsubishi Electric CITY MULTI Control System"),
                m("6608","M-NET no response","No responsive frame","Transmission line or target controller/unit fault.","Check error address, line and target controller.","Repair communication path/controller.","Mitsubishi Electric CITY MULTI Control System"),
                m("7100","System configuration fault","Total connected capacity error","Connected-unit total capacity outside allowable combination.","Check connected indoor capacities against outdoor combination limits.","Correct connected capacity/configuration.","Mitsubishi Electric CITY MULTI Check Code List"),
                m("7101","System configuration fault","Capacity-code error","Incorrect capacity setting/code detected.","Check capacity setting/code of indicated unit.","Correct capacity setting or board configuration.","Mitsubishi Electric CITY MULTI Check Code List"),
                m("7102","System configuration fault","Connected-unit number error","Number of connected units outside allowable configuration.","Check actual connected units and addressing.","Correct connection/address configuration.","Mitsubishi Electric CITY MULTI Check Code List"),
                m("7105","Address-setting fault","Address set error","Invalid/incorrect unit address setting.","Check all unit/controller address switches/settings.","Correct addresses and reset.","Mitsubishi Electric CITY MULTI Check Code List"),
                m("7109","System configuration fault","Incorrect connection","Piping/wiring/system connection does not match configuration.","Check piping, transmission wiring and assigned addresses.","Correct connection/configuration.","Mitsubishi Electric CITY MULTI Check Code List"),
                m("7111","Remote sensor fault","Remote-controller sensor abnormality","Remote temperature sensor/controller or wiring abnormal.","Check controller sensor and remote wiring.","Repair wiring or replace controller/sensor.","Mitsubishi Electric CITY MULTI Check Code List"),
                m("7130","System configuration fault","Incorrect setup","Control/system setup inconsistent with connected equipment.","Check function settings and system configuration.","Correct setup and reset.","Mitsubishi Electric CITY MULTI Check Code List"),

                m("6831 / 6832 / 6833","Remote-controller communication fault","MA remote communication abnormality","Remote cable, noise, controller or indoor board issue.","Run remote-controller check; inspect transmission line and data errors.","Repair cable/communication or replace confirmed controller/board.","Mitsubishi Electric CITY MULTI Control System"),
                m("2600","CITY MULTI check code","Water leakage","Water leakage from connected water/humidifier piping.","Inspect water piping and leakage point.","Repair water leak.","Mitsubishi Electric CITY MULTI Service Handbook — Troubleshooting / Check Code List"),
                m("2601","CITY MULTI check code","Water supply cut","No water supply, solenoid valve or float-switch abnormality.","Check water supply, solenoid valve, connector and float switch.","Restore water supply or repair valve/switch.","Mitsubishi Electric CITY MULTI Service Handbook — Troubleshooting / Check Code List"),
                m("4220 / 4225","CITY MULTI check code","Bus voltage abnormality","DC bus voltage drop/rise or power/inverter/fan-board abnormality.","Check supply voltage, DC bus, inverter/fan board and power components.","Correct supply or repair confirmed inverter/fan/power board.","Mitsubishi Electric CITY MULTI Service Handbook — Troubleshooting / Check Code List"),
                m("4230 / 4235","CITY MULTI check code","Heat sink overheat protection","Blocked cooling air path, THHS, cooling fan, IPM or inverter-board abnormality.","Check heat-sink airflow, fan, THHS and inverter board.","Restore cooling or repair confirmed fan/sensor/inverter.","Mitsubishi Electric CITY MULTI Service Handbook — Troubleshooting / Check Code List"),
                m("4240 / 4245","CITY MULTI check code","Overload abnormality","Air short-cycle/blockage, supply, THHS, cooling fan, current sensor, inverter or compressor.","Check airflow, supply, fan, THHS, current sensor, inverter and compressor.","Correct airflow/power or repair confirmed inverter/compressor.","Mitsubishi Electric CITY MULTI Service Handbook — Troubleshooting / Check Code List"),
                m("4250 / 4255","CITY MULTI check code","IPM / overcurrent abnormality","IPM, current-sensor overcurrent, ground fault, compressor/fan or inverter output abnormality.","Check compressor/fan insulation, output wiring, IPM and inverter/fan board.","Repair confirmed load/inverter/fan-board fault.","Mitsubishi Electric CITY MULTI Service Handbook — Troubleshooting / Check Code List"),
                m("4260 / 4265","CITY MULTI check code","Cooling fan abnormality","Heat-sink cooling fan or associated circuit abnormality.","Check cooling fan operation, wiring, heat-sink temperature and drive circuit.","Repair fan/wiring/drive circuit.","Mitsubishi Electric CITY MULTI Service Handbook — Troubleshooting / Check Code List"),
                m("5105","CITY MULTI check code","Discharge thermistor abnormality","Discharge thermistor open/short, lead/connector or main-board input fault.","Check TH11/TH12 and wiring against manual.","Repair wiring or replace thermistor/confirmed board.","Mitsubishi Electric CITY MULTI Service Handbook — Troubleshooting / Check Code List"),
                m("5108","CITY MULTI check code","Liquid-temperature thermistor abnormality","TH7/related temperature sensor open/short or input circuit fault.","Check sensor resistance, lead and connector.","Repair wiring or replace sensor/board.","Mitsubishi Electric CITY MULTI Service Handbook — Troubleshooting / Check Code List"),
            )
        }

        // Ecodan: technician-visible controller/service fault groups.
        if(type=="Αντλία θερμότητας"){
            return listOf(
                m("L3","Heating stops","Circulation water temperature / flow protection","Insufficient water flow, air, blockage, pump or sensor issue.","Check system pressure, air, valves, strainer, pump and flow.","Restore design water flow and retest.","Mitsubishi Electric Ecodan Service / FTC Troubleshooting"),
                m("L4","Heating stops","Water temperature protection","Abnormal water temperature, flow or sensor condition.","Check water circuit, thermistors, pump and valves.","Correct water-flow/sensor cause.","Mitsubishi Electric Ecodan Service / FTC Troubleshooting"),
                m("L5","Heating stops","Indoor / water thermistor abnormality","Open/short water-side thermistor or wiring.","Measure relevant thermistor and inspect harness.","Repair wiring or replace thermistor.","Mitsubishi Electric Ecodan FTC Troubleshooting"),
                m("L6","Heating stops","Circulation / flow abnormality","Low flow, pump, airlock, blockage or flow sensor/switch issue.","Check pump, air purge, strainer, valves and flow sensor.","Restore flow or repair flow device.","Mitsubishi Electric Ecodan FTC Troubleshooting"),
                m("L8","System stops","Heating-water temperature abnormality","Water-side temperature or control abnormality.","Check flow, water thermistors and hydraulic circuit.","Correct hydraulic/sensor cause.","Mitsubishi Electric Ecodan FTC Troubleshooting"),
                m("L9","System stops","Flow sensor / flow rate abnormality","Insufficient circulation or flow-sensor fault.","Verify actual flow, pump speed, valves, strainer and sensor.","Restore flow or replace confirmed sensor.","Mitsubishi Electric Ecodan FTC Troubleshooting"),
                m("L1","Heating stops","Water temperature thermistor abnormality","Water-side thermistor open/short or harness abnormality.","Identify FTC thermistor from service data; measure resistance and inspect connector.","Repair wiring or replace thermistor.","Mitsubishi Electric Ecodan FTC Troubleshooting"),
                m("L2","Heating stops","Water temperature / hydraulic protection","Abnormal water temperature condition, poor circulation or sensing fault.","Check water temperatures, system pressure, pump, valves, air and thermistors.","Restore hydraulic operation or repair sensor fault.","Mitsubishi Electric Ecodan FTC Troubleshooting"),
                m("L7","Heating stops","Hydraulic / water-circuit abnormality","Flow, water temperature, pump/valve or sensor condition outside allowable range.","Check flow rate, pump, strainer, valves, air purge and water sensors.","Correct hydraulic/sensor cause.","Mitsubishi Electric Ecodan FTC Troubleshooting"),

                m("LA","System stops","Pressure sensor abnormality","Water/refrigerant pressure sensing circuit issue depending system configuration.","Check pressure/sensor wiring against model service manual.","Repair wiring or replace confirmed sensor.","Mitsubishi Electric Ecodan Service Manual"),
                m("LC","System stops","Hydraulic control abnormality","Water-circuit control/input abnormality.","Check FTC inputs, water circuit, sensors, pump and wiring according to unit service data.","Repair confirmed hydraulic/control fault.","Mitsubishi Electric Ecodan FTC Troubleshooting"),
                m("LE","System stops","Hydraulic / flow protection","Abnormal flow or water-side operating condition.","Check flow, pump, valves, strainer, air and relevant sensors.","Restore correct water circulation and repair sensor if required.","Mitsubishi Electric Ecodan FTC Troubleshooting"),

                m("P1","Sensor fault","Room / intake thermistor abnormality","Open/short thermistor or wiring.","Measure sensor and harness.","Repair wiring or replace thermistor.","Mitsubishi Electric Ecodan / connected unit service manual"),
                m("P6","Protection stop","Freeze / overheat protection","Insufficient flow/airflow or refrigerant-side abnormality.","Check hydraulic flow, heat exchangers and refrigerant-side operation.","Correct flow/refrigerant cause.","Mitsubishi Electric Ecodan Service Manual"),
                m("E6 / E7","Communication stop","Indoor/outdoor communication abnormality","Interconnect wiring, power, noise or control-board fault.","Check S1-S2-S3 / communication wiring and power.","Repair wiring/power or confirmed board.","Mitsubishi Electric Ecodan Service Manual"),
                m("U1","Outdoor stops","High-pressure protection","Water/airflow deficiency, overcharge, valve or pressure issue.","Check water flow/airflow, heat exchanger, charge and pressure circuit.","Correct high-pressure cause.","Mitsubishi Electric Ecodan Outdoor Service Manual"),
                m("U2","Outdoor stops","High discharge temperature","Refrigerant shortage/restriction, sensor or compressor load.","Check leakage/charge, discharge sensor and refrigerant circuit.","Repair leak/restriction/sensor.","Mitsubishi Electric Ecodan Outdoor Service Manual"),
                m("U3 / U4","Outdoor stops","Outdoor thermistor abnormality","Thermistor open/short or harness issue.","Measure indicated outdoor thermistor and wiring.","Repair connection or replace sensor.","Mitsubishi Electric Ecodan Outdoor Service Manual"),
                m("U6","Outdoor stops","Compressor overcurrent / inverter protection","Compressor, inverter, supply or excessive load abnormality.","Check compressor current/resistance, inverter and supply.","Repair inverter/power/compressor as confirmed.","Mitsubishi Electric Ecodan Outdoor Service Manual"),
                m("U8","Outdoor stops","Outdoor fan abnormality","Fan motor, connector or outdoor board fault.","Check fan rotation, motor and board output.","Repair/replace fan motor or board.","Mitsubishi Electric Ecodan Outdoor Service Manual")
,
                m("U9 / UH","Outdoor stops","Power-supply voltage/current abnormality","Supply voltage, wiring, converter/inverter or detection circuit abnormality.","Measure supply under load; inspect terminals and power circuit.","Correct supply/wiring or repair confirmed power circuit.","Mitsubishi Electric Ecodan Outdoor Service Manual"),
                m("UF","Outdoor stops","Compressor current interruption / lock protection","Compressor, inverter or wiring abnormality.","Check compressor resistance/insulation, current and inverter output.","Repair inverter/wiring or replace confirmed compressor.","Mitsubishi Electric Ecodan Outdoor Service Manual"),
                m("UP","Outdoor stops","Compressor overcurrent protection","High compressor current due to load, inverter, supply or refrigerant circuit.","Check current, pressures, inverter, supply and valves.","Correct electrical/refrigerant cause.","Mitsubishi Electric Ecodan Outdoor Service Manual"),
                m("UL","Outdoor stops","Low-pressure / refrigerant abnormality","Leak, undercharge, restriction, LEV or pressure detection problem.","Leak-test, check charge, piping restriction, LEV and pressure circuit.","Repair cause and recharge correctly.","Mitsubishi Electric Ecodan Outdoor Service Manual"),
                m("LEV","Capacity/pressure abnormal","Electronic expansion valve abnormality","LEV coil/valve, connector or drive circuit fault.","Check coil resistance, connector and temperature/pressure response.","Repair wiring/drive or replace LEV.","Mitsubishi Electric Ecodan Outdoor Service Manual"),
                m("Refrigerant shortage","Poor heating / high discharge","Insufficient refrigerant","Leak/undercharge or piping issue.","Leak-test and verify refrigerant charge/operating temperatures.","Repair leak and charge to specification.","Mitsubishi Electric Ecodan Service Manual"),
                m("Water flow low","Heating/DHW stops","Insufficient primary water flow","Airlock, dirty strainer, closed valve, weak pump or flow sensor problem.","Check pressure, purge air, strainer, valves, pump speed and flow rate.","Restore design flow and retest.","Mitsubishi Electric Ecodan Commissioning & Servicing Handbook"),
                m("Water pressure low","Hydraulic protection","System water pressure too low","Leak, insufficient fill pressure or expansion-vessel issue.","Check gauge, leaks, fill loop and expansion vessel.","Restore pressure and repair hydraulic cause.","Mitsubishi Electric Ecodan Commissioning & Servicing Handbook"),
                m("Pump abnormal","No/low circulation","Circulation pump abnormality","Pump blocked, no supply, airlock or control/output fault.","Check pump supply, rotation, air purge and command.","Restore/replace pump or repair control output.","Mitsubishi Electric Ecodan Commissioning & Servicing Handbook"),
                m("DHW sensor","DHW temperature abnormal","Cylinder/DHW thermistor abnormality","Sensor open/short, poor placement or wiring fault.","Measure DHW thermistor and inspect placement/harness.","Repair wiring/refit or replace sensor.","Mitsubishi Electric Ecodan FTC Service Data"),
                m("Zone sensor","Zone temperature abnormal","Zone flow/room sensor abnormality","Sensor or wiring fault in configured heating zone.","Identify zone input and measure sensor/harness.","Repair wiring or replace sensor.","Mitsubishi Electric Ecodan FTC Service Data"),
                m("3-way valve","Wrong DHW/heating routing","3-way valve / actuator abnormality","Valve stuck, actuator, wiring or control output fault.","Command DHW/heating and verify actuator movement/pipe temperatures.","Repair actuator/wiring or replace valve.","Mitsubishi Electric Ecodan Commissioning & Servicing Handbook"),
                m("Backup heater","Low output / heater unavailable","Electric backup heater abnormality","Breaker, contactor, thermal cutout, element or control fault.","Check breaker, cutout, contactor, element resistance and command.","Reset/repair circuit or replace failed element/contactor.","Mitsubishi Electric Ecodan Service Manual")
            )
        }

        val stored=faults.filter{
            brandMatches(it,"Mitsubishi Electric") &&
            inferredType(it)==type &&
            (it.series==model || it.series.isBlank())
        }.distinctBy{it.code}
        if(stored.isNotEmpty()) return stored

        // Safety net for Mitsubishi families that share the same indoor self-diagnosis architecture:
        // never leave a model page empty while still avoiding Daikin/other-brand codes.
        return when{
            type=="Split / Inverter" -> splitCore()
            type=="Multi-Split" -> splitCore()
            else -> emptyList()
        }
    }

    private fun mitsubishiRemotePhoto(type:String,model:String,height:Int):ImageView=ImageView(this).apply{
        scaleType=ImageView.ScaleType.CENTER_INSIDE
        adjustViewBounds=true
        setPadding(2,2,2,2)
        background=GradientDrawable().apply{
            setColor(Color.WHITE);cornerRadius=18f;setStroke(1,Color.rgb(232,236,241))
        }
        clipToOutline=true
        contentDescription="Φωτογραφία Mitsubishi Electric • $model"

        val target=this
        val key=mitsubishiModelKey(model)
        val cacheName="mitsubishi_"+(model.hashCode().toLong() and 0xffffffffL).toString(16)+".jpg"
        val cacheFile=File(cacheDir,cacheName)

        // ΠΡΩΤΟΣ ΚΑΝΟΝΑΣ: ό,τι έχει ήδη φορτώσει σωστά ΔΕΝ ξαναλλάζει.
        if(cacheFile.exists() && cacheFile.length()>1000){
            try{
                BitmapFactory.decodeFile(cacheFile.absolutePath)?.let{
                    setImageBitmap(normalizeProductPhotoSize(it))
                }
            }catch(_:Exception){}
            return@apply
        }

        val chosen=java.util.concurrent.atomic.AtomicBoolean(false)

        fun tryPhotoUrl(photoUrl:String):Boolean{
            if(chosen.get()) return true
            return try{
                val c=(URL(photoUrl).openConnection() as HttpURLConnection).apply{
                    connectTimeout=8000;readTimeout=15000;instanceFollowRedirects=true
                    setRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/140 Mobile Safari/537.36")
                    setRequestProperty("Accept","image/avif,image/webp,image/apng,image/*,*/*;q=0.8")
                    setRequestProperty("Referer","https://www.google.com/")
                }
                if(c.responseCode !in 200..299){c.disconnect();return false}
                val bytes=c.inputStream.use{it.readBytes()};c.disconnect()
                if(bytes.size<5000) return false
                val bmp=BitmapFactory.decodeByteArray(bytes,0,bytes.size) ?: return false
                if(bmp.width<220 || bmp.height<110) return false
                if(!chosen.compareAndSet(false,true)) return true
                try{cacheFile.writeBytes(bytes)}catch(_:Exception){}
                runOnUiThread{
                    target.setImageBitmap(normalizeProductPhotoSize(bmp))
                    target.contentDescription="Φωτογραφία Mitsubishi Electric • $model"
                }
                true
            }catch(_:Exception){false}
        }

        Thread{
            // 1. Ήδη επιλεγμένες ακριβείς φωτογραφίες + δεύτερα fallback.
            val direct=buildList{
                mitsubishiStaticPhotoUrl(model)?.let{add(it)}
                addAll(mitsubishiFallbackPhotoUrls(model))
            }.distinct()
            for(u in direct) if(tryPhotoUrl(u)) return@Thread

            // 2. Επίσημες σελίδες Mitsubishi.
            try{
                for(page in mitsubishiCataloguePages(model)){
                    if(chosen.get()) return@Thread
                    val conn=(URL(page).openConnection() as HttpURLConnection).apply{
                        connectTimeout=7000;readTimeout=10000;instanceFollowRedirects=true
                        setRequestProperty("User-Agent","Mozilla/5.0 (Android) Psyktikos/1.3")
                    }
                    if(conn.responseCode !in 200..299){conn.disconnect();continue}
                    val html=conn.inputStream.bufferedReader().use{it.readText()}
                        .replace("\\/","/").replace("&amp;","&")
                    conn.disconnect()

                    val variants=linkedSetOf(
                        key,key.replace("(","").replace(")",""),
                        key.substringBefore(" "),model.substringAfter("•",model).trim()
                    ).filter{it.length>=3}
                    val hit=variants.mapNotNull{v->html.indexOf(v,ignoreCase=true).takeIf{it>=0}}.minOrNull() ?: continue
                    val from=maxOf(0,hit-26000); val to=minOf(html.length,hit+30000)
                    val local=html.substring(from,to)
                    val images=linkedSetOf<String>()
                    Regex("""(?i)(?:src|data-src|data-original)=["']([^"']+\.(?:jpg|jpeg|png|webp)(?:\?[^"']*)?)["']""")
                        .findAll(local).forEach{
                            val u=it.groupValues[1]
                            images.add(
                                if(u.startsWith("http")) u
                                else if(u.startsWith("//")) "https:$u"
                                else "https://les.mitsubishielectric.gr"+(if(u.startsWith("/")) u else "/$u")
                            )
                        }
                    for(u in images) if(tryPhotoUrl(u)) return@Thread
                }
            }catch(_:Exception){}

            // 3. ΤΕΛΙΚΟ fallback ΜΟΝΟ για όσα παραμένουν κενά:
            // ακριβής αναζήτηση εικόνων "Mitsubishi Electric + μοντέλο".
            try{
                if(chosen.get()) return@Thread
                val q=java.net.URLEncoder.encode("Mitsubishi Electric $key $model","UTF-8")
                val searchUrl="https://www.bing.com/images/search?q=$q&form=HDRSC3&first=1"
                val sc=(URL(searchUrl).openConnection() as HttpURLConnection).apply{
                    connectTimeout=8000;readTimeout=12000;instanceFollowRedirects=true
                    setRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/140 Mobile Safari/537.36")
                }
                if(sc.responseCode in 200..299){
                    val h=sc.inputStream.bufferedReader().use{it.readText()}
                    sc.disconnect()
                    val urls=linkedSetOf<String>()
                    Regex("""(?i)[&"]murl(?:&quot;|")?\s*[:=]\s*(?:&quot;|")([^"&]+)""")
                        .findAll(h).forEach{
                            val u=it.groupValues[1]
                                .replace("&amp;","&")
                                .replace("\\/","/")
                            if(u.startsWith("http")) urls.add(u)
                        }
                    Regex("""(?i)murl&quot;:&quot;(https?://[^&]+?)&quot;""")
                        .findAll(h).forEach{
                            val u=it.groupValues[1].replace("&amp;","&").replace("\\/","/")
                            urls.add(u)
                        }

                    val preferred=urls.sortedByDescending{u->
                        val lu=u.lowercase()
                        var score=0
                        val cleanKey=key.lowercase().replace("-","").replace(" ","")
                        if(lu.replace("-","").replace("_","").contains(cleanKey)) score+=80
                        if(lu.contains("mitsubishi")) score+=40
                        if(lu.contains("product")||lu.contains("catalog")) score+=15
                        if(lu.contains("logo")||lu.contains("icon")||lu.contains("manual")) score-=100
                        score
                    }
                    for(u in preferred.take(20)) if(tryPhotoUrl(u)) return@Thread
                }else sc.disconnect()
            }catch(_:Exception){}
        }.start()
    }


    private fun inferredType(f:Fault):String = f.type

    private fun brandMatches(f:Fault,brand:String):Boolean =
        f.brand.equals(brand,true) || f.brand.startsWith("$brand •",true)

    private fun faultSeriesScreen(brand:String,type:String){
        val r=base()
        val series=if(brand.equals("Daikin",true)){
            daikinModels[type].orEmpty().distinct()
        }else if(brand.equals("Mitsubishi Electric",true)){
            mitsubishiModels[type].orEmpty().distinct()
        }else if(brand.equals("Midea",true)){
            mideaModels[type].orEmpty().distinct()
        }else if(brand.equals("Aermec",true)){
            aermecModels[type].orEmpty().distinct()
        }else if(brand.equals("Airwell",true)){
            airwellModels[type].orEmpty().distinct()
        }else if(brand.equals("AUX",true)){
            auxModels[type].orEmpty().distinct()
        }else if(brand.equals("Ariston",true)){
            aristonModels[type].orEmpty().distinct()
        }else if(brand.equals("Bosch",true)){
            boschModels[type].orEmpty().distinct()
        }else if(brand.equals("Carrier",true)){
            carrierModels[type].orEmpty().distinct()
        }else if(brand.equals("Climaveneta",true)){
            climavenetaModels[type].orEmpty().distinct()
        }else if(brand.equals("Cooper&Hunter",true)){
            cooperHunterModels[type].orEmpty().distinct()
        }else if(brand.equals("Fujitsu",true)){
            fujitsuModels[type].orEmpty().distinct()
        }else if(brand.equals("General",true)){
            generalModels[type].orEmpty().distinct()
        }else if(brand.equals("Gree",true)){
            greeModels[type].orEmpty().distinct()
        }else if(brand.equals("Haier",true)){
            haierModels[type].orEmpty().distinct()
        }else if(brand.equals("Hisense",true)){
            hisenseModels[type].orEmpty().distinct()
        }else if(brand.equals("Hitachi",true)){
            hitachiModels[type].orEmpty().distinct()
        }else if(brand.equals("Inventor",true)){
            inventorModels[type].orEmpty().distinct()
        }else if(brand.equals("Lennox",true)){
            lennoxModels[type].orEmpty().distinct()
        }else if(brand.equals("LG",true)){
            lgModels[type].orEmpty().distinct()
        }else if(brand.equals("Mitsubishi Heavy",true)){
            mitsubishiHeavyModels[type].orEmpty().distinct()
        }else if(brand.equals("Nordstar",true)){
            nordstarModels[type].orEmpty().distinct()
        }else if(brand.equals("Panasonic",true)){
            panasonicModels[type].orEmpty().distinct()
        }else if(brand.equals("Rhoss",true)){
            rhossModels[type].orEmpty().distinct()
        }else if(brand.equals("Rotenso",true)){
            rotensoModels[type].orEmpty().distinct()
        }else if(brand.equals("Samsung",true)){
            samsungModels[type].orEmpty().distinct()
        }else if(brand.equals("Sharp",true)){
            sharpModels[type].orEmpty().distinct()
        }else if(brand.equals("Sinclair",true)){
            sinclairModels[type].orEmpty().distinct()
        }else if(brand.equals("TCL",true)){
            tclModels[type].orEmpty().distinct()
        }else if(brand.equals("Tesla",true)){
            teslaModels[type].orEmpty().distinct()
        }else if(brand.equals("Toshiba",true)){
            toshibaModels[type].orEmpty().distinct()
        }else if(brand.equals("Toyotomi",true)){
            toyotomiModels[type].orEmpty().distinct()
        }else if(brand.equals("Trane",true)){
            traneModels[type].orEmpty().distinct()
        }else if(brand.equals("Vaillant",true)){ vaillantModels[type].orEmpty().distinct()
        }else if(brand.equals("Viessmann",true)){ viessmannModels[type].orEmpty().distinct()
        }else if(brand.equals("York",true)){ yorkModels[type].orEmpty().distinct()
        }else if(brand.equals("Pitsos",true)){ pitsosModels[type].orEmpty().distinct()
        }else if(brand.equals("Sendo",true)){ sendoModels[type].orEmpty().distinct()
        }else if(brand.equals("Morris",true)){ morrisModels[type].orEmpty().distinct()
        }else if(brand.equals("Juro-Pro",true)){ juroProModels[type].orEmpty().distinct()
        }else if(brand.equals("F&U",true)){ fuModels[type].orEmpty().distinct()
        }else if(brand.equals("United",true)){ unitedModels[type].orEmpty().distinct()
        }else if(brand.equals("Argo",true)){ argoModels[type].orEmpty().distinct()
        }else if(brand.equals("CIAT",true)){ ciatModels[type].orEmpty().distinct()
        }else{
            faults.filter{brandMatches(it,brand) && inferredType(it)==type}.map{it.series}.distinct().sorted()
        }

        r.addView(proSectionHeader(
            "$brand  •  $type",
            "${series.size} μοντέλα / σειρές • επίλεξε κάρτα για service data"
        ),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,8)})

        val chips=HorizontalScrollView(this).apply{
            isHorizontalScrollBarEnabled=false
            addView(LinearLayout(this@MainActivity).apply{
                orientation=LinearLayout.HORIZONTAL
                addView(hmtChip("Όλα (${series.size})"),LinearLayout.LayoutParams(-2,-2).apply{setMargins(0,0,6,0)})
                if(brand.equals("Daikin",true)){
                    addView(hmtChip("Daikin"),LinearLayout.LayoutParams(-2,-2).apply{setMargins(0,0,6,0)})
                    addView(hmtChip(type))
                }
            })
        }
        r.addView(chips,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,8)})

        val q=searchInput(if(brand.equals("Daikin",true) || brand.equals("Mitsubishi Electric",true) || brand.equals("Midea",true)) "🔎  Μοντέλο ή βλάβη..." else "🔎  Αναζήτηση μοντέλου...")
        q.background=GradientDrawable().apply{
            setColor(Color.WHITE);cornerRadius=24f;setStroke(2,Color.rgb(210,222,234))
        }
        if(brand.equals("Mitsubishi Electric",true)){
            q.setOnEditorActionListener{_,_,_->
                val term=q.text.toString().trim()
                if(term.isNotBlank()) mitsubishiGlobalFaultSearch(term)
                true
            }
        }

        val grid=GridLayout(this).apply{columnCount=2;alignmentMode=GridLayout.ALIGN_BOUNDS}

        fun render(){
            grid.removeAllViews()
            val term=q.text.toString().trim()
            val filtered=series.filter{model->
                if(term.isBlank() || model.contains(term,true)) true
                else if(brand.equals("Daikin",true)){
                    daikinGeneratedFaults(type,model).any{f->
                        val hay="${f.code} ${f.symptom} ${f.meaning} ${f.causes} ${f.checks}"
                        val compact=f.code.uppercase().replace(" ","")
                        val wanted=term.uppercase().replace(" ","")
                        hay.contains(term,true) || compact==wanted || compact.startsWith(wanted)
                    }
                }else if(brand.equals("Mitsubishi Electric",true)){
                    mitsubishiGeneratedFaults(type,model).any{f->
                        val hay="${f.code} ${f.symptom} ${f.meaning} ${f.causes} ${f.checks}"
                        val compact=f.code.uppercase().replace(" ","")
                        val wanted=term.uppercase().replace(" ","")
                        hay.contains(term,true) || compact==wanted || compact.startsWith(wanted)
                    }
                }else if(brand.equals("Midea",true)){
                    mideaGeneratedFaults(type,model).any{f->
                        val hay="${f.code} ${f.symptom} ${f.meaning} ${f.causes} ${f.checks}"
                        val compact=f.code.uppercase().replace(" ","")
                        val wanted=term.uppercase().replace(" ","")
                        hay.contains(term,true) || compact==wanted || compact.startsWith(wanted)
                    }
                }else{
                    faults.filter{faultMatchesModel(it,brand,type,model)}.any{f->
                        val hay="${f.code} ${f.symptom} ${f.meaning} ${f.causes} ${f.checks}"
                        val compact=f.code.uppercase().replace(" ","")
                        val wanted=term.uppercase().replace(" ","")
                        hay.contains(term,true) || compact==wanted || compact.startsWith(wanted)
                    }
                }
            }
            filtered.forEach{model->
                val count=if(brand.equals("Daikin",true)) daikinGeneratedFaults(type,model).size
                          else if(brand.equals("Mitsubishi Electric",true)) mitsubishiGeneratedFaults(type,model).size
                          else if(brand.equals("Midea",true)) mideaGeneratedFaults(type,model).size
                          else faults.count{faultMatchesModel(it,brand,type,model)}
                val card=LinearLayout(this).apply{
                    orientation=LinearLayout.VERTICAL
                    setPadding(9,9,9,10)
                    background=GradientDrawable().apply{
                        setColor(Color.WHITE);cornerRadius=22f;setStroke(2,Color.rgb(225,232,240))
                    }
                    elevation=4f
                    if(brand.equals("Daikin",true)){
                        addView(daikinRemotePhoto(type,model,220),LinearLayout.LayoutParams(-1,220))
                    }else if(brand.equals("Mitsubishi Electric",true)){
                        addView(mitsubishiRemotePhoto(type,model,220),LinearLayout.LayoutParams(-1,220))
                    }else if(brand.equals("Midea",true)){
                        addView(mideaRemotePhoto(type,model,220),LinearLayout.LayoutParams(-1,220))
                    }else if(brand.equals("Aermec",true)){
                        addView(aermecModelPhoto(type,model,220),LinearLayout.LayoutParams(-1,220))
                    }else{
                        addView(ImageView(this@MainActivity).apply{
                            val id=faultTypeIconRes(type)
                            if(id!=0) setImageResource(id)
                            scaleType=ImageView.ScaleType.CENTER_INSIDE
                            setPadding(18,18,18,18)
                            contentDescription="$brand $model"
                        },LinearLayout.LayoutParams(-1,110))
                    }
                    addView(TextView(this@MainActivity).apply{
                        text=model;textSize=13f;typeface=uiFont(true);setTextColor(Color.rgb(12,55,105))
                        maxLines=3;setPadding(2,6,2,2)
                    })
                    addView(TextView(this@MainActivity).apply{
                        text="$count κωδικοί βλαβών";textSize=10.5f;setTextColor(Color.rgb(0,112,190))
                    })
                    setOnClickListener{faultListScreen(brand,type,model)}
                }
                grid.addView(card,GridLayout.LayoutParams().apply{
                    width=0;height=GridLayout.LayoutParams.WRAP_CONTENT
                    columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f)
                    setMargins(5,5,5,5)
                })
            }
            if(filtered.isEmpty()) grid.addView(card("Δεν βρέθηκε μοντέλο ή βλάβη για «$term»."))
        }
        q.addTextChangedListener(object:android.text.TextWatcher{
            override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}
            override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){render()}
            override fun afterTextChanged(s:android.text.Editable?){}
        })
        if(brand.equals("Daikin",true)){
            q.imeOptions=android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
            q.setOnEditorActionListener{_,_,_->
                val term=q.text.toString().trim()
                if(term.isNotBlank()) daikinGlobalFaultSearch(term)
                true
            }
        }
        r.addView(q,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,5)})
        if(brand.equals("Daikin",true)){
            r.addView(TextView(this).apply{
                text="Αναζήτηση βλάβης / κωδικού  →"
                textSize=12f
                typeface=uiFont(true)
                setTextColor(Color.rgb(0,112,190))
                gravity=Gravity.END
                setPadding(8,2,8,7)
                setOnClickListener{
                    val term=q.text.toString().trim()
                    if(term.isBlank()) toast("Γράψε πρώτα κωδικό ή σύμπτωμα.")
                    else daikinGlobalFaultSearch(term)
                }
            })
        }
        r.addView(scroll(grid),LinearLayout.LayoutParams(-1,0,1f))
        setContentView(r);render()
    }


    private fun daikinModelImageRes(model:String):Int{
        val m=model.uppercase()
        return when{
            m.contains("EBLA") || m.contains("EDLA") -> resources.getIdentifier("daikin_ebla_edla","drawable",packageName)
            m.contains("FTXM") -> resources.getIdentifier("daikin_ftxm","drawable",packageName)
            else -> 0
        }
    }

    private fun modelImageView(resId:Int):ImageView = ImageView(this).apply{
        adjustViewBounds=true
        scaleType=ImageView.ScaleType.CENTER_INSIDE
        setPadding(10,10,10,10)
        background=GradientDrawable().apply{
            setColor(Color.WHITE)
            cornerRadius=22f
        }
        if(resId!=0) setImageResource(resId)
    }



    private fun verifiedDirectDaikinPdf(type:String,model:String):String?{
        val m=model.uppercase()
        return when{
            // Altherma 4 H — individually verified official direct PDFs
            (m.contains("EPSK-A") || m.contains("EPSK")) && (m.contains("EPVX") || m.contains("EPVZ")) ->
                "https://www.daikin.eu/content/dam/document-library/Installer-reference-guide/heat/air-to-water-heat-pump-high-temperature/epsk06-10av3/EPSK06-10AV3.EPSK08-10AW1.EPSK12-14AW1.EPSKS-AV3.EPVX07A.EPVX10A%284V.9W%29.EPVX14A%284V.9W%29_Installer%20reference%20guide_4PEN773391-1C_English.pdf"
            (m.contains("EPSK-A") || m.contains("EPSK")) && (m.contains("EPSX") || m.contains("EPSXB")) ->
                "https://www.daikin.eu/content/dam/document-library/Installer-reference-guide/heat/air-to-water-heat-pump-high-temperature/epsk06-10av3/EPSK06-10AV3.EPSK08-10AW1.EPSK12-14AW1.EPSKS-AV3.EPSX%28B%2907A.EPSX%28B%2910A.EPSX%28B%2914A_Installer%20reference%20guide_4PEN773394-1C_English.pdf"
            (m.contains("EPSK-A") || m.contains("EPSK")) && (m.contains("EPBX") || m.contains("EPBXU")) ->
                "https://www.daikin.eu/content/dam/document-library/Installer-reference-guide/heat/air-to-water-heat-pump-high-temperature/epbx10a4v/EPSK06-10AV3.EPSK08-10AW1.EPSK12-14AW1.EPSKS-AV3.EPBX%28U%2907A.EPBX%28U%2910A4V.EPBX10A9W.EPBX14A4V.EPBX%28U%2914A9W_Installer%20reference%20guide_4PEN773390-1C_English.pdf"
            m.contains("FTXJ-A") || m.contains("EMURA") ->
                "https://www.daikin.eu/content/dam/document-library/Installer-reference-guide/ac/split/ftxj-as_b_w/FTXJ-AW.FTXJ-AS.FTXJ-AB_Installer%20reference%20guide_4PEN518023-12Q_English.pdf"

            m.contains("FTXP-N9") || m.contains("ATXP-N9") || m.contains("COMFORA") ->
                "https://www.daikin.eu/content/dam/document-library/Installer-reference-guide/ac/split/atxp-n9/ATXP-N9.FTXP-N9_Installer%20reference%20guide_4PEN751614-1B_English.pdf"
            m.contains("FTXC-E") || m.contains("RXC-E") ->
                "https://www.daikin.eu/content/dam/document-library/installation-manuals/ac/split/RXC-E/FTXC-E.RXC-E_Installation%20manual_3PEN621327-4G_English.pdf"
            m.contains("FVXM-B") || m.contains("FVXTM-B") || m.contains("CVXM-B") ->
                "https://www.daikin.eu/content/dam/document-library/Installer-reference-guide/ac/split/cvxm-b/CVXM-B.FVXM-B.FVXTM-B_Installer%20reference%20guide_4PEN769827-3E_English.pdf"
            m.contains("FTXTJ-A") || m.contains("FTXTJ-AW") || m.contains("FTXTJ-AB") ->
                "https://www.daikin.eu/content/dam/document-library/Installer-reference-guide/ac/split/ftxtj-aw/FTXTJ-AB.FTXTJ-AW_Installer%20reference%20guide_4PEN728168-2A_English.pdf"
            m.contains("FTXA-D") || (m.contains("STYLISH") && m.contains("-D")) ->
                "https://www.daikin.eu/content/dam/document-library/Installer-reference-guide/ac/split/ctxa-dc/CTXA-D%28C.G.L.P.Y%29.FTXA-D%28C.G.L.P.Y%29_Installer%20reference%20guide_4PEN769827-20J_English.pdf"
            m.contains("FTXTM-A") ->
                "https://www.daikin.eu/content/dam/document-library/Installer-reference-guide/ac/split/atxtm-a/ATXTM-A.FTXTM-A_Installer%20reference%20guide_4PEN769827-1F_English.pdf"
            m.contains("FTXM-A") || m.contains("ATXM-A") || m.contains("CTXM-A") || (m.contains("PERFERA") && m.contains("FTXM")) ->
                "https://www.daikin.eu/content/dam/document-library/Installer-reference-guide/ac/split/CTXM-A.FTXM20-50A.ATXM-A_Installer%20reference%20guide_4PEN518023-17P_English.pdf"
            (m.contains("2MXM40A9") || m.contains("2MXM50A8")) ->
                "https://www.daikin.eu/content/dam/document-library/Installer-reference-guide/ac/split/2MXM40A9.2MXM50A8_Installer%20reference%20guide_4PEN766272-4C_English.pdf"
            (m.contains("A8") && (m.contains("2MXM68") || m.contains("3MXM") || m.contains("4MXM") || m.contains("5MXM"))) ->
                "https://www.daikin.eu/content/dam/document-library/Installer-reference-guide/ac/split/2MXM68A8.3MXM-A8.4MXM-A8.5MXM-A8_Installer%20reference%20guide_4PEN766272-5C_English.pdf"
            (m.contains("A9") && (m.contains("2MXM68") || m.contains("3MXM") || m.contains("4MXM") || m.contains("5MXM"))) ->
                "https://www.daikin.eu/content/dam/document-library/Installer-reference-guide/ac/split/2MXM68A9.3MXM-A9.4MXM-A9.5MXM-A9_Installer%20reference%20guide_4PEN600463-7J_English.pdf"
            m.contains("2MXM40-50A9") ->
                "https://www.daikin.eu/content/dam/document-library/Installer-reference-guide/ac/split/2MXM40-50A9_Installer%20reference%20guide_4PEN600463-6H_English.pdf"
            m.contains("2MXM68A") || m.contains("3MXM-A") || m.contains("4MXM-A") || m.contains("5MXM-A") ->
                "https://www.daikin.eu/content/dam/document-library/Installer-reference-guide/ac/split/2MXM68A_3MXM-A_4MXM-A_5MXM-A_Installer%20reference%20guide_4PEN600463-5F_English.pdf"
            m.contains("FXFA-A") ->
                "https://www.daikin.eu/content/dam/document-library/Installer-reference-guide/ac/vrv/fxfa-a/FXFA-A_Installer%20and%20user%20reference%20guide_4PEN599624-1D_English.pdf"
            m.contains("RZAG-B") ->
                "https://www.daikin.eu/content/dam/document-library/Installer-reference-guide/ac/split/arxf-a/ARXF50A6V1B.ARXF60-71A9.ARXM50A9.ARXM60-71A.RXF50D6V1B.RXF60-71D9.RXM-A.RXM50A9.RXP50-71N9.RZAG-B_Installer%20reference%20guide_4PEN766272-2F_English.pdf"
            m.contains("FXDA-A") ->
                "https://www.daikin.eu/content/dam/document-library/Installer-reference-guide/ac/vrv/fxda-a/FXDA-A_Installer%20and%20user%20reference%20guide_4PEN599621-1B_English.pdf"
            m.contains("FXZA-A") ->
                "https://www.daikin.eu/content/dam/document-library/Installer-reference-guide/ac/vrv/fxza-a/FXZA-A_Installer.User%20reference%20guide_4PEN599623-1D_English.pdf"
            m.contains("FBA-A") || m.contains("FBA-A(9)") || m.contains("ADEA-A") ->
                "https://www.daikin.eu/content/dam/document-library/Installer-reference-guide/ac/sky-air/adea-a/ADEA-A.FBA-A.FBA-A%289%29_Installer%20reference%20guide_4PEN550955-2D_English.pdf"
            m.contains("FXSA-A") ->
                "https://www.daikin.eu/content/dam/document-library/Installer-reference-guide/ac/vrv/fxsa-a/FXSA-A_Installer%20and%20user%20reference%20guide_4PEN599622-1B_English.pdf"
            m.contains("FXMA-A") ->
                "https://www.daikin.eu/content/dam/document-library/Installer-reference-guide/ac/vrv/fxma-a/FXMA200-250A_Installer.User%20reference%20guide_4PEN688305-1C_English.pdf"
            (m.contains("EBLA-D") || m.contains("EDLA-D")) && (m.contains("9-16") || m.contains("09-16") || m.contains("ALTHERMA 3 M")) ->
                "https://www.daikin.eu/content/dam/document-library/Installer-reference-guide/heat/air-to-water-heat-pump-low-temperature/EBLA09-163V33W1%2CV3%2CW1%2CEDLA09-16DV33W1%2CV3%2CW1_4PEN620241-1_Installer%20reference%20guide_English.pdf"
            else -> null
        }
    }

    private fun pdfLooksValid(url:String):Boolean{
        return try{
            val conn=(URL(url).openConnection() as HttpURLConnection).apply{
                connectTimeout=8000
                readTimeout=10000
                instanceFollowRedirects=true
                setRequestProperty("User-Agent","Mozilla/5.0 (Android) Psyktikos/1.3")
                setRequestProperty("Range","bytes=0-15")
            }
            val code=conn.responseCode
            val ct=(conn.contentType ?: "").lowercase()
            val bytes=if(code in 200..299) conn.inputStream.use{it.readBytes().take(8).toByteArray()} else byteArrayOf()
            conn.disconnect()
            code in 200..299 && (ct.contains("pdf") || String(bytes,Charsets.ISO_8859_1).startsWith("%PDF"))
        }catch(_:Exception){ false }
    }

    private fun normalizeDaikinPdfUrl(raw:String,page:String):String?{
        var u=raw.trim()
            .replace("\\/","/")
            .replace("&amp;","&")
            .replace("&#x2F;","/")
            .replace("&#47;","/")
        if(u.isBlank() || !u.contains(".pdf",true)) return null
        if(u.startsWith("//")) u="https:"+u
        if(u.startsWith("/")) u="https://www.daikin.eu"+u
        if(!u.startsWith("http",true)){
            try{ u=URL(URL(page),u).toString() }catch(_:Exception){ return null }
        }
        val host=try{URL(u).host.lowercase()}catch(_:Exception){return null}
        if(!(host=="daikin.eu" || host.endsWith(".daikin.eu"))) return null
        return u
    }

    private fun extractDaikinPdfCandidates(html:String,page:String):List<String>{
        val cleaned=html.replace("\\/","/").replace("&amp;","&")
        val scored=mutableListOf<Pair<Int,String>>()

        fun add(raw:String,context:String){
            val u=normalizeDaikinPdfUrl(raw,page) ?: return
            val c=context.lowercase()
            var score=0
            if(c.contains("installer reference guide")) score+=500
            if(c.contains("installation manual")) score+=420
            if(c.contains("installer")) score+=260
            if(c.contains("service manual")) score+=450
            if(c.contains("reference guide")) score+=220
            if(c.contains("operation manual")) score+=80
            if(c.contains("user reference")) score+=50
            if(c.contains("declaration")) score-=500
            if(c.contains("catalog")) score-=250
            if(c.contains("flyer")) score-=250
            if(u.contains("Installer-reference-guide",true)) score+=300
            if(u.contains("installation-manual",true) || u.contains("installation_manual",true)) score+=220
            scored.add(score to u)
        }

        Regex("""(?is)<a[^>]+href=["']([^"']+\.pdf(?:\?[^"']*)?)["'][^>]*>(.*?)</a>""")
            .findAll(cleaned).forEach{m-> add(m.groupValues[1], m.groupValues[2].replace(Regex("<[^>]+>")," ")) }

        Regex("""(?i)(https?://[^"'<>\\\s]+\.pdf(?:\?[^"'<>\\\s]*)?)""")
            .findAll(cleaned).forEach{m->
                val st=(m.range.first-180).coerceAtLeast(0)
                val en=(m.range.last+180).coerceAtMost(cleaned.length-1)
                add(m.groupValues[1],cleaned.substring(st,en+1))
            }

        Regex("""(?i)(/content/dam/[^"'<>\\\s]+\.pdf(?:\?[^"'<>\\\s]*)?)""")
            .findAll(cleaned).forEach{m->
                val st=(m.range.first-180).coerceAtLeast(0)
                val en=(m.range.last+180).coerceAtMost(cleaned.length-1)
                add(m.groupValues[1],cleaned.substring(st,en+1))
            }

        return scored
            .sortedByDescending{it.first}
            .map{it.second}
            .distinct()
    }

    private fun resolveDaikinPdf(type:String,model:String):String?{
        verifiedDirectDaikinPdf(type,model)?.let{ if(pdfLooksValid(it)) return it }

        val verification=daikinVerificationKeys(model)
        for(page in daikinOfficialPageCandidates(model)){
            try{
                val conn=(URL(page).openConnection() as HttpURLConnection).apply{
                    connectTimeout=8000
                    readTimeout=12000
                    instanceFollowRedirects=true
                    setRequestProperty("User-Agent","Mozilla/5.0 (Android) Psyktikos/1.3")
                    setRequestProperty("Accept-Language","en-US,en;q=0.9")
                }
                if(conn.responseCode !in 200..299){conn.disconnect();continue}
                val finalPage=conn.url.toString()
                val html=conn.inputStream.bufferedReader().use{it.readText()}
                conn.disconnect()

                if(verification.isNotEmpty() && verification.none{html.contains(it,true)}) continue

                for(pdf in extractDaikinPdfCandidates(html,finalPage)){
                    if(pdfLooksValid(pdf)) return pdf
                }
            }catch(_:Exception){}
        }
        return null
    }

    private fun daikinManualUrl(type:String,model:String):String? =
        verifiedDirectDaikinPdf(type,model)

    private fun openOfficialManual(type:String,model:String){
        toast("Αναζήτηση επίσημου Daikin PDF…")
        Thread{
            val pdf=resolveDaikinPdf(type,model)
            runOnUiThread{
                if(pdf==null){
                    AlertDialog.Builder(this)
                        .setTitle("Δεν βρέθηκε PDF")
                        .setMessage("Δεν βρέθηκε ενεργό επίσημο PDF της Daikin για τη συγκεκριμένη σειρά. Δεν θα ανοίξω λάθος manual.")
                        .setPositiveButton("OK",null)
                        .show()
                }else{
                    try{
                        startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(pdf)))
                    }catch(_:Exception){
                        toast("Δεν υπάρχει εφαρμογή για άνοιγμα PDF/συνδέσμου.")
                    }
                }
            }
        }.start()
    }


    private data class PipeSpec(
        val brand:String,
        val model:String,
        val liquid:String,
        val gas:String,
        val note:String="",
        val source:String=""
    )

    private val verifiedPipeSpecs=listOf(
        PipeSpec("Daikin","FTXZ25N / FTXZ35N / FTXZ50N","1/4\" (6.35 mm)","3/8\" (9.5 mm)",
            "Ururu Sarara FTXZ-N / RXZ-N","Daikin official product technical table"),
        PipeSpec("Daikin","FTXC20E / FTXC25E / FTXC35E","1/4\" (6.35 mm)","3/8\" (9.52 mm)",
            "Sensira FTXC-E","Daikin official product technical table"),
        PipeSpec("Daikin","FTXC50E / FTXC60E / FTXC71E","1/4\" (6.35 mm)","1/2\" (12.7 mm)",
            "Sensira FTXC-E","Daikin official product technical table"),
        PipeSpec("Daikin","FTXP20N / FTXP25N / FTXP35N","1/4\" (6.35 mm)","3/8\" (9.52 mm)",
            "Comfora FTXP-N/N9","Daikin official product technical table"),
        PipeSpec("Daikin","FTXP50N / FTXP60N / FTXP71N","1/4\" (6.35 mm)","1/2\" (12.7 mm)",
            "Comfora FTXP-N","Daikin official product technical table"),
        PipeSpec("Daikin","FTXF20F / FTXF25F / FTXF35F / FTXF42F","1/4\" (6.35 mm)","3/8\" (9.52 mm)",
            "Sensira FTXF-F","Daikin official product technical table"),
        PipeSpec("Daikin","FTXF50F / FTXF60F / FTXF71F","1/4\" (6.35 mm)","1/2\" (12.7 mm)",
            "Sensira FTXF-F","Daikin official product technical table"),
        PipeSpec("Daikin","FTXM20A / FTXM25A / FTXM35A / FTXM42A","1/4\" (6.35 mm)","3/8\" (9.52 mm)",
            "Perfera FTXM-A • R32 • επαληθευμένο από Daikin Installer Reference Guide",
            "Daikin 4P518023-17P"),
        PipeSpec("Daikin","FTXM50A","1/4\" (6.35 mm)","1/2\" (12.7 mm)",
            "Perfera FTXM-A • R32 • επαληθευμένο από Daikin Installer Reference Guide",
            "Daikin 4P518023-17P"),
        PipeSpec("Daikin","FTXM60A / FTXM71A","1/4\" (6.35 mm)","5/8\" (15.9 mm)",
            "Perfera FTXM-A • R32 • επαληθευμένο από Daikin Installer Reference Guide",
            "Daikin 4P518023-18V"),
        PipeSpec("Daikin","FTXTM-A / ATXTM-A","1/4\" (6.35 mm)","3/8\" (9.52 mm)",
            "Nepura / cold-climate split • έλεγξε ακριβές capacity πριν εγκατάσταση",
            "Daikin 4P769827-1F"),
        PipeSpec("Daikin","4MXM68A9","4 × 1/4\" (6.4 mm)","2 × 3/8\" (9.5 mm) + 2 × 1/2\" (12.7 mm)",
            "Multi A9 • διατομές ανά outdoor connection port",
            "Daikin 4P600463-7J"),
        PipeSpec("Daikin","4MXM80A9","4 × 1/4\" (6.4 mm)","1 × 3/8\" + 1 × 1/2\" + 2 × 5/8\"",
            "Multi A9 • διατομές ανά outdoor connection port",
            "Daikin 4P600463-7J"),
        PipeSpec("Daikin","5MXM90A9","5 × 1/4\" (6.4 mm)","2 × 3/8\" + 1 × 1/2\" + 2 × 5/8\"",
            "Multi A9 • διατομές ανά outdoor connection port",
            "Daikin 4P600463-7J"),
        PipeSpec("Daikin","ERGA04-08D / Altherma 3 R 4-8kW","1/4\" (6.4 mm)","5/8\" (15.9 mm)",
            "Altherma low-temperature split • ψυκτικές σωληνώσεις field piping",
            "Daikin 4P489913-1D"),
        PipeSpec("Daikin","Altherma 3 H • EPGA011-016D","ΥΔΡΑΥΛΙΚΗ ΣΥΝΔΕΣΗ","MONOBLOC / HYDRONIC",
            "Το ψυκτικό κύκλωμα βρίσκεται στην εξωτερική μονάδα. Προς την εσωτερική μονάδα γίνεται υδραυλική σύνδεση.",
            "Daikin Altherma 3 H installer reference guides"),
        PipeSpec("Daikin","Altherma 3 M • EBLA-D / EDLA-D","ΥΔΡΑΥΛΙΚΗ ΣΥΝΔΕΣΗ","MONOBLOC / HYDRONIC",
            "Monobloc: δεν υπάρχει ζεύγος field refrigerant liquid/gas προς εσωτερική μονάδα.",
            "Daikin Altherma 3 M installer reference guide"),
        PipeSpec("LG","THERMA V R32 Split 4 kW / 6 kW","1/4\" (6.35 mm)","1/2\" (12.7 mm)",
            "Οι παρεχόμενοι adapters δίνουν τελική σύνδεση 6.35 / 12.7 mm",
            "LG THERMA V Split manufacturer leaflet"),
        PipeSpec("Mitsubishi Electric","MSZ-AY25 / MSZ-AY35 / MSZ-AY42","1/4\" (6.35 mm)","3/8\" (9.52 mm)",
            "M-Series wall mounted • επαληθευμένη οικογένεια",
            "Mitsubishi Electric MSZ-AY installation documentation")
    )

    private fun normPipeSearch(s:String)=s.uppercase()
        .replace(" ","")
        .replace("-","")
        .replace("_","")
        .replace("/","")

    private fun pipeSearchScore(spec:PipeSpec,q:String):Int{
        val nq=normPipeSearch(q)
        if(nq.isBlank()) return 0
        val hay=normPipeSearch(spec.brand+" "+spec.model)
        var score=0
        if(hay.contains(nq)) score+=1000
        nq.chunked(3).filter{it.length>=2}.forEach{ if(hay.contains(it)) score+=8 }
        q.uppercase().split(Regex("[^A-Z0-9]+")).filter{it.length>=2}.forEach{
            if((spec.brand+" "+spec.model).uppercase().contains(it)) score+=20
        }
        return score
    }

    private data class PipeBrand(val name:String,val logo:Int,val enabled:Boolean=false)

    private val pipeBrands=listOf(
        PipeBrand("Daikin",R.drawable.logo_daikin,true),
        PipeBrand("Mitsubishi Electric",R.drawable.logo_mitsubishi_electric),
        PipeBrand("Mitsubishi Heavy",R.drawable.logo_mitsubishi_heavy),
        PipeBrand("Fujitsu / General",R.drawable.logo_fujitsu),
        PipeBrand("Toshiba",R.drawable.logo_toshiba),
        PipeBrand("Panasonic",R.drawable.logo_panasonic),
        PipeBrand("LG",R.drawable.logo_lg),
        PipeBrand("Samsung",R.drawable.logo_samsung),
        PipeBrand("Midea",R.drawable.logo_midea),
        PipeBrand("Gree",R.drawable.logo_gree),
        PipeBrand("Haier",R.drawable.logo_haier),
        PipeBrand("Hitachi",R.drawable.logo_hitachi),
        PipeBrand("Carrier",R.drawable.logo_carrier),
        PipeBrand("Toyotomi",R.drawable.logo_toyotomi),
        PipeBrand("Inventor",R.drawable.logo_inventor),
        PipeBrand("AUX",R.drawable.logo_aux),
        PipeBrand("Hisense",R.drawable.logo_hisense),
        PipeBrand("TCL",R.drawable.logo_tcl),
        PipeBrand("Bosch",R.drawable.logo_bosch),
        PipeBrand("Tesla",R.drawable.logo_tesla),
        PipeBrand("Airwell",R.drawable.logo_airwell),
        PipeBrand("York",R.drawable.logo_york),
        PipeBrand("Ariston",R.drawable.logo_ariston),
        PipeBrand("Vaillant",R.drawable.logo_vaillant),
        PipeBrand("Sharp",R.drawable.logo_sharp),
        PipeBrand("Lennox",R.drawable.logo_lennox),
        PipeBrand("Viessmann",R.drawable.logo_viessmann),
        PipeBrand("Sinclair",R.drawable.logo_sinclair)
    )

    private fun pipeBrandTile(b:PipeBrand)=LinearLayout(this).apply{
        orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(8,9,8,8)
        background=GradientDrawable().apply{setColor(Color.rgb(4,35,70));cornerRadius=18f;setStroke(2,Color.rgb(0,137,220))}
        elevation=3f
        addView(ImageView(this@MainActivity).apply{
            setImageResource(b.logo);scaleType=ImageView.ScaleType.CENTER_INSIDE
            setBackgroundColor(Color.WHITE);setPadding(10,8,10,8)
        },LinearLayout.LayoutParams(-1,76))
        addView(TextView(this@MainActivity).apply{
            text=b.name;textSize=15f;typeface=uiFont(true);gravity=Gravity.CENTER
            setTextColor(Color.WHITE);setPadding(4,8,4,6);maxLines=2
        },LinearLayout.LayoutParams(-1,52))
        if(!b.enabled) alpha=.82f
        setOnClickListener{
            if(b.enabled) daikinPipeCategories()
            else Toast.makeText(this@MainActivity,"${b.name}: τα μοντέλα θα προστεθούν μετά την επαλήθευση.",Toast.LENGTH_SHORT).show()
        }
    }

    private fun pipeSizeSearchScreen(){
        val r=base()
        r.background=GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,intArrayOf(Color.rgb(1,16,34),Color.rgb(2,32,61)))
        r.addView(proSectionHeader("🔧 ΔΙΑΤΟΜΕΣ ΣΩΛΗΝΩΣΕΩΝ","HVAC PIPE SIZES • Επίλεξε κατασκευαστή"),
            LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,10)})
        val search=searchInput("🔎 Αναζήτηση μάρκας...")
        search.setTextColor(Color.WHITE);search.setHintTextColor(Color.rgb(160,184,205))
        search.background=GradientDrawable().apply{setColor(Color.rgb(3,29,56));cornerRadius=22f;setStroke(1,Color.rgb(0,119,203))}
        r.addView(search,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,10)})
        val grid=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        r.addView(grid)
        fun render(term:String){
            grid.removeAllViews()
            val filtered=pipeBrands.filter{term.isBlank() || it.name.contains(term,true)}
            filtered.chunked(2).forEach{rowBrands->
                grid.addView(LinearLayout(this).apply{
                    orientation=LinearLayout.HORIZONTAL
                    rowBrands.forEachIndexed{i,b->
                        addView(pipeBrandTile(b),LinearLayout.LayoutParams(0,142,1f).apply{setMargins(if(i==0) 0 else 5,0,if(i==0) 5 else 0,8)})
                    }
                    if(rowBrands.size==1)addView(Space(this@MainActivity),LinearLayout.LayoutParams(0,1,1f).apply{setMargins(5,0,0,0)})
                })
            }
        }
        search.addTextChangedListener(object:TextWatcher{
            override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}
            override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){render(s?.toString()?:"")}
            override fun afterTextChanged(s:Editable?){}
        });render("")
        r.addView(button("← Υπολογιστές"){toolsScreen()})
        setContentView(r)
    }

    private fun daikinPipeCategories(){
        val r=base()
        r.background=GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.rgb(1,16,34),Color.rgb(2,32,61)))
        r.addView(LinearLayout(this).apply{
            gravity=Gravity.CENTER_VERTICAL;setPadding(14,12,14,12)
            addView(ImageView(this@MainActivity).apply{
                setImageResource(R.drawable.logo_daikin);scaleType=ImageView.ScaleType.CENTER_INSIDE
                setBackgroundColor(Color.WHITE);setPadding(7,7,7,7)
            },LinearLayout.LayoutParams(100,58).apply{setMargins(0,0,14,0)})
            addView(TextView(this@MainActivity).apply{
                text="DAIKIN\nΔΙΑΤΟΜΕΣ ΣΩΛΗΝΩΣΕΩΝ";textSize=18f;typeface=uiFont(true);setTextColor(Color.WHITE)
            })
        },LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,12)})
        r.addView(toolDashboardCard("❄️","SPLIT / INVERTER","Οικιακά split • ανά σειρά και capacity"){daikinPipeModels("Split / Inverter")},LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,9)})
        r.addView(toolDashboardCard("🔀","MULTI-SPLIT","2MXM • 3MXM • 4MXM • 5MXM"){daikinPipeModels("Multi-Split")},LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,9)})
        r.addView(toolDashboardCard("🏢","VRV / VRF","Εξωτερικές & εσωτερικές μονάδες VRV"){daikinPipeModels("VRV / VRF")},LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,9)})
        r.addView(toolDashboardCard("♨️","ΑΝΤΛΙΕΣ ΘΕΡΜΟΤΗΤΑΣ","Altherma • ψυκτικές ή υδραυλικές συνδέσεις ανά σύστημα"){daikinPipeModels("Αντλία θερμότητας")},LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,9)})
        r.addView(button("← Μάρκες"){pipeSizeSearchScreen()})
        r.addView(ImageView(this).apply{
            setImageResource(R.drawable.approved_manifold_art)
            scaleType=ImageView.ScaleType.FIT_CENTER
            adjustViewBounds=true
            background=GradientDrawable().apply{
                setColor(Color.rgb(2,25,49));cornerRadius=22f;setStroke(1,Color.rgb(0,119,203))
            }
            setPadding(4,4,4,4)
        },LinearLayout.LayoutParams(-1,920).apply{setMargins(0,14,0,8)})
        setContentView(r)
    }

    private fun daikinPipeModels(category:String){
        val r=base()
        r.background=GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.rgb(1,16,34),Color.rgb(2,32,61)))
        r.addView(proSectionHeader("DAIKIN • $category","Μοντέλα και επαληθευμένες διατομές"),
            LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,10)})
        val q=searchInput("🔎 Αναζήτηση μοντέλου...")
        q.setTextColor(Color.WHITE);q.setHintTextColor(Color.rgb(160,184,205))
        q.background=GradientDrawable().apply{setColor(Color.rgb(3,29,56));cornerRadius=22f;setStroke(1,Color.rgb(0,119,203))}
        r.addView(q,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,10)})
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        r.addView(box)
        val models=daikinModels[category].orEmpty()
        fun render(term:String){
            box.removeAllViews()
            val nq=normPipeSearch(term)
            models.filter{nq.isBlank() || normPipeSearch(it).contains(nq)}.forEach{model->
                val matches=verifiedPipeSpecs.filter{it.brand=="Daikin" && pipeModelMatches(it.model,model)}
                box.addView(daikinPipeModelCard(model,matches),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,8)})
            }
        }
        q.addTextChangedListener(object:TextWatcher{
            override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}
            override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){render(s?.toString()?:"")}
            override fun afterTextChanged(s:Editable?){}
        })
        render("")
        r.addView(button("← Κατηγορίες Daikin"){daikinPipeCategories()})
        setContentView(r)
    }

    private fun pipeModelMatches(specModel:String,displayModel:String):Boolean{
        val a=normPipeSearch(specModel); val b=normPipeSearch(displayModel)
        return specModel.uppercase().split(Regex("[^A-Z0-9]+"))
            .filter{it.length>=4}
            .any{b.contains(normPipeSearch(it))}
            || displayModel.uppercase().split(Regex("[^A-Z0-9]+"))
            .filter{it.length>=4}
            .any{a.contains(normPipeSearch(it))}
    }

    private fun daikinPipeModelCard(model:String,specs:List<PipeSpec>)=LinearLayout(this).apply{
        orientation=LinearLayout.VERTICAL;setPadding(15,13,15,13)
        background=GradientDrawable().apply{setColor(Color.rgb(4,35,70));cornerRadius=20f;setStroke(1,Color.rgb(0,126,205))}
        addView(TextView(this@MainActivity).apply{text=model;textSize=15.5f;typeface=uiFont(true);setTextColor(Color.WHITE)})
        if(specs.isEmpty()){
            addView(TextView(this@MainActivity).apply{
                text="⏳ Διατομή σε επαλήθευση — δεν δίνεται μη επιβεβαιωμένη τιμή"
                textSize=12.5f;setTextColor(Color.rgb(255,205,95));setPadding(0,6,0,0)
            })
        }else specs.forEach{spec->
            addView(TextView(this@MainActivity).apply{
                text="✓ ${spec.model}\nΥγρό: ${spec.liquid}   •   Αέριο: ${spec.gas}\n${spec.source}"
                textSize=13f;setTextColor(Color.rgb(112,224,255));setPadding(0,7,0,0)
            })
        }
    }

    private fun pipeSpecCard(spec:PipeSpec)=LinearLayout(this).apply{
        orientation=LinearLayout.VERTICAL
        setPadding(16,14,16,14)
        background=GradientDrawable().apply{
            setColor(Color.WHITE);cornerRadius=22f;setStroke(2,Color.rgb(220,230,238))
        }
        elevation=3f
        addView(TextView(this@MainActivity).apply{
            text="${spec.brand} • ${spec.model}"
            textSize=16f;typeface=uiFont(true);setTextColor(Color.rgb(0,73,145))
        })
        addView(TextView(this@MainActivity).apply{
            text="🔵 Υγρό: ${spec.liquid}\n🔴 Αέριο: ${spec.gas}"
            textSize=17f;typeface=uiFont(true);setTextColor(Color.rgb(35,35,35));setPadding(0,9,0,5)
        })
        if(spec.note.isNotBlank()) addView(TextView(this@MainActivity).apply{
            text="✓ ${spec.note}"
            textSize=12.5f;setTextColor(Color.rgb(45,110,65))
        })
        if(spec.source.isNotBlank()) addView(TextView(this@MainActivity).apply{
            text="Πηγή: ${spec.source}"
            textSize=11f;setTextColor(Color.rgb(105,110,118));setPadding(0,4,0,0)
        })
    }


    private fun faultListScreen(brand:String,type:String,series:String){
        val r=base()
        r.addView(hmtModelHero(brand,type,series),
            LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,8)})
        if(brand.equals("Daikin",true)){
            val manualUrl=daikinManualUrl(type,series)
            r.addView(LinearLayout(this).apply{
                orientation=LinearLayout.HORIZONTAL
                gravity=Gravity.CENTER_VERTICAL
                setPadding(12,10,12,10)
                background=GradientDrawable().apply{
                    setColor(Color.rgb(245,249,253));cornerRadius=20f
                    setStroke(1,Color.rgb(205,220,234))
                }
                addView(TextView(this@MainActivity).apply{
                    text="📖  Άνοιγμα επίσημου Daikin PDF"
                    textSize=13f;typeface=uiFont(true)
                    setTextColor(Color.rgb(0,82,155))
                },LinearLayout.LayoutParams(0,-2,1f))
                addView(TextView(this@MainActivity).apply{
                    text="ΑΝΟΙΓΜΑ  ›";textSize=11f;typeface=uiFont(true);setTextColor(Color.rgb(0,112,190))
                })
                setOnClickListener{openOfficialManual(type,series)}
            },LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,8)})
        }

        val q=searchInput("🔎  Αναζήτηση κωδικού ή συμπτώματος...")
        q.background=GradientDrawable().apply{
            setColor(Color.WHITE);cornerRadius=24f;setStroke(2,Color.rgb(210,222,234))
        }
        r.addView(q,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,7)})

        val stats=LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER
        }
        val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}

        fun allFaults():List<Fault>{
            val brandFaults=faults.filter{brandMatches(it,brand)}
            val base=brandFaults.filter{faultMatchesModel(it,brand,type,series)}
            return if(brand.equals("Daikin",true))
                (base+daikinGeneratedFaults(type,series)).distinctBy{it.code}
            else if(brand.equals("Mitsubishi Electric",true))
                (base+mitsubishiGeneratedFaults(type,series)).distinctBy{it.code}
            else if(brand.equals("Midea",true))
                (base+mideaGeneratedFaults(type,series)).distinctBy{it.code}
            else base
        }

        val total=allFaults().size
        listOf("Όλα $total","Κρίσιμες","Σημαντικές","Λοιπές").forEach{
            stats.addView(hmtChip(it),LinearLayout.LayoutParams(0,-2,1f).apply{setMargins(3,0,3,0)})
        }
        r.addView(stats,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,7)})

        fun render(){
            list.removeAllViews()
            val term=q.text.toString().trim()
            val results=allFaults().filter{f->
                term.isBlank() || "${f.code} ${f.symptom} ${f.meaning} ${f.causes} ${f.checks}".contains(term,true)
            }
            if(results.isEmpty()) list.addView(card("Δεν υπάρχουν επαληθευμένοι κωδικοί για αυτή την αναζήτηση."))
            else results.forEach{f->
                val symptom=faultGreek(f.symptom)
                val meaning=faultGreek(f.meaning)
                val desc=if(symptom.equals(meaning,true)) meaning else if(meaning.isNotBlank()) meaning else symptom
                list.addView(proFaultCard(f,desc){faultDetail(f,brand,type)},
                    LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,5,0,5)})
            }
        }
        q.addTextChangedListener(object:android.text.TextWatcher{
            override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}
            override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){render()}
            override fun afterTextChanged(s:android.text.Editable?){}
        })
        r.addView(scroll(list),LinearLayout.LayoutParams(-1,0,1f))
        setContentView(r);render()
    }


    private fun faultGreek(text:String):String{
        var s=text.trim()
        val phrases=listOf(
            "Capacity mismatch" to "Ασυμφωνία ισχύος",
            "Compressor sensor error" to "Βλάβη αισθητήρα συμπιεστή",
            "Pump error" to "Βλάβη αντλίας / κυκλοφορητή",
            "Refrigerant sensor error" to "Βλάβη αισθητήρα ψυκτικού",
            "Service valve error" to "Βλάβη βάνας σέρβις",
            "Pressure switch activated" to "Ενεργοποίηση πρεσοστάτη",
            "Poor compressor rotation" to "Ανωμαλία περιστροφής συμπιεστή",
            "Fan motor lock" to "Μπλοκάρισμα μοτέρ ανεμιστήρα",
            "Current protection" to "Προστασία από υπερένταση",
            "Compressor overload protection" to "Προστασία υπερφόρτωσης συμπιεστή",
            "Transistor module overload" to "Υπερφόρτωση μονάδας ισχύος",
            "DC peak" to "Αιχμή τάσης συνεχούς ρεύματος",
            "Serial transmission abnormality" to "Ανωμαλία σειριακής επικοινωνίας",
            "Discharge temperature abnormality" to "Ανωμαλία θερμοκρασίας κατάθλιψης",
            "Low pressure abnormality" to "Ανωμαλία χαμηλής πίεσης",
            "High pressure abnormality" to "Ανωμαλία υψηλής πίεσης",
            "Overcharged refrigerant abnormality" to "Ανωμαλία λόγω υπερπλήρωσης ψυκτικού",
            "Water leakage abnormality" to "Ανωμαλία διαρροής νερού",
            "Drain pump abnormality" to "Ανωμαλία αντλίας αποχέτευσης",
            "Drain sensor abnormality" to "Ανωμαλία αισθητήρα αποχέτευσης",
            "Reverse phase abnormality" to "Ανωμαλία αντίστροφης διαδοχής φάσεων",
            "Fan speed abnormality" to "Ανωμαλία ταχύτητας ανεμιστήρα",
            "Bus voltage abnormality" to "Ανωμαλία τάσης διαύλου συνεχούς ρεύματος",
            "Heat sink overheat protection" to "Προστασία υπερθέρμανσης ψύκτρας",
            "Overload protection" to "Προστασία υπερφόρτωσης",
            "IPM / over-current abnormality" to "Ανωμαλία μονάδας ισχύος / υπερέντασης",
            "Cooling fan abnormality" to "Ανωμαλία ανεμιστήρα ψύξης",
            "Thermal sensor abnormality" to "Ανωμαλία θερμικού αισθητήρα",
            "High pressure sensor abnormality" to "Ανωμαλία αισθητήρα υψηλής πίεσης",
            "Multiple address abnormality" to "Ανωμαλία διπλής διεύθυνσης",
            "Transmission processor hardware abnormality" to "Βλάβη υλικού επεξεργαστή επικοινωνίας",
            "Transmission bus-busy abnormality" to "Ανωμαλία απασχολημένου διαύλου επικοινωνίας",
            "Communication abnormality" to "Ανωμαλία επικοινωνίας",
            "Refrigerant shortage/circuit abnormality" to "Έλλειψη ψυκτικού / ανωμαλία ψυκτικού κυκλώματος",
            "Water temperature sensor problem" to "Βλάβη αισθητήρα θερμοκρασίας νερού",
            "Heat exchanger frozen" to "Πάγωμα εναλλάκτη",
            "Water circuit overheat" to "Υπερθέρμανση κυκλώματος νερού",
            "Mode conflict" to "Σύγκρουση τρόπου λειτουργίας",
            "Communication error indoor–outdoor" to "Σφάλμα επικοινωνίας εσωτερικής–εξωτερικής μονάδας",
            "Outlet air sensor TA error" to "Βλάβη αισθητήρα θερμοκρασίας αέρα εξόδου TA",
            "Room temperature sensor fault" to "Βλάβη αισθητήρα θερμοκρασίας χώρου",
            "Indoor heat exchanger sensor fault" to "Βλάβη αισθητήρα εναλλάκτη εσωτερικής μονάδας",
            "Fan motor/circuit fault" to "Βλάβη μοτέρ ανεμιστήρα / κυκλώματος",
            "EEPROM fault" to "Βλάβη μνήμης EEPROM",
            "Indoor coil sensor open/short" to "Ανοιχτό κύκλωμα ή βραχυκύκλωμα αισθητήρα εσωτερικού εναλλάκτη",
            "Outdoor coil sensor open/short" to "Ανοιχτό κύκλωμα ή βραχυκύκλωμα αισθητήρα εξωτερικού εναλλάκτη",
            "service manual" to "εγχειρίδιο σέρβις",
            "Service Manual" to "Εγχειρίδιο σέρβις",
            "fan motor" to "μοτέρ ανεμιστήρα",
            "Fan motor" to "Μοτέρ ανεμιστήρα",
            "sensor" to "αισθητήρας",
            "Sensor" to "Αισθητήρας",
            "wiring" to "καλωδίωση",
            "Wiring" to "Καλωδίωση",
            "pump" to "αντλία",
            "Pump" to "Αντλία",
            "valve" to "βαλβίδα",
            "Valve" to "Βαλβίδα",
            "overcurrent" to "υπερένταση",
            "Overcurrent" to "Υπερένταση",
            "overload" to "υπερφόρτωση",
            "Overload" to "Υπερφόρτωση",
            "pressure" to "πίεση",
            "Pressure" to "Πίεση",
            "temperature" to "θερμοκρασία",
            "Temperature" to "Θερμοκρασία",
            "communication" to "επικοινωνία",
            "Communication" to "Επικοινωνία",
            "refrigerant" to "ψυκτικό",
            "Refrigerant" to "Ψυκτικό",
            "open/short" to "ανοιχτό κύκλωμα / βραχυκύκλωμα",
            "outdoor" to "εξωτερικής μονάδας",
            "indoor" to "εσωτερικής μονάδας",
            "check" to "έλεγχο",
            "Check" to "Έλεγχο"
        )
        phrases.forEach{(a,b)->s=s.replace(a,b,ignoreCase=false)}
        return s.replace(Regex("\\s+")," ").trim()
    }


    private fun detailedFaultDescription(f:Fault):String{
        val code=f.code.uppercase()
        val text="${f.symptom} ${f.meaning} ${f.causes}".lowercase()
        return when{
            text.contains("επικοινων") || text.contains("communication") ->
                "Η μονάδα έχει χάσει ή δεν μπορεί να ολοκληρώσει σωστά την επικοινωνία μεταξύ πλακετών, εσωτερικής–εξωτερικής μονάδας ή περιφερειακού ελεγκτή. Η βλάβη μπορεί να είναι μόνιμη ή διακοπτόμενη και συχνά εμφανίζεται μετά από πτώση τάσης, κακή επαφή, λάθος συνδεσμολογία ή βλάβη πλακέτας."
            text.contains("αισθητήρ") || text.contains("sensor") ->
                "Η ηλεκτρονική πλακέτα λαμβάνει τιμή αισθητήρα εκτός επιτρεπτού εύρους ή δεν λαμβάνει καθόλου σήμα. Πιθανό αίτιο είναι ανοικτό κύκλωμα, βραχυκύκλωμα, αλλοιωμένη αντίσταση αισθητήρα, οξείδωση σε φίσα ή πρόβλημα στην είσοδο της πλακέτας."
            text.contains("ανεμισ") || text.contains("fan") ->
                "Η μονάδα δεν επιβεβαιώνει τη σωστή λειτουργία ή τις αναμενόμενες στροφές του ανεμιστήρα. Ελέγχεται τόσο το μηχανικό μέρος (φτερωτή, ρουλεμάν, εμπλοκή) όσο και το ηλεκτρικό μέρος (μοτέρ, Hall feedback, τάση οδήγησης και πλακέτα)."
            text.contains("πίεσ") || text.contains("pressure") || code in listOf("U0","F3") ->
                "Η προστασία σχετίζεται με μη φυσιολογικές πιέσεις ή θερμοκρασίες του ψυκτικού κυκλώματος. Δεν αρκεί μία μόνο ένδειξη μανόμετρου: απαιτείται συσχέτιση πιέσεων, θερμοκρασιών, ροής αέρα ή νερού, superheat/subcooling και κατάστασης εναλλακτών."
            text.contains("συμπιεστ") || text.contains("compressor") || text.contains("inverter") || text.contains("ipm") ->
                "Η προστασία αφορά το κύκλωμα ισχύος ή/και τον συμπιεστή. Μπορεί να οφείλεται σε τροφοδοσία εκτός ορίων, υπερένταση, μπλοκαρισμένο συμπιεστή, πρόβλημα IPM/inverter, κακή ψύξη της πλακέτας ή μη φυσιολογικό ψυκτικό φορτίο."
            text.contains("αποχ") || text.contains("νερ") || text.contains("drain") ->
                "Η μονάδα εντοπίζει πρόβλημα στην απομάκρυνση συμπυκνωμάτων ή στη στάθμη νερού. Πρέπει να ελεγχθούν λεκάνη, σωλήνωση αποχέτευσης, κλίσεις, σιφώνια, αντλία και αισθητήρας στάθμης, καθώς και πιθανό πάγωμα του στοιχείου."
            else ->
                "Ο κωδικός ${f.code} δηλώνει ότι το σύστημα εντόπισε συνθήκη εκτός φυσιολογικής λειτουργίας. Η τελική διάγνωση γίνεται στο συγκεκριμένο μοντέλο, με παρατήρηση του πότε εμφανίζεται ο κωδικός και με μετρήσεις στα αντίστοιχα κυκλώματα πριν αλλαχθεί οποιοδήποτε εξάρτημα."
        }
    }

    private fun detailedFaultChecks(f:Fault):String{
        val text="${f.symptom} ${f.meaning} ${f.causes}".lowercase()
        val steps=mutableListOf<String>()
        steps += "1. Κατέγραψε πλήρες model/serial, κωδικό βλάβης και αν εμφανίζεται άμεσα ή μετά από χρόνο λειτουργίας."
        steps += "2. Κάνε οπτικό έλεγχο για χαλαρές φίσες, καμένα σημεία, υγρασία, οξείδωση, κομμένα καλώδια και εμφανείς διαρροές."
        steps += "3. Μέτρησε τροφοδοσία υπό φορτίο και επιβεβαίωσε σωστή γείωση, ασφάλειες και συνδέσεις."
        when{
            text.contains("επικοινων") || text.contains("communication") -> {
                steps += "4. Έλεγξε τη γραμμή επικοινωνίας άκρο-άκρο, πολικότητα/τερματισμούς όπου απαιτούνται και συνέχεια αγωγών με απομονωμένη τροφοδοσία."
                steps += "5. Απομόνωσε προαιρετικά περιφερειακά ή επιμέρους μονάδες, όπου επιτρέπεται από το manual, ώστε να εντοπιστεί ποιο τμήμα ρίχνει το bus."
            }
            text.contains("αισθητήρ") || text.contains("sensor") -> {
                steps += "4. Αποσύνδεσε τον αισθητήρα με ασφαλή διαδικασία και μέτρησε αντίσταση/τάση σύμφωνα με τον πίνακα του κατασκευαστή στην πραγματική θερμοκρασία."
                steps += "5. Έλεγξε καλωδίωση από αισθητήρα έως PCB και σύγκρινε την ένδειξη service mode με πραγματική θερμοκρασία."
            }
            text.contains("ανεμισ") || text.contains("fan") -> {
                steps += "4. Με κλειστή τροφοδοσία επιβεβαίωσε ότι η φτερωτή περιστρέφεται ελεύθερα και δεν βρίσκει σε κάλυμμα ή καλώδια."
                steps += "5. Έλεγξε τροφοδοσία μοτέρ, feedback/σήμα στροφών και κατάσταση φίσας/καλωδίωσης σύμφωνα με το manual."
            }
            text.contains("πίεσ") || text.contains("pressure") || text.contains("ψυκτ") || text.contains("refrigerant") -> {
                steps += "4. Έλεγξε φίλτρα, εναλλάκτες και πραγματική ροή αέρα/νερού πριν αξιολογήσεις τις πιέσεις."
                steps += "5. Μέτρησε αναρρόφηση, κατάθλιψη, θερμοκρασίες σωληνώσεων, superheat και subcooling στις σωστές συνθήκες λειτουργίας."
                steps += "6. Κάνε έλεγχο διαρροών και έλεγξε για τσακισμένη σωλήνα, κλειστή βάνα ή περιορισμό πριν προστεθεί/αφαιρεθεί ψυκτικό."
            }
            text.contains("συμπιεστ") || text.contains("compressor") || text.contains("inverter") || text.contains("ipm") -> {
                steps += "4. Μέτρησε τάση τροφοδοσίας και ρεύμα λειτουργίας/εκκίνησης και έλεγξε αν η προστασία εμφανίζεται με συγκεκριμένο φορτίο."
                steps += "5. Με απομονωμένη τροφοδοσία έλεγξε τυλίγματα συμπιεστή, διαρροή προς γη και καλωδίωση U/V/W όπου εφαρμόζεται."
                steps += "6. Έλεγξε ψύκτρα/IPM, ανεμιστήρα εξωτερικής και καθαρότητα εναλλάκτη ώστε να αποκλειστεί θερμική υπερφόρτωση."
            }
        }
        steps += "Τελικός έλεγχος: σύγκρινε τις μετρήσεις με το επίσημο service manual της ακριβούς σειράς πριν καταλήξεις σε ανταλλακτικό."
        return steps.joinToString("\n")
    }

    private fun detailedFaultResolution(f:Fault):String{
        val text="${f.symptom} ${f.meaning} ${f.causes}".lowercase()
        return when{
            text.contains("επικοινων") || text.contains("communication") ->
                "• Σφίξε/καθάρισε ακροδέκτες και αποκατάστησε λάθος ή τραυματισμένη καλωδίωση.\n• Διόρθωσε τροφοδοσία ή γείωση αν είναι εκτός προδιαγραφών.\n• Αν το bus επανέλθει όταν απομονωθεί μία μονάδα/πλακέτα, επισκεύασε ή αντικατάστησε μόνο το επιβεβαιωμένα ελαττωματικό τμήμα.\n• Κάνε reset μόνο αφού διορθωθεί η αιτία και επιβεβαίωσε σταθερή επικοινωνία σε πλήρη λειτουργία."
            text.contains("αισθητήρ") || text.contains("sensor") ->
                "• Επισκεύασε φίσα ή καλωδίωση αν υπάρχει κακή επαφή.\n• Αν η αντίσταση/τάση του αισθητήρα είναι εκτός πίνακα, αντικατάστησέ τον με τον σωστό κωδικό ανταλλακτικού.\n• Αν ο αισθητήρας και η καλωδίωση είναι σωστά αλλά η PCB διαβάζει λάθος τιμή, έλεγξε/επισκεύασε την αντίστοιχη είσοδο πλακέτας.\n• Μετά την επισκευή έλεγξε στο service mode ότι η ένδειξη ακολουθεί τη πραγματική θερμοκρασία."
            text.contains("ανεμισ") || text.contains("fan") ->
                "• Καθάρισε ή ελευθέρωσε φτερωτή και αποκατάστησε μηχανική εμπλοκή.\n• Επισκεύασε καλωδίωση/φίσα ή αντικατάστησε μοτέρ όταν δεν υπάρχει σωστό feedback ή οι μετρήσεις είναι εκτός manual.\n• Αν το μοτέρ είναι σωστό αλλά δεν υπάρχει σωστή οδήγηση, προχώρησε σε έλεγχο πλακέτας.\n• Επιβεβαίωσε ομαλές στροφές σε όλες τις ταχύτητες χωρίς θόρυβο ή υπερθέρμανση."
            text.contains("πίεσ") || text.contains("pressure") || text.contains("ψυκτ") || text.contains("refrigerant") ->
                "• Αποκατάστησε πρώτα ροή αέρα/νερού και καθάρισε εναλλάκτες.\n• Επισκεύασε διαρροή, κάνε δοκιμή στεγανότητας και σωστό vacuum πριν από επαναφόρτιση με ζύγιση όπου απαιτείται.\n• Αν υπάρχει περιορισμός, έλεγξε φίλτρο, εκτονωτικό, βάνες και σωληνώσεις.\n• Μην αφαιρείς ή προσθέτεις ψυκτικό μόνο επειδή μία πίεση φαίνεται υψηλή ή χαμηλή· επιβεβαίωσε με SH/SC και θερμοκρασίες."
            text.contains("συμπιεστ") || text.contains("compressor") || text.contains("inverter") || text.contains("ipm") ->
                "• Διόρθωσε τροφοδοσία, χαλαρές συνδέσεις και αιτία υπερθέρμανσης πριν γίνει οποιαδήποτε αντικατάσταση.\n• Αν ο συμπιεστής αποτύχει σε ηλεκτρικές/μονωτικές μετρήσεις, αντικατάστησέ τον σύμφωνα με τη διαδικασία του κατασκευαστή.\n• Αν ο συμπιεστής είναι εντός προδιαγραφών αλλά η έξοδος inverter/IPM είναι ελαττωματική, έλεγξε και αντικατάστησε την αντίστοιχη πλακέτα ισχύος.\n• Μετά την επισκευή κάνε δοκιμή σε χαμηλό και υψηλό φορτίο και επανέλεγξε ρεύματα/θερμοκρασίες."
            else ->
                "• Διόρθωσε την αιτία που επιβεβαιώθηκε από τις μετρήσεις και όχι μόνο την ένδειξη του κωδικού.\n• Αντικατάστησε εξάρτημα μόνο όταν οι έλεγχοι του κατασκευαστή το καταδείξουν.\n• Μετά την επισκευή καθάρισε το ιστορικό βλάβης όπου προβλέπεται, κάνε πλήρη δοκιμή ψύξης/θέρμανσης και επανέλεγξε τις βασικές μετρήσεις."
        }
    }

    private fun faultDetail(f:Fault,brand:String=f.brand.substringBefore(" •"),type:String=inferredType(f)){
        val r=base()
        r.addView(topBar("⚠️ ${f.code}"){faultListScreen(brand,type,f.series)})
        r.addView(card("ΜΑΡΚΑ\n$brand\n\nΤΥΠΟΣ\n$type\n\nΜΟΝΤΕΛΟ / ΣΕΙΡΑ\n${f.series}\n\nΠΗΓΗ\n${f.source}"))

        val symptom=faultGreek(f.symptom)
        val meaning=faultGreek(f.meaning)
        if(symptom.equals(meaning,ignoreCase=true)){
            r.addView(card("ΒΛΑΒΗ / ΤΙ ΣΗΜΑΙΝΕΙ\n$meaning"))
        }else{
            r.addView(card("ΣΥΜΠΤΩΜΑ\n$symptom"))
            r.addView(card("ΤΙ ΣΗΜΑΙΝΕΙ\n$meaning"))
        }

        r.addView(card("ΑΝΑΛΥΤΙΚΗ ΠΕΡΙΓΡΑΦΗ ΒΛΑΒΗΣ\n${detailedFaultDescription(f)}"))
        r.addView(card("ΠΙΘΑΝΕΣ ΑΙΤΙΕΣ\n${faultGreek(f.causes)}"))
        r.addView(card("ΔΙΑΓΝΩΣΤΙΚΟΙ ΕΛΕΓΧΟΙ – ΒΗΜΑ ΒΗΜΑ\n${detailedFaultChecks(f)}"))
        r.addView(card("ΤΡΟΠΟΙ ΕΠΙΛΥΣΗΣ / ΕΠΙΣΚΕΥΗΣ\n${detailedFaultResolution(f)}"))
        r.addView(card("ΣΥΝΟΠΤΙΚΗ ΚΑΤΕΥΘΥΝΣΗ ΚΑΤΑΣΚΕΥΑΣΤΗ\n${faultGreek(f.action)}"))
        r.addView(button("📋 Νέα εργασία με κωδικό ${f.code}"){jobEditor(null,null,null)})
        setContentView(r)
    }

    private fun toolDashboardCard(icon:String,titleText:String,subtitle:String,action:()->Unit)=LinearLayout(this).apply{
        orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(14,14,14,14)
        background=GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,intArrayOf(Color.rgb(4,35,70),Color.rgb(5,57,103))).apply{cornerRadius=22f;setStroke(2,Color.rgb(0,137,220))}
        elevation=5f
        addView(TextView(this@MainActivity).apply{text=icon;textSize=30f;gravity=Gravity.CENTER;setTextColor(Color.WHITE)},LinearLayout.LayoutParams(58,64))
        addView(LinearLayout(this@MainActivity).apply{
            orientation=LinearLayout.VERTICAL
            addView(TextView(this@MainActivity).apply{text=titleText;textSize=16f;typeface=uiFont(true);setTextColor(Color.WHITE)})
            addView(TextView(this@MainActivity).apply{text=subtitle;textSize=12f;setTextColor(Color.rgb(103,210,255));setPadding(0,3,0,0)})
        },LinearLayout.LayoutParams(0,-2,1f))
        addView(TextView(this@MainActivity).apply{text="›";textSize=30f;setTextColor(Color.WHITE);gravity=Gravity.CENTER},LinearLayout.LayoutParams(36,58))
        setOnClickListener{action()}
    }
    private fun toolChip(textValue:String)=TextView(this).apply{
        text=textValue;textSize=11f;typeface=uiFont(true);gravity=Gravity.CENTER;setTextColor(Color.rgb(93,211,255));setPadding(13,7,13,7)
        background=GradientDrawable().apply{setColor(Color.rgb(3,30,59));cornerRadius=30f;setStroke(1,Color.rgb(0,120,205))}
    }


    private fun referenceToolsScreen(){
        val density=resources.displayMetrics.density
        fun dp(v:Int)=(v*density).toInt()
        val root=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(12),dp(12),dp(12),dp(28))
            background=GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.rgb(1,16,34),Color.rgb(2,32,61)))
        }
        root.addView(TextView(this).apply{
            text="🛠  ΕΡΓΑΛΕΙΑ"
            textSize=27f;gravity=Gravity.CENTER;typeface=uiFont(true)
            setTextColor(Color.rgb(25,151,255));setPadding(0,dp(4),0,dp(14))
        })
        fun tool(icon:String,name:String,desc:String,action:()->Unit)=LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
            setPadding(dp(14),dp(12),dp(12),dp(12))
            background=GradientDrawable().apply{
                setColor(Color.rgb(3,30,59));cornerRadius=dp(18).toFloat()
                setStroke(dp(1),Color.rgb(0,126,205))
            }
            addView(TextView(this@MainActivity).apply{
                text=icon;textSize=28f;gravity=Gravity.CENTER
                setTextColor(Color.rgb(26,162,255))
            },LinearLayout.LayoutParams(dp(52),dp(58)))
            addView(LinearLayout(this@MainActivity).apply{
                orientation=LinearLayout.VERTICAL
                addView(TextView(this@MainActivity).apply{
                    text=name;textSize=15f;typeface=uiFont(true);setTextColor(Color.WHITE)
                })
                addView(TextView(this@MainActivity).apply{
                    text=desc;textSize=11.5f;setTextColor(Color.rgb(170,204,227));setPadding(0,dp(3),0,0)
                })
            },LinearLayout.LayoutParams(0,-2,1f))
            addView(TextView(this@MainActivity).apply{
                text="›";textSize=28f;gravity=Gravity.CENTER;setTextColor(Color.rgb(38,165,255))
            },LinearLayout.LayoutParams(dp(32),dp(52)))
            setOnClickListener{action()}
        }
        val entries=listOf<Triple<Pair<String,String>,String,()->Unit>>(
            Triple("▦" to "PT CHART ΨΥΚΤΙΚΩΝ","R32 • R410A • R407C • R134a • R290"){techScreen()},
            Triple("⌁" to "ΠΙΝΑΚΑΣ ΧΑΛΚΟΣΩΛΗΝΩΝ","Διάμετροι και αντιστοιχίες mm ↔ ίντσες"){pipeReferenceScreen()},
            Triple("🔩" to "ΡΟΠΕΣ ΡΑΚΟΡ / ΕΚΧΕΙΛΩΣΗΣ","Γρήγορος πίνακας ενδεικτικών ροπών"){flareTorqueScreen()},
            Triple("▣" to "VACUUM & MICRON GUIDE","Τι σημαίνουν οι ενδείξεις κενού"){vacuumGuideScreen()},
            Triple("❄" to "SUPERHEAT / SUBCOOLING GUIDE","Γρήγορος οδηγός διάγνωσης"){shScGuideScreen()},
            Triple("🌍" to "F-GAS / GWP ΨΥΚΤΙΚΩΝ","Βασικός πίνακας ψυκτικών και GWP"){fgasGuideScreen()},
            Triple("✓" to "CHECKLISTS ΤΕΧΝΙΚΟΥ","Εγκατάσταση • συντήρηση • διάγνωση"){checklistScreen()},
            Triple("📚" to "ΤΕΧΝΙΚΗ ΒΙΒΛΙΟΘΗΚΗ","Οδηγοί και τεχνικές σημειώσεις"){techScreen()}
        )
        entries.forEach{it->
            root.addView(tool(it.first.first,it.first.second,it.second,it.third),
                LinearLayout.LayoutParams(-1,dp(88)).apply{setMargins(0,0,0,dp(9))})
        }
        root.addView(button("← Πίσω"){home()},
            LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(4),0,dp(20))})
        setContentView(ScrollView(this).apply{isFillViewport=true;addView(root)})
    }

    private fun pipeReferenceScreen(){
        val r=base();r.addView(title("⌁ Πίνακας χαλκοσωλήνων"))
        listOf(
            "1/4″ = 6,35 mm","3/8″ = 9,52 mm","1/2″ = 12,70 mm",
            "5/8″ = 15,88 mm","3/4″ = 19,05 mm","7/8″ = 22,23 mm","1 1/8″ = 28,58 mm"
        ).forEach{r.addView(card(it))}
        r.addView(card("Για επιλογή διατομής συγκεκριμένου μηχανήματος χρησιμοποίησε τον Υπολογιστή → Διατομές Σωληνώσεων."))
        r.addView(button("← Εργαλεία"){referenceToolsScreen()});setContentView(scroll(r))
    }

    private fun flareTorqueScreen(){
        val r=base();r.addView(title("🔩 Ροπές ρακόρ / εκχείλωσης"))
        listOf(
            "1/4″ (6,35 mm)  •  περίπου 14–18 N·m",
            "3/8″ (9,52 mm)  •  περίπου 33–42 N·m",
            "1/2″ (12,70 mm) •  περίπου 50–62 N·m",
            "5/8″ (15,88 mm) •  περίπου 63–77 N·m",
            "3/4″ (19,05 mm) •  περίπου 90–110 N·m"
        ).forEach{r.addView(card(it))}
        r.addView(card("⚠ Οι τιμές είναι γρήγορος οδηγός. Προτεραιότητα έχει πάντα η ροπή που δίνει το installation/service manual του συγκεκριμένου κατασκευαστή και μοντέλου."))
        r.addView(button("← Εργαλεία"){referenceToolsScreen()});setContentView(scroll(r))
    }

    private fun vacuumGuideScreen(){
        val r=base();r.addView(title("▣ Vacuum & micron guide"))
        listOf(
            "760.000 micron ≈ ατμοσφαιρική πίεση",
            "5.000 micron • ακόμη πολύ ψηλά για τελικό vacuum",
            "2.000 micron • χρειάζεται περαιτέρω εκκένωση / έλεγχο υγρασίας",
            "1.000 micron • πλησιάζει, αλλά δεν αποτελεί μόνο του τελικό κριτήριο",
            "500 micron • συνηθισμένος στόχος βαθιού κενού πριν από standing test",
            "Standing vacuum test • απομόνωσε την αντλία και έλεγξε την άνοδο της πίεσης"
        ).forEach{r.addView(card(it))}
        r.addView(card("Η συμπεριφορά στο standing test βοηθά να ξεχωρίσεις πιθανή υγρασία/απαέρωση από πραγματική διαρροή. Ακολούθησε πάντα τις οδηγίες του κατασκευαστή."))
        r.addView(button("← Εργαλεία"){referenceToolsScreen()});setContentView(scroll(r))
    }

    private fun shScGuideScreen(){
        val r=base();r.addView(title("❄ Superheat / Subcooling guide"))
        listOf(
            "Υψηλό superheat • πιθανή υποτροφοδότηση εξατμιστή, χαμηλή φόρτιση ή περιορισμός",
            "Χαμηλό superheat • πιθανή υπερτροφοδότηση / κίνδυνος επιστροφής υγρού",
            "Υψηλό subcooling • μπορεί να συνδέεται με αυξημένη ποσότητα υγρού στον συμπυκνωτή ή περιορισμό",
            "Χαμηλό subcooling • μπορεί να συνδέεται με ανεπαρκή στήλη υγρού / χαμηλή φόρτιση"
        ).forEach{r.addView(card(it))}
        r.addView(card("⚠ Δεν γίνεται διάγνωση μόνο από μία τιμή. Συνδύασε SH/SC με πιέσεις, θερμοκρασίες, airflow/waterflow και τις προδιαγραφές του συγκεκριμένου συστήματος."))
        r.addView(button("← Εργαλεία"){referenceToolsScreen()});setContentView(scroll(r))
    }

    private fun fgasGuideScreen(){
        val r=base();r.addView(title("🌍 F-Gas / GWP ψυκτικών"))
        listOf(
            "R32 • GWP100 ≈ 675 (παλαιό AR4 metric)",
            "R410A • GWP100 ≈ 2088 (παλαιό AR4 metric)",
            "R134a • GWP100 ≈ 1430 (παλαιό AR4 metric)",
            "R407C • GWP100 ≈ 1774 (παλαιό AR4 metric)",
            "R290 (προπάνιο) • πολύ χαμηλό GWP • A3 εύφλεκτο"
        ).forEach{r.addView(card(it))}
        r.addView(card("⚠ Οι κανονιστικές τιμές/μετρικές GWP αλλάζουν ανά νομοθετικό πλαίσιο. Για F-Gas συμμόρφωση χρησιμοποίησε την ισχύουσα νομοθεσία και τα στοιχεία του ψυκτικού."))
        r.addView(button("← Εργαλεία"){referenceToolsScreen()});setContentView(scroll(r))
    }

    private fun toolsScreen(){
        val density=resources.displayMetrics.density
        fun dp(v:Int)=(v*density).toInt()

        val root=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(10),dp(10),dp(10),dp(14))
            background=GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.rgb(1,16,34),Color.rgb(2,32,61)))
        }

        root.addView(TextView(this).apply{
            text="▣  ΥΠΟΛΟΓΙΣΤΕΣ"
            textSize=27f
            gravity=Gravity.CENTER
            typeface=uiFont(true)
            setTextColor(Color.rgb(25,151,255))
            setPadding(0,dp(4),0,dp(12))
        },LinearLayout.LayoutParams(-1,-2))

        fun card(icon:String,title:String,sub:String,action:()->Unit)=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            gravity=Gravity.CENTER
            setPadding(dp(7),dp(8),dp(7),dp(8))
            background=GradientDrawable().apply{
                setColor(Color.rgb(3,28,54))
                cornerRadius=dp(18).toFloat()
                setStroke(dp(1),Color.rgb(0,118,195))
            }
            elevation=dp(2).toFloat()

            addView(TextView(this@MainActivity).apply{
                text=icon
                textSize=34f
                gravity=Gravity.CENTER
                setTextColor(Color.rgb(20,158,255))
                typeface=uiFont(true)
                includeFontPadding=false
            },LinearLayout.LayoutParams(-1,dp(52)))

            addView(TextView(this@MainActivity).apply{
                text=title
                textSize=12.2f
                gravity=Gravity.CENTER
                typeface=uiFont(true)
                setTextColor(Color.WHITE)
                maxLines=3
                setLines(3)
                includeFontPadding=false
                setPadding(dp(2),dp(2),dp(2),0)
            },LinearLayout.LayoutParams(-1,dp(58)))

            addView(TextView(this@MainActivity).apply{
                text=sub
                textSize=10.2f
                gravity=Gravity.CENTER
                setTextColor(Color.rgb(190,207,222))
                maxLines=2
                setLines(2)
                includeFontPadding=false
                setPadding(dp(2),dp(2),dp(2),0)
            },LinearLayout.LayoutParams(-1,dp(38)))

            setOnClickListener{action()}
        }

        val items=listOf<Triple<Pair<String,String>,String,()->Unit>>(
            Triple("◉" to "ΥΠΟΛΟΓΙΣΜΟΣ\nSUPERHEAT","Υπολογισμός\nsuperheat"){
                calculator("Superheat = Θερμοκρασία αναρρόφησης − Θερμοκρασία κορεσμού\n\nΒάλε τις δύο θερμοκρασίες σε °C.","SH")
            },
            Triple("◉" to "ΥΠΟΛΟΓΙΣΜΟΣ\nSUBCOOLING","Υπολογισμός\nsubcooling"){
                calculator("Subcooling = Θερμοκρασία κορεσμού − Θερμοκρασία υγρής γραμμής\n\nΒάλε τις δύο θερμοκρασίες σε °C.","SC")
            },
            Triple("↔" to "ΜΕΤΑΤΡΟΠΗ\nΜΟΝΑΔΩΝ","Μετατροπές\nμονάδων"){pressureConverter()},

            Triple("▰" to "ΥΠΟΛΟΓΙΣΜΟΣ\nΚΕΝΟΥ","Χρόνος κενού\nμε αντλία"){vacuumCalculator()},
            Triple("⌁" to "ΔΙΑΤΟΜΕΣ\nΣΩΛΗΝΩΣΕΩΝ","Υγρό • αέριο\nανά μοντέλο"){pipeSizeSearchScreen()},
            Triple("❄" to "ΠΟΣΟΤΗΤΑ\nΨΥΚΤΙΚΟΥ","Υπολογισμός\nποσότητας"){refrigerantQuantityCalculator()},

            Triple("ϟ" to "ΗΛΕΚΤΡΙΚΟ\nΦΟΡΤΙΟ","Ρεύμα\n& καλώδια"){powerConverter()},
            Triple("♨" to "ΔΕΙΚΤΗΣ ΥΓΡΑΣΙΑΣ\n(ΣΗΜΕΙΟ ΔΡΟΣΟΥ)","Υπολογισμός\nσημείου δρόσου"){dewPointCalculator()},
            Triple("❄" to "ΥΠΟΛΟΓΙΣΜΟΣ\nBTU ΧΩΡΟΥ","Υπολογισμός BTU\nκλιματιστικού"){btuRoomCalculator()}        )

        val cardHeight=dp(166)
        items.chunked(3).forEach{rowItems->
            root.addView(LinearLayout(this).apply{
                orientation=LinearLayout.HORIZONTAL
                rowItems.forEachIndexed{i,it->
                    addView(card(it.first.first,it.first.second,it.second,it.third),
                        LinearLayout.LayoutParams(0,cardHeight,1f).apply{
                            setMargins(
                                if(i==0)0 else dp(4),
                                0,
                                if(i==rowItems.lastIndex)0 else dp(4),
                                dp(8)
                            )
                        })
                }
                if(rowItems.size<3){
                    repeat(3-rowItems.size){
                        addView(Space(this@MainActivity),
                            LinearLayout.LayoutParams(0,cardHeight,1f).apply{
                                setMargins(dp(4),0,0,dp(8))
                            })
                    }
                }
            })
        }

        root.addView(button("← Πίσω"){home()},
            LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(6),dp(4),dp(6),0)})

        setContentView(ScrollView(this).apply{
            isFillViewport=true
            addView(root)
        })
    }

    private fun vacuumCalculator(){
        val r=base()
        r.addView(proSectionHeader("▰ ΥΠΟΛΟΓΙΣΜΟΣ ΚΕΝΟΥ","Εκτίμηση χρόνου εκκένωσης συστήματος"))
        val volume=btuField("Εκτιμώμενος εσωτερικός όγκος συστήματος (L)","π.χ. 8")
        val pump=btuField("Παροχή αντλίας κενού (L/min)","π.χ. 85")
        val start=btuField("Αρχική πίεση (mbar)","π.χ. 1000","1000")
        val target=btuField("Στόχος κενού (mbar)","π.χ. 0.67","0.67")
        listOf(volume,pump,start,target).forEach{r.addView(it)}
        val out=resultText()
        r.addView(button("ΥΠΟΛΟΓΙΣΜΟΣ"){
            fun v(w:LinearLayout)=((w.getChildAt(1) as EditText).text.toString().replace(",",".").toDoubleOrNull())
            val V=v(volume); val Q=v(pump); val P1=v(start); val P2=v(target)
            out.text=if(V!=null&&Q!=null&&P1!=null&&P2!=null&&V>0&&Q>0&&P1>P2&&P2>0){
                val ideal=(V/Q)*kotlin.math.ln(P1/P2)
                String.format(java.util.Locale.US,"Θεωρητικός ελάχιστος χρόνος: %.1f min\nΠρακτικά απαιτείται περισσότερος χρόνος λόγω υγρασίας, σωληνώσεων, διαρροών και conductance.\n\nΕπιβεβαίωσε πάντα με micron gauge και standing vacuum test.",ideal)
            }else "Έλεγξε τις τιμές."
        }); r.addView(out); r.addView(button("← Υπολογιστές"){toolsScreen()}); setContentView(scroll(r))
    }

    private fun refrigerantQuantityCalculator(){
        val r=base()
        r.addView(proSectionHeader("❄ ΠΟΣΟΤΗΤΑ ΨΥΚΤΙΚΟΥ","Πρόσθετη φόρτιση βάσει μήκους σωλήνωσης"))
        val extra=btuField("Επιπλέον μήκος πάνω από το εργοστασιακό (m)","π.χ. 8")
        val grams=btuField("Πρόσθετη φόρτιση κατασκευαστή (g/m)","π.χ. 20")
        r.addView(extra);r.addView(grams);val out=resultText()
        r.addView(button("ΥΠΟΛΟΓΙΣΜΟΣ"){
            val a=((extra.getChildAt(1) as EditText).text.toString().replace(",",".").toDoubleOrNull())
            val b=((grams.getChildAt(1) as EditText).text.toString().replace(",",".").toDoubleOrNull())
            out.text=if(a!=null&&b!=null&&a>=0&&b>=0) String.format(java.util.Locale.US,"Πρόσθετη ποσότητα: %.0f g  (%.3f kg)",a*b,a*b/1000.0) else "Έλεγξε τις τιμές."
        });r.addView(out)
        r.addView(TextView(this).apply{text="Χρησιμοποίησε αποκλειστικά το g/m και το δωρεάν μήκος που ορίζει το επίσημο manual του συγκεκριμένου μοντέλου.";setTextColor(Color.LTGRAY);textSize=12f;setPadding(6,8,6,8)})
        r.addView(button("← Υπολογιστές"){toolsScreen()});setContentView(scroll(r))
    }

    private fun dewPointCalculator(){
        val r=base()
        r.addView(proSectionHeader("♨ ΔΕΙΚΤΗΣ ΥΓΡΑΣΙΑΣ","Υπολογισμός σημείου δρόσου"))
        val temp=btuField("Θερμοκρασία αέρα (°C)","π.χ. 26")
        val rh=btuField("Σχετική υγρασία (%)","π.χ. 60")
        r.addView(temp);r.addView(rh);val out=resultText()
        r.addView(button("ΥΠΟΛΟΓΙΣΜΟΣ"){
            val t=((temp.getChildAt(1) as EditText).text.toString().replace(",",".").toDoubleOrNull())
            val h=((rh.getChildAt(1) as EditText).text.toString().replace(",",".").toDoubleOrNull())
            out.text=if(t!=null&&h!=null&&h>0&&h<=100){
                val a=17.62;val b=243.12
                val g=kotlin.math.ln(h/100.0)+(a*t)/(b+t)
                val dp=(b*g)/(a-g)
                String.format(java.util.Locale.US,"Σημείο δρόσου: %.1f °C",dp)
            }else "Έλεγξε θερμοκρασία και υγρασία."
        });r.addView(out);r.addView(button("← Υπολογιστές"){toolsScreen()});setContentView(scroll(r))
    }

    private fun btuField(label:String,hintText:String,defaultValue:String="")=LinearLayout(this).apply{
        orientation=LinearLayout.VERTICAL
        addView(TextView(this@MainActivity).apply{
            text=label;textSize=13f;typeface=uiFont(true);setTextColor(Color.rgb(142,205,238));setPadding(4,0,4,5)
        })
        addView(EditText(this@MainActivity).apply{
            hint=hintText
            if(defaultValue.isNotBlank()) setText(defaultValue)
            inputType=android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            textSize=17f;setTextColor(Color.WHITE);setHintTextColor(Color.rgb(140,160,178));setSingleLine(true);setPadding(14,12,14,12)
            background=GradientDrawable().apply{setColor(Color.rgb(4,31,59));cornerRadius=18f;setStroke(1,Color.rgb(0,129,212))}
            tag="btu_input"
        },LinearLayout.LayoutParams(-1,-2))
    }

    private fun btuSpinner(label:String,items:List<String>,defaultIndex:Int=0)=LinearLayout(this).apply{
        orientation=LinearLayout.VERTICAL
        addView(TextView(this@MainActivity).apply{
            text=label;textSize=13f;typeface=uiFont(true);setTextColor(Color.rgb(142,205,238));setPadding(4,0,4,5)
        })
        addView(Spinner(this@MainActivity).apply{
            adapter=object:ArrayAdapter<String>(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,items){
                override fun getView(position:Int,convertView:View?,parent:android.view.ViewGroup):View{
                    return (super.getView(position,convertView,parent) as TextView).apply{
                        setTextColor(Color.rgb(10,35,55));textSize=17f;typeface=uiFont(true);setPadding(16,0,12,0)
                    }
                }
                override fun getDropDownView(position:Int,convertView:View?,parent:android.view.ViewGroup):View{
                    return (super.getDropDownView(position,convertView,parent) as TextView).apply{
                        setTextColor(Color.rgb(10,35,55));textSize=17f;typeface=uiFont(true);setPadding(16,14,16,14)
                    }
                }
            }
            setSelection(defaultIndex.coerceIn(0,items.lastIndex))
            background=GradientDrawable().apply{setColor(Color.WHITE);cornerRadius=18f;setStroke(2,Color.rgb(0,129,212))}
            tag="btu_spinner"
        },LinearLayout.LayoutParams(-1,54))
    }

    private fun recommendedBtuClass(value:Double):Int{
        val classes=intArrayOf(7000,9000,12000,14000,18000,21000,24000,28000,30000,36000,42000,48000,60000)
        return classes.firstOrNull{it>=value} ?: kotlin.math.ceil(value/6000.0).toInt()*6000
    }

    private fun btuRoomCalculator(){
        val r=base()
        r.background=GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.rgb(1,16,34),Color.rgb(2,32,61)))

        r.addView(proSectionHeader("❄️ ΥΠΟΛΟΓΙΣΜΟΣ BTU ΧΩΡΟΥ",
            "Αρκούν m² + ύψος • τα υπόλοιπα έχουν ασφαλείς μέσες προεπιλογές"),
            LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,12)})

        val areaWrap=btuField("Εμβαδόν χώρου (m²)","π.χ. 35")
        val heightWrap=btuField("Ύψος χώρου (m)","π.χ. 2.80","2.80")
        val windowsWrap=btuField("Συνολική επιφάνεια παραθύρων (m²) — προαιρετικό","αν μείνει κενό: μέση παραδοχή")
        val peopleWrap=btuField("Άτομα στον χώρο — προαιρετικό","αν μείνει κενό: 2 άτομα")

        val insulationWrap=btuSpinner("Μόνωση",listOf("Καλή / σύγχρονη","Μέτρια","Κακή / παλιό κτίριο"),1)
        val sunWrap=btuSpinner("Ηλιακή επιβάρυνση",listOf("Σκιασμένος / βόρειος","Κανονική","Έντονος ήλιος / δυτικός-νότιος"),1)
        val floorWrap=btuSpinner("Θέση χώρου",listOf("Ενδιάμεσος όροφος","Τελευταίος όροφος / ταράτσα","Ισόγειο πάνω από μη θερμαινόμενο χώρο"),0)
        val useWrap=btuSpinner("Χρήση χώρου",listOf("Υπνοδωμάτιο","Σαλόνι / καθιστικό","Γραφείο","Κουζίνα / έντονα θερμικά φορτία"),1)

        listOf(areaWrap,heightWrap,windowsWrap,peopleWrap,insulationWrap,sunWrap,floorWrap,useWrap).forEach{
            r.addView(it,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,10)})
        }

        val result=TextView(this).apply{
            text="ΥΠΟΛΟΓΙΣΜΟΣ"
            textSize=15f;setTextColor(Color.WHITE);setPadding(16,16,16,16)
            background=GradientDrawable().apply{setColor(Color.rgb(4,35,70));cornerRadius=20f;setStroke(2,Color.rgb(0,137,220))}
        }

        fun fieldValue(wrap:LinearLayout):Double? =
            ((wrap.getChildAt(1) as? EditText)?.text?.toString()?.replace(",",".")?.toDoubleOrNull())

        fun spinnerPos(wrap:LinearLayout):Int = (wrap.getChildAt(1) as Spinner).selectedItemPosition

        r.addView(Button(this).apply{
            text="ΥΠΟΛΟΓΙΣΜΟΣ";isAllCaps=false;textSize=17f;typeface=uiFont(true)
            setTextColor(Color.WHITE)
            background=GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.rgb(0,102,180),Color.rgb(0,150,220))).apply{cornerRadius=20f}
            setOnClickListener{
                val area=fieldValue(areaWrap)
                val height=fieldValue(heightWrap)
                val windowsEntered=fieldValue(windowsWrap)
                val peopleEntered=fieldValue(peopleWrap)
                if(area==null || height==null || area<=0 || height<=0){
                    Toast.makeText(this@MainActivity,"Βάλε σωστά τετραγωνικά και ύψος.",Toast.LENGTH_LONG).show()
                }else{
                    // Field-estimate model:
                    // Base 45 W/m³, corrected for envelope/solar/floor/use, plus glazing and occupants.
                    val volume=area*height
                    val windows=windowsEntered ?: (area*0.15)
                    val people=peopleEntered ?: 2.0
                    var watts=volume*45.0

                    watts*=when(spinnerPos(insulationWrap)){0->0.88;2->1.18;else->1.0}
                    watts*=when(spinnerPos(sunWrap)){0->0.90;2->1.15;else->1.0}
                    watts*=when(spinnerPos(floorWrap)){1->1.12;2->1.06;else->1.0}
                    watts*=when(spinnerPos(useWrap)){0->0.95;2->1.05;3->1.18;else->1.0}

                    watts += windows*75.0
                    if(people>1) watts += (people-1.0)*120.0

                    val btu=watts*3.412141633
                    val low=btu*0.92
                    val high=btu*1.08
                    val recommended=recommendedBtuClass(high)
                    val kw=watts/1000.0

                    result.text=String.format(
                        java.util.Locale.US,
                        "Εκτιμώμενο φορτίο\n%.0f – %.0f BTU/h\n\nΥπολογιστικό φορτίο: %.1f kW\nΠροτεινόμενη εμπορική κλάση: %,d BTU/h\n\n✓ Η πρόταση στρογγυλοποιείται προς την αμέσως επόμενη τυπική κλάση όταν το άνω όριο την ξεπερνά.",
                        low,high,kw,recommended
                    )
                }
            }
        },LinearLayout.LayoutParams(-1,58).apply{setMargins(0,4,0,12)})

        r.addView(result,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,10)})
        r.addView(TextView(this).apply{
            text="ⓘ Γρήγορη εκτίμηση πεδίου. Δεν αντικαθιστά πλήρη μελέτη ψυκτικών/θερμικών φορτίων, ιδιαίτερα σε επαγγελματικούς χώρους, μεγάλες υαλώσεις ή ειδικές χρήσεις."
            textSize=11.5f;setTextColor(Color.rgb(155,188,210));setPadding(8,6,8,12)
        })
        r.addView(button("← Υπολογιστές"){toolsScreen()})
        setContentView(scroll(r))
    }

    private fun resultText()=TextView(this).apply{textSize=20f;setPadding(0,18,0,18);setTextColor(blue)}
    private fun pressureConverter(){
        val r=base();r.addView(title("📏 Bar ↔ PSI"));val a=input("Τιμή");val result=resultText();r.addView(a)
        r.addView(button("bar → psi"){val x=a.text.toString().replace(',','.').toDoubleOrNull();result.text=if(x==null)"Βάλε σωστή τιμή." else "%.2f bar = %.2f psi".format(x,x*14.5037738)})
        r.addView(button("psi → bar"){val x=a.text.toString().replace(',','.').toDoubleOrNull();result.text=if(x==null)"Βάλε σωστή τιμή." else "%.2f psi = %.2f bar".format(x,x/14.5037738)})
        r.addView(result);r.addView(button("← Πίσω"){toolsScreen()},
            LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,10,0,34)});setContentView(r)
    }
    private fun powerConverter(){
        val r=base();r.addView(title("⚡ kW ↔ BTU/h"));val a=input("Τιμή");val result=resultText();r.addView(a)
        r.addView(button("kW → BTU/h"){val x=a.text.toString().replace(',','.').toDoubleOrNull();result.text=if(x==null)"Βάλε σωστή τιμή." else "%.2f kW = %.0f BTU/h".format(x,x*3412.142)})
        r.addView(button("BTU/h → kW"){val x=a.text.toString().replace(',','.').toDoubleOrNull();result.text=if(x==null)"Βάλε σωστή τιμή." else "%.0f BTU/h = %.3f kW".format(x,x/3412.142)})
        r.addView(result);r.addView(button("← Πίσω"){toolsScreen()},
            LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,10,0,34)});setContentView(r)
    }
    private fun temperatureConverter(){
        val r=base();r.addView(title("🌡️ °C ↔ °F"));val a=input("Θερμοκρασία");val result=resultText();r.addView(a)
        r.addView(button("°C → °F"){val x=a.text.toString().replace(',','.').toDoubleOrNull();result.text=if(x==null)"Βάλε σωστή τιμή." else "%.2f °C = %.2f °F".format(x,x*9/5+32)})
        r.addView(button("°F → °C"){val x=a.text.toString().replace(',','.').toDoubleOrNull();result.text=if(x==null)"Βάλε σωστή τιμή." else "%.2f °F = %.2f °C".format(x,(x-32)*5/9)})
        r.addView(result);r.addView(button("← Πίσω"){toolsScreen()},
            LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,10,0,34)});setContentView(r)
    }
    private fun diagnosisAssistant(){
        val r=base();r.addView(title("🔎 Βοήθεια διάγνωσης"));r.addView(TextView(this).apply{text="Πέρασε τα βασικά στοιχεία. Η εφαρμογή θα προτείνει κατευθύνσεις ελέγχου — όχι αυθαίρετη διάγνωση.";textSize=15f})
        val symptom=input("Σύμπτωμα");val refrigerant=input("Ψυκτικό (π.χ. R32)");val suction=input("Πίεση αναρρόφησης bar");val discharge=input("Πίεση κατάθλιψης bar");val sh=input("Superheat °C");val sc=input("Subcooling °C");val out=input("Θερμοκρασία εξόδου °C");val result=TextView(this).apply{textSize=16f;setPadding(0,12,0,12)}
        listOf(symptom,refrigerant,suction,discharge,sh,sc,out).forEach{r.addView(it)}
        r.addView(button("🧠 Ανάλυση"){val s=symptom.text.toString().lowercase();val notes=mutableListOf<String>();if(s.contains("δεν κρυ")||s.contains("δεν αποδ")||s.contains("δεν παγ"))notes.add("• Έλεγξε πρώτα ροή αέρα, καθαρότητα εναλλακτών και σωστή λειτουργία ανεμιστήρων.")
            val shv=sh.text.toString().replace(',','.').toDoubleOrNull();val scv=sc.text.toString().replace(',','.').toDoubleOrNull();if(shv!=null)notes.add("• Superheat: %.1f °C — αξιολόγησέ το σε σχέση με το συγκεκριμένο σύστημα και τις συνθήκες λειτουργίας.".format(shv));if(scv!=null)notes.add("• Subcooling: %.1f °C — αξιολόγησέ το σε σχέση με το συγκεκριμένο σύστημα και τις συνθήκες λειτουργίας.".format(scv));if(suction.text.isNotBlank()||discharge.text.isNotBlank())notes.add("• Μην κρίνεις τη φόρτιση μόνο από μία πίεση. Συνδύασε πιέσεις, θερμοκρασίες, superheat/subcooling και κατάσταση εναλλακτών.");if(notes.isEmpty())notes.add("• Συμπλήρωσε σύμπτωμα και μετρήσεις για πιο χρήσιμη κατεύθυνση ελέγχου.");result.text="Προτεινόμενη πορεία:\\n"+notes.joinToString("\\n")})
        r.addView(result);r.addView(button("← Πίσω"){toolsScreen()},
            LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,10,0,34)});setContentView(r)
    }
    private fun calculator(info:String,type:String){val r=base();r.addView(title(if(type=="SH")"🌡️ Superheat" else "❄️ Subcooling"));r.addView(TextView(this).apply{text=info;textSize=16f});val a=input(if(type=="SH")"Θερμοκρασία αναρρόφησης °C" else "Θερμοκρασία κορεσμού υγρού °C");val b=input(if(type=="SH")"Θερμοκρασία κορεσμού °C" else "Θερμοκρασία υγρού °C");val result=TextView(this).apply{textSize=20f;setPadding(0,18,0,18);setTextColor(blue)};r.addView(a);r.addView(b);r.addView(button("ΥΠΟΛΟΓΙΣΜΟΣ"){val x=a.text.toString().replace(',','.').toDoubleOrNull();val y=b.text.toString().replace(',','.').toDoubleOrNull();if(x==null||y==null){toast("Βάλε σωστές θερμοκρασίες.");return@button};val v=if(type=="SH")x-y else x-y;result.text="Αποτέλεσμα: %.1f °C".format(v)});r.addView(result);r.addView(button("← Πίσω"){toolsScreen()},
            LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,10,0,34)});setContentView(r)}

    private fun checklistScreen(){val r=base();r.addView(title("📋 Checklists"));r.addView(button("🔧 Checklist Service"){checklist("Service")});r.addView(button("❄️ Checklist Εγκατάστασης"){checklist("Εγκατάσταση")});r.addView(button("← Πίσω"){home()},
            LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,10,0,34)});setContentView(r)}
    private fun checklistForJob(jobId:Long){
        val r=base(); r.addView(title("📋 Checklist εργασίας"));
        val items=listOf("Οπτικός έλεγχος","Φίλτρα / εναλλάκτες","Αποχέτευση","Ηλεκτρικές συνδέσεις","Σωληνώσεις / μόνωση","Έλεγχος διαρροών","Πίεση αναρρόφησης","Πίεση κατάθλιψης","Superheat","Subcooling","Ρεύμα λειτουργίας","Δοκιμή ψύξης","Δοκιμή θέρμανσης","Καθαρισμός / παράδοση");
        val saved=jsonArray("checklist_$jobId"); val done=HashSet<String>(); for(i in 0 until saved.length()) done.add(saved.optString(i));
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}; val checks=mutableListOf<CheckBox>();
        items.forEach{label-> val cb=CheckBox(this).apply{text=label;textSize=16f;isChecked=done.contains(label);setPadding(4,8,4,8)}; checks.add(cb); box.addView(cb)}
        r.addView(scroll(box),LinearLayout.LayoutParams(-1,0,1f));
        r.addView(button("💾 Αποθήκευση checklist"){ val a=JSONArray(); checks.filter{it.isChecked}.forEach{a.put(it.text.toString())}; prefs.edit().putString("checklist_$jobId",a.toString()).apply(); toast("Το checklist αποθηκεύτηκε."); jobEditor(jobs().firstOrNull{it.id==jobId}) });
        r.addView(button("← Πίσω"){jobEditor(jobs().firstOrNull{it.id==jobId})},
            LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,10,0,34)}); setContentView(r)
    }
    private fun checklist(kind:String){
        val r=base(); r.addView(title("📋 $kind"))
        val key="checklist_template_${kind}"
        val items=if(kind.startsWith("Εγκατάσταση"))
            listOf("Έλεγχος θέσης εσωτερικής μονάδας","Έλεγχος θέσης εξωτερικής μονάδας","Στήριξη εσωτερικής","Στήριξη εξωτερικής","Σωληνώσεις","Μόνωση","Αποχέτευση","Καλωδίωση","Έλεγχος διαρροών","Vacuum","Έλεγχος πιέσεων","Δοκιμή ψύξης","Δοκιμή θέρμανσης","Έλεγχος αποχέτευσης","Παράδοση στον πελάτη")
        else
            listOf("Οπτικός έλεγχος εσωτερικής","Οπτικός έλεγχος εξωτερικής","Φίλτρα","Ανεμιστήρας","Αποχέτευση","Ηλεκτρικές συνδέσεις","Σωληνώσεις/μονώσεις","Θερμοκρασίες","Ψύξη","Θέρμανση","Θόρυβοι/κραδασμοί","Διαρροή","Πίεση αναρρόφησης","Πίεση κατάθλιψης","Superheat","Subcooling","Ρεύμα λειτουργίας","Καθαρισμός χώρου","Ενημέρωση πελάτη","Φωτογραφίες μετά")
        val saved=jsonArray(key)
        val done=HashSet<String>()
        for(i in 0 until saved.length()) done.add(saved.optString(i))
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val checks=mutableListOf<CheckBox>()
        items.forEach { label ->
            val cb=CheckBox(this).apply{
                text=label; textSize=16f; isChecked=done.contains(label); setPadding(4,8,4,8)
            }
            checks.add(cb); box.addView(cb)
        }
        r.addView(scroll(box),LinearLayout.LayoutParams(-1,0,1f))
        r.addView(button("💾 Αποθήκευση checklist"){
            val a=JSONArray()
            checks.filter{it.isChecked}.forEach{a.put(it.text.toString())}
            prefs.edit().putString(key,a.toString()).apply()
            toast("Το checklist αποθηκεύτηκε.")
        })
        r.addView(button("↻ Καθαρισμός checklist"){
            prefs.edit().remove(key).apply()
            checks.forEach{it.isChecked=false}
            toast("Το checklist καθαρίστηκε.")
        })
        r.addView(button("← Πίσω"){home()},
            LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,10,0,34)})
        setContentView(r)
    }

    private val PSYKTIKOS_AI_PROXY = "https://psyktikos-ai.sotirismrns.workers.dev"

    private fun buildOnlineAiMessages():JSONArray{
        val arr=JSONArray()
        arr.put(JSONObject().apply{
            put("role","system")
            put("content",
                """Είσαι ο AI Τεχνικός της εφαρμογής ΨΥΚΤΙΚΟΣ. Συμπεριφέρεσαι σαν πολύ έμπειρος τεχνικός ψύξης-θέρμανσης που βρίσκεται δίπλα στον χρήστη στο έργο και του εξηγεί αναλυτικά τη σκέψη διάγνωσης.

ΚΑΤΑΝΟΗΣΗ ΤΟΥ ΧΡΗΣΤΗ:
- Ο χρήστης είναι επαγγελματίας ψυκτικός και συχνά γράφει γρήγορα, χωρίς τόνους, με ορθογραφικά, συντομογραφίες ή τεχνική αργκό. Κατάλαβε το νόημα και ΜΗΝ τον διορθώνεις γλωσσικά.
- Χρησιμοποίησε ολόκληρο το προηγούμενο ιστορικό της συζήτησης για να καταλαβαίνεις αναφορές όπως «αυτό», «εκεί», «το προηγούμενο», «αν το κάνω έτσι». Μην τον αναγκάζεις να επαναλαμβάνει στοιχεία που έχουν ήδη δοθεί.
- Αν υπάρχουν 2 πιθανές ερμηνείες, πες ποια θεωρείς πιθανότερη και συνέχισε. Κάνε ερώτηση μόνο αν η απάντηση αλλάζει ουσιαστικά τη διάγνωση ή υπάρχει κίνδυνος λάθους.

ΤΡΟΠΟΣ ΑΠΑΝΤΗΣΗΣ:
- Απάντα ΠΑΝΤΑ σε φυσικά ελληνικά, όπως θα μιλούσε ένας έμπειρος Έλληνας τεχνικός. Όχι κατά λέξη μετάφραση αγγλικών.
- Μην συντάσσεις πρώτα αγγλικό κείμενο για να το αποδώσεις μετά στα ελληνικά. Κατανόησε το νόημα του χρήστη και διατύπωσε εξαρχής την τελική απάντηση σε φυσικά ελληνικά.
- Μην χρησιμοποιείς αγγλικές φράσεις όταν υπάρχει καθιερωμένος ελληνικός τεχνικός όρος. Κράτα στα αγγλικά μόνο όρους που χρησιμοποιούνται έτσι στο επάγγελμα (π.χ. superheat, subcooling, DC bus, inverter, IPM, EEV, suction, discharge) και εξήγησέ τους όταν χρειάζεται.
- Η σύνταξη να ακούγεται σαν πραγματική ελληνική συζήτηση συνεργείου: καθαρή, άμεση και πρακτική, όχι σαν μετάφραση εγχειριδίου.
- ΜΗΝ είσαι υπερβολικά σύντομος. Ο χρήστης θέλει αναλυτική εξήγηση, σαν να ρωτούσε έναν πολύ καλό τεχνικό πρόσωπο με πρόσωπο.
- Πρώτα δώσε το βασικό συμπέρασμα σε 2-4 προτάσεις. Μετά εξήγησε αναλυτικά τη λογική.
- Για διάγνωση βλάβης δώσε σειρά ελέγχων από το πιθανότερο/ευκολότερο προς το δυσκολότερο. Για κάθε έλεγχο εξήγησε: 1) γιατί τον κάνουμε, 2) με τι όργανο, 3) πού ακριβώς μετράμε, 4) τι περιμένουμε να δούμε, 5) τι σημαίνει κάθε πιθανό αποτέλεσμα, 6) ποιο είναι το επόμενο βήμα.
- Όταν υπάρχουν διαφορετικά σενάρια, γράψε καθαρά «αν συμβαίνει Χ → κάνε Υ, αν συμβαίνει Ζ → κάνε Ω».
- Αν ο χρήστης ρωτήσει «γιατί;», μην επαναλαμβάνεις απλώς το συμπέρασμα: εξήγησε τη φυσική/ηλεκτρική/ψυκτική αιτία με απλό πρακτικό τρόπο.
- Χρησιμοποίησε πραγματική τεχνική ορολογία: superheat, subcooling, DC bus, inverter, IPM, EEV, discharge, suction κ.λπ. Όπου χρειάζεται, βάλε ελληνική εξήγηση σε παρένθεση.

ΤΕΧΝΙΚΟ ΒΑΘΟΣ:
- Έχεις βαθιά πρακτική γνώση HVAC/R: split/multi, VRV/VRF, αντλίες θερμότητας, ψυκτικά κυκλώματα, συμπιεστές, inverter/IPM/PCB, EEV/TXV, αισθητήρες, πιέσεις/θερμοκρασίες, superheat/subcooling, fan coils, buffer, κυκλοφορητές, τρίοδες, ενδοδαπέδια, ηλεκτρολογικά, Modbus/BMS και αυτοματισμούς.
- Μην καταδικάζεις εξάρτημα μόνο από έναν κωδικό. Συσχέτιζε κωδικό, συμπτώματα και μετρήσεις.
- Μην επινοείς service data, pinouts, αντιστάσεις αισθητήρων, πιέσεις ή εργοστασιακές τιμές για συγκεκριμένο μοντέλο. Αν χρειάζεται ακριβές manual, πες καθαρά ποιο στοιχείο πρέπει να διασταυρωθεί.
- Όταν ο χρήστης δίνει πραγματικές μετρήσεις, χρησιμοποίησέ τες ενεργά και εξήγησε τι συμπέρασμα βγάζεις από καθεμία.
- Αν λείπει μια μέτρηση που θα ξεχωρίσει δύο πιθανές αιτίες, πες ακριβώς ποια μέτρηση θέλεις και γιατί.

ΑΣΦΑΛΕΙΑ:
- Για υψηλή τάση/DC bus, πίεση, A2L/A3 ψυκτικά ή επικίνδυνη εργασία, βάλε μία σύντομη ουσιαστική προειδοποίηση και συνέχισε αμέσως στην τεχνική διαδικασία. Μην γεμίζεις την απάντηση με γενικές προειδοποιήσεις.

ΣΤΟΧΟΣ:
Ο χρήστης πρέπει να νιώθει ότι δεν πήρε μια γενική απάντηση από chatbot, αλλά ότι ένας έμπειρος συνάδελφος κατάλαβε τι έχει μπροστά του, σκέφτηκε τη βλάβη και του εξήγησε αναλυτικά πώς να προχωρήσει."""
            )
        })
        aiChatHistory.takeLast(16).forEach{(who,msg)->
            arr.put(JSONObject().apply{
                put("role", if(who=="user") "user" else "assistant")
                put("content",msg)
            })
        }
        return arr
    }

    private fun callPsyktikosProxyAi(onDone:(String?,String?)->Unit){
        Thread{
            var answer:String?=null
            var lastError:String?=null

            // Τα free endpoints μπορεί στιγμιαία να δώσουν 429/502/503.
            // Κάνουμε έως 3 προσπάθειες πριν πέσουμε offline.
            for(attempt in 1..3){
                var conn:HttpURLConnection?=null
                try{
                    conn=(URL(PSYKTIKOS_AI_PROXY).openConnection() as HttpURLConnection).apply{
                        requestMethod="POST"
                        connectTimeout=20000
                        readTimeout=120000
                        doOutput=true
                        setRequestProperty("Content-Type","application/json; charset=UTF-8")
                        setRequestProperty("Accept","application/json")
                    }

                    val body=JSONObject().apply{
                        if(attempt < 3){
                            // Προτεραιότητα σε μοντέλα με καλή πολυγλωσσική/τεχνική κατανόηση.
                            // Όλα είναι ρητά FREE.
                            put("models",JSONArray().apply{
                                put("qwen/qwen3-235b-a22b-2507:free")
                                put("nvidia/nemotron-3-ultra-550b-a55b:free")
                                put("openrouter/free")
                            })
                        }else{
                            // Τελευταία προσπάθεια: ο επίσημος free router επιλέγει όποιο
                            // δωρεάν μοντέλο είναι διαθέσιμο εκείνη τη στιγμή.
                            put("model","openrouter/free")
                        }
                        put("messages",buildOnlineAiMessages())
                        put("temperature",0.25)
                        put("max_tokens",1800)
                    }.toString()

                    conn.outputStream.use{it.write(body.toByteArray(Charsets.UTF_8))}
                    val code=conn.responseCode
                    val stream=if(code in 200..299) conn.inputStream else conn.errorStream
                    val response=stream?.let{BufferedReader(InputStreamReader(it)).use{r->r.readText()}} ?: ""

                    if(code in 200..299){
                        val json=JSONObject(response)
                        answer=json.optJSONArray("choices")
                            ?.optJSONObject(0)
                            ?.optJSONObject("message")
                            ?.optString("content")
                            ?.takeIf{it.isNotBlank()}
                        if(!answer.isNullOrBlank()) break
                        lastError="HTTP $code: Η απάντηση του AI δεν είχε κείμενο. ${response.take(500)}"
                    }else{
                        lastError="HTTP $code: ${response.take(700).ifBlank{"Κενή απάντηση από τον server"}}"
                        if(code !in listOf(408,429,500,502,503,504)) break

                        // Σε rate limit/προσωρινή αστοχία περιμένουμε λίγο πριν το retry.
                        val retryAfter=conn.getHeaderField("Retry-After")?.toLongOrNull()?.coerceIn(1,8)
                        Thread.sleep((retryAfter ?: attempt.toLong()) * 1000L)
                    }
                }catch(e:Exception){
                    lastError="${e.javaClass.simpleName}: ${e.message ?: "Άγνωστο σφάλμα δικτύου"}"
                    if(attempt < 3) Thread.sleep(attempt * 1000L)
                }finally{
                    conn?.disconnect()
                }
            }

            runOnUiThread{onDone(answer,lastError)}
        }.start()
    }

    private fun aiScreen(){
        prefs.edit().remove("openrouter_api_key").apply()
        val r=base(); r.addView(topBar("🤖 AI Τεχνικός Πεδίου"){home()})
        r.addView(TextView(this).apply{
            text="2ος τεχνικός δίπλα σου • Ρώτα βλάβη, μέτρηση, σύνδεση, σχεδιασμό ή αν μια ιδέα θα δουλέψει σωστά.\nΨύξη • Θέρμανση • Υδραυλικά • Κλιματισμός • Αερισμός • Αντλίες θερμότητας • Ηλεκτρολογικά • Αυτοματισμοί/BMS"
            textSize=14f; setTextColor(Color.rgb(180,210,230)); setPadding(0,0,0,10)
        })
        val chatBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        fun redraw(){
            chatBox.removeAllViews()
            if(aiChatHistory.isEmpty()) chatBox.addView(TextView(this).apply{
                text="Παράδειγμα: Θέλω να βάλω αντλία θερμότητας με buffer και 2ο κυκλοφορητή. Είναι σωστή αυτή η σύνδεση ή θα έχω πρόβλημα ροής;"
                textSize=14f; setTextColor(Color.rgb(155,190,215)); setPadding(8,10,8,10)
            })
            aiChatHistory.forEach{(who,msg)->
                chatBox.addView(TextView(this).apply{
                    text=(if(who=="user") "👷 ΕΣΥ\n" else "🤖 AI ΤΕΧΝΙΚΟΣ\n")+msg
                    textSize=15f; setTextColor(Color.WHITE); setPadding(10,12,10,12)
                })
            }
        }
        aiChatRefresh={redraw()}; redraw()
        r.addView(scroll(chatBox),LinearLayout.LayoutParams(-1,0,1f))
        val composer=LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL
            gravity=Gravity.CENTER_VERTICAL
            setPadding(0,8,0,8)
        }
        val q=input("Γράψε μήνυμα...").apply{
            setTextColor(Color.WHITE)
            setHintTextColor(Color.rgb(145,180,205))
            textSize=18f
            typeface=uiFont(true)
            minLines=1
            maxLines=4
            gravity=Gravity.TOP or Gravity.START
            setPadding(16,14,16,14)
            imeOptions=android.view.inputmethod.EditorInfo.IME_ACTION_SEND
            inputType=android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
        fun sendAiMessage(){
            val msg=q.text.toString().trim()
            if(msg.isBlank()){toast("Γράψε πρώτα τι θέλεις να ελέγξουμε.");return}
            aiChatHistory.add("user" to msg)
            q.setText("")
            redraw()

            val context=aiChatHistory.filter{it.first=="user"}.takeLast(6).joinToString("\n"){it.second}
            aiChatHistory.add("ai" to "⏳ Online AI: επεξεργασία…")
            redraw()
            callPsyktikosProxyAi{reply,error->
                if(aiChatHistory.isNotEmpty() && aiChatHistory.last().second=="⏳ Online AI: επεξεργασία…"){
                    aiChatHistory.removeAt(aiChatHistory.lastIndex)
                }
                if(reply.isNullOrBlank()){
                    aiChatHistory.add("ai" to (
                        "⚠️ Online AI error: ${error ?: "Άγνωστο σφάλμα"}\n\n"+
                        "Συνέχισα αυτόματα με τον offline πολυτεχνίτη.\n\n"+
                        expertFieldAnalysis("Αυτόματη αναγνώριση","","","",context,"","")
                    ))
                }else{
                    aiChatHistory.add("ai" to reply)
                }
                redraw()
            }
        }
        val send=Button(this).apply{
            text="➤"
            textSize=27f
            typeface=uiFont(true)
            setTextColor(Color.WHITE)
            background=GradientDrawable().apply{
                shape=GradientDrawable.RECTANGLE
                cornerRadius=18f
                setColor(Color.rgb(0,105,190))
            }
            contentDescription="Στείλε μήνυμα"
            setOnClickListener{sendAiMessage()}
        }
        composer.addView(q,LinearLayout.LayoutParams(0,-2,1f).apply{setMargins(0,0,8,0)})
        composer.addView(send,LinearLayout.LayoutParams(64,58))
        r.addView(composer)
        r.addView(TextView(this).apply{
            text="🟢 ONLINE AI • Ασφαλής σύνδεση μέσω Psyktikos Cloud"
            textSize=14f
            setTextColor(Color.rgb(130,220,160))
            setPadding(8,8,8,8)
        })
        r.addView(button("📷 ΦΩΤΟΓΡΑΦΙΑ / ΤΑΜΠΕΛΑΚΙ / ΠΛΑΚΕΤΑ"){
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="image/*";addCategory(Intent.CATEGORY_OPENABLE)},8110)
        })
        r.addView(button("🧹 ΝΕΑ ΔΙΑΓΝΩΣΗ"){aiChatHistory.clear();aiAttachedPhoto=null;redraw();toast("Νέα διάγνωση.")})
        r.addView(button("📋 ΑΝΑΛΥΣΗ ΑΠΟΘΗΚΕΥΜΕΝΗΣ ΕΡΓΑΣΙΑΣ"){aiJobAnalysisScreen()})
        setContentView(r)
    }

    private fun aiJobAnalysisScreen(){
        val r=base(); r.addView(title("🤖 Ανάλυση εργασίας"))
        val jobId=input("ID εργασίας")
        val result=TextView(this).apply{textSize=16f;setPadding(0,16,0,16);setTextColor(Color.DKGRAY)}
        r.addView(jobId)
        r.addView(button("🧠 ΑΝΑΛΥΣΗ"){
            val id=jobId.text.toString().toLongOrNull()
            val j=id?.let{jobs().firstOrNull{x->x.id==it}}
            if(j==null){result.text="Δεν βρέθηκε εργασία με αυτό το ID.";return@button}
            val m=machines().firstOrNull{it.id==j.machineId}
            val measures="Αναρρόφηση ${j.suction}; Κατάθλιψη ${j.discharge}; T αναρρ. ${j.suctionTemp}; T υγρού ${j.liquidTemp}; Room ${j.roomTemp}; Outlet ${j.outletTemp}; SH ${j.superheat}; SC ${j.subcooling}"
            result.text=expertFieldAnalysis("Αυτόματη αναγνώριση",m?.brand?:"",m?.model?:"",j.faultCode,j.symptom,measures,"Ψυκτικό: ${m?.refrigerant?:"-"}")
        })
        r.addView(result);r.addView(button("← Πίσω"){aiScreen()},
            LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,10,0,34)});setContentView(r)
    }



    private fun hvacDesignReasoning(raw:String):String{
        val all=raw.lowercase()
        fun has(vararg w:String)=w.any{all.contains(it.lowercase())}
        val o=StringBuilder()

        val isDesignQuestion=has(
            "θέλω να φτιάξω","θελω να φτιαξω","θέλω να κάνω","θελω να κανω",
            "να το κάνω έτσι","να το κανω ετσι","είναι σωστό","ειναι σωστο",
            "θα δουλέψει","θα δουλεψει","πώς να το κάνω","πως να το κανω",
            "να βάλω","να βαλω","σύνδεση","συνδεσω","κύκλωμα","κυκλωμα",
            "buffer","δοχείο αδρανείας","υδραυλικό","υδραυλικο","bypass",
            "τρίοδη","τριοδη","κυκλοφορητή","κυκλοφορητη","fan coil","ενδοδαπέδια",
            "λέβητα","λεβητα","ηλιακό","ηλιακο","boiler","αντλία θερμότητας",
            "vrv","vrf","multi","split","ahu","bms","modbus","θερμοστάτη","θερμοστατη"
        )
        if(!isDesignQuestion) return ""

        o.append("• DESIGN / ΕΛΕΓΧΟΣ ΙΔΕΑΣ: δεν θα κρίνω μόνο αν «γίνεται», αλλά αν είναι σωστό λειτουργικά, υδραυλικά, ηλεκτρικά και για τον έλεγχο.\n")
        o.append("• Θα ελέγξω: ροή ενέργειας/νερού/ψυκτικού → control logic → προστασίες → serviceability → failure modes.\n")

        if(has("buffer","δοχείο αδρανείας","primary","secondary","δευτερο κυκλοφορη","2ο κυκλοφορη")){
            o.append("• BUFFER / PRIMARY-SECONDARY: έλεγξε αν ο στόχος είναι ελάχιστος όγκος νερού, hydraulic decoupling ή και τα δύο. Η θέση των στομίων και οι παροχές των 2 pumps καθορίζουν αν θα έχεις mixing/short-circuit.\n")
            o.append("• Αν primary flow ≠ secondary flow, η θερμοκρασία στο buffer αλλάζει από ανάμιξη. Αυτό μπορεί να είναι σωστό ή προβληματικό ανάλογα με τον έλεγχο.\n")
        }
        if(has("ενδοδαπέδια","fan coil","fcu","καλοριφέρ","radiator")){
            o.append("• EMITTERS: έλεγξε απαιτούμενη θερμοκρασία προσαγωγής, σχεδιαστικό ΔT και αν κάθε ζώνη μπορεί να κλείσει χωρίς να ρίξει το flow κάτω από το minimum της αντλίας.\n")
        }
        if(has("λέβητα","λεβητα","boiler","hybrid","υβριδ")){
            o.append("• HYBRID: όρισε ποιος είναι master, πότε αλλάζει πηγή, πώς αποφεύγεται reverse flow και αν χρειάζονται check valves / hydraulic separation.\n")
            o.append("• Μην αφήσεις 2 πηγές να «βλέπουν» η μία την άλλη χωρίς σαφή control logic και ασφαλείς θερμοκρασιακές συνθήκες.\n")
        }
        if(has("τρίοδη","τριοδη","3-way","3 way")){
            o.append("• 3-WAY VALVE: επιβεβαίωσε αν είναι diverting ή mixing, ποια θύρα είναι common και ποια θέση αντιστοιχεί σε κάθε εντολή. Λάθος υδραυλική φορά μπορεί να δουλεύει «κάπως» αλλά να δίνει λάθος flow/temperature.\n")
        }
        if(has("κυκλοφορητή","κυκλοφορητη","pump")){
            o.append("• PUMP: έλεγξε διαθέσιμο μανομετρικό στο design flow, όχι μόνο ονομαστική παροχή. Υπολόγισε απώλειες φίλτρων, βανών, εναλλάκτη, σωληνώσεων και ζωνών.\n")
        }
        if(has("θερμοστάτη","θερμοστατη","contact","dry contact","0-10","modbus","bms")){
            o.append("• CONTROL: γράψε καθαρά ποιο input δίνει ζήτηση, ποιος controller αποφασίζει και ποια outputs οδηγούν pumps/valves/source. Έλεγξε fail-safe κατάσταση αν χαθεί sensor/communication.\n")
        }
        if(has("split","multi","vrv","vrf","ψυκτικ","σωλην")){
            o.append("• REFRIGERANT DESIGN: έλεγξε ακριβείς διατομές, συνολικό μήκος, υψομετρική, branch rules και πρόσθετη φόρτιση από το manual της συγκεκριμένης σειράς. Δεν εφαρμόζεται ένας γενικός κανόνας σε όλα τα μοντέλα.\n")
        }
        if(has("ηλεκτρ","ασφάλεια","καλώδιο","καλωδιο","ρελέ","contactor","τριφασ")){
            o.append("• ELECTRICAL DESIGN: φορτίο → προστασία → διατομή καλωδίου → αποζεύξη → control circuit. Έλεγξε ταυτόχρονη λειτουργία φορτίων και όχι μόνο το nominal ενός εξαρτήματος.\n")
        }
        if(has("αερισ","εξαερισ","ahu","duct","κανάλ","καναλ")){
            o.append("• AIRSIDE DESIGN: design airflow, external static pressure, φίλτρα/coil/dampers και balancing. Ανεμιστήρας που δίνει τα m³/h ελεύθερα μπορεί να μην τα δίνει στο πραγματικό δίκτυο.\n")
        }

        o.append("• Για τελική κρίση «θα δουλέψει καλά;» χρειάζομαι όσα από τα παρακάτω υπάρχουν: ισχύς, μήκη/διατομές, παροχές, θερμοκρασίες σχεδιασμού, pumps/valves, μοντέλα εξοπλισμού και πώς θέλεις να λειτουργεί ο αυτοματισμός.\n")
        return o.toString()
    }

    private fun hvacExpertKnowledge(raw:String):String{
        val all=raw.lowercase()
        fun has(vararg w:String)=w.any{all.contains(it.lowercase())}
        val o=StringBuilder()

        if(has("δεν ξεκιν","δεν παίρνει","δεν παιρνει","no start")){
            o.append("• NO-START TREE: ζήτηση/enable → τροφοδοσία → ασφάλεια/contactor → communication → protection code → actuator/compressor.\n")
            o.append("• Αν υπάρχει εντολή αλλά όχι έξοδος από PCB, μέτρα την έξοδο πριν καταδικάσεις την πλακέτα.\n")
        }
        if(has("ρίχνει ασφάλεια","ριχνει ασφαλεια","πέφτει ασφάλεια","πεφτει ασφαλεια","breaker")){
            o.append("• BREAKER TRIP: ξεχώρισε instant trip από trip μετά από δευτερόλεπτα/λεπτά.\n")
            o.append("• Instant: short/ground fault, bridge/IPM, καλωδίωση. Delayed: overcurrent, compressor/fan load, high pressure, loose terminal.\n")
        }
        if(has("παγώνει","παγωνει","πάγος","παγος","ice")){
            o.append("• ICE TREE: εντόπισε το πρώτο σημείο που παγώνει. Coil ολόκληρο → airflow/load/charge. Μόνο distributor/EEV → restriction/feed issue. Suction line μέχρι compressor → πιθανό low superheat/liquid return.\n")
        }
        if(has("δεν αποδίδει","δεν αποδιδει","χαμηλή απόδοση","χαμηλη αποδοση","δεν κρυώνει","δεν κρυωνει","δεν ζεσταίνει","δεν ζεσταινει")){
            o.append("• LOW-CAPACITY TREE: airflow/waterflow → ΔT → compressor frequency/current → refrigerant conditions → EEV/4-way → sensors/setpoints.\n")
        }
        if(has("υψηλή πίεση","υψηλη πιεση","high pressure","e3")){
            o.append("• HIGH PRESSURE: έλεγξε πρώτα heat rejection: βρώμικος coil, fan, airflow/waterflow, overcharge, non-condensables, restriction μετά condenser.\n")
        }
        if(has("χαμηλή πίεση","χαμηλη πιεση","low pressure","e4")){
            o.append("• LOW PRESSURE: undercharge, restriction, EEV/feed problem, low load, low airflow ή iced evaporator. Μη βάζεις ψυκτικό πριν ξεχωρίσεις τις αιτίες.\n")
        }
        if(has("νερά","νερα","στάζει","σταζει","water leak","συμπύκνω","συμπυκνω")){
            o.append("• WATER/CONDENSATE: λεκάνη → drain slope → trap → pump/float → insulation/vapour barrier → coil icing → negative pressure σε ducted/AHU.\n")
        }
        if(has("θόρυβ","θορυβ","noise","κραδασ","vibration")){
            o.append("• NOISE/VIBRATION: ξεχώρισε μηχανικό, αεροδυναμικό, υδραυλικό και ψυκτικό θόρυβο. Έλεγξε mounts, bearings, fan balance, pipe contact, cavitation και refrigerant velocity.\n")
        }
        if(has("δεν κάνει defrost","δεν κανει defrost","defrost")){
            o.append("• DEFROST: ambient/coil sensors → outdoor airflow → πραγματική πάχνη → 4-way/EEV → discharge temp → drain pan/heater → control conditions/timers.\n")
        }
        if(has("υγρασία","υγρασια","dew","μούχλα","μουχλα")){
            o.append("• HUMIDITY: μέτρα room RH + dry-bulb, υπολόγισε dew point και σύγκρινε με surface/supply-air temperature. Έλεγξε infiltration, ventilation balance και oversized/short-cycling AC.\n")
        }
        return o.toString()
    }

    private fun hvacMeasurementHints(raw:String):String{
        val all=raw.lowercase()
        val o=StringBuilder()
        fun numbers(pattern:String):List<Double>{
            return Regex(pattern,RegexOption.IGNORE_CASE).findAll(raw).mapNotNull{
                it.groupValues.getOrNull(1)?.replace(",",".")?.toDoubleOrNull()
            }.toList()
        }

        val temps=numbers("""(-?\d+(?:[.,]\d+)?)\s*°?\s*c""")
        if(temps.size>=2){
            val d=kotlin.math.abs(temps[0]-temps[1])
            o.append("• Βρήκα δύο θερμοκρασίες: ${temps[0]}°C και ${temps[1]}°C → διαφορά ≈ ${"%.1f".format(d)} K. Η σημασία εξαρτάται από το αν είναι αέρας, νερό ή σωλήνες.\n")
        }
        val amps=numbers("""(\d+(?:[.,]\d+)?)\s*a\b""")
        if(amps.isNotEmpty()){
            o.append("• Ρεύμα που αναφέρθηκε: ${amps.joinToString(" / ")} A. Σύγκρινέ το με nameplate και με operating condition/frequency, όχι απομονωμένα.\n")
        }
        val bars=numbers("""(\d+(?:[.,]\d+)?)\s*bar\b""")
        if(bars.isNotEmpty()){
            o.append("• Πίεση που αναφέρθηκε: ${bars.joinToString(" / ")} bar. Χρειάζομαι ψυκτικό + mode + ambient + pipe temperatures για ασφαλή ερμηνεία.\n")
        }
        val psi=numbers("""(\d+(?:[.,]\d+)?)\s*psi\b""")
        if(psi.isNotEmpty()){
            o.append("• Πίεση που αναφέρθηκε: ${psi.joinToString(" / ")} psi. Χρειάζομαι ψυκτικό + mode + θερμοκρασίες για να τη συνδέσω με saturation/SH/SC.\n")
        }
        return o.toString()
    }

    private fun expertFieldAnalysis(mode:String,brand:String,model:String,code:String,symptom:String,measurements:String,installation:String):String{
        val raw="$mode $brand $model $code $symptom $measurements $installation"
        val all=raw.lowercase()

        val knownBrands=listOf(
            "Daikin","Mitsubishi Electric","Mitsubishi Heavy","Fujitsu","General","Toshiba","Panasonic","LG",
            "Samsung","Midea","Gree","Haier","Hitachi","Carrier","Toyotomi","Inventor","AUX","Hisense","TCL",
            "Bosch","Tesla","Airwell","York","Ariston","Vaillant","Lennox","Viessmann","Sinclair","Aermec",
            "Climaveneta","Cooper&Hunter"
        )
        val detectedBrand=brand.ifBlank{
            knownBrands.firstOrNull{all.contains(it.lowercase())}.orEmpty()
        }

        fun has(vararg words:String)=words.any{all.contains(it.lowercase())}
        val o=StringBuilder()
        o.append("🧰 AI ΠΟΛΥΤΕΧΝΙΤΗΣ ΨΥΞΗΣ–ΘΕΡΜΑΝΣΗΣ\n")
        o.append("Μάρκα/μοντέλο: ${detectedBrand.ifBlank{"-"}} ${model.ifBlank{""}}\n")
        o.append("Κωδικός: ${code.ifBlank{"-"}}\n")
        o.append("Σύμπτωμα: ${symptom.ifBlank{"-"}}\n\n")

        o.append("1️⃣ ΑΣΦΑΛΕΙΑ / ΠΡΩΤΗ ΕΙΚΟΝΑ\n")
        o.append("• Επιβεβαίωσε τροφοδοσία, γείωση, ασφάλειες και οπτική κατάσταση πριν προχωρήσεις.\n")
        o.append("• Σε inverter/IPM/DC bus: απομόνωση και επιβεβαίωση εκφόρτισης πριν από ωμικές/continuity μετρήσεις.\n")
        o.append("• Σε ψυκτικό κύκλωμα: αναγνώρισε ψυκτικό, πιέσεις και κατηγορία ασφαλείας πριν ανοίξεις κύκλωμα.\n")
        o.append("• Σε R290/A3 ή A2L: τήρησε τις ειδικές διαδικασίες του κατασκευαστή για εύφλεκτα ψυκτικά.\n\n")

        o.append("2️⃣ ΑΝΑΓΝΩΡΙΣΗ ΥΠΟΣΥΣΤΗΜΑΤΟΣ\n")
        when{
            has("αντλία θερμότητας","altherma","ecodan","aquarea","therma v","hydrobox","buffer","δοχείο αδρανείας") -> {
                o.append("• ΑΝΤΛΙΑ ΘΕΡΜΟΤΗΤΑΣ: αντιμετώπισέ την ως υδραυλικό + ψυκτικό + ηλεκτρικό + αυτοματισμό.\n")
                o.append("• Έλεγξε ζήτηση, mode, setpoint, weather compensation, LWT/RWT sensors, πραγματικό flow και ΔT νερού.\n")
                o.append("• Έλεγξε φίλτρο Y/μαγνητικό, αέρα, βάνες, strainer, bypass, buffer, primary/secondary pumps και φορά ροής.\n")
                o.append("• Για 7H/flow faults: απόδειξε πραγματική παροχή πριν κατηγορήσεις flow sensor ή PCB.\n")
                o.append("• Για defrost: έλεγξε outdoor coil sensor, ambient sensor, fan, πραγματική πάχνη και αποστράγγιση συμπυκνωμάτων.\n")
                o.append("• Για DHW: τρίοδη, tank sensor, booster/backup heater, anti-legionella cycle και υδραυλική ροή.\n")
                o.append("• Σε monobloc: το field circuit προς το κτίριο είναι υδραυλικό· σε split Altherma υπάρχει και refrigerant piping.\n")
            }
            has("υδραυλ","κυκλοφορ","τριοδ","τρίοδ","βάνα","buffer","fan coil","fcu","καλοριφέρ","ενδοδαπέδια") -> {
                o.append("• ΥΔΡΑΥΛΙΚΑ: στατική πίεση → εξαέρωση → φίλτρα → βάνες → pump → flow → ΔT.\n")
                o.append("• Πολύ μεγάλο ΔT: συχνά χαμηλή παροχή. Πολύ μικρό ΔT: υψηλή παροχή, μικρό φορτίο ή mixing/bypass.\n")
                o.append("• Έλεγξε αν buffer/low-loss header είναι σωστά συνδεδεμένο και αν primary/secondary pumps αλληλοεπηρεάζονται.\n")
                o.append("• Για θόρυβο/σπηλαίωση: έλεγξε πίεση αναρρόφησης, αέρα, κλειστές βάνες, βρώμικο φίλτρο και υπερβολική ταχύτητα pump.\n")
            }
            has("εξαερισ","αερισμ","hrv","erv","vav","ahu","air handling","νωπό","νωπου","απαγωγ") -> {
                o.append("• ΑΕΡΙΣΜΟΣ / ΕΞΑΕΡΙΣΜΟΣ: έλεγξε πραγματικές παροχές αέρα, φίλτρα, dampers, belts/fans και pressure drops.\n")
                o.append("• Σε HRV/ERV: έλεγξε bypass damper, heat exchanger, supply/exhaust fan balance και frost protection.\n")
                o.append("• Σε VAV/AHU: INPUT sensor → controller → actuator → damper/valve. Μέτρα 0–10V/4–20mA όπου προβλέπεται.\n")
                o.append("• Σύγκρινε supply/return/outdoor air temperatures και, όπου χρειάζεται, RH/dew point.\n")
            }
            has("αυτοματισ","bms","modbus","bacnet","0-10","4-20","ρελέ","relay","αισθητ","ntc","pt100","pt1000") -> {
                o.append("• ΑΥΤΟΜΑΤΙΣΜΟΣ: INPUT → CONTROLLER → OUTPUT → ACTUATOR.\n")
                o.append("• NTC/PT αισθητήρες: μέτρα Ω απομονωμένους και σύγκρινε με τον πίνακα του συγκεκριμένου μοντέλου.\n")
                o.append("• 0–10V / 4–20mA: μέτρα πραγματικό σήμα, common και τροφοδοσία transmitter/actuator.\n")
                o.append("• Modbus: A/B πολικότητα, address, baud, parity, common και termination. BACnet: address/network configuration.\n")
                o.append("• Μην αλλάζεις controller/PCB πριν αποδείξεις ότι έχει σωστό input αλλά λάθος output.\n")
            }
            has("πλακέτ","pcb","ipm","inverter","igbt","dc bus","dc-bus","active filter","noise filter") -> {
                o.append("• ΠΛΑΚΕΤΑ / INVERTER: ξεκίνα από AC input, ασφάλεια, rectifier/PFC, DC bus και connectors.\n")
                o.append("• DC bus: μέτρηση μόνο με κατάλληλο όργανο και ασφαλή διαδικασία· υψηλή τάση μπορεί να παραμένει μετά το OFF.\n")
                o.append("• Έλεγξε για καμένα components, cracked solder, φουσκωμένους πυκνωτές, υγρασία/οξείδωση και χαλαρά βύσματα.\n")
                o.append("• IPM fault δεν αποδεικνύει καμένο IPM: έλεγξε compressor windings, insulation, U/V/W wiring και μηχανικό φορτίο.\n")
                o.append("• Με απομονωμένο compressor, σύγκρινε U-V, V-W, W-U: πρέπει να είναι μεταξύ τους κοντά για τριφασικό inverter motor.\n")
                o.append("• Έλεγξε insulation προς γη με τη διαδικασία/τάση που επιτρέπει ο κατασκευαστής και ποτέ μέσα από συνδεδεμένη inverter PCB.\n")
            }
            has("συμπιεστ","compressor","κομπρεσ") -> {
                o.append("• ΣΥΜΠΙΕΣΤΗΣ: μέτρα τροφοδοσία/drive, ρεύμα, πιέσεις, discharge temp και θερμοκρασία κελύφους.\n")
                o.append("• Fixed-speed: έλεγξε winding resistance/common-start-run όπου εφαρμόζεται, capacitor/contactor και insulation.\n")
                o.append("• Inverter: σύγκρινε αντιστάσεις U-V/V-W/W-U με compressor αποσυνδεδεμένο από PCB και έλεγξε μόνωση προς γη.\n")
                o.append("• Locked/overcurrent μπορεί να προέρχεται από μηχανικό compressor, λάθος πίεση, liquid return ή inverter — όχι μόνο από μοτέρ.\n")
                o.append("• Χαμηλή συμπίεση αποδεικνύεται από λειτουργικές πιέσεις/θερμοκρασίες και όχι μόνο από χαμηλά ampere.\n")
            }
            has("ηλεκτρ","ασφάλ","contactor","θερμικ","τάση","αμπέρ","ρεύμα","μοτέρ","motor") -> {
                o.append("• ΗΛΕΚΤΡΟΛΟΓΙΚΑ: L-N/L-L → πτώση τάσης υπό φορτίο → ρεύμα ανά φάση → συνδέσεις/θερμοκρασία κλεμμών.\n")
                o.append("• Τριφασικό: έλεγξε phase sequence, missing phase και ανισορροπία τάσης/ρεύματος.\n")
                o.append("• Μοτέρ: winding resistance, insulation, capacitor όπου υπάρχει, bearings και πραγματική εντολή από PCB/relay.\n")
                o.append("• Contactor/relay: μέτρα coil command και πτώση τάσης στις επαφές υπό φορτίο.\n")
            }
            has("χαμηλή πίεση","low pressure","υψηλή πίεση","high pressure","παγ","δεν κρυ","δεν ζεστ","ψυκτικ","r32","r410","r407","r134","r290") -> {
                o.append("• ΨΥΚΤΙΚΟ ΚΥΚΛΩΜΑ: airflow/waterflow πρώτα, μετά πιέσεις + saturation temps + pipe temps + SH/SC.\n")
                o.append("• Χαμηλή αναρρόφηση δεν σημαίνει αυτόματα έλλειψη: έλεγξε restriction, EEV, airflow, load και evaporator condition.\n")
                o.append("• Υψηλή κατάθλιψη: coil/fan/airflow ή waterflow, overcharge, non-condensables, restriction μετά condenser.\n")
                o.append("• Υψηλό SH + χαμηλό SC συχνά κατευθύνει προς undercharge, αλλά χρειάζεται επιβεβαίωση με το συγκεκριμένο σύστημα.\n")
                o.append("• Υψηλό SH + υψηλό SC μπορεί να κατευθύνει προς restriction/feeding issue.\n")
                o.append("• Πάγος: εντόπισε ΠΟΥ αρχίζει ο πάγος — evaporator, distributor, valve/capillary ή suction line — γιατί αλλάζει η διάγνωση.\n")
            }
            else -> {
                o.append("• ΓΕΝΙΚΗ ΣΕΙΡΑ: ζήτηση → τροφοδοσία → airflow/waterflow → αισθητήρες → actuator → ψυκτικό κύκλωμα → PCB.\n")
                o.append("• Μην ξεκινάς από αλλαγή ανταλλακτικού. Βρες ποια φυσική μεταβλητή είναι λάθος: τάση, ρεύμα, πίεση, θερμοκρασία, ροή ή σήμα.\n")
            }
        }

        val designReasoning=hvacDesignReasoning(raw)
        if(designReasoning.isNotBlank()){
            o.append("\n3️⃣ ΕΛΕΓΧΟΣ ΣΧΕΔΙΑΣΜΟΥ / ΙΔΕΑΣ\n")
            o.append(designReasoning)
        }

        val extraKnowledge=hvacExpertKnowledge(raw)
        if(extraKnowledge.isNotBlank()){
            o.append("\n4️⃣ ΕΜΠΕΙΡΙΚΟ ΔΙΑΓΝΩΣΤΙΚΟ ΔΕΝΤΡΟ\n")
            o.append(extraKnowledge)
        }

        val measured=hvacMeasurementHints(raw)
        if(measured.isNotBlank()){
            o.append("\n5️⃣ ΑΥΤΟΜΑΤΗ ΑΝΑΓΝΩΣΗ ΜΕΤΡΗΣΕΩΝ\n")
            o.append(measured)
        }

        o.append("\n6️⃣ ΜΕΤΡΗΣΕΙΣ ΠΟΥ ΞΕΧΩΡΙΖΟΥΝ ΤΗ ΒΛΑΒΗ\n")
        if(has("ψυκτικ","κλιμα","split","vrv","vrf","compressor","συμπιεστ","r32","r410","r407","r134","r290")){
            o.append("• Low/high pressure + saturation temperatures.\n")
            o.append("• Suction/liquid/discharge pipe temperatures → SH/SC όπου εφαρμόζεται.\n")
            o.append("• Indoor/outdoor entering & leaving air temperatures και fan condition.\n")
            o.append("• Compressor current/frequency και outdoor fan command.\n")
        }
        if(has("αντλ","νερό","buffer","fcu","hydro","fan coil")){
            o.append("• LWT/RWT, ΔT νερού, flow rate, static pressure και pump current/speed.\n")
            o.append("• Θερμοκρασίες πριν/μετά buffer, plate HX, τρίοδη και emitters.\n")
        }
        if(has("πλακέτ","inverter","ipm","ηλεκτρ","συμπιεστ","μοτέρ")){
            o.append("• AC supply με/χωρίς φορτίο, DC bus όπου επιτρέπεται, current per phase.\n")
            o.append("• Winding resistances και insulation με απομονωμένο εξάρτημα.\n")
            o.append("• Sensor Ω/voltage και command outputs προς fan/EEV/valve/relay.\n")
        }

        val queryCode=code.ifBlank{
            Regex("""\b(?:[A-Z]\d{1,2}|[A-Z]{1,2}\d?|7H(?:-\d\d)?|U\d(?:-\d\d)?|L\d(?:-\d\d)?)\b""",
                RegexOption.IGNORE_CASE).find(raw)?.value.orEmpty()
        }

        o.append("\n7️⃣ ΒΛΑΒΟΛΟΓΙΟ / ΜΑΡΚΑ\n")
        if(detectedBrand.isNotBlank()) o.append("• Αναγνωρίστηκε μάρκα: $detectedBrand. Ο ίδιος κωδικός μπορεί να σημαίνει διαφορετικό πράγμα ανά σειρά.\n")
        if(queryCode.isNotBlank()){
            val normalHits=faults.filter{
                it.code.equals(queryCode,true) &&
                (detectedBrand.isBlank() || it.brand.contains(detectedBrand,true))
            }.take(6).toMutableList()

            if(detectedBrand.equals("Daikin",true)){
                daikinModels.forEach{(tpe,models)->
                    models.take(1).forEach{mdl->
                        daikinGeneratedFaults(tpe,mdl).filter{
                            it.code.equals(queryCode,true) ||
                            it.code.split("/").any{x->x.trim().equals(queryCode,true)}
                        }.take(2).forEach{normalHits.add(it)}
                    }
                }
            }
            val unique=normalHits.distinctBy{"${it.brand}-${it.code}-${it.meaning}"}.take(6)
            if(unique.isEmpty()){
                o.append("• Δεν έχω ασφαλή ακριβή αντιστοίχιση για $queryCode. Δώσε μάρκα + πλήρες μοντέλο/σειρά ή έλεγξε το επίσημο service manual.\n")
            }else{
                unique.forEach{f->
                    o.append("• ${f.brand} ${f.code}: ${f.meaning}\n")
                    o.append("  Πιθανά: ${f.causes}\n")
                    o.append("  Έλεγχος: ${f.checks}\n")
                }
            }
        }else{
            o.append("• Αν υπάρχει error code, γράψ' τον ακριβώς μαζί με μάρκα και μοντέλο για στοχευμένη διαδρομή ελέγχου.\n")
        }

        o.append("\n8️⃣ ΓΝΩΣΗ ΑΝΑ ΜΑΡΚΑ\n")
        when{
            detectedBrand.equals("Daikin",true) -> o.append("• Daikin: δώσε ακριβή σειρά (Split/SkyAir/VRV/Altherma) και detail code π.χ. U0, U4, 7H-xx. Χρησιμοποιώ και την τοπική Daikin βάση της εφαρμογής.\n")
            detectedBrand.contains("Mitsubishi",true) -> o.append("• Mitsubishi: ξεχώρισε Electric/Heavy και ακριβή σειρά. Error LEDs/remote codes και thermistor tables διαφέρουν σημαντικά.\n")
            detectedBrand.equals("Fujitsu",true) || detectedBrand.equals("General",true) -> o.append("• Fujitsu/General: δώσε ακριβές pattern operation/timer LEDs ή wired-controller code και μοντέλο.\n")
            detectedBrand.equals("LG",true) -> o.append("• LG: δώσε CH code + αν είναι Multi/VRF/Therma V, γιατί η ερμηνεία αλλάζει ανά οικογένεια.\n")
            detectedBrand.equals("Midea",true) || detectedBrand.equals("Carrier",true) || detectedBrand.equals("Inventor",true) -> o.append("• Midea-platform μονάδες: χρειάζεται ακριβές OEM/model γιατί ίδιο chassis μπορεί να έχει διαφορετική mapping κωδικών.\n")
            detectedBrand.equals("Gree",true) || detectedBrand.equals("Toyotomi",true) -> o.append("• Gree-platform: χρειάζεται ακριβής σειρά/μοντέλο, ειδικά για inverter/IPM/temperature-sensor codes.\n")
            detectedBrand.isNotBlank() -> o.append("• Για $detectedBrand θα βασίσω τη διάγνωση σε μετρήσεις και στο service data της ακριβούς σειράς — όχι σε γενικό πίνακα κωδικών.\n")
            else -> o.append("• Γράψε μάρκα + μοντέλο για να περιοριστεί η διάγνωση στη σωστή οικογένεια εξοπλισμού.\n")
        }

        o.append("\n9️⃣ ΤΙ ΘΕΛΩ ΝΑ ΜΟΥ ΔΩΣΕΙΣ\n")
        o.append("• Μάρκα + πλήρες model indoor/outdoor.\n")
        o.append("• Ακριβή κωδικό και πότε εμφανίζεται.\n")
        o.append("• Mode, setpoint, εξωτερική/εσωτερική θερμοκρασία.\n")
        o.append("• Τάση και ρεύματα.\n")
        o.append("• Πιέσεις και θερμοκρασίες ή LWT/RWT/flow ανάλογα με το σύστημα.\n")
        if(measurements.isNotBlank()) o.append("• Μετρήσεις που έδωσες: $measurements\n")
        if(installation.isNotBlank()) o.append("• Εγκατάσταση: $installation\n")

        o.append("\n🔟 ΚΑΝΟΝΑΣ ΔΙΑΓΝΩΣΗΣ\n")
        o.append("Πρώτα απόδειξη με μέτρηση, μετά ανταλλακτικό. PCB, συμπιεστής, EEV, αισθητήρας ή ψυκτικό δεν καταδικάζονται μόνο από έναν κωδικό.")
        return o.toString()
    }

    private fun techLibrarySection(titleText:String,subtitle:String,body:String){
        val r=base()
        r.addView(title(titleText))
        r.addView(card(subtitle))
        body.split("\n\n").forEach{section->
            if(section.isNotBlank()) r.addView(card(section))
        }
        r.addView(button("← Τεχνική βιβλιοθήκη"){techScreen()},
            LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,10,0,34)})
        setContentView(scroll(r))
    }

    private fun refrigerationScreen(){
        val r=base()
        r.setPadding(8,6,8,10)
        r.addView(title("❄ Ψύξη & Ψυγεία"))

        // Exact visual grid approved by the user: 2 columns x 4 rows.
        // Each drawable already contains the photo + dark title band, so nothing is cropped
        // and there is no blank area under the cards.
        val sections=listOf(
            Pair("refrig_card_systems"){refrigerationSystemsScreen()},
            Pair("refrig_card_coldroom"){refrigerationTopicScreen("🚪 Ψυκτικοί Θάλαμοι",listOf("Κατασκευή & μόνωση","Εξατμιστές θαλάμων","Απόψυξη","Πόρτες & στεγανότητα","Συντήρηση & διάγνωση"))},
            Pair("refrig_card_fridges"){refrigerationTopicScreen("🏪 Επαγγελματικά Ψυγεία",listOf("Οικιακά ψυγεία","Βιτρίνες","Πάγκοι συντήρησης","Καταψύκτες","Bottle coolers","Ice makers"))},
            Pair("refrig_card_controls"){refrigerationTopicScreen("🎛 Ελεγκτές & Αυτοματισμοί",listOf("Θερμοστάτες","Αισθητήρες NTC/PTC","Defrost controllers","Πρεσοστάτες","Alarms & protections"))},
            Pair("refrig_card_pressure"){techScreen()},
            Pair("refrig_card_compressors"){refrigerationTopicScreen("🧊 Συμπιεστές",listOf("Hermetic","Semi-hermetic","Scroll","Reciprocating","Parallel racks","Λάδια & επιστροφή λαδιού"))},
            Pair("refrig_card_parts"){refrigerationTopicScreen("🔧 Εξαρτήματα Ψύξης",listOf("TXV / EEV","Solenoid","Receiver","Accumulator","Filter drier","Sight glass","Oil separator"))},
            Pair("refrig_card_theory"){refrigerationTopicScreen("📘 Θεωρία Ψύξης",listOf("Κύκλος συμπίεσης","Ενθαλπία","Superheat","Subcooling","Flash gas","Capacity & COP"))}
        )

        val grid=GridLayout(this).apply{
            columnCount=2
            rowCount=4
            useDefaultMargins=false
            alignmentMode=GridLayout.ALIGN_BOUNDS
            setPadding(0,0,0,0)
        }

        // Fit exactly to the current phone: 4 card rows consume the available
        // viewport under the header. No fixed px height => no empty half-screen.
        val dm=resources.displayMetrics
        val screenH=dm.heightPixels
        val topUi=(118f*dm.density).toInt()
        val available=(screenH-topUi).coerceAtLeast((520f*dm.density).toInt())
        val rowH=(available/4).coerceAtLeast((145f*dm.density).toInt())

        sections.forEachIndexed{index,item->
            val image=ImageView(this).apply{
                val id=resources.getIdentifier(item.first,"drawable",packageName)
                if(id!=0)setImageResource(id)
                // The approved card artwork has the same aspect throughout.
                // FIT_XY fills the allocated card without leaving blank strips.
                scaleType=ImageView.ScaleType.FIT_XY
                adjustViewBounds=false
                background=GradientDrawable().apply{
                    setColor(Color.WHITE);cornerRadius=18f
                }
                clipToOutline=true
                setOnClickListener{item.second()}
            }
            grid.addView(image,GridLayout.LayoutParams().apply{
                width=0
                height=rowH
                rowSpec=GridLayout.spec(index/2)
                columnSpec=GridLayout.spec(index%2,1f)
                setMargins(4,4,4,4)
            })
        }

        r.addView(grid,LinearLayout.LayoutParams(-1,-2))
        setContentView(scroll(r))
    }

    private fun refrigerationSystemsScreen(){
        val r=base()
        r.addView(title("❄ Συστήματα Ψύξης"))

        val items=listOf(
            Triple("Βασικός Κύκλος Συμπίεσης","Λειτουργία και βασικά σημεία του ψυκτικού κύκλου","refrig_sys_1"),
            Triple("Μονοβάθμια Συστήματα","Ανάλυση και λειτουργία μονοβάθμιων συστημάτων","refrig_sys_2"),
            Triple("Διβάθμια Συστήματα","Ανάλυση και λειτουργία διβάθμιων συστημάτων","refrig_sys_3"),
            Triple("Παράλληλα Συστήματα / Racks","Συνδυασμός συμπιεστών σε παράλληλη διάταξη","refrig_sys_4"),
            Triple("Καταρρακτά Συστήματα / Cascade","Δύο ανεξάρτητα ψυκτικά κυκλώματα","refrig_sys_5"),
            Triple("Συστήματα με Economizer","Αύξηση απόδοσης με ενδιάμεση έγχυση","refrig_sys_6"),
            Triple("Συστήματα CO₂ (R744)","Υψηλές πιέσεις • transcritical / subcritical","refrig_sys_7")
        )

        items.forEach{(name,desc,img)->
            r.addView(LinearLayout(this).apply{
                orientation=LinearLayout.HORIZONTAL
                gravity=Gravity.CENTER_VERTICAL
                setPadding(8,8,10,8)
                background=GradientDrawable().apply{
                    setColor(Color.WHITE);cornerRadius=16f;setStroke(1,Color.rgb(210,220,232))
                }
                val id=resources.getIdentifier(img,"drawable",packageName)
                addView(ImageView(this@MainActivity).apply{
                    if(id!=0)setImageResource(id)
                    scaleType=ImageView.ScaleType.CENTER_CROP
                    background=GradientDrawable().apply{setColor(Color.rgb(248,250,252));cornerRadius=12f}
                },LinearLayout.LayoutParams(118,82).apply{setMargins(0,0,12,0)})

                addView(LinearLayout(this@MainActivity).apply{
                    orientation=LinearLayout.VERTICAL
                    addView(TextView(this@MainActivity).apply{
                        text=name
                        textSize=15f
                        typeface=uiFont(true)
                        setTextColor(Color.rgb(8,40,80))
                    })
                    addView(TextView(this@MainActivity).apply{
                        text=desc
                        textSize=12.2f
                        maxLines=2
                        setTextColor(Color.rgb(75,85,98))
                        setPadding(0,4,0,0)
                    })
                },LinearLayout.LayoutParams(0,-2,1f))

                addView(TextView(this@MainActivity).apply{
                    text="›";textSize=28f;gravity=Gravity.CENTER;setTextColor(Color.rgb(0,100,180))
                },LinearLayout.LayoutParams(30,70))

                setOnClickListener{refrigerationArticleScreen(name)}
            },LinearLayout.LayoutParams(-1,102).apply{setMargins(0,0,0,8)})
        }

        r.addView(button("← Ψύξη & Ψυγεία"){refrigerationScreen()},LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,8,0,24)})
        setContentView(scroll(r))
    }

    private fun refrigerationTopicScreen(titleText:String,items:List<String>){
        val r=base()
        r.addView(title(titleText))
        items.forEachIndexed{index,name->
            r.addView(LinearLayout(this).apply{
                orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
                setPadding(16,13,12,13)
                background=GradientDrawable().apply{setColor(Color.WHITE);cornerRadius=16f;setStroke(1,Color.rgb(210,220,232))}
                addView(TextView(this@MainActivity).apply{
                    text=when{
                        "CO₂" in name -> "CO₂"
                        "Συμπ" in name || "Racks" in name -> "⚙"
                        "Απόψ" in name -> "♨"
                        else -> "❄"
                    }
                    textSize=22f;gravity=Gravity.CENTER;setTextColor(Color.rgb(0,105,185))
                },LinearLayout.LayoutParams(54,54))
                addView(LinearLayout(this@MainActivity).apply{
                    orientation=LinearLayout.VERTICAL
                    addView(TextView(this@MainActivity).apply{
                        text=name;textSize=16f;typeface=uiFont(true);setTextColor(Color.rgb(10,35,70))
                    })
                    addView(TextView(this@MainActivity).apply{
                        text=when{
                            "Βασικός" in name -> "Λειτουργία και βασικά σημεία του ψυκτικού κύκλου"
                            "Μονοβάθμια" in name -> "Ανάλυση και λειτουργία μονοβάθμιων συστημάτων"
                            "Διβάθμια" in name -> "Ανάλυση και λειτουργία διβάθμιων συστημάτων"
                            "Παράλληλα" in name -> "Συνδυασμός συμπιεστών σε παράλληλη διάταξη"
                            "Cascade" in name -> "Δύο ανεξάρτητα ψυκτικά κυκλώματα"
                            "Economizer" in name -> "Αύξηση απόδοσης με ενδιάμεση έγχυση / economizer"
                            "CO₂" in name -> "Υψηλές πιέσεις • transcritical/subcritical • R744"
                            else -> "Τεχνική ενότητα • διάγνωση • λειτουργία • έλεγχοι"
                        }
                        textSize=12.5f;setTextColor(Color.rgb(70,80,92));setPadding(0,4,0,0)
                    })
                },LinearLayout.LayoutParams(0,-2,1f))
                addView(TextView(this@MainActivity).apply{text="›";textSize=28f;setTextColor(Color.rgb(0,95,170))})
                setOnClickListener{refrigerationArticleScreen(name)}
            },LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,8)})
        }
        r.addView(button("← Ψύξη & Ψυγεία"){refrigerationScreen()})
        setContentView(scroll(r))
    }

    private fun refrigerationArticleScreen(name:String){
        val r=base()
        r.addView(title(name))
        val body=when{
            "Βασικός" in name -> "Ο βασικός κύκλος αποτελείται από συμπιεστή → συμπυκνωτή → εκτονωτικό στοιχείο → εξατμιστή.\\n\\nΣτη διάγνωση ελέγχουμε μαζί πιέσεις, θερμοκρασίες, superheat, subcooling, παροχή αέρα/νερού και ηλεκτρικά στοιχεία."
            "Μονοβάθμια" in name -> "Ένας βαθμός συμπίεσης από την πίεση αναρρόφησης στην πίεση κατάθλιψης. Η πιο συνηθισμένη διάταξη σε μικρή και μεσαία επαγγελματική ψύξη."
            "Διβάθμια" in name -> "Η συμπίεση χωρίζεται σε δύο στάδια για εφαρμογές με μεγάλη διαφορά πιέσεων/θερμοκρασιών. Απαιτεί σωστό έλεγχο ενδιάμεσης πίεσης και θερμοκρασίας κατάθλιψης."
            "Παράλληλα" in name -> "Δύο ή περισσότεροι συμπιεστές λειτουργούν σε κοινές γραμμές αναρρόφησης/κατάθλιψης. Χρειάζεται ιδιαίτερη προσοχή στην επιστροφή και εξισορρόπηση λαδιού."
            "Cascade" in name -> "Δύο ανεξάρτητα ψυκτικά κυκλώματα συνδέονται θερμικά μέσω cascade heat exchanger. Χρησιμοποιείται σε πολύ χαμηλές θερμοκρασίες."
            "Economizer" in name -> "Ο economizer/intermediate injection μπορεί να βελτιώσει capacity και απόδοση, ιδιαίτερα σε υψηλά compression ratios."
            "CO₂" in name -> "Το R744/CO₂ λειτουργεί σε πολύ υψηλότερες πιέσεις από τα συμβατικά ψυκτικά. Απαιτούνται εξαρτήματα, όργανα και διαδικασίες ειδικά σχεδιασμένα για CO₂."
            else -> "Η ενότητα αυτή οργανώνεται για πρακτική χρήση πεδίου: λειτουργία, βασικά εξαρτήματα, μετρήσεις, συχνές βλάβες και έλεγχοι."
        }
        body.split("\\n\\n").forEach{r.addView(card(it))}
        r.addView(button("← Πίσω"){goBackHistory()})
        setContentView(scroll(r))
    }

    private fun techScreen(){
        val r=base()
        r.addView(title("📚 Τεχνική βιβλιοθήκη"))
        r.addView(card("Αναλυτικοί τεχνικοί οδηγοί για ψύξη, κλιματισμό, VRV/VRF και αντλίες θερμότητας."))

        val sections=listOf<Triple<String,String,()->Unit>>(
            Triple("❄️ Ψυκτικά μέσα","R32 • R410A • R407C • R134a • R290"){
                techLibrarySection(
                    "❄️ Ψυκτικά μέσα",
                    "Βασικά χαρακτηριστικά, φόρτιση και ασφάλεια.",
                    "R32\n• Ψυκτικό μονού συστατικού.\n• Χρησιμοποιείται ευρέως σε σύγχρονα split και αντλίες θερμότητας.\n• Κατηγορία ασφάλειας A2L: χαμηλή τοξικότητα, ήπια ευφλεκτότητα.\n• Φόρτιση κατά κανόνα σε υγρή φάση με ζυγαριά και σύμφωνα με το manual.\n\nR410A\n• Μίγμα υψηλής πίεσης.\n• Χρησιμοποιείται σε παλαιότερα και αρκετά επαγγελματικά συστήματα.\n• Δεν αναμιγνύεται με R32 ή άλλο ψυκτικό.\n• Πάντα έλεγχος με πιέσεις + θερμοκρασίες και όχι μόνο από ένδειξη μανόμετρου.\n\nR407C\n• Ζεοτροπικό μίγμα με temperature glide.\n• Η φόρτιση γίνεται σε υγρή φάση ώστε να μη μεταβάλλεται η σύσταση του μίγματος.\n\nR134a\n• Χρησιμοποιείται σε ψύξη, chillers και ειδικές εφαρμογές.\n• Χαμηλότερες πιέσεις σε σχέση με R410A/R32.\n\nR290\n• Προπάνιο, πολύ χαμηλού GWP.\n• Κατηγορία A3: υψηλή ευφλεκτότητα.\n• Απαιτεί αυστηρή τήρηση διαδικασιών ασφαλείας και εργαλείων κατάλληλων για εύφλεκτα ψυκτικά."
                )
            },
            Triple("🌡 Superheat & Subcooling","Υπολογισμός • ερμηνεία • διάγνωση"){
                techLibrarySection(
                    "🌡 Superheat & Subcooling",
                    "Πώς διαβάζεις σωστά το ψυκτικό κύκλωμα.",
                    "SUPERHEAT\nSuperheat = θερμοκρασία σωλήνα αναρρόφησης − θερμοκρασία κορεσμού στην πίεση αναρρόφησης.\n\nΥψηλό superheat μπορεί να δείχνει:\n• χαμηλή φόρτιση,\n• περιορισμό,\n• χαμηλή τροφοδότηση εξατμιστή,\n• χαμηλή παροχή ψυκτικού.\n\nΧαμηλό superheat μπορεί να δείχνει:\n• υπερτροφοδότηση εξατμιστή,\n• ανεπαρκή εξάτμιση,\n• κίνδυνο επιστροφής υγρού.\n\nSUBCOOLING\nSubcooling = θερμοκρασία κορεσμού στην υψηλή − θερμοκρασία υγρής γραμμής.\n\nΥψηλό subcooling μπορεί να σχετίζεται με αυξημένη ποσότητα υγρού στον συμπυκνωτή ή περιορισμό.\n\nΧαμηλό subcooling μπορεί να σχετίζεται με χαμηλή φόρτιση ή ανεπαρκή στήλη υγρού.\n\nΚανόνας: ποτέ διάγνωση μόνο από SH ή SC. Συνδύασέ τα με airflow/waterflow, θερμοκρασίες, πιέσεις και προδιαγραφές κατασκευαστή."
                )
            },
            Triple("🧪 Vacuum & αφύγρανση","Micron • standing test • σωστή διαδικασία"){
                techLibrarySection(
                    "🧪 Vacuum & αφύγρανση",
                    "Ο στόχος δεν είναι μόνο χαμηλή πίεση αλλά και στεγνό, στεγανό κύκλωμα.",
                    "ΒΑΣΙΚΗ ΔΙΑΔΙΚΑΣΙΑ\n• Σωστό pressure test πριν το vacuum.\n• Χρήση vacuum pump σε καλή κατάσταση.\n• Ιδανικά αφαίρεση Schrader cores και χρήση χοντρών σωλήνων κενού.\n• Μέτρηση με micron gauge στο σύστημα και όχι πάνω στην αντλία.\n\nMICRON\n• Όσο μικρότερη τιμή, τόσο βαθύτερο το κενό.\n• Η τιμή πρέπει να σταθεροποιείται και όχι απλώς να πέσει στιγμιαία.\n\nSTANDING TEST\nΑπομόνωσε την αντλία και παρακολούθησε την άνοδο.\n• Γρήγορη και συνεχής άνοδος μπορεί να δείχνει διαρροή.\n• Άνοδος που επιβραδύνεται μπορεί να σχετίζεται με υγρασία/απαέρωση.\n\nΠάντα ακολούθησε την απαίτηση micron και τον χρόνο σταθεροποίησης του κατασκευαστή."
                )
            },
            Triple("🔍 Έλεγχος διαρροών","Άζωτο • ηλεκτρονικός ανιχνευτής • σαπουνάδα"){
                techLibrarySection(
                    "🔍 Έλεγχος διαρροών",
                    "Σειρά ελέγχου για πιο αξιόπιστο εντοπισμό.",
                    "1. Οπτικός έλεγχος\n• λάδια σε ρακόρ,\n• βαλβίδες,\n• κολλήσεις,\n• heat exchangers.\n\n2. Pressure test με άζωτο\n• πίεση μόνο εντός ορίων κατασκευαστή.\n• ποτέ οξυγόνο ή πεπιεσμένος αέρας.\n\n3. Ηλεκτρονικός ανιχνευτής\n• αργή κίνηση γύρω από πιθανά σημεία.\n• αποφυγή ρευμάτων αέρα.\n\n4. Αφρώδες διάλυμα\n• χρήσιμο για επιβεβαίωση συγκεκριμένου σημείου.\n\n5. Μετά την επισκευή\n• επανάληψη pressure test,\n• vacuum,\n• standing test,\n• σωστή φόρτιση."
                )
            },
            Triple("⚡ Ηλεκτρολογικοί έλεγχοι","Τάση • ρεύμα • αντίσταση • μόνωση"){
                techLibrarySection(
                    "⚡ Ηλεκτρολογικοί έλεγχοι",
                    "Βασική σειρά ελέγχου πριν κατηγορήσεις πλακέτα ή συμπιεστή.",
                    "ΤΡΟΦΟΔΟΣΙΑ\n• Μέτρησε τάση χωρίς φορτίο και με φορτίο.\n• Έλεγξε πτώση τάσης και σφίξιμο ακροδεκτών.\n\nΡΕΥΜΑ\n• Σύγκρινε με ονομαστικό ρεύμα/τεχνικά στοιχεία.\n• Υψηλό ρεύμα χωρίς σωστή ψύξη μπορεί να δείχνει μηχανικό ή ψυκτικό πρόβλημα.\n\nΑΝΤΙΣΤΑΣΕΙΣ\n• Έλεγξε τυλίγματα μοτέρ/συμπιεστή όπου επιτρέπεται.\n• Έλεγξε θερμίστορ με βάση πίνακα αντίστασης-θερμοκρασίας του κατασκευαστή.\n\nΜΟΝΩΣΗ\n• Έλεγχος προς γη μόνο με κατάλληλη διαδικασία και αφού προστατευθούν ηλεκτρονικά μέρη που δεν πρέπει να δεχθούν megger."
                )
            },
            Triple("🧠 Inverter & αισθητήρες","IPM • DC bus • thermistors • προστασίες"){
                techLibrarySection(
                    "🧠 Inverter & αισθητήρες",
                    "Πρακτική λογική ελέγχου πριν την αντικατάσταση πλακέτας.",
                    "INVERTER\n• Έλεγξε πρώτα τροφοδοσία AC.\n• Έλεγξε ασφάλειες, φίλτρα, συνδέσεις και οπτικά σημάδια καύσης.\n• Το DC bus μπορεί να διατηρεί επικίνδυνη τάση μετά την αποσύνδεση: απαιτείται ασφαλής διαδικασία.\n\nIPM / COMPRESSOR DRIVE\n• Fault IPM δεν σημαίνει πάντα καμένη πλακέτα.\n• Έλεγξε συμπιεστή, μόνωση, καλωδίωση, ψύξη πλακέτας και τάση τροφοδοσίας.\n\nTHERMISTORS\n• Μέτρηση αντίστασης σε γνωστή θερμοκρασία.\n• Σύγκριση με επίσημο πίνακα του συγκεκριμένου μοντέλου.\n• Ανοιχτό κύκλωμα ή σχεδόν 0 Ω συνήθως υποδεικνύει βλάβη αισθητήρα/καλωδίωσης."
                )
            },
            Triple("🔧 Σωληνώσεις & εγκατάσταση","Διατομές • flare • μήκη • λάδι"){
                techLibrarySection(
                    "🔧 Σωληνώσεις & εγκατάσταση",
                    "Βασικά σημεία που επηρεάζουν άμεσα την αξιοπιστία.",
                    "ΔΙΑΤΟΜΕΣ\n• Πάντα οι διατομές που ορίζει ο κατασκευαστής για το συγκεκριμένο μοντέλο.\n• Λάθος διάμετρος επηρεάζει πτώση πίεσης, επιστροφή λαδιού και απόδοση.\n\nFLARE\n• Καθαρή κοπή,\n• σωστή αφαίρεση γρεζιών,\n• σωστή προεξοχή,\n• σωστή ροπή με torque wrench.\n\nΜΗΚΗ / ΥΨΟΜΕΤΡΙΚΗ\n• Έλεγξε μέγιστο συνολικό μήκος, μέγιστη υψομετρική και μήκος χωρίς πρόσθετη φόρτιση.\n\nΛΑΔΙ\n• Σε μεγάλα δίκτυα και VRV/VRF είναι κρίσιμη η επιστροφή λαδιού και η σωστή σχεδίαση σύμφωνα με το manual."
                )
            },
            Triple("🏢 VRV / VRF","Επικοινωνία • διευθύνσεις • branch • oil return"){
                techLibrarySection(
                    "🏢 VRV / VRF",
                    "Βασικές αρχές διάγνωσης μεγάλων πολυδιαιρούμενων συστημάτων.",
                    "ΕΠΙΚΟΙΝΩΝΙΑ\n• Έλεγξε πολικότητα/συνδεσμολογία όπου απαιτείται.\n• Έλεγξε τάση bus και ποιότητα συνδέσεων.\n• Ένα πρόβλημα σε μία μονάδα μπορεί να επηρεάζει όλο το δίκτυο.\n\nΔΙΕΥΘΥΝΣΕΙΣ / AUTO ADDRESS\n• Μετά από αλλαγή πλακέτας ή επέμβαση στο δίκτυο μπορεί να απαιτείται νέα διαδικασία addressing.\n\nBRANCH / BS BOX\n• Έλεγξε σωστή φορά και διατομές.\n• Σε heat recovery συστήματα, οι branch selector boxes είναι βασικό σημείο ελέγχου.\n\nOIL RETURN\n• Η σωστή σωλήνωση και τα όρια μήκους/ύψους είναι κρίσιμα για επιστροφή λαδιού."
                )
            },
            Triple("🔥 Αντλίες θερμότητας","Νερά • ΔT • flow • defrost • backup heater"){
                techLibrarySection(
                    "🔥 Αντλίες θερμότητας",
                    "Γρήγορη τεχνική βάση για air-to-water συστήματα.",
                    "ΥΔΡΑΥΛΙΚΟ ΚΥΚΛΩΜΑ\n• Έλεγξε παροχή νερού και φίλτρα.\n• Έλεγξε εξαέρωση.\n• Έλεγξε κυκλοφορητή, βάνες και by-pass.\n\nΔT ΝΕΡΟΥ\n• Πολύ μεγάλο ΔT μπορεί να δείχνει χαμηλή παροχή.\n• Πολύ μικρό ΔT μπορεί να δείχνει υψηλή παροχή ή χαμηλό φορτίο.\n\nDEFROST\n• Επηρεάζεται από εξωτερική θερμοκρασία/υγρασία, αισθητήρες και airflow στην εξωτερική μονάδα.\n\nBACKUP / BOOSTER HEATER\n• Έλεγξε εντολή, ασφάλειες, contactors και πραγματική κατανάλωση πριν θεωρήσεις ότι λειτουργεί."
                )
            },
            Triple("💧 Υδραυλικά / Fan Coil","Flow • balancing • buffer • κυκλοφορητές"){
                techLibrarySection(
                    "💧 Υδραυλικά / Fan Coil",
                    "Βασικά για σωστή διανομή νερού.",
                    "FLOW\n• Χωρίς σωστή παροχή νερού δεν μπορεί να γίνει σωστή διάγνωση της αντλίας θερμότητας.\n\nBUFFER\n• Χρησιμοποιείται για υδραυλική σταθερότητα/όγκο νερού ανάλογα με τη μελέτη.\n• Λάθος σύνδεση primary/secondary μπορεί να δημιουργεί ανεπιθύμητη ανάμιξη.\n\nΚΥΚΛΟΦΟΡΗΤΕΣ\n• Έλεγξε φορά, στροφές, μανομετρικό και αν υπάρχει πραγματική κυκλοφορία.\n\nFAN COIL\n• Έλεγξε θερμοκρασίες προσαγωγής/επιστροφής, βαλβίδα, φίλτρο και ταχύτητα ανεμιστήρα."
                )
            },
            Triple("🧰 Συμπιεστές & εκτόνωση","Compressor • EEV • capillary • 4-way valve"){
                techLibrarySection(
                    "🧰 Συμπιεστές & εκτόνωση",
                    "Βασική λογική ελέγχου βασικών εξαρτημάτων.",
                    "ΣΥΜΠΙΕΣΤΗΣ\n• Έλεγξε τροφοδοσία, ρεύμα, πιέσεις και θερμοκρασίες.\n• Μηχανική βλάβη δεν αποδεικνύεται μόνο από έναν κωδικό.\n\nEEV\n• Έλεγξε πηνίο, βήματα/εντολές όπου υποστηρίζεται και μεταβολή πιέσεων/θερμοκρασιών.\n\nCAPILLARY / RESTRICTION\n• Περιορισμός μπορεί να προκαλεί χαμηλή αναρρόφηση, υψηλό superheat και πάγο πριν από το σημείο περιορισμού.\n\n4-WAY VALVE\n• Έλεγξε πηνίο, εντολή και πραγματική αλλαγή θερμοκρασιών σωληνώσεων."
                )
            }
        )

        sections.forEach{(name,sub,action)->
            val box=LinearLayout(this).apply{
                orientation=LinearLayout.VERTICAL
                setPadding(16,14,16,14)
                background=GradientDrawable().apply{
                    setColor(Color.rgb(4,38,73))
                    cornerRadius=22f
                    setStroke(1,Color.rgb(0,119,203))
                }
                elevation=3f
                addView(TextView(this@MainActivity).apply{
                    text=name;textSize=17f;typeface=uiFont(true);setTextColor(Color.WHITE)
                })
                addView(TextView(this@MainActivity).apply{
                    text=sub;textSize=11.5f;setTextColor(Color.rgb(160,205,235));setPadding(0,4,0,0)
                })
                setOnClickListener{action()}
            }
            r.addView(box,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,9)})
        }

        r.addView(button("← Πίσω"){home()},
            LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,10,0,34)})
        setContentView(scroll(r))
    }


    private fun notes():MutableList<Note>{val a=jsonArray("notes");return MutableList(a.length()){i->val o=a.getJSONObject(i);Note(o.getLong("id"),o.optString("title"),o.optString("text"))}}
    private fun saveNotes(x:List<Note>){val a=JSONArray();x.forEach{a.put(JSONObject().apply{put("id",it.id);put("title",it.title);put("text",it.text)})};prefs.edit().putString("notes",a.toString()).apply()}
    private fun notesScreen(){val r=base();r.addView(title("📝 Σημειώσεις"));val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};notes().forEach{n->list.addView(card("📌 ${n.title}\n${n.text}"){noteEditor(n)})};r.addView(scroll(list),LinearLayout.LayoutParams(-1,0,1f));r.addView(button("＋ Νέα σημείωση"){noteEditor(null)});r.addView(button("← Πίσω"){home()},
            LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,10,0,34)});setContentView(r)}
    private fun noteEditor(e:Note?){
        val r=base();r.addView(title("📝 Σημείωση"))
        val t=input("Τίτλος")
        val x=input("Κείμενο")
        val existingId=e?.id
        e?.let{t.setText(it.title);x.setText(it.text)}
        r.addView(t);r.addView(x)
        r.addView(button("💾 Αποθήκευση"){
            val d=notes();val id=existingId?:System.currentTimeMillis();val n=Note(id,t.text.toString(),x.text.toString());val i=d.indexOfFirst{it.id==id};if(i>=0)d[i]=n else d.add(n);saveNotes(d);notesScreen()
        })
        if(existingId!=null)r.addView(button("🗑 Διαγραφή"){saveNotes(notes().filter{it.id!=existingId});notesScreen()})
        r.addView(button("← Πίσω"){notesScreen()},
            LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,10,0,34)});setContentView(r)
    }
    private data class Material(val id:Long,val name:String,val code:String,val qty:String,val price:String,val notes:String)
    private fun materialList():MutableList<Material>{val a=jsonArray("materials");return MutableList(a.length()){i->val o=a.getJSONObject(i);Material(o.getLong("id"),o.optString("name"),o.optString("code"),o.optString("qty"),o.optString("price"),o.optString("notes"))}}
    private fun saveMaterialList(x:List<Material>){val a=JSONArray();x.forEach{m->a.put(JSONObject().apply{put("id",m.id);put("name",m.name);put("code",m.code);put("qty",m.qty);put("price",m.price);put("notes",m.notes)})};prefs.edit().putString("materials",a.toString()).apply()}
    private fun materialsScreen(){val r=base();r.addView(title("📦 Υλικά / Αποθήκη"));val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};val data=materialList();if(data.isEmpty())list.addView(card("Δεν υπάρχουν υλικά. Πρόσθεσε τα βασικά ανταλλακτικά και αναλώσιμα που χρησιμοποιείς."));data.forEach{m->list.addView(card("🔩 ${m.name}\nΚωδικός: ${m.code}\nΠοσότητα: ${m.qty} • Τιμή: €${m.price}\n${m.notes}"){materialEditor(m)})};r.addView(scroll(list),LinearLayout.LayoutParams(-1,0,1f));r.addView(button("＋ Νέο υλικό"){materialEditor(null)});r.addView(button("← Πίσω"){home()},
            LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,10,0,34)});setContentView(r)}
    private fun materialEditor(e:Material?){val r=base();r.addView(title(if(e==null)"＋ Νέο υλικό" else "✏️ Υλικό"));val n=input("Όνομα υλικού");val c=input("Κωδικός / Part Number");val q=input("Ποσότητα");val pr=input("Τιμή (€)");val no=input("Σημειώσεις");e?.let{n.setText(it.name);c.setText(it.code);q.setText(it.qty);pr.setText(it.price);no.setText(it.notes)};listOf(n,c,q,pr,no).forEach{r.addView(it)};r.addView(button("💾 Αποθήκευση"){if(n.text.isBlank()){toast("Συμπλήρωσε όνομα.");return@button};val d=materialList();val id=e?.id?:System.currentTimeMillis();val m=Material(id,n.text.toString(),c.text.toString(),q.text.toString(),pr.text.toString(),no.text.toString());val i=d.indexOfFirst{it.id==id};if(i>=0)d[i]=m else d.add(m);saveMaterialList(d);materialsScreen()});if(e!=null)r.addView(button("🗑 Διαγραφή"){saveMaterialList(materialList().filter{it.id!=e.id});materialsScreen()});r.addView(button("← Πίσω"){materialsScreen()},
            LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,10,0,34)});setContentView(r)}
    private fun backupJson(): JSONObject {
        val keys=listOf("customers","machines","jobs","notes","materials")
        return JSONObject().apply {
            put("app", "Psyktikos")
            put("version", "1.1")
            put("createdAt", System.currentTimeMillis())
            keys.forEach { k -> put(k, JSONArray(prefs.getString(k,"[]"))) }
        }
    }

    private fun backupScreen(){
        val r=base(); r.addView(title("💾 Backup / Επαναφορά"))
        r.addView(TextView(this).apply{
            text="Στο v1.0 μπορείς να εξάγεις όλα τα βασικά δεδομένα της εφαρμογής σε αρχείο JSON και να τα επαναφέρεις αργότερα. Τα δεδομένα παραμένουν τοπικά στη συσκευή."
            textSize=16f; setPadding(0,0,0,16)
        })
        r.addView(button("📤 Εξαγωγή backup JSON"){
            val i=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{
                addCategory(Intent.CATEGORY_OPENABLE); type="application/json"; putExtra(Intent.EXTRA_TITLE,"Psyktikos_backup_v1.0.json")
            }; startActivityForResult(i,BACKUP_EXPORT)
        })
        r.addView(button("📥 Επαναφορά από backup JSON"){
            val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{
                addCategory(Intent.CATEGORY_OPENABLE); type="application/json"
            }; startActivityForResult(i,BACKUP_IMPORT)
        })
        r.addView(button("👁 Προβολή backup"){
            val v=EditText(this).apply{setText(backupJson().toString(2));textSize=12f;minLines=12;isVerticalScrollBarEnabled=true}
            r.addView(v,2); toast("Το backup είναι έτοιμο.")
        })
        r.addView(button("🧹 Καθαρισμός όλων των δεδομένων"){
            AlertDialog.Builder(this).setTitle("Προσοχή").setMessage("Θα διαγραφούν πελάτες, μηχανήματα, εργασίες, σημειώσεις και υλικά.")
                .setNegativeButton("Ακύρωση",null).setPositiveButton("Διαγραφή"){_,_->prefs.edit().clear().apply();home()}.show()
        })
        r.addView(button("← Πίσω"){home()},
            LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,10,0,34)}); setContentView(r)
    }

}
