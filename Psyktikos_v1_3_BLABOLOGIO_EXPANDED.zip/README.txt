Psyktikos v1.3 - Expanded Blavologio

- 36 brands in alphabetical logo grid.
- Brand -> equipment type -> faults.
- Added verified LG and GREE codes from official manufacturer support sources.
- More categories prepared for continued manual-by-manual expansion.
- Signing is handled by the existing permanent GitHub workflow/keystore; do not replace the signing key.
